package fr.inria.spirals.fm.loader.xtext
import fr.inria.spirals.fm.model.FeatureModel
/**
 * Created by gustavo on 09/06/15.
 */
class XtextLoaderTests extends GroovyTestCase {
    public static FeatureModel loadOpenShift() {
        XtextLoader loader = new XtextLoader()
        loader.loadFeatureModel(getClass().getResource('/OpenShift.fm'))
    }

    static URL getURLFromContent(String content) {
        File temp = File.createTempFile("validator", ".fm")
        temp.text = content
        temp.toURI().toURL()
    }

    static FeatureModel loadFm(String content) {
        XtextLoader.INSTANCE.loadFeatureModel(getURLFromContent(content))
    }


    void testLoadModel() {
        FeatureModel fm = loadOpenShift()

        assertEquals 'OpenShift', fm.root.name

        def featureNames = fm.features*.name
        println featureNames
        assertTrue featureNames.containsAll(['OpenShift', 'Free', 'Tomcat7', 'DoItYourself'])
        assertEquals 8, fm.constraints.size()

        println fm
    }

    void testLoadModelWithCardinalities() {
        FeatureModel fm = loadOpenShift()

        fm.declared.each { println it }

        def free = fm.getFeature('Free')
        assertEquals 1..1, free.getLocalCardinality()
    }





    void testLoadConfig() {
        def config = new XtextLoader().loadConfiguration(getClass().getResource('/configFm1.fm'))
        assertNotNull config.featureModel.root.name

        config.instances.each { println it.feature.name }
    }
}
