package fr.inria.spirals.fm.config

import fr.inria.spirals.fm.loader.xtext.XtextLoader

/**
 * Created by gustavo on 16/06/15.
 */
class ConfigurationTests extends GroovyTestCase {
    public void testLoadAndCheck() {
        def config = new XtextLoader().loadConfiguration(getClass().getResource('/ConfigRoot2.fm'))

        assertTrue config.isComplete()

    }

    public void testLoadAndCheck2() {
        def config = new XtextLoader().loadConfiguration(getClass().getResource('/configFm1.fm'))

        assertFalse config.isComplete()

    }
}
