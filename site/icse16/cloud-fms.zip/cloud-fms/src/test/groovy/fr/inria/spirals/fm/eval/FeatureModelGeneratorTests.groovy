package fr.inria.spirals.fm.eval

/**
 * Created by gustavo on 20/08/15.
 */
class FeatureModelGeneratorTests extends GroovyTestCase {
    void testMaxDepth() {
        def generator = new FeatureModelGenerator(maxDepth: 10)

        def fm = generator.generate(100)
        assertTrue fm.depth <= 10
    }

    void testNumFeats() {
        def generator = new FeatureModelGenerator(maxDepth: 100)

        def fm = generator.generate(100)
        assertEquals 100, fm.features.size()
    }

    void testMaxCardinality() {
        def generator = new FeatureModelGenerator(maxDepth: 100, probCardOther: 100, probCardUpper: 100, maxCard: 2)

        def fm = generator.generate(100)
        assertTrue fm.features.every { it.localCardinality.max <= 2 }
        assertTrue fm.features.any { it.localCardinality.max > 1 }
    }

    void testCardinality1() {
        def generator = new FeatureModelGenerator(maxDepth: 100, probCardOther: 100, probCardUpper: 100)

        def fm = generator.generate(100)
        def stats = new FeatureModelStats(fm)
        assertEquals 99, stats.numberOfFeaturesWithCardinalities
    }

    void testCardinality2() {
        def generator = new FeatureModelGenerator(maxDepth: 100, probCardOther: 0, probCardUpper: 0)

        def fm = generator.generate(100)
        def stats = new FeatureModelStats(fm)
        assertEquals 0, stats.numberOfFeaturesWithCardinalities
    }

    void testCardinality3() {
        def generator = new FeatureModelGenerator(maxDepth: 100, probCardOther: 0, probCardUpper: 50)

        def fm = generator.generate(100)
        def upperFeats = fm.features.findAll { it.depth <= 2 }
        def upperWithCard = upperFeats.findAll { it.localCardinality.max > 1 }
        assertTrue upperWithCard.size() < upperFeats.size()
    }
}
