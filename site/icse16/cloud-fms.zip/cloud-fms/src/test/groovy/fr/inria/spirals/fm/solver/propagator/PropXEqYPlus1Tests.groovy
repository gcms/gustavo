package fr.inria.spirals.fm.solver.propagator

import fr.inria.spirals.fm.solver.propagator.PropXEqYPlus1
import org.chocosolver.solver.Solver
import org.chocosolver.solver.constraints.Constraint
import org.chocosolver.solver.variables.BoolVar
import org.chocosolver.solver.variables.VF
/**
 * Created by gustavo on 17/07/15.
 */
class PropXEqYPlus1Tests extends GroovyTestCase {
    void testMyProp() {
        Solver solver = new Solver()
        def v1 = VF.bounded("v1", 0, 5, solver)
        def v1m1 = VF.bounded("v1-1", 0, 4, solver)
        solver.post(new Constraint("Cstr", new PropXEqYPlus1(v1, v1m1)))

        assertEquals 6, solver.findAllSolutions()
//        if (solver.findSolution())
//            while (true) {
//                println solver.getVars()
//                if (!solver.nextSolution())
//                    break
//            }
    }

    void testMyProp2() {
        Solver solver = new Solver()
        def v1 = VF.bounded("v1", 1, 1, solver)
        def v1m1 = VF.bounded("v1-1", 0, 0, solver)
        solver.post(new Constraint("Cstr", new PropXEqYPlus1(v1, v1m1)))

        assertEquals 1, solver.findAllSolutions()
//        if (solver.findSolution())
//            while (true) {
//                println solver.getVars()
//                if (!solver.nextSolution())
//                    break
//            }
    }

    void testMyProp3() {
        Solver solver = new Solver()
        def v1 = VF.bounded("v1", 0, 0, solver)
        def v1m1 = VF.bounded("v1-1", 0, 0, solver)
        solver.post(new Constraint("Cstr", new PropXEqYPlus1(v1, v1m1)))

        assertEquals 1, solver.findAllSolutions()
    }
}
