package fr.inria.spirals.fm.solver.propagator

import fr.inria.spirals.fm.loader.xtext.XtextLoader
import fr.inria.spirals.fm.solver.SolverFactory
import org.chocosolver.solver.Solver
import org.chocosolver.solver.constraints.Constraint
import org.chocosolver.solver.constraints.ICF
import org.chocosolver.solver.variables.IntVar
import org.chocosolver.solver.variables.VF

/**
 * Created by gustavo on 17/07/15.
 */
class PropArrayTests extends GroovyTestCase {
    void testMyProp() {
        Solver solver = new Solver()
        IntVar size = VF.bounded("v1", 0, 10, solver)
        IntVar[] is = VF.boundedArray('i', 10, 0, 1, solver)

        solver.post(new Constraint("Cstr", new PropArray(size, is)))

        assertEquals 11, solver.findAllSolutions()

        solver.solutionRecorder.solutions.each {
            println it
        }
    }

    void testMyProp2() {
        for (int i = 0; i < 10; i++) {
            Map assign = [:]
            assign.put(i, 1)
            Solver solver = buildSolver(assign)
            assertEquals 10 - i, solver.findAllSolutions()
        }
    }

    Solver buildSolver(Map<Integer, Integer> assign) {
        Solver solver = new Solver()
        IntVar size = VF.bounded("v1", 0, 10, solver)
        IntVar[] is = VF.boundedArray('i', 10, 0, 1, solver)

        solver.post(new Constraint("Cstr", new PropArray(size, is)))

        assign.each { int idx, int val ->
            solver.post(ICF.arithm(is[idx], "=", val))
        }

        solver
    }

    void testRealCase() {
        def fm = XtextLoader.INSTANCE.loadFeatureModel(getClass().getResource('/MultipleRelativeCardinalitiesFM.fm'))

        def sf = new SolverFactory().createSolver(fm)
        assertEquals 131, sf.numSolutions
    }
}
