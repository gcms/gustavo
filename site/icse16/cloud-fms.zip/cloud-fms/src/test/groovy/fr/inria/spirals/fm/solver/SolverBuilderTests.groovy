package fr.inria.spirals.fm.solver
import fr.inria.spirals.fm.CardinalityInferrer
import fr.inria.spirals.fm.Configuration
import fr.inria.spirals.fm.loader.xtext.XtextLoader
import fr.inria.spirals.fm.model.FeatureModel
import org.chocosolver.solver.trace.Chatterbox
/**
 * Created by gustavo on 10/06/15.
 */
class SolverBuilderTests extends GroovyTestCase {
    void testBasic() {
        def fm = XtextLoader.INSTANCE.loadFeatureModel(getClass().getResource('/SimpleCardinalitiesFM.fm'))

        def sf = new SolverFactory().createSolver(fm)
//        println "Num vars: ${sf.variables.size()}"
//        sf.variables.each { println it }
//        println "Num cstrs: ${sf.solver.getNbCstrs()}"
//        sf.constraints.each { println it }

        assertEquals 42, sf.numSolutions
//
//        sf.getSolutions().eachWithIndex { sol, idx ->
//            println "${idx+1}" + sol
//        }


//
//        long start = System.currentTimeMillis()
//        println 'Solving...'
//        println sf.numSolutions
//        long end = System.currentTimeMillis()
//
//        System.out.println((end - start) / 1000.0)
    }

    void testBasic2() {
        def fm = XtextLoader.INSTANCE.loadFeatureModel(getClass().getResource('/teste.fm'))

        def sf = new SolverFactory().createSolver(fm)
        assertEquals 4, sf.numSolutions
    }

    void testRelative() {
        def fm = XtextLoader.INSTANCE.loadFeatureModel(getClass().getResource('/RelativeCardinalitiesFM.fm'))

        def sf = new SolverFactory().createSolver(fm)
        println sf.numSolutions

        sf.getSolutions().eachWithIndex { sol, idx ->
            def instances = sol.getInstancesOf(fm.getFeature('c'))
            assertTrue instances.size() <= 6
//            println "${idx+1}" + sol
        }
    }

    void testRelative2() {
        def fm = XtextLoader.INSTANCE.loadFeatureModel(getClass().getResource('/MultipleRelativeCardinalitiesFM.fm'))

        def sf = new SolverFactory().createSolver(fm)
        println sf.numSolutions

        def solutions = sf.getSolutions()

        solutions.eachWithIndex { sol, idx ->
            def instances = sol.getInstancesOf(fm.getFeature('c'))
            assertTrue instances.size() <= 5
//            println "${idx+1}" + sol
        }

        (1..5).each { int it ->
            assertTrue solutions.any { sol ->
                println "${it} ${sol}"
                sol.getInstancesOf(fm.getFeature('c')).size() == it
            }
        }

    }

    void testRelative3() {
        def fm = XtextLoader.INSTANCE.loadFeatureModel(getClass().getResource('/MultipleRelativeCardinalitiesFM2.fm'))

        def sf = new SolverFactory().createSolver(fm)
        println sf.numSolutions

        def solutions = sf.getSolutions()

        solutions.eachWithIndex { sol, idx ->
            def instances = sol.getInstancesOf(fm.getFeature('c'))
            assertTrue instances.size() <= 5

            def instances2 = sol.getInstancesOf(fm.getFeature('b'))
            assertTrue instances2.size() <= 3
        }

        1..5.each {
            assertTrue solutions.any { sol ->
                sol.getInstancesOf(fm.getFeature('c')).size() == it
            }
        }

        1..3.each {
            assertTrue solutions.any { sol ->
                sol.getInstancesOf(fm.getFeature('b')).size() == it
            }
        }
    }

    void testWithSimpleConstraints() {
        def fm = XtextLoader.INSTANCE.loadFeatureModel(getClass().getResource('/SimpleFMWithConstraints.fm'))

        def sf = new SolverFactory().createSolver(fm)
//        println "Num vars: ${sf.variables.size()}"
//        sf.variables.each { println it }
//        println "Num cstrs: ${sf.solver.getNbCstrs()}"
//        sf.constraints.each { println it }

        assertEquals 12, sf.numSolutions
        def solutions = sf.getSolutions()
        solutions.eachWithIndex { sol, idx ->
            def numB = sol.getInstancesOf(fm.getFeature('b')).size()
            def numC = sol.getInstancesOf(fm.getFeature('c')).size()
            assertTrue numB <= numC

//            println "${idx+1}" + sol
        }
    }

    void testWithSimpleConstraints2() {
        def fm = XtextLoader.INSTANCE.loadFeatureModel(getClass().getResource('/SimpleFMWithConstraints2.fm'))

        def sf = new SolverFactory().createSolver(fm)
//        println "Num vars: ${sf.variables.size()}"
//        sf.variables.each { println it }
//        println "Num cstrs: ${sf.solver.getNbCstrs()}"
//        sf.constraints.each { println it }

        println sf.numSolutions
        def solutions = sf.getSolutions()
        solutions.eachWithIndex { sol, idx ->
            def numB = sol.getInstancesOf(fm.getFeature('b')).size()
            def numC = sol.getInstancesOf(fm.getFeature('c')).size()
            assertEquals numB, numC

//            println "${idx + 1}" + sol
        }
    }

    void testWithComplexConstraints() {
        def fm = XtextLoader.INSTANCE.loadFeatureModel(getClass().getResource('/SimpleFMWithRelativeConstraints.fm'))

        def sf = new SolverFactory().createSolver(fm)
//        println "Num vars: ${sf.variables.size()}"
//        sf.variables.each { println it }
//        println "Num cstrs: ${sf.solver.getNbCstrs()}"
//        sf.constraints.each { println it }

        println sf.numSolutions
        def solutions = sf.getSolutions()
        solutions.eachWithIndex { sol, idx ->
            def numB = sol.getInstancesOf(fm.getFeature('b')).size()
            def numC = sol.getInstancesOf(fm.getFeature('c')).size()

            assertTrue numB != 1 || numC == 2

//            println "${idx + 1}" + sol
        }
    }

    void testWithComplexConstraints2() {
        def fm = XtextLoader.INSTANCE.loadFeatureModel(getClass().getResource('/FMWithCrossContextConstraints.fm'))

        def sf = new SolverFactory().createSolver(fm)
//        println "Num vars: ${sf.variables.size()}"
//        sf.variables.each { println it }
//        println "Num cstrs: ${sf.solver.getNbCstrs()}"
//        sf.constraints.each { println it }

        println sf.numSolutions
        def solutions = sf.getSolutions()
        solutions.eachWithIndex { sol, idx ->
            def numB = sol.getInstancesOf(fm.getFeature('b')).size()
            def numC = sol.getInstancesOf(fm.getFeature('c')).size()
            assertEquals numB, numC

            println "${idx + 1}" + sol
        }
    }

    void testWithGroup() {
        def fm = XtextLoader.INSTANCE.loadFeatureModel(getClass().getResource('/GroupFM.fm'))

        def sf = new SolverFactory().createSolver(fm)
//        println "Num vars: ${sf.variables.size()}"
//        sf.variables.each { println it }
//        println "Num cstrs: ${sf.solver.getNbCstrs()}"
//        sf.constraints.each { println it }

        assertEquals 3, sf.numSolutions
        def solutions = sf.getSolutions()
        solutions.eachWithIndex { sol, idx ->
//            println sf.solver.solutionRecorder.lastSolution
            println "${idx + 1}" + sol
        }
    }

    void testBuilderGroupAndCardinalities() {
        def fm = XtextLoader.INSTANCE.loadFeatureModel(getClass().getResource('/GroupAndCardinalities.fm'))

        long start = System.currentTimeMillis()
        def solver = new SolverBuilder().setFeatureModel(fm).buildSolver()
        long end = System.currentTimeMillis()

        def vars = solver.variableManager.getVariables()
        vars.each { println it.name }

        assertNotNull solver.variableManager.getVariable('/GroupAndCardinalities')
        assertNotNull solver.variableManager.getVariable('/GroupAndCardinalities[1]')
        assertNull solver.variableManager.getVariable('/GroupAndCardinalities[2]')
        assertNotNull solver.variableManager.getVariable('/GroupAndCardinalities[1]/app')
        assertNotNull solver.variableManager.getVariable('/GroupAndCardinalities[1]/app[1]')
        assertNotNull solver.variableManager.getVariable('/GroupAndCardinalities[1]/app[5]')
        assertNull solver.variableManager.getVariable('/GroupAndCardinalities[2]/app[6]')

        assertNotNull solver.variableManager.getVariable('/GroupAndCardinalities')
        for (int grp = 1; grp <= 1; grp++) {
            assertNotNull solver.getVariableManager().getVariable("/GroupAndCardinalities[${grp}]")
            assertNotNull solver.getVariableManager().getVariable("/GroupAndCardinalities[${grp}]/app")
            for (int app = 1; app <= 5; app++) {
                assertNotNull solver.getVariableManager().getVariable("/GroupAndCardinalities[${grp}]/app[${app}]")
                assertNotNull solver.getVariableManager().getVariable("/GroupAndCardinalities[${grp}]/app[${app}]/web")
                assertNotNull solver.getVariableManager().getVariable("/GroupAndCardinalities[${grp}]/app[${app}]/cartridge")
                for (int cart = 1; cart <= 4; cart++) {
                    assertNotNull solver.getVariableManager().getVariable("/GroupAndCardinalities[${grp}]/app[${app}]/cartridge[${cart}]")
                    assertNotNull solver.getVariableManager().getVariable("/GroupAndCardinalities[${grp}]/app[${app}]/cartridge[${cart}]/type")
                    assertNotNull solver.getVariableManager().getVariable("/GroupAndCardinalities[${grp}]/app[${app}]/cartridge[${cart}]/type[1]")
                    assertNotNull solver.getVariableManager().getVariable("/GroupAndCardinalities[${grp}]/app[${app}]/cartridge[${cart}]/type[1]<group>")
                }
            }

            assertNotNull solver.getVariableManager().getVariable("/GroupAndCardinalities[${grp}]/location")
            assertNotNull solver.getVariableManager().getVariable("/GroupAndCardinalities[${grp}]/location[1]")
        }


        println "Time: ${end - start} ms"
        println "Vars: ${solver.solver.vars.size()}"
    }

    void testWithGroup2() {
//        def fm = XtextLoader.INSTANCE.loadFeatureModel(getClass().getResource('/GroupAndCardinalities.fm'))
        def config = XtextLoader.INSTANCE.loadConfiguration(getClass().getResource('/ConfigGroupAndCardinalities.fm'))
        def fm = config.featureModel

        def sf = new SolverFactory().createSolver(config)
//        println "Num vars: ${sf.variables.size()}"
//        sf.variables.each { println it }
//        println "Num cstrs: ${sf.solver.getNbCstrs()}"
//        sf.constraints.each { println it }

//        println sf.numSolutions
        def solutions = sf.getSolutions()
        solutions.eachWithIndex { sol, idx ->
            assertEquals 2, sol.getInstancesOf(fm.getFeature('web')).size()
//            println sf.solver.solutionRecorder.lastSolution
            println "${idx + 1}" + sol
        }
    }

    void testWithConfig() {
        def config = XtextLoader.INSTANCE.loadConfiguration(getClass().getResource('/configFm1.fm'))

        def sf = new SolverFactory().createSolver(config)
        def solutions = sf.getSolutions()
        solutions.eachWithIndex { sol, idx ->
            def numEs = sol.getInstancesOf(config.featureModel.getFeature('FeatE')).size()
            def numB2s = sol.getInstancesOf(config.featureModel.getFeature('B2')).size()

            assertTrue numEs >= 3
            assertTrue numB2s >= 1
            println "${idx + 1}" + sol
        }
    }


//    void testExample() {
//        def solver = new Solver()
//        def v1 = VariableFactory.bounded("v1", 0, 100, solver)
//        def v2 = VariableFactory.bounded("v2", 0, 100, solver)
//
//        def limitV1 = ICF.arithm(v1, "<=", 2)
//        def limitV2 = ICF.arithm(v2, "<=", 2)
//        solver.post(limitV1)
//        solver.post(limitV2)
//        solver.post(ICF.arithm(v1, "<", v2))
////        solver.post(ICF.arithm(v1, "=", 0))
////        solver.post(ICF.arithm(v2, "=", 1))
//
//        def solRecorder = solver.getSolutionRecorder()
//        if (solver.findSolution()) {
//
//            while (true) {
//                println solRecorder.lastSolution
//                if (!solver.nextSolution())
//                    break;
//            }
//        }
//
//        println "extending..."
//        solver.getObjectiveManager()
//
//        solver.findSolution()
//        solver2.unpost(limitV2)
//        limitV2 = ICF.arithm(v2, "<=", 3)
//        solver2.post(limitV2)
//
//        solRecorder = solver2.getSolutionRecorder()
//
//        if (solver2.findSolution()) {
//            while (true) {
//                println solRecorder.lastSolution
//                if (!solver2.nextSolution())
//                    break;
//            }
//        }
//    }


    void testWithValidCompleteConfiguration() {
        def config = new XtextLoader().loadConfiguration(getClass().getResource('/ConfigRoot2.fm'))

        def builder = new SolverBuilder()
        builder.setConfiguration(config)

        FeatureModelSolver solver = builder.buildChecker()


        def numSolutions = solver.numSolutions
        println solver.solutions.iterator().next().printHierarchy()


        assertNotNull solver.vm.getVariable('/Root2[1]/Parent[1]')
        assertNotNull solver.vm.getVariable('/Root2[1]/Parent[2]')
        assertNull solver.vm.getVariable('/Root2[1]/Parent[3]')

        assertEquals 1, numSolutions

    }

    void testDoesntMeetMinimumCardinality() {
        // Parent feature has minimum 2 instances
        def config = XtextLoader.INSTANCE.loadFromString("""
config Root2 from '${getClass().getResource('/Root2.fm')}'
Root2 {
    Parent {
        FeatB { B2 }
        FeatC { FeatD }
    }
}
""")

        def solver = new SolverBuilder().
                setConfiguration(config).
                buildChecker()


        assertNotNull solver.vm.getVariable('/Root2[1]/Parent[1]')
        assertNotNull solver.vm.getVariable('/Root2[1]/Parent[1]/FeatB[1]')
        assertNotNull solver.vm.getVariable('/Root2[1]/Parent[1]/FeatB[1]/B2[1]')
        assertNotNull solver.vm.getVariable('/Root2[1]/Parent[1]/FeatC[1]/FeatD[1]')
        assertNull solver.vm.getVariable('/Root2[1]/Parent[2]')

        def numSolutions = solver.numSolutions
        assertEquals 0, numSolutions

    }

    void testeValidCompleteConfiguration2() {
        def config = XtextLoader.INSTANCE.loadFromString("""
config root from '${getClass().getResource('/SimpleCardinalitiesFM.fm')}'
root {
    a {
        b
    }
}
""")

        def solver = new SolverBuilder().
                setConfiguration(config).
                buildChecker()


        assertNotNull solver.vm.getVariable('/root[1]/a[1]/b[1]')
        assertNull solver.vm.getVariable('/root[1]/a[2]')
        assertNull solver.vm.getVariable('/root[1]/a[1]/b[2]')
        assertNull solver.vm.getVariable('/root[1]/a[1]/b[1]/c[1]')

        def numSolutions = solver.numSolutions
        assertEquals 1, numSolutions

    }

    void testeInvalidMandatoryFeatureOmmited() {
        // Feature D is mandatory but not in the config
        def config = XtextLoader.INSTANCE.loadFromString("""
config ConfigFM from '${getClass().getResource('/ConfigFM.fm')}'
ConfigFM {
    A {
        C
    }
}
""")

        def solver = new SolverBuilder().
                setConfiguration(config).
                buildChecker()

        def numSolutions = solver.numSolutions
        assertEquals 0, numSolutions
    }

    void testeInvalidConstraintNotMeet() {
        // B implies C
        def config = XtextLoader.INSTANCE.loadFromString("""
config ConfigFM from '${getClass().getResource('/ConfigFM.fm')}'
ConfigFM {
    A {
        B
    }
}
""")
        def solver = new SolverBuilder().setConfiguration(config).buildChecker()
        assertEquals 0, solver.numSolutions
    }

    void testValidFullCompleteOpenShiftConfig() {
        def config = XtextLoader.INSTANCE.loadFromString("""
config OpenShift2 from '${getClass().getResource('/OpenShift2.fm')}'
OpenShift2 {
    Plan { Free }
    Application {
        Location { aws_us_east_1 }
        Cartridge {
            Gear
            GearSize { small }
            Type { Web { Tomcat7 } }
        }
        Cartridge {
            Type { Addon { MongoDB } }
        }
    }
    Application {
        Scalable
        Location { aws_us_east_1 }
        Cartridge {
            Gear Gear
            GearSize { small }
            Type { Web { Python } }
        }
    }
}
""")
        def solver = new SolverBuilder().setConfiguration(config).buildChecker()
        assertEquals 1, solver.numSolutions
    }

    void testInvalidOpenShiftTwoWebCartridges() {
        def config = XtextLoader.INSTANCE.loadFromString("""
config OpenShift2 from '${getClass().getResource('/OpenShift2.fm')}'
OpenShift2 {
    Plan { Bronze }
    Application {
        Location { aws_us_east_1 }
        Cartridge {
            Gear
            GearSize { small }
            Type { Web { Tomcat7 } }
        }
        Cartridge {
            Type { Addon { MongoDB } }
        }
        Cartridge {
            Type { Web { Python } }
        }
    }
}
""")
        def solver = new SolverBuilder().setConfiguration(config).buildChecker()
        assertEquals 0, solver.numSolutions
    }

    void testInvalidOpenShiftFreeOutsideUS() {
        def config = XtextLoader.INSTANCE.loadFromString("""
config OpenShift2 from '${getClass().getResource('/OpenShift2.fm')}'
OpenShift2 {
    Plan { Free }
    Application {
        Location { aws_ap_southwest_2 }
        Cartridge {
            Gear
            GearSize { small }
            Type { Web { Tomcat7 } }
        }
        Cartridge {
            Type { Addon { MongoDB } }
        }
    }
}
""")
        def solver = new SolverBuilder().setConfiguration(config).buildChecker()
        assertEquals 0, solver.numSolutions
    }

    void testInvalidOpenShiftFreeNotSmall() {
        def config = XtextLoader.INSTANCE.loadFromString("""
config OpenShift2 from '${getClass().getResource('/OpenShift2.fm')}'
OpenShift2 {
    Plan { Free }
    Application {
        Location { aws_us_east_1 }
        Cartridge {
            Gear
            GearSize { smallhighcpu }
            Type { Web { Tomcat7 } }
        }
        Cartridge {
            Type { Addon { MongoDB } }
        }
    }
}
""")
        def solver = new SolverBuilder().setConfiguration(config).buildChecker()
        assertEquals 0, solver.numSolutions
    }

    void testInvalidOpenShiftFreeMoreThan3Gears() {
        def config = XtextLoader.INSTANCE.loadFromString("""
config OpenShift2 from '${getClass().getResource('/OpenShift2.fm')}'
OpenShift2 {
    Plan { Free }
    Application {
        Scalable
        Location { aws_us_east_1 }
        Cartridge {
            3 Gear
            GearSize { small }
            Type { Web { Tomcat7 } }
        }
        Cartridge {
            Gear
            GearSize { small }
            Type { Addon { MongoDB } }
        }
    }
}
""")
        def solver = new SolverBuilder().setConfiguration(config).buildChecker()
        assertEquals 0, solver.numSolutions
    }

    void testInvalidNonScalableAppWithAddonGears() {
        def config = XtextLoader.INSTANCE.loadFromString("""
config OpenShift2 from '${getClass().getResource('/OpenShift2.fm')}'
OpenShift2 {
    Plan { Free }
    Application {
        Location { aws_us_east_1 }
        Cartridge {
            Gear
            GearSize { small }
            Type { Web { Tomcat7 } }
        }
        Cartridge {
            Gear
            GearSize { small }
            Type { Addon { MongoDB } }
        }
    }
}
""")
        def solver = new SolverBuilder().setConfiguration(config).buildChecker()
        assertEquals 0, solver.numSolutions
    }

    void testUnspecifiedGearSize() {
        def config = XtextLoader.INSTANCE.loadFromString("""
config OpenShift2 from '${getClass().getResource('/OpenShift2.fm')}'
OpenShift2 {
    Plan { Free }
    Application {
        Location { aws_us_east_1 }
        Cartridge {
            Gear
            Type { Web { Tomcat7 } }
        }
    }
}
""")
        def solver = new SolverBuilder().setConfiguration(config).buildChecker()
        assertEquals 0, solver.numSolutions
    }

    void testMissingMandatoryFeatures() {
        def config = XtextLoader.INSTANCE.loadFromString("""
config OpenShift2 from '${getClass().getResource('/OpenShift2.fm')}'
OpenShift2 {
    Plan { Free }
    Application {
        Location { aws_us_east_1 }
        Cartridge {
            Gear
            GearSize
            Type { Web { Tomcat7 } }
        }
    }
}
""")
        def solver = new SolverBuilder().setConfiguration(config).buildChecker()
        assertEquals 0, solver.numSolutions
    }

    void testExceedingGearBronzePlan() {
        def config = XtextLoader.INSTANCE.loadFromString("""
config OpenShift2 from '${getClass().getResource('/OpenShift2.fm')}'
OpenShift2 {
    Plan { Bronze }
    Application {
        Scalable
        Location { aws_us_east_1 }
        Cartridge {
            17 Gear
            GearSize { small }
            Type { Web { Tomcat7 } }
        }
    }
}
""")
        def solver = new SolverBuilder().setConfiguration(config).buildChecker()
        assertEquals 0, solver.numSolutions
    }

    void testValidConfigBronzePlan() {
        def config = XtextLoader.INSTANCE.loadFromString("""
config OpenShift2 from '${getClass().getResource('/OpenShift2.fm')}'
OpenShift2 {
    Plan { Bronze }
    2 Application {
        Scalable
        Location { aws_eu_west_1 }
        Cartridge {
            4 Gear
            GearSize { medium }
            Type { Web { Tomcat7 } }
        }
        Cartridge {
            2 Gear
            GearSize { large }
            Type { Addon { MongoDB } }
        }
        Cartridge {
            2 Gear
            GearSize { medium }
            Type { Addon { MySQL } }
        }
    }
}
""")
        def solver = new SolverBuilder().setConfiguration(config).buildChecker()
        assertEquals 1, solver.numSolutions
    }

    void testExampleOpenShift() {
        def config = XtextLoader.INSTANCE.loadFromString("""
config OpenShift3 from '${getClass().getResource('/OpenShift3.fm')}'
OpenShift3 {
    Plan { Bronze }
    2 Application {
        Scalable
        Location { aws_eu_west_1 }
        Cartridge {
            4 Gear
            GearSize { medium }
            Type { Web { Tomcat7 } }
        }
        Cartridge {
            2 Gear
            GearSize { large }
            Type { Addon { MongoDB } }
        }
        Cartridge {
            2 Gear
            GearSize { medium }
            Type { Addon { MySQL } }
        }
    }
}
""")
        def solver = new SolverBuilder().setConfiguration(config).buildSolver()
//        println solver.solver.isFeasible()
//        solver.solver.set


        Chatterbox.showDecisions(solver.solver)
        Chatterbox.showSolutions(solver.solver)

        return
//
//        println "Solving..."
        def firstSolution = solver.getSolutions().iterator().next()
//        assertNotNull firstSolution
        println(firstSolution.printHierarchy())

    }

    void testInferenceWithCSP() {
        def inf = new CardinalityInferrer(XtextLoader.INSTANCE.loadFeatureModel(getClass().getResource('/OpenShift4.fm')))
        inf.cardinalities.each { println it }
    }

    void testBuildCSP() {
        def fm = XtextLoader.INSTANCE.loadFeatureModel(getClass().getResource('/OpenShift3.fm'))

        long start = System.currentTimeMillis()
        def solver = new SolverBuilder().setFeatureModel(fm).buildSolver()
        long end = System.currentTimeMillis()
        println (end - start)
    }

    void sample() {
        // Load feature model from file
        URL fileURL = new File("/Users/gustavo/OpenShift.fm");
        FeatureModel fm = XtextLoader.INSTANCE.load(fileURL.toURI().toURL());

        // Build a solver for the feature model
        SolverBuilder builder = new SolverBuilder();
        FeatureModelSolver solver = builder.setFeatureModel(fm).buildSolver();

        // Find a configuration for the feature model
        Iterator<Configuration> configIterator = solver.solutions.iterator();
        if (!configIterator.hasNext())
            return; // No solution found

        Configuration config = configIterator.next();

        // Build a solver to verify a configuration
        FeatureModelSolver checker = builder.setConfiguration(config.toConfig()).buildChecker();

        // Check the configuration
        assertTrue checker.isSatisfied();

        // Load config from file
        File configFile = new File("src/main/resources/configOpenShift.fm");
        Configuration configFromFile = XtextLoader.INSTANCE.loadConfiguration(configFile.toURI().toURL());
        checker = builder.setConfiguration(configFromFile).buildChecker()


        assertTrue checker.isSatisfied()
    }
}
