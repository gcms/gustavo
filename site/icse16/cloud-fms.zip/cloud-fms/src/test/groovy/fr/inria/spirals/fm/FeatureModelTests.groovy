package fr.inria.spirals.fm

import fr.inria.spirals.fm.eval.FeatureModelGenerator
import fr.inria.spirals.fm.loader.xtext.XtextLoader

/**
 * Created by gustavo on 11/08/15.
 */
class FeatureModelTests extends GroovyTestCase {
    void testCopy() {
        def fm = new FeatureModelGenerator().generate(100)
        def copy = fm.copy()

        assertEquals fm.toString(), copy.toString()


        def loader = XtextLoader.INSTANCE
        assertEquals loader.convert(fm), loader.convert(copy)

    }
}
