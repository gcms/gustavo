package fr.inria.spirals.fm

import fr.inria.spirals.fm.loader.xtext.XtextLoader
import fr.inria.spirals.fm.loader.xtext.XtextLoaderTests
import fr.inria.spirals.fm.model.FeatureModel
import fr.inria.spirals.fm.model.FeaturePair
import fr.inria.spirals.fm.model.RelativeCardinalityCollection

/**
 * Created by gustavo on 16/06/15.
 */
class CardinalityInferrerTests extends GroovyTestCase{
    void testInferedCardinalities() {
        FeatureModel fm = XtextLoaderTests.loadOpenShift()

        def table = new RelativeCardinalityCollection(new CardinalityInferrer(fm).cardinalities)
//        table.init()


        assertEquals 1..1, table.get(fm.getFeature('Plan'), fm.getFeature('OpenShift'))
        assertEquals 0..1, table.get(fm.getFeature('Free'), fm.getFeature('OpenShift'))

        assertEquals 0..1, table.get(fm.getFeature('Web'), fm.getFeature('Type'))
        assertEquals 0..1, table.get(fm.getFeature('Web'), fm.getFeature('Cartridge'))
        assertEquals 1..1, table.get(fm.getFeature('Web'), fm.getFeature('Application'))
        assertEquals 0..100, table.get(fm.getFeature('Web'), fm.getFeature('OpenShift'))

        assertEquals 0..100, table.get(fm.getFeature('Gear'), fm.getFeature('Cartridge'))
        assertEquals 1..100, table.get(fm.getFeature('Gear'), fm.getFeature('Application'))
        assertEquals 0..100, table.get(fm.getFeature('Gear'), fm.getFeature('OpenShift'))

        assertEquals 1..100, table.get(fm.getFeature('Cartridge'), fm.getFeature('Application'))
        assertEquals 0..10000, table.get(fm.getFeature('Cartridge'), fm.getFeature('OpenShift'))

    }

    void testInferred2() {
        FeatureModel fm = XtextLoader.INSTANCE.loadFeatureModel('''
a {
  b [1..2] {
    c <a> [1..6]
    d [1..3]
  }
}
''')

        def table = new RelativeCardinalityCollection(new CardinalityInferrer(fm).cardinalities)

        assertEquals 1..2, table.get(fm.getFeature('b'), fm.getFeature('a'))
        assertEquals 1..6, table.get(fm.getFeature('c'), fm.getFeature('a'))
        assertEquals 0..6, table.get(fm.getFeature('c'), fm.getFeature('b'))
        assertEquals 1..3, table.get(fm.getFeature('d'), fm.getFeature('b'))
        assertEquals 1..6, table.get(fm.getFeature('d'), fm.getFeature('a'))
    }

    void testInferred3() {
        FeatureModel fm = XtextLoader.INSTANCE.loadFeatureModel('''
a {
  b [1..2] {
    c [1..1]
    d [1..2] {
        e <b> [1..2]
    }
  }
}
''')

        def table = new RelativeCardinalityCollection(new CardinalityInferrer(fm).cardinalities)

        assertEquals 1..2, table.get(fm.getFeature('b'), fm.getFeature('a'))
        assertEquals 1..2, table.get(fm.getFeature('c'), fm.getFeature('a'))
        assertEquals 1..1, table.get(fm.getFeature('c'), fm.getFeature('b'))
        assertEquals 1..2, table.get(fm.getFeature('d'), fm.getFeature('b'))
        assertEquals 1..4, table.get(fm.getFeature('d'), fm.getFeature('a'))
        assertEquals 1..4, table.get(fm.getFeature('e'), fm.getFeature('a'))
        assertEquals 1..2, table.get(fm.getFeature('e'), fm.getFeature('b'))
        assertEquals 0..2, table.get(fm.getFeature('e'), fm.getFeature('d'))
    }

    void testInferred4() {
        FeatureModel fm = XtextLoader.INSTANCE.loadFeatureModel('''
a {
  b [2..2] {
    c [0..3] <a> [2..6]
  }
}
''')

        assertEquals 2..2, fm.getRelativeCardinality('b', 'a')
        assertEquals 0..3, fm.getRelativeCardinality('c', 'b')
        assertEquals 2..6, fm.getRelativeCardinality('c', 'a')

    }

    void testIllegal1() {
        FeatureModel fm = XtextLoader.INSTANCE.loadFeatureModel('''
a {
  b [2..4] {
    c [1..4] <a> [2..4]
  }
}
''')
    }

        void testIllegal1Legal() {
            FeatureModel fm = XtextLoader.INSTANCE.loadFeatureModel('''
a {
  b [2..4] {
    c [1..4] <a> [2..5]
  }
}
''')

            def table = new RelativeCardinalityCollection(new CardinalityInferrer(fm).cardinalities)
            table.asCollection().each { println it }
    }

    void testIllegal2() {
        FeatureModel fm = XtextLoader.INSTANCE.loadFeatureModel('''
a {
  b [1..1] {
    c [1..4] <a> [2..4]
  }
}
''')

        shouldFail {
            def table = new RelativeCardinalityCollection(new CardinalityInferrer(fm).cardinalities)
            table.asCollection().each { println it }
        }
    }

    void testIllegal2Legal() {
        FeatureModel fm = XtextLoader.INSTANCE.loadFeatureModel('''
a {
  b [1..1] {
    c [1..4] <a> [1..4]
  }
}
''')

        def table = new RelativeCardinalityCollection(new CardinalityInferrer(fm).cardinalities)
        table.asCollection().each { println it }

    }

    void testGoogle() {
        FeatureModel fm = XtextLoader.INSTANCE.loadFeatureModel(getClass().getResource('/Google.fm'))

        assertEquals 1..200, fm.getRelativeCardinality('Instance', 'Module')
        assertEquals 1..200, fm.getRelativeCardinality('Instance', 'AppEngine')
        assertEquals 0..200, fm.getRelativeCardinality('Instance', 'Project')
    }

    void testJelastic() {
        FeatureModel fm = XtextLoader.INSTANCE.loadFeatureModel(getClass().getResource('/Jelastic.fm'))
        fm.getInferredCardinalities()
    }

    void testHeroku() {
        FeatureModel fm = XtextLoader.INSTANCE.loadFeatureModel(getClass().getResource('/Heroku.fm'))

        assertEquals 0..1, fm.getRelativeCardinality('Web', 'Kind')
        assertEquals 0..1, fm.getRelativeCardinality('Web', 'ProcessType')
        assertEquals 0..1, fm.getRelativeCardinality('Web', 'Application')
        assertEquals 0..100, fm.getRelativeCardinality('Web', 'Heroku')
    }

    void testRelativeCardinality() {
        FeatureModel fm = XtextLoader.INSTANCE.loadFeatureModel('''
Feat_1 {
  Feat_2[0..8] <2..4> [
        Feat_69[1..3]
        Feat_7[1..1]
        Feat_93[1..4]
        Feat_31[1..6] <Feat_1> [0..6]
    ]
}
''')

        println new CardinalityInferrer(fm).getMaxValueMax(fm.getFeature('Feat_31'), fm.getFeature('Feat_1'))
    }

    private Set<FeaturePair> notDeclared(FeatureModel fm) {
        def result = []

        fm.features.sort { it.depth }.each { feat ->
            feat.ancestors.each { ances ->
                if (!fm.getDeclaredCardinality(feat, ances)) {
                    result << new FeaturePair(feat, ances)
                }
            }
        }

        result
    }

    private Set<FeaturePair> declared(FeatureModel fm) {
        def result = []

        fm.features.sort { it.depth }.each { feat ->
            feat.ancestors.each { ances ->
                if (fm.getDeclaredCardinality(feat, ances)) {
                    result << new FeaturePair(feat, ances)
                }
            }
        }

        result
    }

    private int numConsistencyChecks(FeatureModel fm) {
        fm.features.collect { feat ->
            feat.ancestors.collect { ances ->
                Math.max(0, feat.depth - ances.depth)
            }
        }.flatten().sum()
    }


    void testAllFMs() {
        URL url = getClass().getResource('/teste.fm')
        assertTrue url.protocol == 'file'

        def file = new File(url.toURI())
        def dir = file.parentFile

        def files = dir.listFiles().findAll { it.name.endsWith('.fm') && !it.text.startsWith('config') }.findAll {
            !it.name.startsWith('Sample')
        }

        Map<FeatureModel, Long> times = files.collectEntries { fmFile ->
            def fm = XtextLoader.INSTANCE.loadFeatureModel(fmFile.toURI().toURL())

            println "Inferring: ${fm.name}"
            long start = System.currentTimeMillis()
            def inferrer = new CardinalityInferrer(fm)
            long end = System.currentTimeMillis()


            int features = fm.features.size()
            int declared = declared(fm).size()
            int notDeclared = notDeclared(fm).size()
            int relative = declared + notDeclared
            assertEquals relative, fm.getInferredCardinalities().size()
            int checks = numConsistencyChecks(fm)
            long time = end - start

            println "${fm.name} -> nFeatures: ${features} / relativeCards: ${relative} [dec: ${declared}, not: ${notDeclared}] / checks: ${checks} / nVars: ${inferrer.solver.nbVars} / Time: ${time} ms / ${time/checks} / ${time/relative}"

            System.gc()

            new MapEntry(fm, end - start)
        }

        times.each { k, v ->

        }

    }
}
