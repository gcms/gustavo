select fm.num_feats, rc.value
from featuremodel fm join run rc on rc.model_id = fm.id
where fm.base_model_id is not null
and experiment = 'Experiment2'
and measure = 'inference'
and num_feats <= 2500
group by fm.num_feats, fm.base_model_id
order by num_feats;