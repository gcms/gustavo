select
    fmRc.num_feats, regular.value as regularValue, rc.value as rcValue
from
run rc join featuremodel fmRc on rc.model_id = fmRc.id
join featuremodel fm on fmRc.base_model_id = fm.id
join run regular on regular.model_id = fm.id
where
rc.experiment = 'Experiment2'
and regular.experiment = rc.experiment
and rc.measure = 'generation'
and regular.measure = 'generation'
and fmRc.num_feats = fm.num_feats
and fmRc.num_feats <= 2500
and regular.id = rc.id
order by fmRc.num_feats;

