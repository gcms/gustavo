package stats
import org.yaml.snakeyaml.Yaml

import java.lang.reflect.Method

public class Main {
    public static void main(String[] args) {
        List operations = FeatureModelAnalyzer.methods*.name.findAll { it.startsWith("analyze") }.collect {
            it.replace('analyze', '')
        }
        if (args.size() < 1) {
            operations.each {
                println "fma <file> ${it}"
            }
            System.exit(1)
        }
        List files = []
        List ops = []

        for (String arg : args) {
            File f = new File(arg)
            if (f.exists())
                files << f
            else if (operations.contains(arg))
                ops << 'analyze' + arg
            else {
                println "Invalid argument '${arg}'"
                System.exit(1)
            }
        }

        if (files.empty) {
            println "No files specified"
            System.exit(1)
        }

        if (ops.empty)
            ops << "analyzebasic"

        for (File f : files) {
            List<FeatureModel> fms = loadFMs(f)
            FeatureModelAnalyzer analyzer = new FeatureModelAnalyzer(fms)
            for (String op : ops) {
                Method m = FeatureModelAnalyzer.getMethod(op)
                m.invoke(analyzer)
            }
        }

//
//        System.out.println(args.size())
//        ['PaaS.yaml', 'IaaS.yaml'].each {
//            println "\n\nAnalyzing $it"
//            analyze(new File(it))
//        }
    }

    public static void analyze(File f) {
        ArrayList<FeatureModel> fms = loadFMs(f)

        def analyzer = new FeatureModelAnalyzer(fms)
        analyzer.analyze()
    }

    private static ArrayList<FeatureModel> loadFMs(File f) {
        List<FeatureModel> fms = new ArrayList<FeatureModel>()

        Yaml yaml = new Yaml()
        for (Map map : yaml.load(f.text)) {
            FeatureModel fm = new FeatureModel(map)
//            println fm
            fms << fm
        }
        fms
    }
}