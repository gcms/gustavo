package stats
/**
 * Created by gustavo on 02/04/15.
 */
class FeatureModel {
    Set<Feature> features = new LinkedHashSet<Feature>()

    public FeatureModel() {

    }

    public FeatureModel(Map map) {
        createSubFeatures(features, null, map)
    }

    void createSubFeatures(Set<Feature> features, Feature feature, List list) {
        for (Object obj : list) {
            if (obj != null)
                createSubFeatures(features, feature, obj)
        }
    }

    void createSubFeatures(Set<Feature> features, Feature feature, Map map) {
        for (Map.Entry entry : map) {
            Feature feat = new Feature(name: entry.getKey(), parent: feature)
            features << feat

            if (entry.value != null)
                createSubFeatures(features, feat, entry.value)
        }
    }

    void createSubFeatures(Set<Feature> features, Feature feature, Object obj) {
        Feature feat = new Feature(name: obj, parent: feature)
        features << feat
    }

    public Feature getRoot() {
        features.first()
    }

    public String toString() {
        features*.getPath().join("\n")
    }

    public int hashCode() {
        features.hashCode()
    }

    public boolean equals(FeatureModel o) {
        if (!(o instanceof FeatureModel))
            return false

        ((FeatureModel)o).features == features
    }

    String getName() {
        root.name
    }

    int getNumFeats() {
        features.size()
    }

    boolean contains(String featPath) {
        features.find { it.pathStd == featPath }
    }

    public int size() {
        features.size() - 1
    }
}
