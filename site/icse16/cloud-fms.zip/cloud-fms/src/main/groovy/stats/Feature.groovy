package stats

/**
 * Created by gustavo on 02/04/15.
 */
class Feature {
    String name

    Feature parent

    String getPath() {
        parent != null ? "${parent.getPath()}.${name}" : name
    }

    String getPathStd() {
        parent != null ? "${parent.getPathStd()}.${name}" : "ROOT"
    }

    public int hashCode() {
        path.hashCode()
    }

    public boolean equals(Object o) {
        if (!(o instanceof Feature))
            return false

        ((Feature) o).path == path
    }
}
