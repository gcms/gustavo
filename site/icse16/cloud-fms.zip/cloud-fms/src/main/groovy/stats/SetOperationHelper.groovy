package stats

/**
 * Created by gustavo on 02/04/15.
 */
class SetOperationHelper {
    public static <T> Collection<T> intersect(List<Collection<T>> sets) {
        Iterator<Collection<T>> iter = sets.iterator()
        if (!iter.hasNext())
            return null

        Collection<T> result = iter.next()

        while (iter.hasNext()) {
            result = result.intersect(iter.next())
        }

        return result
    }

    public static <T> Collection<List<T>> crossProduct(Collection<T> col1, Collection<T> col2, Closure includes) {
        Collection<List<T>> result = new LinkedHashSet<List<T>>()

        for (T i1 : col1) {
            for (T i2 : col2) {
                if (includes == null || includes(i1, i2)) {
                    List<T> tuple = new ArrayList<T>(2)
                    tuple.add(0, i1)
                    tuple.add(1, i2)
                    result.add(tuple)
                }
            }
        }

        result
    }
}
