package stats

import java.text.DecimalFormat

import static stats.SetOperationHelper.crossProduct
import static stats.SetOperationHelper.intersect
/**
 * Created by gustavo on 02/04/15.
 */
class FeatureModelAnalyzer {
    Collection<FeatureModel> fms

    public FeatureModelAnalyzer(Collection<FeatureModel> fms) {
        this.fms = fms
    }

    public void analyzebasic() {
        Set commonFeats = analyzecommonFeatures()

        Set commonFeatsWPath = analyzecommonFeaturesWithPath()

//        println "\nAverage num of Common Features"
//        for (FeatureModel fm : fms) {
//            BigDecimal avg = commonFeats.size() / fm.features.size()
//            println "${fm.root.name}: ${avg}"
//        }
//
//        println "\nAverage num of Common Features with Path"
//        for (FeatureModel fm : fms) {
//            BigDecimal avg = commonFeatsWPath.size() / fm.features.size()
//            println "${fm.root.name}: ${avg}"
//        }

        analyzesimilarityBetweenTwo()
        analyzemostCommonFeatures()
        System.out.println("\n\nOk!")
    }

    private Set analyzecommonFeaturesWithPath() {
        println "\nCommon Features with Path"
        Set commonFeatsWPath = intersect(fms.collect { it.features*.pathStd - "ROOT" })
        println commonFeatsWPath
        commonFeatsWPath
    }

    public Set analyzecommonFeatures() {
        println "\nCommon Features"
        Set commonFeats = intersect(fms.collect { it.features*.name })
        println commonFeats
        commonFeats
    }

    public void analyzesimilarityBetweenTwo() {
        DecimalFormat fmt = new DecimalFormat("0.00")
        BigDecimal avg = 0

        Collection<List<FeatureModel>> tuples = crossProduct(fms, fms) { fm1, fm2 -> fm1 != fm2 }
        println "\nAverage num of Common Features (considering path) between two FM"
        for (List<FeatureModel> tuple : tuples) {
            FeatureModel fm1 = tuple[0]
            FeatureModel fm2 = tuple[1]

            List common = intersect(tuple.collect { it.features*.pathStd})
            BigDecimal percent = 100 * (common.size() / fm1.numFeats + common.size() / fm2.numFeats) / 2

            println "${fm1.name} (${fm1.numFeats})/${fm2.name} (${fm2.numFeats}): ${common.size()} ${fmt.format(percent)}% similar"

            avg += percent
        }

        avg = avg / tuples.size()
        println "TOTAL AVERAGE: ${fmt.format(avg)}%"
    }

    public void analyzemostCommonFeatures() {
        println "Total number of FMs: ${fms.size()}"
        println "Average FM num of Features: ${fms.sum { it.size() } / fms.size()}"

        Set totalFeats = fms.collect { fms.features*.pathStd }.flatten().unique() - "ROOT"
        println "Total number of Features: ${fms.sum { it.size() }}"
        println "Total number of unique Features: ${totalFeats.size()}"


        List featAndOccurrences = totalFeats.collect { String featPath ->
            [featPath, fms.count { it.contains(featPath) }]
        }

        println "Total number of Features that appear more than once: ${featAndOccurrences.size()}"

        featAndOccurrences.findAll { it[1] > 1 }.sort { -it[1] }.each {
            println "${it[0]}: ${it[1]}"
        }


        featAndOccurrences.groupBy { it[1] }.sort { it.key }.each {
            println "${it.key} ${it.value.size()}"
        }

    }
}
