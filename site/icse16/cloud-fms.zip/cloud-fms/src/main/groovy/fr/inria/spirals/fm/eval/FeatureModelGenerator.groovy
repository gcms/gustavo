package fr.inria.spirals.fm.eval
import fr.inria.spirals.fm.model.Cardinality
import fr.inria.spirals.fm.model.FeatureModel
import fr.inria.spirals.fm.model.FeatureNode

/**
 * Created by gustavo on 20/07/15.
 */
class FeatureModelGenerator {
    int maxDepth = 5
    int maxCard = 10

    int probCardUpper = 50
    int probCardOther = 1

//    int minFeatureCardinalityRange = 0..1

    Random random = new Random(System.currentTimeMillis())

    FeatureModel generate(int nFeatures) {
        def graph = GraphGenerator.tree(nFeatures, maxDepth)

        int rootIndex = 0

        FeatureModel fm = new FeatureModel(getFeatName(rootIndex))
        processChildren(graph.adj(rootIndex).toList(), fm, fm.root, [rootIndex], graph)
        fm
    }

    private static String getFeatName(int index) {
        "Feat_${index+1}"
    }

    private void process(FeatureModel fm, FeatureNode parent, int featIndex, Collection parents, GraphGenerator.Graph graph) {
        def children = graph.adj(featIndex).toList() - parents
        def createGroup = children.size() >= 2 && random.nextInt(3) == 1

        def node = createGroup ?
                fm.createFeatureGroup(getFeatName(featIndex), parent, randomGroupCardinality(children.size())) :
                fm.createFeature(getFeatName(featIndex), parent)
        fm.addCardinality(node, node.parent, randomFeatureCardinality(node))

        processChildren(children, fm, node, parents + [featIndex], graph)
    }

    private void processChildren(Collection<Integer> children, FeatureModel fm, FeatureNode node, Collection parents, GraphGenerator.Graph  graph) {
        for (int child : children) {
            process(fm, node, child, parents, graph)
        }
    }

    private Cardinality randomGroupCardinality(int numChildren) {
        def minCardGroup = Math.min(numChildren - 1, random.nextInt(numChildren) + 1)
        def maxCardGroup = Math.max(minCardGroup, random.nextInt(numChildren) + 1)

        minCardGroup..maxCardGroup
    }

    private Cardinality randomFeatureCardinality(FeatureNode node) {
        boolean hasCard = node.depth <= 2 ?
                (random.nextInt(100) < probCardUpper) :
                (random.nextInt(100) < probCardOther)

        def min = node.groupVariant ? 1 : random.nextInt(2)
        def max = hasCard ? 2 + random.nextInt(maxCard - 1) : 1
        min..max as Cardinality
    }

}
