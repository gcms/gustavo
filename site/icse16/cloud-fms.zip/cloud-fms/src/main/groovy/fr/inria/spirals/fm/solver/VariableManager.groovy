package fr.inria.spirals.fm.solver

import fr.inria.spirals.fm.locators.VariableLocator
import org.chocosolver.solver.Solver
import org.chocosolver.solver.variables.IntVar
import org.chocosolver.solver.variables.VariableFactory
import org.slf4j.Logger
import org.slf4j.LoggerFactory
/**
 * Created by gustavo on 22/04/15.
 */
class VariableManager {
    private static Logger log = LoggerFactory.getLogger(VariableManager)

    public Solver solver

    private Map<String, IntVar> variables = [:]

    public VariableManager(Solver solver) {
        this.solver = solver
    }

    public IntVar createVariable(VariableLocator loc, int min, int max) {
        if (variables.containsKey(loc.name))
            throw new IllegalArgumentException("Variable ${loc.name} already created: ${variables.get(loc.name)}")

        IntVar var = VariableFactory.bounded(loc.name, min, max, solver)
        variables.put(loc.name, var)

        log.debug var.toString()

        var
    }

    IntVar getVariable(VariableLocator featIndex) {
        getVariable(featIndex.name)
    }

    IntVar getVariable(String name) {
        variables.get(name)
    }

    IntVar[] getVariables(Iterable<VariableLocator> locators) {
        locators.collect { getVariable(it) }
    }

    Collection<IntVar> getVariables() {
        variables.values()
    }

    long getNumInstances() {
        getVariables().count { it.name =~ /.*\[[0-9]+\]/}
    }

    long getNumLocators() {
        variables.size()
    }

    long getNumVars() {
        solver.vars.size()
    }
}
