package fr.inria.spirals.fm.solver

import fr.inria.spirals.fm.model.FeatureModel
import fr.inria.spirals.fm.config.Configuration

/**
 * Created by gustavo on 13/06/15.
 */
class SolverFactory {
    public FeatureModelSolver createSolver(FeatureModel fm) {
        def builder = new SolverBuilder()
        builder.setFeatureModel(fm)
        builder.buildSolver()
    }

    public FeatureModelSolver createSolver(Configuration config) {
        def builder = new SolverBuilder()
        builder.setConfiguration(config)
        builder.buildSolver()
    }


}
