package fr.inria.spirals.fm.eval

import fr.inria.spirals.fm.model.FeatureModel
import fr.inria.spirals.fm.model.FeatureNode

/**
 * Created by gustavo on 23/07/15.
 */
class FeatureModelStats {
    private FeatureModel featureModel

    FeatureModelStats(FeatureModel featureModel) {
        this.featureModel = featureModel
    }

    int getNumberOfFeatures() {
        featureModel.features.size()
    }

    int getNumberOfFeaturesWithCardinalities() {
        featureModel.features.count { hasLocalCardinality(it) }
    }

    int getNumberOfFeaturesWithRelativeCardinalities() {
        featureModel.features.count { hasRelativeCardinality(it)}
    }

    int getNumberOfConstraints() {
        featureModel.constraints*.constrainingExpressions.flatten().unique().size()
    }

    int getNumberOfCardinalityConstraints() {
        featureModel.constraints*.constrainingExpressions.flatten().unique().count {
            it.to == it.from.parent && it.cardinality.max > 1
        }

//        featureModel.constraints.count { constr ->
//            constr.constrainingExpressions.find {
//                hasLocalCardinality(it.from) || hasLocalCardinality(it.to)
//            }
//        }
    }

    int getNumberOfRelativeCardinalityConstraints() {
        featureModel.constraints*.constrainingExpressions.flatten().unique().count {
            it.to != it.from.parent
        }
//        featureModel.constraints.count { constr ->
//            constr.constrainingExpressions.find { it.to != it.from.parent }
//        }
    }

    private boolean hasLocalCardinality(FeatureNode feature) {
//        featureModel.getDeclaredCardinalitiesFrom(feature).find { it.cardinality.max > 1 } ||
        featureModel.getInferredCardinalities().asCollection().
                find { it.from == feature && it.to == feature.parent && it.cardinality.max > 1 }
    }

    private boolean hasRelativeCardinality(FeatureNode node) {
        featureModel.getDeclaredCardinalitiesFrom(node).find { it.to != node.parent}

//        feature.ancestors.find {
//            featureModel.getImplicitCardinality(feature, it) != featureModel.getInferredCardinality(feature, it)
//        }
    }

    Map<Integer, BigDecimal> getPercentageOfCardinalityByDepth() {
        featureModel.features.groupBy { it.depth }.collectEntries { int depth, List<FeatureNode> features ->
            BigDecimal percent = features.count { hasLocalCardinality(it) } / features.size()
            new MapEntry(depth, percent)
        }
    }
}
