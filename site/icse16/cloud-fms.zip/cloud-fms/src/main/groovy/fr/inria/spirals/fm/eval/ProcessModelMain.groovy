package fr.inria.spirals.fm.eval

import fr.inria.spirals.fm.model.FeatureModel
import fr.inria.spirals.fm.loader.xtext.XtextLoader
import org.slf4j.Logger
import org.slf4j.LoggerFactory


/**
 * Created by gustavo on 19/08/15.
 */
class ProcessModelMain {
    static Logger log = LoggerFactory.getLogger(ProcessModelMain)

    public static void main(String[] args) {
        log.debug 'start'

        def db = new DbManager()

        for (Map fm : db.listFeatureModels('where num_feats = 2500 and id > 3132')) {

            Measurer.inference(new FeatureModelGenerator().generate(100))
            Measurer.generation(new FeatureModelGenerator().generate(100))

            println "Changed: ${fm.id}/ nFeats: ${fm.numFeats}"

            FeatureModel model = XtextLoader.INSTANCE.loadFeatureModel(fm.model)

            long inf = Measurer.inference(model)
            long gen = Measurer.generation(model)

            db.addRun('Regular2', null, new Date(), model, inf, gen)

        }

        System.exit(0)

        Measurer.inference(new FeatureModelGenerator().generate(100))
        Measurer.generation(new FeatureModelGenerator().generate(100))

        Map changed = db.loadFeatureModelMap(Integer.parseInt(args[0]))

        println "Changed: ${changed.id}/ nFeats: ${changed.numFeats}"

        FeatureModel changedModel = XtextLoader.INSTANCE.loadFeatureModel(changed.model)
        Integer baseModelId = changed.baseModelId

        changed = null

        println 'infering changed'
        println Measurer.inference(changedModel, 3)
        println 'generating changed'
        println Measurer.generation(changedModel, 3)

        changedModel = null

        System.gc()

        Measurer.inference(new FeatureModelGenerator().generate(100))
        Measurer.generation(new FeatureModelGenerator().generate(100))

        Map original = db.loadFeatureModelMap(baseModelId)

        println "Original: ${original.id}/ nFeats: ${original.numFeats}"

        FeatureModel originalModel = XtextLoader.INSTANCE.loadFeatureModel(original.model)

        println Measurer.inference(originalModel, 3)
        println Measurer.generation(originalModel, 3)
    }

}
