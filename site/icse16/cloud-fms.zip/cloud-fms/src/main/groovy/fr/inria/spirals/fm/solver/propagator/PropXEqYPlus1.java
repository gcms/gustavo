package fr.inria.spirals.fm.solver.propagator;

import gnu.trove.map.hash.THashMap;
import org.chocosolver.solver.Solver;
import org.chocosolver.solver.constraints.Propagator;
import org.chocosolver.solver.constraints.PropagatorPriority;
import org.chocosolver.solver.exception.ContradictionException;
import org.chocosolver.solver.explanations.Deduction;
import org.chocosolver.solver.explanations.Explanation;
import org.chocosolver.solver.explanations.ExplanationEngine;
import org.chocosolver.solver.explanations.ValueRemoval;
import org.chocosolver.solver.explanations.VariableState;
import org.chocosolver.solver.variables.IntVar;
import org.chocosolver.solver.variables.delta.IIntDeltaMonitor;
import org.chocosolver.solver.variables.events.IntEventType;
import org.chocosolver.util.ESat;
import org.chocosolver.util.procedure.IntProcedure;

/**
 * Created by gustavo on 23/07/15.
 */
public class PropXEqYPlus1 extends Propagator<IntVar> {


    private IntVar x, y;

    // enumerated domains
    private boolean bothEnumerated;
    private IIntDeltaMonitor[] idms;
    private RemProc rem_proc;
    private int indexToFilter;

    public PropXEqYPlus1(IntVar x, IntVar y) {
        super(new IntVar[] {x, y}, PropagatorPriority.BINARY, true);
        this.x = vars[0];
        this.y = vars[1];
        if (x.hasEnumeratedDomain() && y.hasEnumeratedDomain()) {
            bothEnumerated = true;
            idms = new IIntDeltaMonitor[2];
            idms[0] = vars[0].monitorDelta(this);
            idms[1] = vars[1].monitorDelta(this);
            rem_proc = new RemProc();
        }
    }

    @Override
    public int getPropagationConditions(int vIdx) {
        if (bothEnumerated)
            return IntEventType.all();
        else
            return IntEventType.boundAndInst();
    }

    @SuppressWarnings("StatementWithEmptyBody")
    private void updateBounds() throws ContradictionException {
//        System.out.printf("before: %s, %s%n", x, y);
        while (x.updateLowerBound(y.getLB() > 0 ? y.getLB() + 1 : 0, aCause) | y.updateLowerBound(x.getLB() > 0 ? x.getLB() - 1 : 0, aCause));
        while (x.updateUpperBound(y.getUB() + 1, aCause) | y.updateUpperBound(x.getUB() > 0 ? x.getUB() - 1 : 0, aCause));
//        System.out.printf("after : %s, %s%n", x, y);
    }

    @Override
    public void propagate(int evtmask) throws ContradictionException {
        updateBounds();
        // ensure that, in case of enumerated domains,  holes are also propagated
        if (bothEnumerated) {
            int ub = x.getUB();
            for (int val = x.getLB(); val <= ub; val = x.nextValue(val)) {
                if (val != 0 && !(y.contains(val - 1))) {
                    x.removeValue(val, aCause);
                }
                if (val == 0 && !(y.contains(0))) {
                    x.removeValue(val, aCause);
                }
            }
            ub = y.getUB();
            for (int val = y.getLB(); val <= ub; val = y.nextValue(val)) {
                if (val != 0 && !(x.contains(val + 1))) {
                    y.removeValue(val, aCause);
                }
                if (val == 0 && !(x.contains(0) || x.contains(val +1)))
                    y.removeValue(val, aCause);
            }
            idms[0].unfreeze();
            idms[1].unfreeze();
        }
        if (x.isInstantiated()) {
            assert (y.isInstantiated());
            // no more test should be done on the value,
            // filtering algo ensures that both are assigned to the same value
            setPassive();
        }
    }


    @Override
    public void propagate(int varIdx, int mask) throws ContradictionException {
        updateBounds();
        if (x.isInstantiated()) {
            assert (y.isInstantiated());
            setPassive();
        } else if (bothEnumerated) {
            indexToFilter = 1 - varIdx;
            idms[varIdx].freeze();
            idms[varIdx].forEachRemVal(rem_proc);
            idms[varIdx].unfreeze();
        }
    }

    @Override
    public ESat isEntailed() {
        if (x.isInstantiated() &&
                y.isInstantiated() &&
                (y.getValue() + 1 == x.getValue() && y.getValue() >= 0) || x.getValue() == y.getValue() && y.getValue() == 0)
            return ESat.TRUE;
        else if ((y.getUB() + 1 < x.getLB()) ||
                (y.getLB() + 1 > x.getUB()) ||
                (y.getUB() < 0) ||
                x.hasEnumeratedDomain() && y.hasEnumeratedDomain() && !match()
                )
            return ESat.FALSE;
        else
            return ESat.UNDEFINED;
    }

    private boolean match() {
        int lb = y.getLB();
        int ub = y.getUB();
        for (; lb <= ub; lb = x.nextValue(lb)) {
            if (x.contains(lb+1) || (lb == 0 && x.contains(lb))) return true;
        }
        return false;
    }

    private class RemProc implements IntProcedure {
        @Override
        public void execute(int i) throws ContradictionException {
            vars[indexToFilter].removeValue(i, aCause);
        }
    }

    @Override
    public String toString() {
        return "prop(" + vars[0].getName() + ".EQ." + vars[1].getName() + "+ 1)";
    }

    @Override
    public void explain(ExplanationEngine xengine, Deduction d, Explanation e) {
        if (d.getVar() == x) {
            e.add(xengine.getPropagatorActivation(this));
            if (d.getmType() == Deduction.Type.ValRem) {
                y.explain(xengine, VariableState.REM, ((ValueRemoval) d).getVal(), e);
            } else {
                throw new UnsupportedOperationException("PropEqualXY only knows how to explain ValueRemovals");
            }
        } else if (d.getVar() == y) {
            e.add(xengine.getPropagatorActivation(this));
            if (d.getmType() == Deduction.Type.ValRem) {
                x.explain(xengine, VariableState.REM, ((ValueRemoval) d).getVal(), e);
            } else {
                throw new UnsupportedOperationException("PropEqualXY only knows how to explain ValueRemovals");
            }
        } else {
            super.explain(xengine, d, e);
        }
    }

    @Override
    public void duplicate(Solver solver, THashMap<Object, Object> identitymap) {
        if (!identitymap.containsKey(this)) {
            this.vars[0].duplicate(solver, identitymap);
            IntVar X = (IntVar) identitymap.get(this.vars[0]);
            this.vars[1].duplicate(solver, identitymap);
            IntVar Y = (IntVar) identitymap.get(this.vars[1]);

            identitymap.put(this, new PropXEqYPlus1(X, Y));
        }
    }
}
