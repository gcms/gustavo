package fr.inria.spirals.fm.locators

/**
 * Created by gustavo on 11/06/15.
 */
interface VariableLocator {
    public String getName()
}