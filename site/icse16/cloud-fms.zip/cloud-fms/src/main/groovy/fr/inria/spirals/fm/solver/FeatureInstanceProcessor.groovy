package fr.inria.spirals.fm.solver

import fr.inria.spirals.fm.locators.FeatureInstanceLocator

/**
 * Created by gustavo on 16/06/15.
 */
interface FeatureInstanceProcessor extends VariableProcessor<FeatureInstanceLocator> {
    void process(SolverBuildingContext context, FeatureInstanceLocator instancePath)
}