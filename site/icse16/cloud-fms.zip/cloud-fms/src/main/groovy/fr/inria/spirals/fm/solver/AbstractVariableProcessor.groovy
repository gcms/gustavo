package fr.inria.spirals.fm.solver

import fr.inria.spirals.fm.locators.VariableLocator

/**
 * Created by gustavo on 16/06/15.
 */
abstract class AbstractVariableProcessor<T extends VariableLocator> extends ContextAwareProcessor implements VariableProcessor<T> {
    AbstractVariableProcessor(SolverBuildingContext context) {
        super(context)
    }

    abstract void process(T locator)
}
