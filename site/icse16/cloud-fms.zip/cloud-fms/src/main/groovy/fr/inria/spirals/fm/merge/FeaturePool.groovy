package fr.inria.spirals.fm.merge

import fr.inria.spirals.fm.model.Feature

/**
 * Created by gustavo on 21/04/15.
 */
class FeaturePool extends AbstractSet<Feature> {
    Map<String, Feature> features = [:]

    public FeaturePool(Collection<Feature> features) {
        features.each { Feature feat ->
            this.features.put(feat.name, feat)
        }
    }

    @Override
    Iterator<Feature> iterator() {
        features.values().iterator()
    }

    @Override
    int size() {
        features.size()
    }

    Feature get(Feature feature) {
        features.get(feature.name)
    }

    boolean contains(Feature feature) {
        features.containsKey(feature.name)
    }
}
