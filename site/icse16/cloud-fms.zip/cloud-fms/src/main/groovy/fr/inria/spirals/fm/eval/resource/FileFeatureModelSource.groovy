package fr.inria.spirals.fm.eval.resource
/**
 * Created by gustavo on 22/08/15.
 */
class FileFeatureModelSource implements FeatureModelSource {
    FeatureModelResource res

    FileFeatureModelSource(File file) {
        res = new FileFeatureModelResource(file: file)
    }

    @Override
    Iterator<FeatureModelResource> iterator() {
        [res].iterator()
    }
}
