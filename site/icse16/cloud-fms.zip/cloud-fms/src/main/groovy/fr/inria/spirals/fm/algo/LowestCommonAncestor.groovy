package fr.inria.spirals.fm.algo

import fr.inria.spirals.fm.model.FeatureNode

/**
 * Created by gustavo on 11/06/15.
 */
class LowestCommonAncestor {
    static FeatureNode calculate(Collection<FeatureNode> nodes) {
        def itr = nodes.iterator()

        FeatureNode result = itr.next()
        while (itr.hasNext()) {
            result = calculate(result, itr.next())
        }

        return result
    }

    static FeatureNode calculate(FeatureNode n1, FeatureNode n2) {
        while (n1.depth > n2.depth)
            n1 = n1.parent

        while (n2.depth > n1.depth)
            n2 = n2.parent

        while (n1 != n2) {
            n1 = n1.parent
            n2 = n2.parent
        }

        return n1
    }
}
