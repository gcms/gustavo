package fr.inria.spirals.fm.eval.resource

/**
 * Created by gustavo on 22/08/15.
 */
interface FeatureModelSource extends Iterable<FeatureModelResource> {
}
