package fr.inria.spirals.fm.merge

import fr.inria.spirals.fm.model.FeatureModel

/**
 * Created by gustavo on 22/04/15.
 */
class MergingContext {
    FeatureModel featureModel

}
