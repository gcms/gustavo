package fr.inria.spirals.fm.solver

import fr.inria.spirals.fm.model.FeatureModel
import fr.inria.spirals.fm.locators.VariableLocator
import org.chocosolver.solver.constraints.Constraint
import org.chocosolver.solver.variables.IntVar

/**
 * Created by gustavo on 16/06/15.
 */
abstract class ContextAwareProcessor {
    protected SolverBuildingContext context

    VariableManager getVariableManager() {
        context.variableManager
    }

    ConstraintManager getConstraintManager() {
        context.constraintManager
    }

    FeatureModel getFeatureModel() {
        context.featureModel
    }

    IntVar getVariable(VariableLocator locator) {
        variableManager.getVariable(locator)
    }

    IntVar[] getVariables(Iterable<VariableLocator> locators) {
        variableManager.getVariables(locators)
    }

    void post(Constraint... constraint) {
        constraintManager.post(constraint)
    }

    public ContextAwareProcessor(SolverBuildingContext context) {
        this.context = context
    }
}
