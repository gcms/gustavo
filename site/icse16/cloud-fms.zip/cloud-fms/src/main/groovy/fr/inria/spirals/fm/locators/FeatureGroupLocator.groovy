package fr.inria.spirals.fm.locators
/**
 * Created by gustavo on 11/06/15.
 */
class FeatureGroupLocator implements VariableLocator {
    private FeatureInstanceLocator featIndex
    private String name

    FeatureGroupLocator(FeatureInstanceLocator featIndex) {
        if (!featIndex.feature.group)
            throw new IllegalArgumentException("Feature ${featIndex.feature.name} is not a group")
        this.featIndex = featIndex

        name = featIndex.name + "<group>"
    }

    @Override
    String getName() {
        name
    }
}
