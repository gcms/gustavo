package fr.inria.spirals.fm.eval

import fr.inria.spirals.fm.model.Cardinality
import fr.inria.spirals.fm.model.FeatureModel
import fr.inria.spirals.fm.InvalidCardinalitiesException
import fr.inria.spirals.fm.model.FeatureNode
import fr.inria.spirals.fm.model.RelativeCardinality

import org.slf4j.Logger
import org.slf4j.LoggerFactory

/**
 * Created by gustavo on 11/08/15.
 */
class RelativeCardinalityGenerator extends FeatureModelGenerator {
    static Logger log = LoggerFactory.getLogger(RelativeCardinalityGenerator)

    int relativeCardinalityPercentage = 50

    public FeatureModel addRelativeCardinalities(FeatureModel fm) {
        def copy = fm.copy()

        while (copy == fm || !hasRelativeCard(copy)) {
            log.debug "- generating cardinalities to add"
            generateAndAddRelativeCardinalities(copy)
        }

        copy
    }

    public FeatureModel generateAndAddRelativeCardinalities(FeatureModel copy) {
        log.debug '- getFeaturesWithCard'
        def localCardFeatures = getFeaturesWithCardinalities(copy)

        log.debug '- getPairs'
        def localCardPairs = localCardFeatures.collect { FeatureNode feature ->
            def ancestor = getRandomAncestor(feature)
            def descendant = getRandomDescendant(feature)

            if (ancestor == null || descendant == null)
                return null

            [from: descendant, pivot: feature, to: ancestor]
        }.findAll { it != null }.sort { it.from.depth }

        log.debug '- sublisting'
        localCardPairs = localCardPairs.subList(0, (int) localCardFeatures.size() * relativeCardinalityPercentage / 100)
        log.debug "- startUpdating ${localCardPairs.size()}"
        localCardPairs.eachWithIndex { Map cardMap, i ->
            log.debug "- Updating ${i}"
            generateAndAddRelativeCardinality(copy, cardMap.to, cardMap.pivot, cardMap.from)
        }

        copy
    }

    private void generateAndAddRelativeCardinality(FeatureModel fm, FeatureNode a, FeatureNode b, FeatureNode c) {
        log.debug "update(${a.name}, ${b.name}, ${c.name})"
        assert a != b && b != c
        assert c.isDescendantOf(b) && b.isDescendantOf(a)

        log.debug '- Getting inferrer'
        def ci = fm.getInferrer()

        def minVar = ci.getMinValue(c, a)
        def maxVar = ci.getMaxValue(c, a)

        def maxVarMin = ci.getMaxValueMin(c, a)
        def maxVarMax = ci.getMaxValueMax(c, a)

        def newMaxVar = (int) maxVarMin + (maxVarMax - maxVarMin) / 2

//        if (inferred.get(c, a).max != maxVar || inferred.get(c, a).min != minVar)
//            throw new IllegalStateException("${inferred.get(c, a).toString()} <> [$minVar..$maxVar]")

        String debug = "(${a.name}, ${b.name}, ${c.name}) min: ${minVar}, max: ${maxVar} in [$maxVarMin..$maxVarMax], newMax: ${newMaxVar}"
        log.debug debug

//        fm.removeCardinality(c, b)
        if (maxVar != newMaxVar)
        try {
            log.debug 'Adding new Card'
            fm.addCardinality(c, a, new Cardinality(minVar, newMaxVar), maxVar != newMaxVar) //maxVar

            System.gc()
            fm.getInferrer()
        } catch (InvalidCardinalitiesException ex) {
            log.debug fm
            fm.removeCardinality(c, a)
            log.error "${ex.message} ${debug}\n${fm}"
//            throw ex
        }

    }

    FeatureNode getRandomAncestor(FeatureNode node) {
        List ancestors = node.getAncestors()
        ancestors[random.nextInt(ancestors.size())]
    }

    FeatureNode getRandomDescendant(FeatureNode node) {
        List descendants = node.getDescendants()
        descendants[random.nextInt(descendants.size())]
    }

    private static List<FeatureNode> getFeaturesWithCardinalities(FeatureModel fm) {
        getLocalCardinalities(fm).collect { rc ->
            rc.from.children.empty ? rc.to : rc.from
        }.unique().findAll { !it.isRoot() }
    }

    private static Collection<RelativeCardinality> getLocalCardinalities(FeatureModel fm) {
        fm.getDeclaredCardinalities().asCollection().
                findAll { it.isLocal() && it.cardinality.max > 1 }
    }

    public static boolean hasRelativeCard(FeatureModel fm) {
            fm.declaredCardinalities.any { it.from.parent != it.to }
    }
}
