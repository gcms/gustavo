package fr.inria.spirals.fm.eval.resource

import fr.inria.spirals.fm.model.FeatureModel

/**
 * Created by gustavo on 22/08/15.
 */
class GeneratedFeatureModelResource implements FeatureModelResource {
    int numFeats
    int maxDepth
    int maxCard
    int probCardUpper
    int probCardOther

    FeatureModel featureModel

    @Override
    FeatureModel getFeatureModel() {
        featureModel
    }

    public Map getConfig() {
        [
            numFeats: numFeats,
            maxDepth: maxDepth,
            maxCard: maxCard,
            probCardUpper: probCardUpper,
            probCardLower: probCardOther
        ]
    }

    @Override
    FeatureModelResource getBaseModelResource() {
        return null
    }
}
