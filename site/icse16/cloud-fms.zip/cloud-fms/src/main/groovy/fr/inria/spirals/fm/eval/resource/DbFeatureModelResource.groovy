package fr.inria.spirals.fm.eval.resource

import fr.inria.spirals.fm.model.FeatureModel
import fr.inria.spirals.fm.loader.xtext.XtextLoader

/**
 * Created by gustavo on 22/08/15.
 */
class DbFeatureModelResource implements FeatureModelResource {
    Long id
    Long baseModelId
    String model
    Map config

    FeatureModel getFeatureModel() {
        XtextLoader.INSTANCE.loadFeatureModel(model)
    }


    @Override
    FeatureModelResource getBaseModelResource() {
        throw new IllegalStateException()
    }
}
