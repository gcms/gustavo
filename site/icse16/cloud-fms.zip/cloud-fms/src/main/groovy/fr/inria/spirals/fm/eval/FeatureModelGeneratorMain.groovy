package fr.inria.spirals.fm.eval

import fr.inria.spirals.fm.model.FeatureModel
import fr.inria.spirals.fm.loader.xtext.XtextLoader
import groovyjarjarcommonscli.CommandLine
import groovyjarjarcommonscli.GnuParser
import groovyjarjarcommonscli.HelpFormatter
import groovyjarjarcommonscli.MissingOptionException
import groovyjarjarcommonscli.Options

import static MainUtils.opt
/**
 * Created by gustavo on 20/07/15.
 */

class FeatureModelGeneratorMain {
    public static void main(String[] args) {
        Options options = new Options()

        options.addOption(opt('f', 'feats', Number, true, "Number of features"))
        options.addOption(opt('d', 'depth', Number, false, "Maximum depth"))
        options.addOption(opt('c', 'card', Number, false, 'Maximum cardinality'))
        options.addOption(opt('pu', 'probCardUpper', Number, false, 'Probability of upper feature (depth <= 2) having cardinality'))
        options.addOption(opt('pl', 'probCardLower', Number, false, 'Probability of lower depth having cardinality'))
        options.addOption(opt('db', 'database', String, false, 'Sqlite database'))
        options.addOption(opt('o', 'output', String, false, 'Feature model output [db | stdout | filename]'))

        def parser = new GnuParser()

        CommandLine cl
        try {
            cl = parser.parse(options, args)
        } catch (MissingOptionException ex) {
            println ex.message
            new HelpFormatter().printHelp("generate", options)
            System.exit(-1)
            return
        }

        Integer nFeatures = cl.getParsedOptionValue('f')
        Integer maxDepth = cl.getParsedOptionValue('d') ?: nFeatures
        Integer maxCardinality = cl.getParsedOptionValue('c') ?: 10
        Integer probCardinalityUpper = cl.getParsedOptionValue('pu') ?: 50
        Integer probCardinalityOther = cl.getParsedOptionValue('pl') ?: 1
        String output = cl.getParsedOptionValue('o')


        String connString = cl.getOptionValue('db') ?: DbManager.DEFAULT_DB
        Map config = [
                numFeats: nFeatures,
                maxDepth: maxDepth,
                maxCard: maxCardinality,
                probCardUpper: probCardinalityUpper,
                probCardLower: probCardinalityOther
        ]

        def fmGenerator = new FeatureModelGenerator(
                maxDepth: maxDepth,
                maxCard: maxCardinality,
                probCardUpper: probCardinalityUpper,
                probCardOther: probCardinalityOther)

        FeatureModel fm = fmGenerator.generate(nFeatures)

        if (output != null && output.toLowerCase().trim() == 'db') {
            def db = new DbManager(connString: connString)
            String configName = db.getConfig(config)
            Long id = db.addFeatureModel(configName, fm)
            println "Feature model saved with id ${id}"
        } else if (output == null || output.toLowerCase().trim() == 'stdout') {
            println XtextLoader.INSTANCE.convert(fm)
        } else {
            new File(output).text = XtextLoader.INSTANCE.convert(fm)
            println "Feature model saved to ${output}"
        }
    }
}
