package fr.inria.spirals.fm.eval

/**
 * Created by gustavo on 22/08/15.
 */
class RunResult {
    /**
     * Time to parse the model
     */
    long parse = -1

    /**
     * Time to infer cardinalities and check consistency
     */
    long inference = -1

    /**
     * Time to translate feature model to CSP
     */
    long buildSolver = -1

    /**
     * Time to generate a valid configuration
     */
    long findConfig = -1

    /** Time to build configuration checker, translate config to CSP */
    long buildChecker = -1

    /** Time to check configuration */
    long solveChecker = -1

    long fmNumInstances
    long fmNumLocators
    long fmNumVars
    long configNumInstances

    String toString() {
        properties.findAll{ k, v ->
            v instanceof Long && v > 0
        }.toString()
    }
}
