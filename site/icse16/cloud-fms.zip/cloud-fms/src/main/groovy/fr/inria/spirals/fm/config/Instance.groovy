package fr.inria.spirals.fm.config

import fr.inria.spirals.fm.model.FeatureNode

/**
 * Created by gustavo on 13/06/15.
 */
class Instance {

    private int number
    private FeatureNode node

    Instance parent
    List<Instance> children = []

    public Instance(Instance parent, int number, FeatureNode feature) {
        if (number == 0 || feature == null)
            throw new IllegalArgumentException("Invalid instance configuration ${number} ${feature}")

        this.parent = parent
        this.number = number
        this.node = feature
    }

    public FeatureNode getFeature() {
        node
    }

    void addChild(Instance child) {
        children << child
    }

    List<Instance> getChildrenOf(FeatureNode feature) {
        if (feature.parent != this.feature)
            throw new IllegalArgumentException("Invalid subFeature type ${feature.name}")

        expandInstances(children.findAll { it.feature == feature})
    }

    public static List<Instance> expandInstances(Collection<Instance> instances) {
        instances.collect { expandInstance(it) }.flatten()
    }

    public static List<Instance> expandInstance(Instance instance) {
        instance.number == 1 ? [instance] : doExpandInstance(instance)
    }

    public static List<Instance> doExpandInstance(Instance instance) {
        (0..<instance.number).collect { instance.copy() }
    }

    public Instance copy() {
        def result = new Instance(parent, 1, feature)
        result.children = children
        result
    }
}
