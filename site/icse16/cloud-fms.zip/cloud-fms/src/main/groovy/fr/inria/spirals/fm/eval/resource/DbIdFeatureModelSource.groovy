package fr.inria.spirals.fm.eval.resource

import fr.inria.spirals.fm.eval.DbManager

/**
 * Created by gustavo on 22/08/15.
 */
class DbIdFeatureModelSource implements FeatureModelSource {
    DbManager db
    Long id

    public DbIdFeatureModelSource(DbManager db, Long id) {
        this.db = db
        this.id = id
    }

    Iterator<FeatureModelResource> iterator() {
        Map map = db.loadFeatureModelMap(id)
        [new DbFeatureModelResource(id: map.id, model: map.model, baseModelId: map.baseModelId, config: [name: map.configName])].iterator()
    }
}
