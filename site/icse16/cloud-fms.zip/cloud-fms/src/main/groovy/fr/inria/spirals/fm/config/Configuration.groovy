package fr.inria.spirals.fm.config

import fr.inria.spirals.fm.model.FeatureModel

/**
 * Created by gustavo on 13/06/15.
 */
class Configuration {
    private List<Instance> instances = []
    private FeatureModel featureModel

    public Configuration(FeatureModel fm) {
        featureModel = fm
    }

    public void addInstance(Instance instance) {
        if (instance == null)
            throw new NullPointerException("Instance is null")

        instances << instance
    }

    public List<Instance> getInstances() {
        Instance.expandInstances(instances)
    }

    public FeatureModel getFeatureModel() {
        featureModel
    }

    public boolean isComplete() {
        instances.size() == 1 && isRoot(instances.first())
    }

    private boolean isRoot(Instance instanceRoot) {
        instanceRoot.feature == featureModel.root &&
                instanceRoot.children.every { isCompleteInstance(it) }
    }

    private boolean isCompleteInstance(Instance instance) {
        instance.feature.parent == instance.parent.feature &&
                instance.children.every { isCompleteInstance(it) }
    }
}
