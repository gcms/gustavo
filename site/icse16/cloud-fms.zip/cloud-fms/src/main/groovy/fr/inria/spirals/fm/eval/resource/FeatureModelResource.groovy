package fr.inria.spirals.fm.eval.resource

import fr.inria.spirals.fm.model.FeatureModel

/**
 * Created by gustavo on 22/08/15.
 */
interface FeatureModelResource {
    FeatureModel getFeatureModel()

    Map getConfig()

    FeatureModelResource getBaseModelResource()
}
