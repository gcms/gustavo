package fr.inria.spirals.fm

/**
 * Created by gustavo on 22/04/15.
 */
interface Converter<T, K> {
    K convert(T t)
}