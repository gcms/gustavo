package fr.inria.spirals.fm.solver.builder

import fr.inria.spirals.fm.model.Cardinality
import fr.inria.spirals.fm.model.RelativeCardinality
import fr.inria.spirals.fm.locators.FeatureInstanceLocator
import fr.inria.spirals.fm.locators.RelativeCardinalityLocator
import fr.inria.spirals.fm.solver.AbstractVariableProcessor
import fr.inria.spirals.fm.solver.SolverBuildingContext
import org.chocosolver.solver.constraints.ICF
import org.chocosolver.solver.constraints.LCF
import org.chocosolver.solver.variables.IntVar
import org.slf4j.Logger
import org.slf4j.LoggerFactory

/**
 * Created by gustavo on 16/06/15.
 */
class RelativeCardinalityBuilder extends AbstractVariableProcessor<FeatureInstanceLocator> {
    private static Logger log = LoggerFactory.getLogger(RelativeCardinalityBuilder)

    RelativeCardinalityBuilder(SolverBuildingContext context) {
        super(context)
    }

    public static void addRelativeCardinalityConstraints(SolverBuildingContext context, FeatureInstanceLocator featIndex) {
        def relativeCards = context.featureModel.getDeclaredNotLocalCardinalitiesTo(featIndex.feature)

        for (def relativeCardinality : relativeCards) {
            addRelativeCardinalityConstraint(context, featIndex, relativeCardinality)
        }
    }

    private static IntVar getRcVar(SolverBuildingContext context, RelativeCardinalityLocator rcLocator, Cardinality card) {
        context.variableManager.getVariable(rcLocator) ?: createRcVar(context, rcLocator, card)
    }

    private static IntVar createRcVar(SolverBuildingContext context, RelativeCardinalityLocator rcLocator, Cardinality card) {
        IntVar[] vars = context.variableManager.getVariables(rcLocator.instances)
        IntVar sumVar = context.variableManager.createVariable(rcLocator, 0, card.max)
        context.constraintManager.post(ICF.sum(vars, sumVar))
        log.debug "${rcLocator} = sum(${vars.join(', ')}) 	//RelativeCardinality"
        sumVar
    }

    public static void addRelativeCardinalityConstraint(SolverBuildingContext context, FeatureInstanceLocator featIndex, RelativeCardinality rc) {
        def rcPath = new RelativeCardinalityLocator(featIndex, rc)

        IntVar sumVar = getRcVar(context, rcPath, rc.cardinality)

        context.constraintManager.post(LCF.ifThen_reifiable(
                ICF.arithm(context.variableManager.getVariable(featIndex), ">", 0),
                ICF.member(sumVar, rc.cardinality.min, rc.cardinality.max)))


        log.debug "if ${featIndex} > 0 then ${rcPath} >= ${rc.cardinality.min}"

    }

    @Override
    void process(FeatureInstanceLocator instancePath) {
        addRelativeCardinalityConstraints(context, instancePath)
    }
}
