package fr.inria.spirals.fm

import fr.inria.spirals.fm.model.FeatureNode

/**
 * Created by gustavo on 22/04/15.
 */
class FeatureInstance {
    private Configuration configuration

    private FeatureInstance parent
    private FeatureNode feature
    private int index

    private Set<FeatureInstance> children = new LinkedHashSet()

    public FeatureInstance(Configuration configuration, FeatureInstance parent, FeatureNode feature, int index) {
        if (index < 1)
            throw new IllegalArgumentException("Index ${index} less than 1")

        this.configuration = configuration
        this.parent = parent
        this.feature = feature
        this.index = index

        configuration.addInstance(this)
        if (parent) {
            parent.addChildren(this)
        }
    }

    FeatureNode getFeature() {
        feature
    }

    void addChildren(FeatureInstance child) {
        children << child
    }

    String getPath() {
        (parent ? parent.path : "") + "/${feature.name}[${index}]"
    }

    boolean equals(Object other) {
        if (!(other instanceof FeatureInstance))
            return false

        other.path == path
    }

    int hashCode() {
        path.hashCode()
    }

    String toString() {
        getPath()
    }

    Collection<FeatureInstance> getChildren() {
        children
    }

    boolean removeChildren(FeatureInstance instance) {
        children.contains(instance) &&
                configuration.removeInstance(instance) &&
                children.remove(instance)
    }
}
