package fr.inria.spirals.fm.loader.saloon
import org.eclipse.emf.common.util.TreeIterator
import org.eclipse.emf.common.util.URI
import org.eclipse.emf.ecore.EObject
import org.eclipse.emf.ecore.EPackage
import org.eclipse.emf.ecore.EcorePackage
import org.eclipse.emf.ecore.resource.Resource
import org.eclipse.emf.ecore.resource.ResourceSet
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl
import org.eclipse.emf.ecore.xmi.impl.EcoreResourceFactoryImpl
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl
/**
 * Created by gustavo on 07/04/15.
 */
class EMFManager {
    private ResourceSet rs

    private static EMFManager _instance
    public static EMFManager getINSTANCE() {
        _instance ?: (_instance = new EMFManager())
    }

    public EMFManager() {
        rs = new ResourceSetImpl()
        Resource.Factory.Registry registry = rs.getResourceFactoryRegistry();

        Map<String,Object> m = registry.getExtensionToFactoryMap();
        m.put("ecore", new EcoreResourceFactoryImpl());
        m.put("xmi", new XMIResourceFactoryImpl());

        EPackage.Registry packageRegistry = rs.getPackageRegistry();
        packageRegistry.put(EcorePackage.eNS_URI, EcorePackage.eINSTANCE);
    }

    private EObject load(URI uri) {
        Resource resource = rs.getResource(uri, true);
        if (resource.isLoaded() && resource.getContents().size() > 0) {
            TreeIterator<EObject> tree = (TreeIterator<EObject>) resource.getAllContents();

            // The returned tree first element is the root Feature.
            // Without next(), the tree first element would be the container package.
            return tree.next();
        }
        return null;
    }

    public EObject loadEcore(URL url) {
        EPackage ecore = load(URI.createURI(url.toString()))
        if (ecore != null) {
            registerPackage(ecore)
        }
        ecore
    }

    void registerPackage(EPackage ecore) {
        rs.getPackageRegistry().put(ecore.getNsURI(), ecore);
//        rs.getPackageRegistry().each { k, v ->
//            println "${k}: ${v.class.name}"
//        }
//        println '---'
    }

    EObject loadXMI(URL url) {
        load(URI.createURI(url.toString()))
    }
}
