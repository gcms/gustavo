package fr.inria.spirals.fm.solver.builder

import fr.inria.spirals.fm.model.FeatureGroup
import fr.inria.spirals.fm.locators.FeatureInstanceLocator
import fr.inria.spirals.fm.solver.AbstractVariableProcessor
import fr.inria.spirals.fm.solver.SolverBuildingContext
import org.chocosolver.solver.constraints.ICF
import org.chocosolver.solver.constraints.LCF
import org.slf4j.Logger
import org.slf4j.LoggerFactory

/**
 * Created by gustavo on 16/06/15.
 */
class GroupConstraintBuilder extends AbstractVariableProcessor<FeatureInstanceLocator> {
    private static Logger log = LoggerFactory.getLogger(GroupConstraintBuilder)

    GroupConstraintBuilder(SolverBuildingContext context) {
        super(context)
    }

    @Override
    void process(FeatureInstanceLocator instancePath) {
        if (!instancePath.feature.group)
            return

        addGroupConstraints(instancePath, instancePath.feature as FeatureGroup)
    }

    private void addGroupConstraints(FeatureInstanceLocator groupIdx, FeatureGroup group) {
        def groupVar = variableManager.createVariable(groupIdx.group, 0, group.children.size())

        // Since it's not possible to count the features greater than 0 we count the 0s
        def vars = variableManager.getVariables(groupIdx.children)

        post(ICF.count(0, vars, groupVar))
        def max0s = group.children.size() - group.groupCardinality.min
        def min0s = group.children.size() - group.groupCardinality.max

        post(LCF.ifThenElse_reifiable(
                CF.positive(getVariable(groupIdx)),
                CF.member(groupVar, min0s, max0s),
                CF.equal(groupVar, group.children.size())))
        log.debug "${groupVar.name} = count0s(${vars*.name.join(", ")} \t//Group"

//        post(CF.countDiff(0, vars, groupVar))
//        post(LCF.ifThenElse_reifiable(
//                CF.positive(getVariable(groupIdx)),
//                CF.member(groupVar, group.groupCardinality.min, group.groupCardinality.max),
//                CF.zero(groupVar)))
//
//        log.debug "if ${groupIdx} > 0 then ${groupVar.name} >= ${group.groupCardinality.from} else ${groupVar.name} = 0 \t//Group"
    }
//
//    private Constraint count(String op, int value, IntVar[] vars, IntVar limit) {
//        new Constraint("CountOP", new PropCount_OP(vars, op, value, limit));
//    }
//
//    private void addGroupConstraints2(FeatureInstanceLocator groupIdx, FeatureGroup group) {
//        def groupVar = variableManager.createVariable(groupIdx.group, 0, group.children.size())
//
//        def vars = variableManager.getVariables(groupIdx.children)
//        log.debug "${groupVar.name} = sum>0(${vars*.name.join(", ")} \t//Group"
//        post(count(">", 0, vars, groupVar))
//
//        post(LCF.ifThenElse_reifiable(
//                ICF.arithm(variableManager.getVariable(groupIdx), ">", 0),
//                LCF.and(
//                        ICF.arithm(groupVar, ">=", group.groupCardinality.min),
//                        ICF.arithm(groupVar, "<=", group.groupCardinality.max)),
//                ICF.arithm(groupVar, "=", group.children.size())))
//
//        log.debug "if ${groupIdx} > 0 then ${groupVar.name} >= ${group.groupCardinality.from} else ${groupVar.name} = 0 \t//Group"
//
//    }
}
