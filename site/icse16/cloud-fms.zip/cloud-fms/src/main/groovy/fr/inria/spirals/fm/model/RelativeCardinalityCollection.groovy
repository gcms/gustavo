package fr.inria.spirals.fm.model

/**
 * Created by gustavo on 09/06/15.
 */
class RelativeCardinalityCollection extends AbstractMap<FeaturePair, Cardinality> {
    Set<RelativeCardinality> inner = new LinkedHashSet()

    public RelativeCardinalityCollection() {
    }

    public RelativeCardinalityCollection(Collection<RelativeCardinality> cards) {
        cards.each { add(it) }
    }

    @Override
    Set<Map.Entry<FeaturePair, Cardinality>> entrySet() {
        inner
    }

    public Collection<RelativeCardinality> asCollection() {
        inner
    }

    public RelativeCardinality add(FeatureNode from, FeatureNode to, Cardinality cardinality) {
        def result = new RelativeCardinality(from, to, cardinality)
        add(result)
        result
    }

    public void add(RelativeCardinality cardinality) {
        remove(cardinality.key)
        inner.add(cardinality)
    }

    public Cardinality get(FeatureNode from, FeatureNode to) {
        get(new FeaturePair(from, to))
    }
}
