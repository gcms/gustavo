package fr.inria.spirals.fm.eval

import fr.inria.spirals.fm.Configuration
import fr.inria.spirals.fm.FeatureInstance
import fr.inria.spirals.fm.model.FeatureModel
import fr.inria.spirals.fm.solver.FeatureModelSolver
import fr.inria.spirals.fm.solver.SolverBuilder
import org.slf4j.Logger
import org.chocosolver.solver.search.loop.monitors.SMF
import org.slf4j.LoggerFactory

/**
 * Created by gustavo on 19/08/15.
 */
class FeatureModelProcessor {
    static Logger log = LoggerFactory.getLogger(FeatureModelProcessor)

    static void main(String[] args) {
        DbManager manager = new DbManager()
        FeatureModelProcessor processor = new FeatureModelProcessor()

//        for (Map fm : manager.listFeatureModels('where num_feats = 2500 and base_model_id is not null and id > 3147')) {
        for (Map fm : manager.listFeatureModels('where num_feats in (1000, 2500)')) {
            RunResult result = processor.process(fm)

            if (fm.numInstances == null) {
                println "${fm.id}: ${fm.numFeats}"

                println 'updating'
                manager.updateFeatureModel(fm.id, [numInstances: result.fmNumInstances,
                                                   numLocators: result.fmNumLocators,
                                                   numVars: result.fmNumVars])
            }
        }
    }

    public RunResult run(RunConfig config, FeatureModel fm) {
        RunResult result = new RunResult()

        if (!config.inference)
            return result

        log.info "- Inferring cardinalities"
        result.inference = Measurer.inference(fm)

        if (!config.buildSolver)
            return result

        log.info "- Building solver"
        SolverBuilder builder = new SolverBuilder().setFeatureModel(fm)
        FeatureModelSolver solver

        result.buildSolver =  Measurer.measure {
            solver = builder.buildSolver()
        }

        result.fmNumInstances = solver.variableManager.numInstances
        result.fmNumLocators = solver.variableManager.numLocators
        result.fmNumVars = solver.variableManager.numVars

        if (!config.findConfig)
            return result


        log.info "- Finding config"
        if (config.limitTime > 0)
            SMF.limitTime(solver.solver, config.limitTime)

        Iterator<Configuration> itr
        Configuration fmConfig
        result.findConfig = Measurer.measure {
            itr = solver.solutions.iterator()
            fmConfig = itr.next()
        }

        if (!config.checkConfig)
            return result

        (1..<config.numConfig).each { int i ->
            if (itr.hasNext()) {
                log.info "- Finding next config ${i+1}"
                fmConfig = itr.next()
            }
        }

        if (!config.validConfig)
            invalidateConfig(fmConfig)

        result.configNumInstances = fmConfig.instances.size()

        log.info "- Building configuration checker"
        builder = new SolverBuilder().setConfiguration(fmConfig.toConfig())
        FeatureModelSolver configChecker
        result.buildChecker = Measurer.measure {
            configChecker = builder.buildChecker()
        }

        log.info "- Checking configuration"
        result.solveChecker = Measurer.measure {
            def valid = configChecker.isSatisfied()
            log.info "Valid: ${valid}"
        }


        result
    }

    private RunResult process(Map fm) {
        println "- process $fm.id ($fm.numFeats)"

        RunResult result = run(new RunConfig(validConfig: false), fm.model.toString())
        println result.dump()

//        println "${fm.id} ${fm.baseModelId} ${fm.numFeats} ${config.instances.size()} ${numSol} ${checking} ${solving} ${findSolution} ${buildSolver} ${inference}"
//        ps.println "${fm.id} ${fm.baseModelId} ${fm.numFeats} ${config.instances.size()} ${numSol} ${checking} ${solving} ${findSolution} ${buildSolver} ${inference}"
        result
    }

    private void invalidateConfig(Configuration config) {
        log.info "- Invalidating config"
        FeatureInstance parent
        def instance = config.root

        WHILE:
        while (!instance.children.empty) {
            parent = instance

            for (def inst : instance.children) {
                if (inst.feature.localCardinality.min > 0) {
                    instance = inst
                    break WHILE
                }
            }

            instance = instance.children.iterator().next()
        }

        log.debug "Remove ${instance} from ${parent}"

        parent.removeChildren(instance)
    }
}
