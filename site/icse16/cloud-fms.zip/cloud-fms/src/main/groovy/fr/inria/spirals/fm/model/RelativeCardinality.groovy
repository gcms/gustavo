package fr.inria.spirals.fm.model

/**
 * Created by gustavo on 09/06/15.
 */
class RelativeCardinality implements Map.Entry<FeaturePair, Cardinality> {
    private FeatureNode from
    private FeatureNode to

    private Cardinality cardinality

    public RelativeCardinality(FeatureNode from, FeatureNode to, Cardinality card) {
        if (!from.isDescendantOf(to))
            throw new IllegalArgumentException("Node ${from.name} is not descendant of ${to.name}")

        this.from = from
        this.to = to
        this.cardinality = card
    }

    public FeatureNode getFrom() {
        from
    }

    public FeatureNode getTo() {
        to
    }

    public Cardinality getCardinality() {
        cardinality
    }

    public int hashCode() {
        from.hashCode() * 3 + to.hashCode() * 21 + cardinality.hashCode()
    }

    @Override
    FeaturePair getKey() {
        new FeaturePair(from, to)
    }

    @Override
    Cardinality getValue() {
        cardinality
    }

    @Override
    Cardinality setValue(Cardinality value) {
        throw new UnsupportedOperationException("Value cannot be changed")
    }

    public boolean equals(Object other) {
        if (!(other instanceof RelativeCardinality))
            return false

        def rc = other as RelativeCardinality

        rc.from == from && rc.to == to && rc.cardinality == cardinality
    }

    String toString() {
        "[${cardinality.min}..${cardinality.max}] (${from.name}, ${to.name})"
    }

    String toStringRelative() {
        "<${to.name}>[${cardinality.toString()}]"
    }

    boolean isLocal() {
        from.parent != null && from.parent == to
    }
}
