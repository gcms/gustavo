package fr.inria.spirals.fm.model.expr

import fr.inria.spirals.fm.model.FeatureModel
import fr.inria.spirals.fm.model.FeatureNode

/**
 * Created by gustavo on 23/07/15.
 */
abstract class ComposedExpression extends Expression {
    Set<Expression> subExpressions

    protected ComposedExpression(FeatureModel fm, Collection<Expression> expressions) {
        super(fm)
        subExpressions = expressions
    }

    @Override
    Set<FeatureNode> getFeatures() {
        subExpressions.collect { it.features }.flatten()
    }

    Set<ConstrainingExpression> getConstrainingExpressions() {
        subExpressions.collect { it.getConstrainingExpressions() }.flatten()
    }
}
