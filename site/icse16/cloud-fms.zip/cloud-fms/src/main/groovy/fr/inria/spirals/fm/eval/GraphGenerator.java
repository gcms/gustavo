package fr.inria.spirals.fm.eval;

/**
 * Created by gustavo on 20/07/15.
 */

import java.util.HashSet;
import java.util.Random;
import java.util.Set;


public class GraphGenerator {

    public static class Graph {
        private final int V;
        private int E;
        private Set<Integer>[] adj;

        public Graph(int V) {
            if (V < 0) throw new IllegalArgumentException("Number of vertices must be nonnegative");
            this.V = V;
            this.E = 0;
            adj = new Set[V];
            for (int v = 0; v < V; v++) {
                adj[v] = new HashSet<>();
            }
        }

        public int V() {
            return V;
        }

        public int E() {
            return E;
        }


        private void validateVertex(int v) {
            if (v < 0 || v >= V)
                throw new IndexOutOfBoundsException("vertex " + v + " is not between 0 and " + (V-1));
        }

        public void addEdge(int v, int w) {
            validateVertex(v);
            validateVertex(w);
            E++;
            adj[v].add(w);
            adj[w].add(v);
        }

        public Set<Integer> adj(int v) {
            validateVertex(v);
            return adj[v];
        }
    }

    private static Random random = new Random(System.currentTimeMillis());

    public static Graph tree(int V, int maxDepth) {
        Graph G = new Graph(V);
        if (V == 1) return G;

        if (V > 1 && maxDepth == 1)
            throw new IllegalArgumentException("Invalid tree with more than one node and maximum depth 1");

        int[] depths = new int[V];
        depths[0] = 1;

        for (int i = 1; i < V; i++) {
            int parent = -1;
            while (parent == -1 || depths[parent] == maxDepth) {
                parent = random.nextInt(i);
            }
            G.addEdge(parent, i);
            depths[i] = depths[parent] + 1;
        }

        return G;
    }

}
