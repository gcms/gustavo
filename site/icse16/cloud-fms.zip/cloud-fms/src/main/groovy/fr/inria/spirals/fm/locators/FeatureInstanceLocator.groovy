package fr.inria.spirals.fm.locators

import fr.inria.spirals.fm.model.FeatureNode

/**
 * Created by gustavo on 21/04/15.
 */
class FeatureInstanceLocator implements VariableLocator {
    protected FeatureInstanceLocator parent
    protected FeatureNode feature
    protected int index

    private String name

    @Override
    String getName() {
        name
    }

    public FeatureNode getFeature() {
        feature
    }

    String toString() {
        getName()
    }

    public FeatureInstanceLocator(FeatureInstanceLocator parent, FeatureNode feature, int index) {
        this.parent = parent
        this.feature = feature
        this.index = index

        this.name = (parent ? parent.name : "") + "/" + feature.name + '[' + index + ']'
    }

    Collection<FeatureLocator> getChildren() {
        feature.children.collect {
            new FeatureLocator(this, it)
        }
    }

    FeatureGroupLocator getGroup() {
        new FeatureGroupLocator(this)
    }

    Collection<FeatureInstanceLocator> getInstancesOf(FeatureNode node) {
        if (feature == node)
            return [this]

        children.collect { it.getInstancesOf(node) }.flatten()
    }

    FeatureInstanceLocator getAncestor(FeatureNode node) {
        FeatureInstanceLocator result = this
        while (result.feature != node)
            result = result.parent

        return result
    }

    FeatureLocator getFeatureLocator() {
        new FeatureLocator(parent, feature)
    }
}
