package fr.inria.spirals.fm.model.expr

import fr.inria.spirals.fm.model.FeatureNode

/**
 * Created by gustavo on 22/04/15.
 */
class FeatureModelConstraint {
    FeatureNode context
    Expression condition
    Expression action

    FeatureModelConstraint(FeatureNode context, Expression condition, Expression action) {
        this.context = context
        this.condition = condition
        this.action = action
    }

    String toString() {
        "<${context.name}> ${condition} => ${action}"
    }

    Set<FeatureNode> getFeatures() {
        condition.features + action.features + context
    }

    Set<ConstrainingExpression> getConstrainingExpressions() {
        condition.constrainingExpressions + action.constrainingExpressions
    }
}
