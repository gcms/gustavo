package fr.inria.spirals.fm.model

/**
 * Created by gustavo on 09/06/15.
 */
class Cardinality extends IntRange implements Range<Integer> {
    Cardinality(int from, int to) {
        super(from, to)
    }

    Cardinality(IntRange range) {
        super(range.from, range.to)
    }

    protected Cardinality(int from, int to, boolean reverse) {
        super(from, to, reverse)
    }

    Cardinality(boolean inclusive, int from, int to) {
        super(inclusive, from, to)
    }

    int getMin() {
        from
    }

    int getMax() {
        to
    }

    String toString() {
        "${min}..${max}"
    }

    Cardinality multiply (Cardinality other) {
        new Cardinality(this.min * other.min, this.max * other.max)
    }

    Cardinality div (Cardinality other) {
        new Cardinality((int) (this.min/other.min), (int) (this.max / other.max))
    }

}
