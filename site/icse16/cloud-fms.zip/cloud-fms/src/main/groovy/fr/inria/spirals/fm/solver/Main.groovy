package fr.inria.spirals.fm.solver

import fr.inria.spirals.fm.model.FeatureModel
import fr.inria.spirals.fm.config.Configuration
import fr.inria.spirals.fm.loader.xtext.XtextLoader
import groovyjarjarcommonscli.GnuParser
import groovyjarjarcommonscli.HelpFormatter
import groovyjarjarcommonscli.Option
import groovyjarjarcommonscli.OptionGroup
import groovyjarjarcommonscli.Options


/**
 * Created by gustavo on 15/06/15.
 */
class Main {
    public static void main(String[] args) {
        Options options = new Options()
        options.addOption('fmp', 'fmpath', true, "Feature model paths")
        options.addOption('v', 'verbose', false, "Verbose")

        def operation = new OptionGroup()
        operation.addOption(new Option('g', 'Check if feature model has solutions'))
        operation.addOption(new Option('f', 'Generate solutions from partial configuration'))
        operation.addOption(new Option('c', 'Check configuration'))
        options.addOptionGroup(operation)

        def parser = new GnuParser()
        def cl = parser.parse(options, args)

        def classPath = []
        if (cl.hasOption("fmp")) {
            classPath = cl.getOptionProperties("fmp").keySet().collect { String str ->
                str.tokenize(":")
            }.flatten().findAll { new File(it).exists() }
        }

//        println classPath

        def loader = new XtextLoader(classPath)
        def files = cl.argList.findAll { new File(it).exists() }.collect {
            loader.load(new File(it).toURI().toURL())
        }

        if (files.empty) {
            new HelpFormatter().printHelp("config [options] <files>", options)
            System.exit(-1)
        }


        def builder = new SolverBuilder()

        for (def resource : files) {

            def solver
            if (cl.hasOption('c')) {
                solver = builder.setConfiguration(resource as Configuration).buildChecker()
            } else if (cl.hasOption('f')) {
                solver = builder.setConfiguration(resource as Configuration).buildSolver()
            } else if (cl.hasOption('g')) {
                solver = builder.setFeatureModel(resource as FeatureModel).buildSolver()
            } else if (resource instanceof Configuration) {
                solver = builder.setConfiguration(resource as Configuration).buildSolver()
            } else if (resource instanceof FeatureModel) {
                solver = builder.setFeatureModel(resource as FeatureModel).buildSolver()
            }

            def solutionIterator = solver.getSolutions().iterator()
//            prinln "Solutions for ${file}"
            int i = 0
            while (solutionIterator.hasNext() && i++ < 10) {
                println solutionIterator.next().printHierarchy()
            }

        }



//        println cl.getOptionProperties("fmp")
//        println cl.getOptionValue("fmp")
//        println cl.getParsedOptionValue("fmp")
//
//        println cl.getArgList()


//
//        return
//
//
//        def path = new File(args[0])
//
//        int number = 1
//        if (args.length > 1 ) {
//            number = Integer.parseInt(args[1])
//        }
//
//        def config = XtextLoader.INSTANCE.loadConfiguration(path.toURI().toURL())
////        def fm = config.featureModel
//
//        def sf = new SolverFactory().createSolver(config)
//
//        def solutions = sf.getSolutions().iterator()
//
//        while (number-- > 0) {
//            println "-" * 20
//            def solution = solutions.next()
//            println(solution.printHierarchy())
//            println "-" * 20
//        }

    }
}
