package fr.inria.spirals.fm.eval.resource

import fr.inria.spirals.fm.model.FeatureModel

/**
 * Created by gustavo on 22/08/15.
 */
class RelativeCardinalityFeatureModelResource implements FeatureModelResource {
    FeatureModel featureModel
    FeatureModelResource baseResource

    public RelativeCardinalityFeatureModelResource(FeatureModel featureModel, FeatureModelResource baseResource) {
        this.featureModel = featureModel
        this.baseResource = baseResource
    }

    @Override
    Map getConfig() {
        baseResource.config
    }


    @Override
    FeatureModelResource getBaseModelResource() {
        baseResource
    }
}
