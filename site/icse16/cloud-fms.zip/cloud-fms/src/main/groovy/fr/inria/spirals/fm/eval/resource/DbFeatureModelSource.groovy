package fr.inria.spirals.fm.eval.resource

import fr.inria.spirals.fm.eval.DbManager

/**
 * Created by gustavo on 22/08/15.
 */
class DbFeatureModelSource implements FeatureModelSource {
    private DbManager db
    private Long numFeats

    public DbFeatureModelSource(DbManager db, Long numFeats) {
        this.db = db
        this.numFeats = numFeats
    }

    Iterator<FeatureModelResource> iterator() {
        String query = numFeats != null ? "where num_feats = ${numFeats}" : null

        db.listFeatureModels(query).collect { Map map ->
            new DbFeatureModelResource(id: map.id, model: map.model,  baseModelId: map.baseModelId, config: [name: map.configName])
        }.iterator()
    }
}
