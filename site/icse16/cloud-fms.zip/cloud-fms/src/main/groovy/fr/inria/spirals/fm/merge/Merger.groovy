package fr.inria.spirals.fm.merge

import fr.inria.spirals.fm.model.Feature
import fr.inria.spirals.fm.model.FeatureModel

/**
 * Created by gustavo on 21/04/15.
 */
class Merger {
    FeatureComparator comparator

    Merger(FeatureComparator comparator = new FeatureComparator()) {
        this.comparator = comparator
    }


    public FeatureModel merge(FeatureModel fm1, FeatureModel fm2) {
        FeatureModel fm = new FeatureModel()
        fm.root = merge(fm, null, fm1.root, fm2.root)
        fm
    }

    public Feature merge(FeatureModel fm, Feature parent, Feature lFeat, Feature rFeat) {
        if (!comparator.areEquiv(lFeat, rFeat))
            throw new IllegalArgumentException("Features ${lFeat} and ${rFeat} aren't equivalent")

        println "Merging ${lFeat} with ${rFeat}"

        Feature merged = fm.createFeature(parent)
        merged.name = lFeat.name
        merged.setFeatureCardinality(
                Math.min(lFeat.cardinality.from, rFeat.cardinality.from),
                Math.max(lFeat.cardinality.to, rFeat.cardinality.to))


        FeaturePool lChildren = new FeaturePool(lFeat.children)
        FeaturePool rChildren = new FeaturePool(rFeat.children)

        for (Feature l : lChildren) {
            if (rChildren.contains(l)) {
                Feature r = rChildren.get(l)
                rChildren.remove(r)

                merged.addChild(merge(fm, merged, l, r))
            } else {
                merged.addChild(relax(fm, merged, l))
            }
        }

        for (Feature r : rChildren) {
            merged.addChild(relax(fm, merged, r))
        }

        merged
    }

    public Feature relax(FeatureModel fm, Feature parent, Feature feat) {
        println "Relaxing ${feat}"
        Feature relaxed = fm.createFeature(parent)
        relaxed.name = feat.name
        relaxed.setFeatureCardinality(0, feat.cardinality.to)
        feat.children.each { Feature child ->
            relaxed.addChild(relax(fm, relaxed, child))
        }
        relaxed
    }
}
