package fr.inria.spirals.fm.eval

import fr.inria.spirals.fm.model.FeatureModel
import fr.inria.spirals.fm.loader.xtext.XtextLoader
import groovyjarjarcommonscli.*

import static MainUtils.opt

/**
 * Created by gustavo on 20/07/15.
 */

class RelativeCardinalityGeneratorMain {
    public static void main(String[] args) {
        Options options = new Options()

        options.addOption(opt('i', 'input', Number, false, "Feature model input [ database id | 'stdin' | filename ] defaults to stdin"))
        options.addOption(opt('o', 'output', String, false, "Feature model output ['db' | 'stdout' | filename] defaults to stdout"))
        options.addOption(opt('rc', 'relativeCard', Number, false, 'Percentage of cardinalities which are relative'))
        options.addOption(opt('db', 'database', String, false, 'Sqlite database'))


        def parser = new GnuParser()

        CommandLine cl
        try {
            cl = parser.parse(options, args)
        } catch (MissingOptionException ex) {
            println ex.message
            new HelpFormatter().printHelp("add_relative_cardinalities", options)
            System.exit(-1)
            return
        }

        Integer rc = cl.getParsedOptionValue('rc') ?: 50
        String input = cl.getParsedOptionValue('i')
        String output = cl.getParsedOptionValue('o')


        String connString = cl.getOptionValue('db') ?: DbManager.DEFAULT_DB
        def db = new DbManager(connString: connString)

        String configName = null

        String fmString
        if (input == null || input.trim().toLowerCase() == 'stdin' || input.trim() == '')
            fmString = new InputStreamReader(System.in).text
        else if (input.isNumber()) {
            Map fm = db.loadFeatureModelMap(Long.parseLong(input))
            configName = fm.configName
            fmString = fm.model
        } else {
            fmString = new File(input).text
        }


        FeatureModel inputFm = XtextLoader.INSTANCE.loadFeatureModel(fmString)

        def cardGenerator = new RelativeCardinalityGenerator(relativeCardinalityPercentage: rc)

        FeatureModel outputFm = cardGenerator.addRelativeCardinalities(inputFm)

        if (output != null && output.toLowerCase().trim() == 'db') {
            Long id = db.addFeatureModel(configName, outputFm)
            println "Feature model saved with id ${id}"
        } else if (output == null || output.toLowerCase().trim() == 'stdout') {
            println XtextLoader.INSTANCE.convert(outputFm)
        } else {
            new File(output).text = XtextLoader.INSTANCE.convert(outputFm)
            println "Feature model saved to ${output}"
        }
    }
}
