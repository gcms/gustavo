package fr.inria.spirals.fm.eval.resource

import fr.inria.spirals.fm.model.FeatureModel
import fr.inria.spirals.fm.loader.xtext.XtextLoader

/**
 * Created by gustavo on 22/08/15.
 */
class FileFeatureModelResource implements FeatureModelResource {
    File file

    @Override
    FeatureModel getFeatureModel() {
        XtextLoader.INSTANCE.loadFeatureModel(file.toURI().toURL())
    }

    @Override
    Map getConfig() {
        [name: file.name]
    }

    @Override
    FeatureModelResource getBaseModelResource() {
        return null
    }
}
