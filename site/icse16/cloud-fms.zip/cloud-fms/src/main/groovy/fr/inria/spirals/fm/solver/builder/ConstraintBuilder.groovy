package fr.inria.spirals.fm.solver.builder

import fr.inria.spirals.fm.model.FeatureNode
import fr.inria.spirals.fm.algo.LowestCommonAncestor
import fr.inria.spirals.fm.model.expr.FeatureModelConstraint
import fr.inria.spirals.fm.locators.FeatureInstanceLocator
import fr.inria.spirals.fm.locators.FeatureLocator
import fr.inria.spirals.fm.solver.AbstractVariableProcessor
import fr.inria.spirals.fm.solver.SolverBuildingContext
import org.chocosolver.solver.constraints.Constraint
import org.chocosolver.solver.constraints.LCF
import org.slf4j.Logger
import org.slf4j.LoggerFactory
/**
 * Created by gustavo on 16/06/15.
 */
class ConstraintBuilder extends AbstractVariableProcessor<FeatureLocator> {
    private static Logger log = LoggerFactory.getLogger(ConstraintBuilder)

    ConstraintBuilder(SolverBuildingContext context) {
        super(context)
    }

    @Override
    void process(FeatureLocator featurePath) {
        if (featurePath.feature.isRoot()) {
            featureModel.constraints.each { FeatureModelConstraint it ->
                buildConstraint(featurePath, it)
            }
        }
    }


    private void buildConstraint(FeatureLocator root, FeatureModelConstraint constraint) {
        FeatureNode context = constraint.context
        FeatureNode commonAncestor = LowestCommonAncestor.calculate(constraint.features)

        for (def contextPath : root.getInstancesOf(context)) {
            def contextAncestor = contextPath.getAncestor(commonAncestor)
            buildConstraint(contextPath, contextAncestor, constraint)
        }
    }

    private void buildConstraint(FeatureInstanceLocator contextPath, FeatureInstanceLocator contextAncestor, FeatureModelConstraint constraint) {
        log.debug "buildConstraint <${contextPath.name}> ${constraint} | commonAncestor ${contextAncestor.name}"
        ExpressionBuilder builder = new ExpressionBuilder(context, contextPath, contextAncestor)

        log.debug " IF ------"
        Constraint cond = builder.buildExpression(constraint.condition)
        log.debug " THEN ----"
        Constraint action = builder.buildExpression(constraint.action)
        log.debug " ENDIF ---"

        post(LCF.ifThen_reifiable(cond, action))
    }
}

