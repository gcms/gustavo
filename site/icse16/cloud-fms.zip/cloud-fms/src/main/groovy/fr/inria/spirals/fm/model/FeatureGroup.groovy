package fr.inria.spirals.fm.model

/**
 * Created by gustavo on 07/04/15.
 */
class FeatureGroup extends FeatureNode {
    protected FeatureGroup(String name, FeatureModel fm, FeatureNode parent) {
        super(name, fm, parent)
    }

    protected FeatureGroup(String name, FeatureModel fm, FeatureNode parent, Cardinality groupCardinality) {
        super(name, fm, parent)
        this.groupCardinality = groupCardinality
    }

    Cardinality groupCardinality

    String toString() {
        "${super.toString()} <${groupCardinality.toString()}>"
    }

    @Override
    boolean isGroup() {
        true
    }

    Set<FeatureNode> getVariants() {
        children
    }
}
