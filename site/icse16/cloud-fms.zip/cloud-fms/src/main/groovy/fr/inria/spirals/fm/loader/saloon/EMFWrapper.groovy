package fr.inria.spirals.fm.loader.saloon

import org.eclipse.emf.common.util.EList
import org.eclipse.emf.ecore.EClass
import org.eclipse.emf.ecore.EObject
import org.eclipse.emf.ecore.EStructuralFeature

/**
 * Created by gustavo on 07/04/15.
 */
class EMFWrapper {
    private EObject eObject

    public EObject eObject() {
        eObject
    }

    public EClass eClass() {
        eObject.eClass()
    }

    public EMFWrapper(EObject object) {
        eObject = object
    }

    public Object propertyMissing(String property) {
        for (EStructuralFeature esf : eClass().getEAllStructuralFeatures()) {
            if (esf.getName() == property)
                return wrap(eObject.eGet(esf))
        }

        null
    }

    public void propertyMissing(String property, Object value) {
        for (EStructuralFeature esf : eClass().getEAllStructuralFeatures()) {
            if (esf.getName() == property) {
                eObject.eSet(esf, unwrap(value))
                return
            }
        }
    }

    public Map getProperties() {
        eClass().getEAllStructuralFeatures().collectEntries { EStructuralFeature attr ->
            [(attr.name): wrap(eObject.eGet(attr))]
        }
    }

    String toString() {
        eObject.toString()
    }

    public static Object wrap(EObject object) {
        new EMFWrapper(object)
    }

    public static List wrap(EList<EObject> object) {
        object.collect { wrap(it) }
    }

    public static Object unwrap(Object object) {
        object
    }

    public static Object unwrap(EMFWrapper wrapper) {
        wrapper.eObject()
    }

    public static Object wrap(Object object) {
        if (object instanceof EObject)
            throw new RuntimeException("Should go to the other overloaded method")

        object
    }
}
