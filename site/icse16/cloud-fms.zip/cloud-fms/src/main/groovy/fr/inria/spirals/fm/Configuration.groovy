package fr.inria.spirals.fm

import fr.inria.spirals.fm.model.FeatureModel
import fr.inria.spirals.fm.model.FeatureNode

/**
 * Created by gustavo on 22/04/15.
 */
class Configuration {
    private FeatureModel featureModel

    Set<FeatureInstance> instances = new LinkedHashSet()

    public Configuration(FeatureModel featureModel) {
        this.featureModel = featureModel
    }

    FeatureModel getFeatureModel() {
        featureModel
    }

    void addInstance(FeatureInstance featureInstance) {
        instances << featureInstance
    }

    Collection<FeatureInstance> getInstancesOf(FeatureNode feature) {
        instances.findAll { it.feature == feature}
    }

    FeatureInstance getRoot() {
        instances.find { it.feature == featureModel.root }
    }

    String toString() {
        "[${instances*.path.join(", ")}]"
    }

    public boolean equals(Object other) {
        if (!(other instanceof Configuration))
            return false

        (other.instances).equals(instances)
    }

    int hashCode() {
        instances.hashCode()
    }

    String printHierarchy() {
        def sw = new StringWriter()
        PrintWriter pw = new PrintWriter(sw)

        print("", root, pw)
        pw.flush()

        sw.toString()
    }

    static void print(String tab, FeatureInstance node, PrintWriter pw) {
        pw.printf("%s|--%s%n", tab, node.feature.name)

        node.children.eachWithIndex { FeatureInstance child, int idx ->
            print(tab + '|  ', child, pw)
        }
    }

    fr.inria.spirals.fm.config.Configuration toConfig() {
        def config = new fr.inria.spirals.fm.config.Configuration(featureModel)
        config.addInstance(convert(null, root))
        config
    }

    private fr.inria.spirals.fm.config.Instance convert(fr.inria.spirals.fm.config.Instance parent, FeatureInstance instance) {
        def result = new fr.inria.spirals.fm.config.Instance(parent, 1, instance.feature)
        instance.children.each {
            result.addChild(convert(result, it))
        }
        result
    }

    boolean removeInstance(FeatureInstance instance) {
        instances.remove(instance)
    }
}
