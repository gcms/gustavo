package fr.inria.spirals.fm.solver

import fr.inria.spirals.fm.Configuration
import fr.inria.spirals.fm.Converter
import fr.inria.spirals.fm.FeatureInstance
import fr.inria.spirals.fm.locators.FeatureInstanceLocator
import fr.inria.spirals.fm.model.FeatureModel
import fr.inria.spirals.fm.locators.FeatureLocator
import org.chocosolver.solver.search.solution.Solution

/**
 * Created by gustavo on 22/04/15.
 */
class SolutionConverter implements Converter<Solution, Configuration> {
    private FeatureModel featureModel
    private VariableManager vm
    FeatureLocator rootPath

    public SolutionConverter(FeatureModel featureModel, VariableManager vm, FeatureLocator rootPath) {
        this.featureModel = featureModel
        this.vm = vm
        this.rootPath = rootPath
    }

    public Configuration convert(Solution solution) {
        Configuration config = new Configuration(featureModel)

        convertFeature(solution, config, null, rootPath)

        config
    }

    private void convertFeature(Solution solution, Configuration config, FeatureInstance parent, FeatureLocator locator) {
        for (FeatureInstanceLocator instanceLocator : locator.instances) {
            int value = solution.getIntVal(vm.getVariable(instanceLocator))
            if (value < 0 || value > 1)
                throw new IllegalStateException("Selectionable variables should not have cardinalities")

            if (value == 0) // all following values should be 0
                break

            FeatureInstance featInstance = new FeatureInstance(config, parent, instanceLocator.feature, instanceLocator.index)
            config.addInstance(featInstance)

            convertInstance(solution, config, featInstance, instanceLocator)
        }
    }

    private void convertInstance(Solution solution, Configuration config, FeatureInstance instance, FeatureInstanceLocator instanceLocator) {
        for (FeatureLocator featureLocator : instanceLocator.children) {
            convertFeature(solution, config, instance, featureLocator)
        }
    }
}
