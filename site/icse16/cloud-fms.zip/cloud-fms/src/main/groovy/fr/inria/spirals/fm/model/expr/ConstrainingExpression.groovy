package fr.inria.spirals.fm.model.expr

import fr.inria.spirals.fm.model.FeatureModel
import fr.inria.spirals.fm.model.FeatureNode
import fr.inria.spirals.fm.model.Cardinality

/**
 * Created by gustavo on 09/06/15.
 */
class ConstrainingExpression extends Expression {
    Cardinality cardinality
    FeatureNode from
    FeatureNode to

    public ConstrainingExpression(FeatureModel fm, Cardinality cardinality, FeatureNode from, FeatureNode to) {
        super(fm)

        if (!from.isDescendantOf(to))
            throw new IllegalArgumentException("$from is not descendant of $to")

//        Cardinality relative = from.getRelativeCardinalityTo(to)
//        if (cardinality.min < relative.min || cardinality.max > relative.max)
//            throw new IllegalArgumentException("Cardinality $cardinality exceeds relative cardinality $relative")

        this.cardinality = cardinality
        this.from = from
        this.to = to
    }

    String toString() {
        "[${cardinality.toString()}] ($from.name, $to.name)"
    }

    @Override
    Set<FeatureNode> getFeatures() {
        [from, to]
    }

    @Override
    Set<ConstrainingExpression> getConstrainingExpressions() {
        [this]
    }

    int hashCode() {
        toString().hashCode() + from.featureModel.hashCode()
    }

    boolean equals(Object other) {
        if (!(other instanceof ConstrainingExpression))
            return false

        ConstrainingExpression ce = other

        toString() == ce.toString() && featureModel == ce.featureModel
    }
}
