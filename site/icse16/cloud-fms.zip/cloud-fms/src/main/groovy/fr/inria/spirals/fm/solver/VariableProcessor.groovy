package fr.inria.spirals.fm.solver

import fr.inria.spirals.fm.locators.VariableLocator

/**
 * Created by gustavo on 16/06/15.
 */
interface VariableProcessor<T extends VariableLocator> {
    public void process(T locator)

}