package fr.inria.spirals.fm.locators

import fr.inria.spirals.fm.model.FeatureNode
import fr.inria.spirals.fm.config.Instance

/**
 * Created by gustavo on 16/06/15.
 */
class InstanceFeatureLocator extends FeatureLocator {
    protected Collection<Instance> configInstances

    protected InstanceFeatureLocator(FeatureInstanceLocator parent, FeatureNode feature, Collection<Instance> instances) {
        super(parent, feature)
//        if (!instances.every { it.feature == feature})
//            throw new IllegalArgumentException("Instances are not of ${feature.name} type")
        if (instances.collect { it.feature }.unique().size() > 1)
            throw new IllegalArgumentException("Mixed instance types")

        this.configInstances = instances
    }

    List<FeatureInstanceLocator> getInstances() {
        int idx = 1
        configInstances.collect { it ->
            new InstanceFeatureInstanceLocator(parent, feature, it, idx++)
        }
    }
}
