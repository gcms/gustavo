package fr.inria.spirals.fm.eval

import fr.inria.spirals.fm.model.FeatureModel
import fr.inria.spirals.fm.eval.resource.DbFeatureModelResource
import fr.inria.spirals.fm.loader.xtext.XtextLoader
import org.apache.log4j.Logger

import java.sql.Connection
import java.sql.DriverManager
import java.sql.ResultSet
import java.sql.Statement

/**
 * Created by gustavo on 28/07/15.
 */
class DbManager {
    static Logger log = Logger.getLogger(RelativeCardinalityGenerator)
    public static String DEFAULT_DB = "jdbc:sqlite:src/main/resources/eval/eval.db"

    String connString = DEFAULT_DB

    static {
        Class.forName("org.sqlite.JDBC")
    }

    boolean addRun(Long id, String experiment, DbFeatureModelResource fm, String measure, long time) {
        String query = "insert into run (id, experiment, model_id, measure, value) values (?, ?, ?, ?, ?)"
        println query

        withConn { Connection conn ->
            def statement = conn.prepareStatement(query)
            statement.setLong(1, id)
            statement.setString(2, experiment)
            statement.setLong(3, fm.id)
            statement.setString(4, measure)
            statement.setLong(5, time)

            statement.executeUpdate() == 1
        }
    }

    Long getFeatureModel(FeatureModel featureModel, FeatureModel baseModel = null) {
        queryFeatureModel(featureModel) ?: addFeatureModel(featureModel, baseModel)
    }

    Long addFeatureModel(String config, FeatureModel featureModel, FeatureModel baseModel = null) {
        Long baseModelId = baseModel ? getFeatureModel(baseModel, null) : null

//        def vm = new SolverBuilder().setFeatureModel(featureModel).buildSolver().getVariableManager()
        String query = 'insert into featuremodel (model, num_feats, depth, base_model_id, config_name) values (?, ?, ?, ?, ?)'
        println query

        withConn { Connection conn ->
            def stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)
            stmt.setString(1, XtextLoader.INSTANCE.convert(featureModel))
            stmt.setInt(2, featureModel.features.size())
            stmt.setInt(3, featureModel.depth)
            stmt.setObject(4, baseModelId)
            stmt.setObject(5, config)
//            stmt.setLong(5, vm.numInstances)
//            stmt.setLong(6, vm.numLocators)
//            stmt.setLong(7, vm.numVars)

            stmt.executeUpdate() == 1 && stmt.generatedKeys.next() ? stmt.generatedKeys.getLong(1) : null
        }
    }

    DbFeatureModelResource queryFeatureModelResource(FeatureModel featureModel) {
        withConn { Connection conn ->
            def stmt = conn.prepareStatement('select id, model, base_model_id, config_name from featureModel where model = ?')
            stmt.setString(1, XtextLoader.INSTANCE.convert(featureModel))

            def rs = stmt.executeQuery()
            rs.next() ?  createResource(rs) : null
        }
    }

    DbFeatureModelResource addFeatureModelResource(LinkedHashMap<String, Object> config, FeatureModel featureModel, DbFeatureModelResource baseModel = null) {
        String configName = getConfig(config)

        Long baseModelId = baseModel ? baseModel.id : null
        String model = XtextLoader.INSTANCE.convert(featureModel)

        String query = 'insert into featuremodel (model, num_feats, depth, base_model_id, config_name) values (?, ?, ?, ?, ?)'
        println query

        withConn { Connection conn ->
            def stmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)
            stmt.setString(1, model)
            stmt.setInt(2, featureModel.features.size())
            stmt.setInt(3, featureModel.depth)
            stmt.setObject(4, baseModelId)
            stmt.setString(5, configName)

            stmt.executeUpdate() == 1 && stmt.generatedKeys.next() ?
                    new DbFeatureModelResource(id: stmt.generatedKeys.getLong(1), model: model, baseModelId: baseModelId, config: [name: config]) : null
        }
    }


    DbFeatureModelResource createResource(ResultSet rs) {
        new DbFeatureModelResource(id : rs.getLong(1),
                model: rs.getString(1),
                baseModelId: rs.getLong(2),
                config: [name: rs.getString(3)])
    }

    Long queryFeatureModel(FeatureModel featureModel) {
        withConn { Connection conn ->
            def stmt = conn.prepareStatement('select id from featureModel where model = ?')
            stmt.setString(1, XtextLoader.INSTANCE.convert(featureModel))

            def rs = stmt.executeQuery()
            rs.next() ? rs.getLong(1) : null
        }
    }

    FeatureModel loadFeatureModel(Long id) {
        withConn { Connection conn ->
            def stmt = conn.prepareStatement('select model from featureModel where id = ?')
            stmt.setLong(1, id)

            def rs = stmt.executeQuery()
            rs.next() ? XtextLoader.INSTANCE.loadFeatureModel(rs.getString(1)) : null
        }
    }

    private Object withConn(Closure closure) {
        Connection conn
        try {
            conn = DriverManager.getConnection(connString)
            return closure(conn)
        } finally {
            if (conn != null) {
                conn.close()
            }
        }
    }

    String getConfig(LinkedHashMap<String, Object> config) {
        queryConfig(config) ?: addConfig(config)
    }

    String addConfig(LinkedHashMap<String, Object> config) {
        String name = config.get('name') ?: config.collect { k, v -> "${k}${v}" }.join('')
        if (!config.containsKey('name'))
            config.put('name', name)

        List<String> params = config.keySet().asList()
        List<String> columns = params.collect { toUnderscore(it) }

        String query = "insert into configuration(${columns.join(', ')}) values (${params.collect{ '?' }.join(', ')})"
        println query

        withConn { Connection conn ->
            def stmt = conn.prepareStatement(query)
            params.eachWithIndex { param, i ->
                stmt.setObject(i + 1, config.get(param))
            }

            stmt.executeUpdate() == 1 ? name : null
        }
    }

    String queryConfig(LinkedHashMap<String, Object> config) {
        List<String> params = config.keySet().asList()
        List<String> columns = params.collect { toUnderscore(it) }

        String query = "select name from configuration where (${columns.collect { "${it} = ?" }.join(' and ')})"
        println query

        withConn { Connection conn ->
            def stmt = conn.prepareStatement(query)
            params.eachWithIndex { param, i ->
                stmt.setObject(i + 1, config.get(param))
            }

            def rs = stmt.executeQuery()
            rs.next() ? rs.getString(1) : null
        }
    }


    static String toUnderscore(String camel) {
        camel.replaceAll('([A-Z])', '_$1').toLowerCase()
    }

    List<Map> queryRun(Map<String, Object> config) {
        List<String> params = config.keySet().asList()
        List<String> columns = params.collect { toUnderscore(it) }

        String query = 'select start_time, model_id, inference_time, generation_time from run where ' + columns.collect { "${it} = ?" }.join(' and ')
        println query

        List<Map> result = []
        withConn { Connection conn ->
            def stmt = conn.prepareStatement(query)
            params.eachWithIndex { param, i ->
                stmt.setObject(i + 1, config.get(param))
            }

            def rs = stmt.executeQuery()
            while (rs.next()) {
                long modelId = rs.getLong(2)
                result << [
                        startTime: rs.getObject(1),
                        modelId: rs.getObject(2),
                        inferenceTime: rs.getObject(3),
                        generationTime: rs.getObject(4),
                        getFeatureModel: { loadFeatureModel(modelId) } as Closure
                ]
            }
        }

        result
    }

    boolean updateFeatureModel(Long id, Map<String, Object> config) {
        List<String> params = config.keySet().asList()
        List<String> columns = params.collect { toUnderscore(it) }

        String query = 'update featuremodel set ' + columns.collect { "$it = ?" }.join(', ') + ' where id = ?'
        withConn { Connection conn ->
            def stmt = conn.prepareStatement(query)
            params.eachWithIndex { param, i ->
                stmt.setObject(i + 1, config.get(param))
            }
            stmt.setObject(params.size() + 1, id)

            stmt.executeUpdate() == 1
        }
    }

    List<String> featureModelFields = ['id', 'model', 'numFeats', 'numInstances', 'numLocators', 'numVars', 'baseModelId', 'configName']

    List<Map> listFeatureModels(String cond = '') {
        List<String> columns = featureModelFields.collect { toUnderscore(it) }

        String query = "select ${columns.join(', ')} from featuremodel ${cond} order by id"
        withConn { Connection conn ->
            List result = []

            def stmt = conn.prepareStatement(query)

            def rs = stmt.executeQuery()

            while (rs.next()) {
                int i = 1
                result << featureModelFields.collectEntries { new MapEntry(it, rs.getObject(i++)) }
            }

            result
        }
    }

    Map loadFeatureModelMap(Long id) {
        List<String> columns = featureModelFields.collect { toUnderscore(it) }

        String query = "select ${columns.join(', ')} from featuremodel where id = ?"
        withConn { Connection conn ->
            def stmt = conn.prepareStatement(query)
            stmt.setLong(1, id)

            def rs = stmt.executeQuery()
            rs.next() ? featureModelRsToMap(rs) : null
        }
    }

    Map featureModelRsToMap(ResultSet rs) {
        int i = 0
        featureModelFields.collectEntries {
            new MapEntry(it, rs.getObject(++i))
        }
    }

}
