package fr.inria.spirals.fm.merge

import fr.inria.spirals.fm.model.Feature

/**
 * Created by gustavo on 21/04/15.
 */
class FeatureComparator {
    boolean areEquiv(Feature f1, Feature f2) {
        f1.name == f2.name
    }
}
