package fr.inria.spirals.fm.model.expr

import fr.inria.spirals.fm.model.FeatureModel
import fr.inria.spirals.fm.model.FeatureNode

/**
 * Created by gustavo on 10/06/15.
 */
abstract class Expression {
    private FeatureModel featureModel

    abstract Set<FeatureNode> getFeatures()

    abstract Set<ConstrainingExpression> getConstrainingExpressions()

    public Expression(FeatureModel fm) {
        featureModel = fm
    }

    public getFeatureModel() {
        featureModel
    }
}
