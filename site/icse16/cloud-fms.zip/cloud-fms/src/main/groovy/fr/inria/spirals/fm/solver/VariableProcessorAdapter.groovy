package fr.inria.spirals.fm.solver

import fr.inria.spirals.fm.locators.VariableLocator

/**
 * Created by gustavo on 16/06/15.
 */
class VariableProcessorAdapter<T extends VariableLocator> {
    Class<VariableProcessor<T>> processorClass

    VariableProcessorAdapter(Class<AbstractVariableProcessor<T>> processorClass) {
        this.processorClass = processorClass
    }

    void process(SolverBuildingContext context, T locator) {
        VariableProcessor<T> processor = processorClass.getConstructor(SolverBuildingContext).newInstance(context)
        processor.process(locator)
    }
}
