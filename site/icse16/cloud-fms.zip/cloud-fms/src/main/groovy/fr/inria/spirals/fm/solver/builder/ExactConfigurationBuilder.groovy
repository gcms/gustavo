package fr.inria.spirals.fm.solver.builder

import fr.inria.spirals.fm.locators.InstanceFeatureInstanceLocator
import fr.inria.spirals.fm.solver.AbstractVariableProcessor
import fr.inria.spirals.fm.solver.SolverBuildingContext
import org.slf4j.Logger
import org.slf4j.LoggerFactory
/**
 * Created by gustavo on 16/06/15.
 */
class ExactConfigurationBuilder  extends AbstractVariableProcessor<InstanceFeatureInstanceLocator> {
    private static Logger log = LoggerFactory.getLogger(ExactConfigurationBuilder)

    ExactConfigurationBuilder(SolverBuildingContext context) {
        super(context)
    }

    @Override
    void process(InstanceFeatureInstanceLocator locator) {
        log.debug "${locator} = 1"
        post(CF.equal(getVariable(locator), 1))
    }
}
