package fr.inria.spirals.fm.eval

import fr.inria.spirals.fm.loader.xtext.XtextLoader

/**
 * Created by gustavo on 23/07/15.
 */
class FeatureModelStatsMain {
    static void main(String[] args) {
        ArrayList<File> files = getFiles(args)

        String fmt = "%-10s | %-9s %-9s %-15s %-9s %-9s %-15s%30s%n"

        printf(fmt, 'Cloud', 'nFeatures', 'nFeatures', 'nFeatures', 'nCstrs', 'nCstrs', 'nCstrs', '')
        printf(fmt, '', '', 'w/Card', 'w/RelativeCard', '', 'w/Card', 'w/RelativeCard', '')
        println('-' * (84 + 30))

        files.each { fmFile ->
            def fm = XtextLoader.INSTANCE.loadFeatureModel(fmFile.toURI().toURL())
            def stats = new FeatureModelStats(fm)

            printf(fmt, fm.name, stats.numberOfFeatures, stats.numberOfFeaturesWithCardinalities, stats.numberOfFeaturesWithRelativeCardinalities,
                    stats.numberOfConstraints, stats.numberOfCardinalityConstraints, stats.numberOfRelativeCardinalityConstraints, stats.getPercentageOfCardinalityByDepth())
        }
    }

    private static ArrayList<File> getFiles(String[] args) {
        args.length == 0 ? listFilesFromDir(getDir()) :
                args.collect { getFiles(it) }.flatten()
    }

    private static List<File> getFiles(String path) {
        def file = new File(path)
        file.isDirectory() ? listFilesFromDir(file) : [file]
    }

    private static File getDir() {
        URL url = getClass().getResource('/teste.fm')
        if (url.protocol != 'file')
            throw new RuntimeException("Protocol != file")

        def file = new File(url.toURI())
        def dir = file.parentFile
        dir
    }

    private static List<File> listFilesFromDir(File dir) {
        dir.listFiles().findAll { it.name.endsWith('.fm') && !it.text.startsWith('config') }
    }
}
