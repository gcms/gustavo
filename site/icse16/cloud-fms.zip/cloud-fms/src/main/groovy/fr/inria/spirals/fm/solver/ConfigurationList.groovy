package fr.inria.spirals.fm.solver
import fr.inria.spirals.fm.Configuration
import fr.inria.spirals.fm.Converter
import fr.inria.spirals.fm.model.FeatureModel
import fr.inria.spirals.fm.locators.FeatureLocator
import org.chocosolver.solver.Solver
import org.chocosolver.solver.search.solution.Solution
/**
 * Created by gustavo on 22/04/15.
 */
class ConfigurationList implements Iterable<Configuration> {
    Converter<Solution, Configuration> converter
    Solver solver

    public ConfigurationList(FeatureModel featureModel, VariableManager vm, Solver solver, FeatureLocator rootPath) {
        converter = new SolutionConverter(featureModel, vm, rootPath)
        this.solver = solver
    }

    @Override
    Iterator<Configuration> iterator() {
        solver.solutionRecorder.lastSolution == null ?
            new SolutionIterator(hasNext: solver.findSolution()) :
            solver.solutionRecorder.solutions.collect { converter.convert(it) }.iterator()
    }

    private class SolutionIterator implements Iterator<Configuration> {
        private boolean hasNext

        @Override
        boolean hasNext() {
            hasNext
        }

        @Override
        Configuration next() {
            if (!hasNext)
                throw new IllegalStateException("Iterator does not have next element")

            Configuration result = converter.convert(solver.solutionRecorder.lastSolution)
            hasNext = solver.nextSolution()
            result
        }
    }
}
