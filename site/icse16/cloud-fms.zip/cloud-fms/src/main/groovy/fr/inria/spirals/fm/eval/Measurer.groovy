package fr.inria.spirals.fm.eval

import fr.inria.spirals.fm.model.FeatureModel
import fr.inria.spirals.fm.solver.FeatureModelSolver
import fr.inria.spirals.fm.solver.SolverBuilder

/**
 * Created by gustavo on 12/08/15.
 */
class Measurer {

    static long inference(FeatureModel fm, int nTimes) {
        (0..<nTimes).collect { inference(fm) }.min()
    }

    static long inference(FeatureModel fm) {
        fm.resetInferredCardinalities()
        long start = System.currentTimeMillis()
        fm.getInferredCardinalities()
        long end = System.currentTimeMillis()

        end - start
    }

    static long generation(FeatureModel fm, int nTimes) {
        (0..<nTimes).collect { generation(fm) }.min()
    }

    static long generation(FeatureModel fm) {
        def builder = new SolverBuilder().setFeatureModel(fm)
        long start = System.currentTimeMillis()
        def solver = builder.buildSolver()
        long end = System.currentTimeMillis()

        updateFeatureModel(fm, solver)


        end - start
    }

    private static void updateFeatureModel(FeatureModel fm, FeatureModelSolver solver) {
        def db = new DbManager()
        def fmId = db.getFeatureModel(fm)

        int numInstances = solver.variableManager.numInstances
        int numLocators = solver.variableManager.numLocators
        int numVars = solver.variableManager.numVars

        db.updateFeatureModel(fmId, [numInstances: numInstances, numLocators: numLocators, numVars: numVars])
    }

    static long measure(Closure closure) {
        long start = System.currentTimeMillis()
        closure()
        long end = System.currentTimeMillis()
        return end - start
    }
}
