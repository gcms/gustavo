package fr.inria.spirals.fm.eval

import groovyjarjarcommonscli.Option

/**
 * Created by gustavo on 22/08/15.
 */
class MainUtils {
    public static opt(String shortName, String longName, Class type, boolean required, String desc) {
        def option = new Option(shortName, longName, true, desc)
        option.type = type
        option.required = required
        option
    }

    public static opt(String shortName, String longName, String desc) {
        new Option(shortName, longName, false, desc)
    }
}
