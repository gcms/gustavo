package fr.inria.spirals.fm.solver.builder

import fr.inria.spirals.fm.model.FeatureNode
import fr.inria.spirals.fm.locators.FeatureInstanceLocator
import fr.inria.spirals.fm.locators.FeatureLocator
import fr.inria.spirals.fm.solver.AbstractVariableProcessor
import fr.inria.spirals.fm.solver.SolverBuildingContext
import org.chocosolver.solver.constraints.ICF
import org.chocosolver.solver.constraints.LCF
import org.chocosolver.solver.variables.IntVar
import org.slf4j.Logger
import org.slf4j.LoggerFactory

/**
 * Created by gustavo on 16/06/15.
 */
class HierarchyConstraintsBuilder extends AbstractVariableProcessor<FeatureLocator> {
    private static Logger log = LoggerFactory.getLogger(HierarchyConstraintsBuilder)

    HierarchyConstraintsBuilder(SolverBuildingContext context) {
        super(context)
    }

    @Override
    void process(FeatureLocator instancePath) {
        addHierarchyConstraints(instancePath)

        addMandatoryConstraints(instancePath)

        addCardinalityConstraints(instancePath)

    }

    private void addHierarchyConstraints(FeatureLocator featurePath) {
        FeatureNode feature = featurePath.feature
        FeatureInstanceLocator parentPath = featurePath.parent

        if (feature.isRoot()) {
            post(CF.equal(getVariable(featurePath), 1))
            log.debug "${featurePath} = 1"
        } else {
            post(LCF.ifThen_reifiable(
                    CF.positive(getVariable(featurePath)),
                    CF.positive(getVariable(parentPath))))

            log.debug "if ${featurePath} > 0 then ${parentPath} > 0 \t//Hierarchy"
        }
    }

    private void addMandatoryConstraints(FeatureLocator featurePath) {
        FeatureNode feature = featurePath.feature
        FeatureInstanceLocator parentPath = featurePath.parent

        if (feature.isRoot() || !feature.isMandatory())
            return

        if (feature.groupVariant) {
            post(LCF.ifThen_reifiable(
                    CF.positive(getVariable(featurePath)),
                    CF.member(getVariable(featurePath), feature.localCardinality.min, feature.localCardinality.max)))

            log.debug "if ${featurePath} > 0 then ${featurePath} in [${feature.localCardinality.toString()}] \t//Mandatory"
        } else {
            post(LCF.ifThenElse_reifiable(
                    CF.positive(getVariable(parentPath)),
                    CF.member(getVariable(featurePath), feature.localCardinality.min, feature.localCardinality.max),
                    CF.zero(getVariable(featurePath))))

            log.debug "if ${parentPath} > 0 then ${featurePath} in [${feature.localCardinality.toString()}] else ${featurePath} = 0 \t//Mandatory"
        }
    }

    private void addCardinalityConstraints(FeatureLocator featurePath) {
        List indexes = featurePath.instances

//        post(CF.array(getVariables(indexes), getVariable(featurePath)))
//        log.debug("${featurePath} = array(${indexes.join(", ")}) \t//Instance")

        IntVar[] subVars = variableManager.getVariables(indexes)

        post(ICF.sum(subVars, "=", getVariable(featurePath)))
        log.debug("${featurePath} = sum(${indexes.join(", ")}) \t//Instance")

        FeatureNode feature = featurePath.feature
//        for (int i = Math.max(feature.localCardinality.min, 1); i < feature.localCardinality.max; i++) {
        for (int i = 1; i < indexes.size(); i++) {
            /* Excludes duplicate equivalent solutions by requiring that if exists
               an instance in position i then an instance in position i-1 should also exist */
            post(LCF.ifThen_reifiable(
                    CF.positive(subVars[i]),
                    CF.positive(subVars[i - 1])))

            log.debug "if ${indexes[i]} > 0 then ${indexes[i - 1]} > 0 \t//CardinalityIndexes"
        }
    }
}
