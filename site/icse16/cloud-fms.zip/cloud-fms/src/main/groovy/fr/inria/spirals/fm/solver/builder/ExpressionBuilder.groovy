package fr.inria.spirals.fm.solver.builder
import fr.inria.spirals.fm.model.Cardinality
import fr.inria.spirals.fm.model.expr.AndExpression
import fr.inria.spirals.fm.model.expr.ConstrainingExpression
import fr.inria.spirals.fm.model.expr.Expression
import fr.inria.spirals.fm.model.expr.OrExpression
import fr.inria.spirals.fm.locators.FeatureInstanceLocator
import fr.inria.spirals.fm.locators.RelativeCardinalityLocator
import fr.inria.spirals.fm.solver.ContextAwareProcessor
import fr.inria.spirals.fm.solver.SolverBuildingContext
import org.chocosolver.solver.constraints.Constraint
import org.chocosolver.solver.constraints.ICF
import org.chocosolver.solver.constraints.LCF
import org.chocosolver.solver.variables.IntVar
import org.slf4j.Logger
import org.slf4j.LoggerFactory
/**
 * Created by gustavo on 16/06/15.
 */
class ExpressionBuilder extends ContextAwareProcessor {
    private static Logger log = LoggerFactory.getLogger(ExpressionBuilder)

    SolverBuildingContext context

    private FeatureInstanceLocator contextPath
    private FeatureInstanceLocator ancestorPath

    public ExpressionBuilder(SolverBuildingContext context, FeatureInstanceLocator contextPath, FeatureInstanceLocator ancestorPath) {
        super(context)
        this.contextPath = contextPath
        this.ancestorPath = ancestorPath
    }

    private Constraint buildExpression(ConstrainingExpression expr) {
//        log.debug "${expr.to.name} is DescendantOf ${contextPath.feature.name} ? ${expr.to.isDescendantOf(contextPath.feature)}"
//        log.debug "${contextPath} / ${contextAncestor}"
        if (expr.to == contextPath.feature || expr.to.isDescendantOf(contextPath.feature))
            buildConstraintFromContextPath(contextPath, expr)
        else
            buildConstraintFromContextPath(ancestorPath, expr)
    }

    private Constraint buildConstraintFromContextPath(FeatureInstanceLocator contextPath, ConstrainingExpression expr) {
        def featureToInstances = contextPath.getInstancesOf(expr.to)

        def subConstraints = featureToInstances.collect { getConstraintForInstancesOf(contextPath, it, expr) }

        subConstraints.empty ? constraintManager.TRUE : LCF.and(subConstraints as Constraint[])
    }

    private Constraint getConstraintForInstancesOf(FeatureInstanceLocator contextPath,
                                                   FeatureInstanceLocator featureTo, ConstrainingExpression expr) {
        def rcLocator = new RelativeCardinalityLocator(featureTo, expr.from, expr.to)
        def rcVariable = getRcVariable(rcLocator)

        log.debug "  && (${contextPath} > 0 && ${rcVariable.name} in [${expr.cardinality.min}..${expr.cardinality.max}])"

        LCF.and(ICF.arithm(getVariable(contextPath), ">", 0),
                ICF.member(rcVariable, expr.cardinality.min, expr.cardinality.max))
    }

    private IntVar getRcVariable(RelativeCardinalityLocator rcLocator) {
        getVariable(rcLocator) ?: createVariable(rcLocator)
    }

    private IntVar createVariable(RelativeCardinalityLocator rcLocator) {
//        Cardinality rc = table.getRelativeCardinality(rcLocator.cardinality.from, rcLocator.cardinality.to)
        Cardinality rc = featureModel.getInferredCardinality(rcLocator.from, rcLocator.to)

        IntVar[] vars = variableManager.getVariables(rcLocator.instances)
        IntVar sumVar = variableManager.createVariable(rcLocator, 0, rc.max)
        constraintManager.post(ICF.sum(vars, sumVar))

        log.debug "${rcLocator} = sum(${vars.join(", ")})"

        sumVar
    }

    private Constraint buildExpression(Expression expr) {
        throw new UnsupportedOperationException("No support expression of type ${expr.class.name} ")
    }

    private Constraint buildExpression(AndExpression expr) {
        def constraints = expr.subExpressions.collect { buildExpression(it) }
        LCF.and(constraints as Constraint[])
    }

    private Constraint buildExpression(OrExpression expr) {
        def constraints = expr.subExpressions.collect { buildExpression(it) }
        LCF.or(constraints as Constraint[])
    }
}
