package fr.inria.spirals.fm.solver
import fr.inria.spirals.fm.*
import fr.inria.spirals.fm.config.Instance
import fr.inria.spirals.fm.locators.FeatureInstanceLocator
import fr.inria.spirals.fm.locators.FeatureLocator
import fr.inria.spirals.fm.locators.InstanceFeatureLocator
import fr.inria.spirals.fm.model.Cardinality
import fr.inria.spirals.fm.model.FeatureModel
import fr.inria.spirals.fm.model.FeatureNode
import fr.inria.spirals.fm.model.RelativeCardinality
import fr.inria.spirals.fm.solver.builder.ConstraintBuilder
import fr.inria.spirals.fm.solver.builder.ExactConfigurationBuilder
import fr.inria.spirals.fm.solver.builder.GroupConstraintBuilder
import fr.inria.spirals.fm.solver.builder.HierarchyConstraintsBuilder
import fr.inria.spirals.fm.solver.builder.RelativeCardinalityBuilder
import org.chocosolver.solver.Solver
import org.chocosolver.solver.constraints.Constraint
import org.chocosolver.solver.search.solution.AllSolutionsRecorder
import org.slf4j.Logger
import org.slf4j.LoggerFactory
/**
 * Created by gustavo on 20/04/15.
 */
class SolverBuilder implements ConstraintManager {
    private static Logger log = LoggerFactory.getLogger(SolverBuilder)

    private FeatureModel featureModel
    private fr.inria.spirals.fm.config.Configuration configuration
    private VariableManager vm
    private Solver solver

    public void post(Constraint... constraints) {
        solver.post(constraints)
    }

    @Override
    Constraint getTRUE() {
        solver.TRUE
    }

    public SolverBuilder setFeatureModel(FeatureModel fm) {
//        Validator validator = new Validator()
//        if (!validator.validate(fm))
//            throw new IllegalArgumentException("Invalid Feature Model.\n${validator.errors}")

        solver = new Solver(fm.root.name)
        solver.set(new AllSolutionsRecorder(solver))
        vm = new VariableManager(solver)

        featureModel = fm

        this
    }

    public SolverBuilder setConfiguration(fr.inria.spirals.fm.config.Configuration config) {
        setFeatureModel(config.featureModel)
        this.configuration = config

        this
    }

    public FeatureModelSolver buildSolver() {
        if (featureModel == null)
            throw new IllegalStateException("Feature Model not set")

        long start = System.currentTimeMillis()
        def rootPath = buildFeatureModel()
        long time = System.currentTimeMillis() - start

//        solver.vars.each {
//            log.debug "SOLVER for ${it} " + (it.name =~ /\/.*[0-9]+/? "[INSTANCE]" : "")
//        }

//        log.info "SOLVER for ${featureModel.root.name}. ${time} ms / ${vm.numInstances} instances / ${solver.nbVars} vars / ${solver.nbCstrs} cstrs"

        buildConfiguration()
        return new FeatureModelSolver(featureModel, solver, vm, rootPath);
    }

    public FeatureModelSolver buildChecker() {
        if (configuration == null)
            throw new IllegalStateException("Configuration not set")

        log.debug('--- START BUILDING ---')
        afterInstances.add(new VariableProcessorAdapter<FeatureInstanceLocator>(ExactConfigurationBuilder))
        def rootPath = buildFeature(new InstanceFeatureLocator(null, featureModel.root, configuration.instances))
        afterInstances.remove(afterInstances.size()-1)
        log.debug('--- FINISH BUILDING ---')

        return new FeatureModelSolver(featureModel, solver, vm, rootPath)
    }

    private void buildConfiguration() {
        if (configuration == null)
            return

        log.debug("Build configuration")
        def rootPath = new FeatureLocator(null, featureModel.root)

        List instances = configuration.instances
        if (instances.size() == 1 && instances.first().feature == featureModel.root) {
            instances = instances.first().children
        }

        buildConfiguration(rootPath.instances.first(), instances)
    }

    private void buildConfiguration(FeatureInstanceLocator parentPath, Collection<Instance> instances) {
        instances.groupBy { it.getFeature() }.each { feature, featureInstances ->
            buildConfiguration(parentPath, feature, featureInstances)
        }
    }

    private void buildConfiguration(FeatureInstanceLocator parentPath, FeatureNode feature, Collection<Instance> instances) {
        int numFeature = instances.sum { it.number }
        def rc = new RelativeCardinality(feature, parentPath.feature, numFeature..numFeature as Cardinality)
        RelativeCardinalityBuilder.addRelativeCardinalityConstraint(context, parentPath, rc)

        def subInstances = parentPath.getInstancesOf(feature).iterator()
        for (Instance instance : instances) {
            if (subInstances.hasNext())
                buildConfiguration(subInstances.next(), instance.children)
        }
    }

    private FeatureLocator buildFeatureModel() {
        buildFeature(new FeatureLocator(null, featureModel.root))
    }

    private List<VariableProcessorAdapter<FeatureInstanceLocator>> afterInstances = [
            new VariableProcessorAdapter<FeatureInstanceLocator>(GroupConstraintBuilder),
            new VariableProcessorAdapter<FeatureInstanceLocator>(RelativeCardinalityBuilder)
    ]

    private List<VariableProcessorAdapter<FeatureLocator>> afterFeatures = [
            new VariableProcessorAdapter<FeatureLocator>(HierarchyConstraintsBuilder),
            new VariableProcessorAdapter<FeatureLocator>(ConstraintBuilder)
    ]

    private FeatureLocator buildFeature(FeatureLocator featurePath) {
//        FeatureLocator featurePath = new FeatureLocator(parentPath, feature)
        FeatureNode feature = featurePath.feature
        vm.createVariable(featurePath, /*feature.isRoot() ? 1 : */ 0, feature.localCardinality.max)

        featurePath.instances.each { FeatureInstanceLocator instance ->
            buildInstance(instance)
        }

        afterFeatures.each { it.process(context, featurePath) }

        return featurePath
    }


    private void buildInstance(FeatureInstanceLocator featIndex) {
        vm.createVariable(featIndex, 0, 1)
//        log.debug vm.getVariable(featIndex).toString()

        for (FeatureLocator featurePath : featIndex.children) {
            buildFeature(featurePath)
        }

        afterInstances.each { it.process(context, featIndex) }
    }

    private SolverBuildingContext _context

    private SolverBuildingContext getContext() {
        if (_context == null)
            _context = new SolverBuildingContext() {
                @Override
                FeatureModel getFeatureModel() {
                    SolverBuilder.this.featureModel
                }

                @Override
                VariableManager getVariableManager() {
                    vm
                }

                @Override
                ConstraintManager getConstraintManager() {
                    SolverBuilder.this
                }
            }
        _context
    }
}
