package fr.inria.spirals.fm.eval

/**
 * Created by gustavo on 22/08/15.
 */
class RunConfig {
    /**
     * To measure the time to verify cardinalities consistency and infer
     * additional cardinalities
     */
    boolean inference = true

    /**
     * To measure the time to translate to CSP
     */
    boolean buildSolver = true

    /**
     * To measure the time to find one valid configuration
     */
    boolean findConfig = true

    /**
     * Limit time to find a configuration, <0 means to not limit
     */
    long limitTime = - 1


    /**
     * To measure the time to check a configuration conformance to FM
     */
    boolean checkConfig = true

    /**
     * If the configuration generated to be checked is to be valid or not
     */
    boolean validConfig = true

    /**
     * Number of configs to generate before checking validity
     */
    int numConfig = 1


}
