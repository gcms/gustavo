package fr.inria.spirals.fm.model

import fr.inria.spirals.fm.CardinalityInferrer
import fr.inria.spirals.fm.model.expr.AndExpression
import fr.inria.spirals.fm.model.expr.ConstrainingExpression
import fr.inria.spirals.fm.model.expr.Expression
import fr.inria.spirals.fm.model.expr.FeatureModelConstraint
import fr.inria.spirals.fm.model.expr.OrExpression
import fr.inria.spirals.fm.loader.xtext.XtextLoader

/**
 * Created by gustavo on 07/04/15.
 */
class FeatureModel {
    private Feature root
    private Map<String, FeatureNode> features = [:]
    private Set<FeatureModelConstraint> constraints = new LinkedHashSet<FeatureModelConstraint>()

    private RelativeCardinalityCollection declared = new RelativeCardinalityCollection()
    private RelativeCardinalityCollection inferred

    public String getName() {
        getRoot().getName()
    }

    public Feature getRoot() {
        root
    }

    public Set<FeatureNode> getFeatures() {
        features.values()
    }

    public Set<FeatureModelConstraint> getConstraints() {
        constraints
    }

    public void addConstraints(FeatureModelConstraint... constraints) {
        this.constraints.addAll(constraints)
    }

    public RelativeCardinalityCollection getInferredCardinalities() {
        if (inferred == null) {
            inferred = new RelativeCardinalityCollection(getInferrer().cardinalities)
        }

        inferred
    }

    private CardinalityInferrer inferrer

    public CardinalityInferrer getInferrer() {
        if (inferrer == null) {
            inferrer = new CardinalityInferrer(this)
        }

        inferrer
    }

    public void addFeature(FeatureNode feat) {
        features.put(feat.name, feat)
        inferrer = null
        inferred = null
    }

    public FeatureGroup createFeatureGroup(String name, FeatureNode parent) {
        createFeatureGroup(name, parent, null)
    }

    public FeatureGroup createFeatureGroup(String name, FeatureNode parent, Cardinality cardinality) {
        if (parent != null && !features.containsValue(parent))
            throw new IllegalArgumentException("Feature ${parent} is not in the FeatureModel")

        new FeatureGroup(name, this, parent, cardinality)
    }

    public Feature createFeature(String name, FeatureNode parent) {
        if (parent != null && !features.containsValue(parent))
            throw new IllegalArgumentException("Feature ${parent} is not in the FeatureModel")

        new Feature(name, this, parent)
    }

    public FeatureNode getFeature(String name) {
        features.get(name)
    }

    Cardinality getLocalCardinality(FeatureNode from) {
        declared.get(from, from.parent) ?: inferredCardinalities.get(from, from.parent)
    }

    public FeatureModel(String rootFeatureName) {
        root = createFeature(rootFeatureName, null)
    }

    public void addCardinality(FeatureNode from, FeatureNode to, Cardinality cardinality) {
        if (!from.isDescendantOf(to)) {
            throw new IllegalArgumentException("Invalid relative cardinality (${from?.name}, ${to?.name})")
        }

        def rc = new RelativeCardinality(from, to, cardinality)
        declared.add(rc)

        inferrer = null
        inferred = null
    }

    public void addCardinality(FeatureNode from, FeatureNode to, Cardinality cardinality, boolean reset) {
        if (!from.isDescendantOf(to)) {
            throw new IllegalArgumentException("Invalid relative cardinality (${from?.name}, ${to?.name})")
        }

        def rc = new RelativeCardinality(from, to, cardinality)
        declared.add(rc)

        if (reset) {
            inferrer = null
            inferred = null
        }
    }



    Collection<RelativeCardinality> getDeclaredCardinalitiesFrom(FeatureNode feature) {
        declared.asCollection().findAll { it.from == feature }
    }

    /**
     * Get the relative cardinality between two feature nodes as it was declared
     * in the feature model. Is considered as declared, the cardinalities which
     * are loaded from the fm description. Therefore, it doesn't consider inferred
     * cardinalities. Obs: some defaults for cardinalities may be defined in the
     * feature model loader, these are considered by this class as if they were
     * declared as it is not inferred directly by this package.
     *
     * @param from
     * @param to
     * @return
     */
    Cardinality getDeclaredRelativeCardinality(FeatureNode from, FeatureNode to) {
        def relativeCardinality = declared.asCollection().find { it.from == from && it.to == to }
        relativeCardinality?.cardinality
    }

    /**
     *  Obtains all cardinalities declared in the feature model, relative to a
     *  feature. It excludes the local cardinality, even if it's declared and
     *  doesn't considered infered cardinalities.
     *
     * @param to
     * @return returns
     */
    Collection<RelativeCardinality> getDeclaredNotLocalCardinalitiesTo(FeatureNode to) {
        declared.asCollection().findAll { it.to == to && !it.local }
    }

    Cardinality getDeclaredCardinality(FeatureNode from, FeatureNode to) {
        declared.get(from, to)
    }

    Cardinality getInferredCardinality(FeatureNode from, FeatureNode to) {
        inferredCardinalities.get(from, to)
    }


    String toString() {
        StringWriter sb = new StringWriter()
        PrintWriter ps = new PrintWriter(sb)

        print(ps, root, "")
        constraints.each {  ps.println(it) }

        ps.flush()
        sb.toString()
    }

    private static void print(PrintWriter ps, FeatureNode feat, String tab) {
        ps.printf("%s%s%n", tab, feat)
        for (FeatureNode child : feat.children) {
            print(ps, child, tab + "  ")
        }
    }

    Cardinality getRelativeCardinality(String from, String to) {
        getInferredCardinality(getFeature(from), getFeature(to))
    }

    int getDepth() {
        (getFeatures()*.depth).max()
    }

    FeatureModel copy() {
        def loader = XtextLoader.INSTANCE
        loader.loadFeatureModel(loader.convert(this))
    }

    RelativeCardinalityCollection getDeclaredCardinalities() {
        declared
    }

    Cardinality removeCardinality(FeatureNode from, FeatureNode to) {
        inferrer = null
        inferred = null
        declared.remove(new FeaturePair(from, to))
    }

    void resetInferredCardinalities() {
        inferrer = null
        inferred = null
    }

    Cardinality getImplicitCardinality(FeatureNode from, FeatureNode to) {
//        if (from == to || !from.isDescendantOf(to))
//            throw new IllegalArgumentException()

        def local = getInferredCardinality(from, from.parent)

        if (from.parent == to)
            return local

        local * getImplicitCardinality(from.parent, to)
    }

    ConstrainingExpression createExpression(Cardinality cardinality, FeatureNode from, FeatureNode to) {
        new ConstrainingExpression(this, cardinality, from, to)
    }

    AndExpression createAndExpression(List<Expression> expressions) {
        new AndExpression(this, expressions)
    }

    OrExpression createOrExpresison(List<Expression> expressions) {
        new OrExpression(this, expressions)
    }

    public boolean equals(Object other) {
        other instanceof FeatureModel && toString() == other.toString()
    }

    public int hashCode() {
        toString().hashCode()
    }
}
