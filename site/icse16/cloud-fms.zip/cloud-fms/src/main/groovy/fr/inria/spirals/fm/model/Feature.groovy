package fr.inria.spirals.fm.model

/**
 * Created by gustavo on 07/04/15.
 */
class Feature extends FeatureNode {
    protected Feature(String name, FeatureModel fm, FeatureNode parent) {
        super(name, fm, parent)
    }

    @Override
    boolean isGroup() {
        false
    }

    Set<FeatureNode> getSubFeatures() {
        children
    }
}
