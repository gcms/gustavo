package fr.inria.spirals.fm.solver.propagator;

/**
 * Created by gustavo on 28/08/15.
 */

import gnu.trove.map.hash.THashMap;
import org.chocosolver.memory.IEnvironment;
import org.chocosolver.solver.Solver;
import org.chocosolver.solver.constraints.Propagator;
import org.chocosolver.solver.constraints.PropagatorPriority;
import org.chocosolver.solver.exception.ContradictionException;
import org.chocosolver.solver.variables.BoolVar;
import org.chocosolver.solver.variables.IntVar;
import org.chocosolver.solver.variables.events.IntEventType;
import org.chocosolver.util.ESat;
import org.chocosolver.util.tools.ArrayUtils;

/**
 * Created by gustavo on 27/08/15.
 */
public class PropArray extends Propagator<IntVar> {

    //***********************************************************************************
    // VARIABLES
    //***********************************************************************************

    IntVar size;
    int n;

    public PropArray(IntVar[] variables, IntVar size) {
        super(ArrayUtils.append(variables, new IntVar[] {size}), PropagatorPriority.UNARY, true);
        n = variables.length;
        this.size = vars[n];
        IEnvironment environment = solver.getEnvironment();
    }

    public PropArray(IntVar size, IntVar[] vars) {
        this(vars, size);
    }


    @Override
    public void propagate(int evtmask) throws ContradictionException {
        int lb = 0;
        int ub = n;

        for (int i = 0; i < n; i++) {
            if (!vars[i].isInstantiatedTo(1))
                break;

            lb = i + 1;
        }

        for (int i = n; i > 0; i--) {
            if (!vars[i-1].isInstantiatedTo(0))
                break;

            ub = i - 1;
        }

        size.updateLowerBound(lb, aCause);
        size.updateUpperBound(ub, aCause);

        if (lb != ub && size.isInstantiated()) {
            for (int i = lb; i < size.getValue(); i++) {
                vars[i].instantiateTo(1, aCause);
            }
            for (int i = size.getValue(); i < ub; i++) {
                vars[i].instantiateTo(0, aCause);
            }
        }
    }

    @Override
    public void propagate(int idx, int mask) throws ContradictionException {
        if (vars[n].getName().equals("/Feat_1[1]/Feat_34")) {
            System.out.print("(");
            for (int i = 0; i < n - 1; i++) {
                System.out.print(vars[i].toString());
                System.out.print(" + ");
            }
            System.out.print(vars[n-1].toString());
            System.out.print(") = ");
            System.out.println(vars[n].toString());

            System.out.printf("propagate(%d, %d) %s%n", idx, mask, vars[idx].toString());
        }

        if (idx < n) {
            propagateIndex(idx);
        } else {
            propagateSize();
        }
    }

    private void propagateSize() throws ContradictionException {
        int lb = size.getLB();
        int ub = size.getUB();

        for (int i = 0; i < lb; i++) {
            vars[i].instantiateTo(1, aCause);
        }
        for (int i = ub; i < n; i++) {
            vars[i].instantiateTo(0, aCause);
        }
    }

    private void propagateIndex(int idx) throws ContradictionException {
        int lb = size.getLB();
        int ub = size.getUB();

        if (vars[idx].isInstantiatedTo(0)) {
            for (int i = idx + 1; i < ub; i++) {
                vars[i].instantiateTo(0, aCause);
            }
            size.updateUpperBound(idx, aCause);
        } else if (vars[idx].isInstantiatedTo(1)) {
            for (int i = lb; i < idx; i++) {
                vars[i].instantiateTo(1, aCause);
            }
            size.updateLowerBound(idx + 1, aCause);
        }
    }

    @Override
    public int getPropagationConditions(int vIdx) {
        if (vIdx == n)
            return IntEventType.boundAndInst();
        return IntEventType.instantiation();
    }

    @Override
    public ESat isEntailed() {
        int lb = size.getLB();
        int ub = size.getUB();

        for (int i = 0; i < lb; i++)
            if (vars[i].isInstantiatedTo(0))
                return ESat.FALSE;

        for (int i = ub; i < n; i++)
            if (vars[i].isInstantiatedTo(1))
                return ESat.FALSE;

        for (IntVar var : vars) {
            if (!var.isInstantiated())
                return ESat.UNDEFINED;
        }

//        for (int i = 0; i < size.getValue(); i++) {
//            if (vars[i].isInstantiatedTo(0))
//                return ESat.FALSE;
//        }
//
//        for (int i = size.getValue(); i < n; i++) {
//            if (vars[i].isInstantiatedTo(1))
//                return ESat.FALSE;
//        }

        return ESat.TRUE;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("PropArray(");
        for (int i = 0; i < vars.length - 2; i++) {
            sb.append(vars[i]).append("+");
        }
        sb.append(vars[vars.length - 2]).append(")");
        sb.append(" = ").append(vars[vars.length - 1]);
        return sb.toString();
    }

    @Override
    public void duplicate(Solver solver, THashMap<Object, Object> identitymap) {
        if (!identitymap.containsKey(this)) {
            int size = this.vars.length - 1;
            BoolVar[] aVars = new BoolVar[size];
            for (int i = 0; i < size; i++) {
                this.vars[i].duplicate(solver, identitymap);
                aVars[i] = (BoolVar) identitymap.get(this.vars[i]);
            }
            this.vars[size].duplicate(solver, identitymap);
            IntVar S = (IntVar) identitymap.get(this.vars[size]);
            identitymap.put(this, new PropArray(aVars, S));
        }
    }
}