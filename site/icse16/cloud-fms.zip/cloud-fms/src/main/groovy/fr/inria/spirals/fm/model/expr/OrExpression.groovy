package fr.inria.spirals.fm.model.expr

import fr.inria.spirals.fm.model.FeatureModel

/**
 * Created by gustavo on 22/04/15.
 */
class OrExpression extends ComposedExpression {
    OrExpression(FeatureModel fm, Collection<Expression> expressions) {
        super(fm, expressions)
    }

    String toString() {
        subExpressions.join(" | ")
    }
}
