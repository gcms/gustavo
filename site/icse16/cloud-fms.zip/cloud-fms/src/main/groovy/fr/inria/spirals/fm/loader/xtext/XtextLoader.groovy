package fr.inria.spirals.fm.loader.xtext

import fr.inria.spirals.fm.model.Feature
import fr.inria.spirals.fm.model.FeatureModel
import fr.inria.spirals.fm.model.FeatureNode
import fr.inria.spirals.fm.config.Configuration
import fr.inria.lille.spirals.fm.FeatureModelLoader
import fr.inria.lille.spirals.fm.featuremodel.FeatureModel as EcoreFeatureModel
import fr.inria.lille.spirals.fm.featuremodel.Configuration as EcoreConfiguration
import fr.inria.spirals.fm.model.FeatureGroup
import org.eclipse.emf.common.util.URI
import org.eclipse.emf.ecore.EObject

/**
 * Created by gustavo on 09/06/15.
 */
class XtextLoader {
    static XtextLoader INSTANCE = new XtextLoader()

    public XtextLoader() {
        this([])
    }

    public XtextLoader(List<String> urls) {
        urls.collect {
            def url
            try {
                url = new URL(it)
            } catch (MalformedURLException ex) {
            } finally {
                url = new File(it).toURI().toURL()
            }

            FeatureModelLoader.addClassPath(url)
        }

        ecoreLoader = new EcoreLoader()
    }

    EcoreLoader ecoreLoader = new EcoreLoader()

    public FeatureModel loadFeatureModel(URL url) {
        EcoreFeatureModel ecoreFm = FeatureModelLoader.loadFeatureModel(URI.createURI(url.toString()))

        ecoreLoader.load(ecoreFm)
    }

    public Configuration loadConfiguration(URL url) {
        EcoreConfiguration ecoreConfig = FeatureModelLoader.loadConfiguration(URI.createURI(url.toString()))

        ecoreLoader.load(ecoreConfig)
    }

    public EObject loadEcore(URL url) {
        FeatureModelLoader.load(URI.createURI(url.toString()))
    }

    public Object load(URL url) {
        ecoreLoader.load(loadEcore(url))
    }


    private static URL getURLFromContent(String content) {
        File temp = File.createTempFile("xtext", ".fm")
        temp.text = content
        temp.toURI().toURL()
    }

    public Configuration loadFromString(String content) {
        loadConfiguration(getURLFromContent(content))
    }

    public FeatureModel loadFeatureModel(String content) {
        loadFeatureModel(getURLFromContent(content))
    }

    public EcoreFeatureModel convertToEcore(FeatureModel fm) {
        loadEcore(getURLFromContent(convert(fm)))
    }

    public String convert(FeatureModel fm) {
        def sw = new StringWriter()
        def pw = new PrintWriter(sw)

        convertNode(pw, '', fm.root)
        fm.constraints.each {
            pw.println(it)
        }

        pw.flush()
        sw.flush()
        sw.toString()
    }

    private void convertNode(PrintWriter ps, String tab, FeatureNode node) {
        ps.print(tab)
        ps.print(node.name)

        def localCard = node.root ? null : node.featureModel.getDeclaredCardinality(node, node.parent)
        if (localCard != null)
            ps.print(" [${localCard.min}..${localCard.max}]")

        for (def card : node.featureModel.getDeclaredCardinalitiesFrom(node)) {
            if (card.isLocal())
                continue

            ps.print(" <${card.to.name}>[${card.cardinality.min}..${card.cardinality.to}]")
        }

        processChildren(ps, tab, node)
    }

    private void processChildren(PrintWriter ps, String tab, FeatureNode node) {
        throw new UnsupportedOperationException()
    }

    private void processChildren(PrintWriter ps, String tab, FeatureGroup group) {
        ps.print(" <${group.groupCardinality.min}..${group.groupCardinality.max}>")
        ps.println(" [")

        for (FeatureNode variant : group.variants) {
            convertNode(ps, tab + '  ', variant)
        }
        ps.print(tab)
        ps.println("]")
    }

    private void processChildren(PrintWriter ps, String tab, Feature feature) {
        if (feature.subFeatures.empty) {
            ps.println()
            return
        }

        ps.println(" {")

        for (FeatureNode subFeature : feature.subFeatures) {
            convertNode(ps, tab + '  ', subFeature)
        }

        ps.print(tab)
        ps.println('}')
    }



}
