package fr.inria.spirals.fm.solver

import fr.inria.spirals.fm.model.FeatureModel

/**
 * Created by gustavo on 16/06/15.
 */
interface SolverBuildingContext {
    FeatureModel getFeatureModel()
    VariableManager getVariableManager()
    ConstraintManager getConstraintManager()
}