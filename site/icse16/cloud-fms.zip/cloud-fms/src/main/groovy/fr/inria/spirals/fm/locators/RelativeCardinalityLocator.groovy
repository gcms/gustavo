package fr.inria.spirals.fm.locators

import fr.inria.spirals.fm.model.FeatureNode
import fr.inria.spirals.fm.model.FeaturePair
import fr.inria.spirals.fm.model.RelativeCardinality

/**
 * Created by gustavo on 11/06/15.
 */
class RelativeCardinalityLocator implements VariableLocator {
    protected FeaturePair cardinality
    protected FeatureInstanceLocator featIndex
    private String name

    public RelativeCardinalityLocator(FeatureInstanceLocator featIndex, FeaturePair cardinality) {
        if (featIndex.feature != cardinality.to)
            throw new IllegalArgumentException("Invalid locator ${featIndex} for rc ${cardinality}")

        this.featIndex = featIndex
        this.cardinality = cardinality

        this.name = featIndex.name + "/" + cardinality.from.name
    }

    public RelativeCardinalityLocator(FeatureInstanceLocator featIndex, FeatureNode from, FeatureNode to) {
        this(featIndex, new FeaturePair(from, to))
    }

    public RelativeCardinalityLocator(FeatureInstanceLocator featIndex, RelativeCardinality cardinality) {
        this(featIndex, cardinality.key)
    }

    public String getName() {
        name
    }

    public Collection<FeatureInstanceLocator> getInstances() {
        featIndex.getInstancesOf(cardinality.from)
    }

    public FeatureNode getFrom() {
        cardinality.from
    }

    public FeatureNode getTo() {
        cardinality.to
    }

    @Override
    String toString() {
        getName()
    }
}
