package fr.inria.spirals.fm


/**
 * Created by gustavo on 13/08/15.
 */
class InvalidCardinalitiesException extends IllegalArgumentException {
    public InvalidCardinalitiesException(String message) {
        super(message)
    }
}
