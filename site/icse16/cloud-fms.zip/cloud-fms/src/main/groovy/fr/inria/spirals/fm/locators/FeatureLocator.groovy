package fr.inria.spirals.fm.locators

import fr.inria.spirals.fm.model.FeatureNode
/**
 * Created by gustavo on 11/06/15.
 */
class FeatureLocator implements VariableLocator {
    protected FeatureInstanceLocator parent
    protected FeatureNode feature
    private String name

    @Override
    String getName() {
        name
    }

    public FeatureNode getFeature() {
        feature
    }

    public FeatureInstanceLocator getParent() {
        parent
    }

    String toString() {
        getName()
    }

    public FeatureLocator(FeatureInstanceLocator parent, FeatureNode feature) {
        this.parent = parent
        this.feature = feature

        this.name = (parent ? parent.name : "") + "/" + feature.name
    }

    List<FeatureInstanceLocator> getInstances() {
        (1..feature.localCardinality.to).collect {
            new FeatureInstanceLocator(parent, feature, it)
        }
    }

    Collection<FeatureInstanceLocator> getInstancesOf(FeatureNode node) {
        getInstances().collect { it.getInstancesOf(node) }.flatten()
    }
}

