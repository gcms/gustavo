package fr.inria.spirals.fm.eval.resource

import fr.inria.spirals.fm.model.FeatureModel
import fr.inria.spirals.fm.eval.FeatureModelGenerator

/**
 * Created by gustavo on 22/08/15.
 */
class GeneratorFeatureModelSource implements FeatureModelSource {
    FeatureModelGenerator generator
    Long numModels
    Integer numFeatures

    GeneratorFeatureModelSource(FeatureModelGenerator generator, Long numModels, Integer numFeatures) {
        this.generator = generator
        this.numModels = numModels
        this.numFeatures = numFeatures
    }

    @Override
    Iterator<FeatureModelResource> iterator() {
        new GeneratorFeatureModelSourceIterator()
    }

    class GeneratorFeatureModelSourceIterator implements Iterator<FeatureModelResource> {
        int i = 0
        @Override
        boolean hasNext() {
            i < numModels
        }

        @Override
        FeatureModelResource next() {
            FeatureModel fm = generator.generate(numFeatures)
            i++
            new GeneratedFeatureModelResource(
                    featureModel: fm,
                    numFeats: numFeatures,
                    maxDepth: generator.maxDepth,
                    maxCard: generator.maxCard,
                    probCardUpper: generator.probCardUpper,
                    probCardOther: generator.probCardOther)
        }
    }


}
