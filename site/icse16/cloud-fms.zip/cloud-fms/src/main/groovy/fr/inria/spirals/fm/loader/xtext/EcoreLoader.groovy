package fr.inria.spirals.fm.loader.xtext

import fr.inria.spirals.fm.model.FeatureNode
import fr.inria.spirals.fm.model.expr.FeatureModelConstraint
import fr.inria.lille.spirals.fm.featuremodel.*
import org.eclipse.emf.common.util.EList


import fr.inria.spirals.fm.model.expr.Expression

/**
 * Created by gustavo on 09/06/15.
 */
class EcoreLoader {
    public fr.inria.spirals.fm.model.FeatureModel load(FeatureModel ecoreFm) {
        def fm = new fr.inria.spirals.fm.model.FeatureModel(ecoreFm.root.name)
        processFeature(ecoreFm.root, fm, fm.root)
        fm.addConstraints(loadConstraints(fm, ecoreFm.constraints))
        fm
    }

    public fr.inria.spirals.fm.config.Configuration load(Configuration ecoreConfig) {
        def fm = load(ecoreConfig.featureModel)
        def config = new fr.inria.spirals.fm.config.Configuration(fm)

        ecoreConfig.instances.each { instance ->
            config.addInstance(createInstance(fm, null, instance))
        }

        config
    }

    public fr.inria.spirals.fm.config.Instance createInstance(fr.inria.spirals.fm.model.FeatureModel fm, fr.inria.spirals.fm.config.Instance parent, Instance ecoreInstance) {
        int number = ecoreInstance?.number ?: 1
        def instance = new fr.inria.spirals.fm.config.Instance(parent, number, fm.getFeature(ecoreInstance.type.name))
        ecoreInstance.children.each { child ->
            instance.addChild(createInstance(fm, instance, child))
        }

        instance
    }

    FeatureModelConstraint[] loadConstraints(fr.inria.spirals.fm.model.FeatureModel fm, EList<Constraint> constraints) {
        constraints.collect { createConstraint(fm, it)}
    }

    FeatureModelConstraint createConstraint(fr.inria.spirals.fm.model.FeatureModel fm, Constraint constraint) {
        def context = fm.getFeature(constraint.context.name)
        def condition = createExpression(fm, constraint.condition)
        def action = createExpression(fm, constraint.consequence)

        new FeatureModelConstraint(context, condition, action)
    }

    Expression createExpression(fr.inria.spirals.fm.model.FeatureModel fm, AbstractConstrainingExpression ce) {
        throw new UnsupportedOperationException("Unsupported subclass of Expression ${ce.getClass().name}")
    }

    Expression createExpression(fr.inria.spirals.fm.model.FeatureModel fm, ConstrainingExpression ce) {
        def card = new fr.inria.spirals.fm.model.Cardinality(ce.cardinality.min, ce.cardinality.max)
        def from = fm.getFeature(ce.from.name)
        def to = fm.getFeature(ce.to.name)

        fm.createExpression(card, from, to)
    }

    Expression createExpression(fr.inria.spirals.fm.model.FeatureModel fm, AndConstrainingExpression ce) {
        fm.createAndExpression(ce.children.collect { createExpression(fm, it)})
    }

    Expression createExpression(fr.inria.spirals.fm.model.FeatureModel fm, OrConstrainingExpression ce) {
        fm.createOrExpresison(ce.children.collect { createExpression(fm, it)})
    }

    void postProcessFeatureNode(fr.inria.spirals.fm.model.FeatureModel fm, FeatureNode f, AbstractFeature ecoreFeat) {
        if (f.parent != null) {
            if (ecoreFeat.cardinalities == null || ecoreFeat.cardinalities.isEmpty()) {
                createDefaultCardinality(fm, f)
            } else {
                processCardinalities(fm, ecoreFeat)
            }
        }
    }

    private void processCardinalities(fr.inria.spirals.fm.model.FeatureModel fm, AbstractFeature ecoreFeat) {
        ecoreFeat.cardinalities.each { ecoreRelativeCard ->
            addRelativeCardinality(fm, ecoreRelativeCard)
        }
    }

    private void addRelativeCardinality(fr.inria.spirals.fm.model.FeatureModel fm, RelativeCardinality ecoreRelativeCard) {
        FeatureNode from = fm.getFeature(ecoreRelativeCard.from.name)
        FeatureNode to = ecoreRelativeCard.to ? fm.getFeature(ecoreRelativeCard.to.name) : from.parent
        fr.inria.spirals.fm.model.Cardinality card = ecoreRelativeCard.cardinality.min..ecoreRelativeCard.cardinality.max

        fm.addCardinality(from, to, card)
    }

    private void createDefaultCardinality(fr.inria.spirals.fm.model.FeatureModel fm, FeatureNode feature) {
//        if (feature.parent.isGroup()) {
//            fm.addCardinality(feature, feature.parent, 1..1 as fm.Cardinality)
//        } else {
//            fm.addCardinality(feature, feature.parent, 0..1 as fm.Cardinality)
//        }
        fm.addCardinality(feature, feature.parent, 1..1 as fr.inria.spirals.fm.model.Cardinality)
    }

    fr.inria.spirals.fm.model.Feature addFeature(fr.inria.spirals.fm.model.FeatureModel fm, FeatureNode parent, Feature ecoreFeat) {
        def feat = fm.createFeature(ecoreFeat.name, parent)
        processFeature(ecoreFeat, fm, feat)
    }

    private fr.inria.spirals.fm.model.Feature processFeature(Feature ecoreFeat, fr.inria.spirals.fm.model.FeatureModel fm, fr.inria.spirals.fm.model.Feature feat) {
        ecoreFeat.subFeatures.each { addFeature(fm, feat, it) }
        postProcessFeatureNode(fm, feat, ecoreFeat)
        feat
    }

    fr.inria.spirals.fm.model.FeatureGroup addFeature(fr.inria.spirals.fm.model.FeatureModel fm, FeatureNode parent, FeatureGroup ecoreGroup) {
        def group = fm.createFeatureGroup(ecoreGroup.name, parent)
        group.groupCardinality = ecoreGroup.groupCardinality.min..ecoreGroup.groupCardinality.max
        ecoreGroup.variants.each { addFeature(fm, group, it) }
        postProcessFeatureNode(fm, group, ecoreGroup)
        group
    }

    FeatureNode addFeature(fr.inria.spirals.fm.model.FeatureModel fm, FeatureNode parent, AbstractFeature ecoreFeat) {
        throw new UnsupportedOperationException("Unsupported subtype of AbstractFeature ${ecoreFeat.class.name}")
    }
}
