package fr.inria.spirals.fm.eval

import fr.inria.spirals.fm.model.FeatureModel
import fr.inria.spirals.fm.eval.resource.DbFeatureModelResource
import fr.inria.spirals.fm.eval.resource.DbFeatureModelSource
import fr.inria.spirals.fm.eval.resource.DbIdFeatureModelSource
import fr.inria.spirals.fm.eval.resource.FeatureModelResource
import fr.inria.spirals.fm.eval.resource.FeatureModelSource
import fr.inria.spirals.fm.eval.resource.FileFeatureModelSource
import fr.inria.spirals.fm.eval.resource.GeneratorFeatureModelSource
import fr.inria.spirals.fm.eval.resource.RelativeCardinalityFeatureModelResource
import groovyjarjarcommonscli.CommandLine
import groovyjarjarcommonscli.GnuParser
import groovyjarjarcommonscli.HelpFormatter
import groovyjarjarcommonscli.MissingOptionException
import groovyjarjarcommonscli.Options
import static MainUtils.opt

/**
 * Created by gustavo on 12/08/15.
 */
class Main {
    static boolean writeDb
    static String name
    static long runId

    public static void main(String[] args) {
        Options options = new Options()

        options.addOption(opt('i', 'input', String, false, "[ 'db' | 'gen' | filename | database id ]"))

        options.addOption(opt('f', 'feats', Number, false, "Number of features to generate or query feature models"))
        options.addOption(opt('d', 'depth', Number, false, "Maximum depth"))
        options.addOption(opt('c', 'card', Number, false, 'Maximum cardinality'))
        options.addOption(opt('pu', 'probCardUpper', Number, false, 'Probability of upper depth having cardinality'))
        options.addOption(opt('pl', 'probCardLower', Number, false, 'Probability of lower depth having cardinality'))
        options.addOption(opt('n', 'times', Number, false, 'Number of executions'))
        options.addOption(opt('rc', 'relativeCard', Number, false, 'Percentage of cardinalities which are relative'))
        options.addOption(opt('db', 'database', String, false, 'Sqlite database'))
        options.addOption(opt('nw', 'nowrite', "Don't write to the database"))
        options.addOption(opt('e', 'exp', String, true, 'Experiment name'))
        options.addOption(opt('op', 'operations', String, false, "Operations to run [ inference | buildSolver | findConfig | checkConfig ]"))

        options.addOption(opt('lt', 'limit', Number, false, "Time limit for finding a configuration (ms)"))
        options.addOption(opt('ic', 'invalidconf', "Use it to generate invalid configurations to be checked"))
        options.addOption(opt('nc', 'numconf', Number, false, "Number of configurations to generate"))


        def parser = new GnuParser()
        try {
            cl = parser.parse(options, args)
        } catch (MissingOptionException ex) {
            println ex.message
            new HelpFormatter().printHelp("eval", options)

            System.exit(-1)
            return
        }

        if (!cl.hasOption('i') && !cl.hasOption('f') || (cl.getParsedOptionValue('i') == 'gen')) {
            println "Should specify either an -input or a -feats to generate feature models"
            new HelpFormatter().printHelp("eval", options)

            System.exit(-1)
            return
        }



        writeDb = !cl.hasOption('nw')
        name = cl.getParsedOptionValue('e')
        runId = System.currentTimeMillis()


        FeatureModelSource fmSource = getFeatureModelSource(cl)

        Integer rc = cl.getParsedOptionValue('rc') ?: 50
        RelativeCardinalityGenerator rcGenerator = new RelativeCardinalityGenerator(relativeCardinalityPercentage: rc)

        FeatureModelProcessor processor = new FeatureModelProcessor()
        for (FeatureModelResource fmResource : fmSource) {
            if (fmResource instanceof DbFeatureModelResource && processed.contains(fmResource.id))
                continue;

            process(processor, fmResource)

            FeatureModel fm = fmResource.featureModel
            if (!rcGenerator.hasRelativeCard(fm)) {
                FeatureModel fmRc = rcGenerator.addRelativeCardinalities(fm)
                process(processor, new RelativeCardinalityFeatureModelResource(fmRc, fmResource))
            }
        }
    }

    static CommandLine cl

    static Set<Long> processed = []
    static FeatureModelResource process(FeatureModelProcessor processor, FeatureModelResource fmResource) {
        FeatureModel fm = fmResource.featureModel

        RunConfig config = newRunConfig()
        RunResult result = processor.run(config, fm)

        if (!writeDb) {
            println result
            return fmResource
        }

        DbFeatureModelResource dbResource = toDbResource(fmResource)
        if (processed.contains(dbResource.id))
            return dbResource


        if (config.inference)
            getDb().addRun(runId, name, dbResource, 'inference', result.inference)

        if (config.buildSolver)
            getDb().addRun(runId, name, dbResource, 'generation', result.buildSolver)

        if (config.findConfig)
            getDb().addRun(runId, name, dbResource, 'findConfig', result.buildSolver)

        if (config.checkConfig)
            getDb().addRun(runId, name, dbResource, 'checkConfig', result.buildChecker + result.solveChecker)

        println "Processed ${dbResource.id}"
        processed.add(dbResource.id)

        dbResource
    }

    static DbFeatureModelResource toDbResource(FeatureModelResource fmResource) {
        fmResource instanceof DbFeatureModelResource ? fmResource : convertToDb(fmResource)
    }

    static DbFeatureModelResource convertToDb(FeatureModelResource fmResource) {
        if (fmResource == null)
            return null

        DbFeatureModelResource baseResource = toDbResource(fmResource.baseModelResource)
        getDb().queryFeatureModelResource(fmResource.featureModel) ?:
                getDb().addFeatureModelResource(fmResource.config, fmResource.featureModel, baseResource)
    }

    static RunConfig newRunConfig() {
        def config  = new RunConfig()

        if (cl.hasOption('lt'))
            config.limitTime = (Integer) cl.getParsedOptionValue('lt')

        if (cl.hasOption('ic'))
            config.validConfig = false

        if (cl.hasOption('nc'))
            config.numConfig = (Integer) cl.getParsedOptionValue('nc')

        String op = cl.getOptionValue('op')

        if (op == null || op == 'checkConfig')
            return config

        config.checkConfig = false

        if (op == 'findConfig')
            return config

        config.findConfig = false

        if (op == 'buildSolver')
            return config

        config.buildSolver = false

        if (op == 'inference')
            return config

        config.inference = false

        config
    }

    private static FeatureModelSource getFeatureModelSource(CommandLine cl) {
        String input = cl.getParsedOptionValue('i')

        if (input == 'db') {
            new DbFeatureModelSource(getDb(), cl.hasOption('f') ? (int) cl.getParsedOptionValue('f') : null)
        } else if (input != null && input.isNumber()) {
            new DbIdFeatureModelSource(getDb(), Long.parseLong(input))
        } else if (input != null && new File(input).exists()) {
            new FileFeatureModelSource(new File(input))
        } else {
            Integer times = cl.getParsedOptionValue('n') ?: 1
            Integer nFeatures = cl.getParsedOptionValue('f')

            FeatureModelGenerator fmGenerator = newFeatureModelGenerator(nFeatures)
            new GeneratorFeatureModelSource(fmGenerator, times, nFeatures)
        }
    }

    private static RelativeCardinalityGenerator newFeatureModelGenerator(int nFeatures) {
        Integer maxDepth = cl.getParsedOptionValue('d') ?: nFeatures
        Integer maxCardinality = cl.getParsedOptionValue('c') ?: 10
        Integer probCardinalityUpper = cl.getParsedOptionValue('pu') ?: 50
        Integer probCardinalityOther = cl.getParsedOptionValue('pl') ?: 1
        Integer rc = cl.getParsedOptionValue('rc') ?: 50

        new RelativeCardinalityGenerator(
                maxDepth: maxDepth,
                maxCard: maxCardinality,
                probCardUpper: probCardinalityUpper,
                probCardOther: probCardinalityOther,
                relativeCardinalityPercentage: rc)
    }

    private static DbManager db

    static DbManager getDb() {
        if (db == null) {
            String connString = cl.getOptionValue('db') ?: DbManager.DEFAULT_DB
            db = new DbManager(connString: connString)
        }
        return db
    }
}
