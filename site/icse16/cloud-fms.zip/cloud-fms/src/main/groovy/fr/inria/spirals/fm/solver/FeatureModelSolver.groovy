package fr.inria.spirals.fm.solver
import fr.inria.spirals.fm.Configuration
import fr.inria.spirals.fm.model.FeatureModel
import fr.inria.spirals.fm.locators.FeatureLocator
import org.chocosolver.solver.Solver
import org.chocosolver.util.ESat

/**
 * Created by gustavo on 22/04/15.
 */
class FeatureModelSolver {
    FeatureModel featureModel

    Solver solver
    VariableManager vm
    FeatureLocator rootPath


    public FeatureModelSolver(FeatureModel featureModel, Solver solver, VariableManager vm, FeatureLocator rootPath) {
        this.featureModel = featureModel
        this.solver = solver
        this.vm = vm
        this.rootPath = rootPath
    }

    public long getNumSolutions() {
        solver.findAllSolutions()
    }

    public Iterable<Configuration> getSolutions() {
        new ConfigurationList(featureModel, vm, solver, rootPath)
    }

    VariableManager getVariableManager() {
        vm
    }

    public boolean isSatisfied() {
        solver.findSolution()
        solver.isSatisfied() == ESat.TRUE
    }
}
