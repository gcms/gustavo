package fr.inria.spirals.fm.locators

import fr.inria.spirals.fm.model.FeatureNode
import fr.inria.spirals.fm.config.Instance

/**
 * Created by gustavo on 16/06/15.
 */
class InstanceFeatureInstanceLocator extends FeatureInstanceLocator {
    Instance instance

    protected InstanceFeatureInstanceLocator(FeatureInstanceLocator parent, FeatureNode feature, Instance instance, int index) {
        super(parent, feature, index)
        this.instance = instance
    }

    Collection<FeatureLocator> getChildren() {
        feature.children.collect {
            new InstanceFeatureLocator(this, it, instance.getChildrenOf(it))
        }
    }
}
