package fr.inria.spirals.fm.solver

import org.chocosolver.solver.constraints.Constraint

/**
 * Created by gustavo on 16/06/15.
 */
interface ConstraintManager {
    void post(Constraint... constraints)

    Constraint getTRUE()
}
