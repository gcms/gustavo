package fr.inria.spirals.fm.model

/**
 * Created by gustavo on 07/04/15.
 */
abstract class FeatureNode {
    private FeatureModel featureModel

    private String name
    private FeatureNode parent
    private Set<FeatureNode> children = new LinkedHashSet()

    protected FeatureNode(String name, FeatureModel fm, FeatureNode parent) {
        this.name = name

        this.featureModel = fm
        fm.addFeature(this)

        this.parent = parent
        if (parent != null)
            parent.addChild(this)
    }

    public FeatureModel getFeatureModel() {
        featureModel
    }

    public String getName() {
        name
    }

    public FeatureNode getParent() {
        parent
    }

    public Set<FeatureNode> getChildren() {
        children
    }

    void setFeatureCardinality(int min, int max) {
        featureModel.addCardinality(this, this.parent, min..max as Cardinality)
    }

    void addChild(FeatureNode feature) {
        children << feature
    }

    boolean isDescendantOf(FeatureNode feature) {
        parent != null && (parent == feature || parent.isDescendantOf(feature))
    }

    FeatureNode getAncestorChildOf(FeatureNode feature) {
        parent == feature ? this : parent.getAncestorChildOf(feature)
    }

    Collection<FeatureNode> getAncestors() {
        parent == null ? [] : [parent] + parent.getAncestors()
    }

    Set<Feature> getSubTreeFeatures() {
        [this] + children.collect { it.subTreeFeatures }.flatten()
    }


    Cardinality getLocalCardinality() {
        parent == null ? 1..1 : featureModel.getLocalCardinality(this)
    }


    private Cardinality getDeclaredLocalCardinality() {
        featureModel.getDeclaredRelativeCardinality(this, this.parent)
    }

    private Collection<RelativeCardinality> getDeclaredRelativeCardinalities() {
        featureModel.getDeclaredCardinalitiesFrom(this).findAll { it.to != parent }
    }


    String toString() {
        if (parent == null)
            return name

        def localCard = getDeclaredLocalCardinality()

        String cardString
        if (localCard == null)
            cardString = ""
        else if (localCard == 1..1)
            cardString = "!"
        else if (localCard == 0..1)
            cardString = "?"
        else
            cardString = "[${localCard.toString()}]"

        def relativeCards = getDeclaredRelativeCardinalities()
        if (!relativeCards.empty)
            cardString += " " + relativeCards.
                    collect { it.toStringRelative() }.join(" ")


        parent == null ? name : "$name$cardString"
    }

    abstract boolean isGroup()

    boolean isRoot() {
        parent == null
    }

    boolean isMandatory() {
        localCardinality.min > 0
    }

    boolean isGroupVariant() {
        parent != null && parent.isGroup()
    }

    private int depth = -1
    int getDepth() {
        depth == -1 ? depth = calcDepth() : depth
    }

    protected int calcDepth() {
        parent == null ? 0 : 1 + parent.getDepth()
    }

    boolean isChildOf(FeatureNode node) {
        parent != null && parent == node
    }

    Collection<FeatureNode> getDescendants() {
        children.collect { [it] + it.getDescendants() }.flatten()
    }
}
