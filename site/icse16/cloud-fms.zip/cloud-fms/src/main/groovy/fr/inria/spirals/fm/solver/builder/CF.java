package fr.inria.spirals.fm.solver.builder;

import fr.inria.spirals.fm.locators.FeatureInstanceLocator;
import fr.inria.spirals.fm.locators.VariableLocator;
import fr.inria.spirals.fm.solver.VariableManager;
import fr.inria.spirals.fm.solver.propagator.PropArray;
import org.chocosolver.solver.constraints.Constraint;
import org.chocosolver.solver.constraints.ICF;
import org.chocosolver.solver.constraints.LCF;
import org.chocosolver.solver.variables.IntVar;
import org.chocosolver.solver.variables.VF;
import org.chocosolver.util.tools.StringUtils;

import java.util.List;

/**
 * Created by gustavo on 29/08/15.
 */
public class CF {
    static Constraint member(IntVar var, int min, int max) {
        if (min == max)
            return ICF.arithm(var, "=", min);

        return ICF.member(var, min, max);
    }

    static Constraint positive(IntVar var) {
        return ICF.arithm(var, ">", 0);
    }

    static Constraint zero(IntVar var) {
        return equal(var, 0);
    }

    static Constraint equal(IntVar v1, int cste) {
        return ICF.arithm(v1, "=", cste);
    }

    static Constraint equal(IntVar v1, IntVar v2) {
        return ICF.arithm(v1, "=", v2);
    }

    static Constraint countDiff(int val, IntVar[] vars, IntVar count) {
        IntVar countVal = VF.bounded(StringUtils.randomName(), 0, vars.length, count.getSolver());

//        count.getSolver().post(ICF.count(val, vars, numVals));
        return LCF.and(ICF.count(val, vars, countVal), ICF.arithm(count, "+", countVal, "=", vars.length));
    }

    static Constraint array(IntVar[] indexes, IntVar size) {
        if (indexes.length == 0) {
            return zero(size);
        } else if (indexes.length == 1) {
            return equal(size, indexes[0]);
        } else {
            return new Constraint("PropArray", new PropArray(indexes, size));
        }
    }

    static Constraint array(VariableManager vm, List<VariableLocator> indexes, VariableLocator size) {
        return array(vm.getVariables(indexes), vm.getVariable(size));
    }
}
