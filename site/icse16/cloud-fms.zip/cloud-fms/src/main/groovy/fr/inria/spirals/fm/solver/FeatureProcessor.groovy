package fr.inria.spirals.fm.solver

import fr.inria.spirals.fm.locators.FeatureLocator

/**
 * Created by gustavo on 16/06/15.
 */
interface FeatureProcessor extends VariableProcessor<FeatureLocator> {
    void process(SolverBuildingContext context, FeatureLocator featurePath)
}
