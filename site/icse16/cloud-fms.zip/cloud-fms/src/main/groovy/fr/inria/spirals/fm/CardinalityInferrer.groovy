package fr.inria.spirals.fm

import fr.inria.spirals.fm.model.Cardinality
import fr.inria.spirals.fm.model.FeatureModel
import fr.inria.spirals.fm.model.FeatureNode
import fr.inria.spirals.fm.model.RelativeCardinality
import fr.inria.spirals.fm.solver.propagator.PropXEqYPlus1
import org.chocosolver.solver.ResolutionPolicy
import org.chocosolver.solver.Settings
import org.chocosolver.solver.Solver
import org.chocosolver.solver.constraints.Constraint
import org.chocosolver.solver.constraints.ICF
import org.chocosolver.solver.search.solution.AllSolutionsRecorder
import org.chocosolver.solver.search.strategy.ISF
import org.chocosolver.solver.search.strategy.selectors.IntValueSelector
import org.chocosolver.solver.search.strategy.selectors.variables.FirstFail
import org.chocosolver.solver.variables.IntVar
import org.chocosolver.solver.variables.VF
import org.chocosolver.util.ESat
import org.slf4j.Logger
import org.slf4j.LoggerFactory
/**
 * Created by gustavo on 20/06/15.
 */
class CardinalityInferrer {
    Logger log = LoggerFactory.getLogger(CardinalityInferrer)

    private Solver solver

    private FeatureModel featureModel

    private IntVar optimize
    private List<IntVar> minVars = []
    private List<IntVar> maxVars = []

    private Map<String, Integer> maxBounds = [:]
    public int getMaxBound(FeatureNode from, FeatureNode to) {
        maxBounds.get(getMaxName(from, to))
    }

    public void calcMaxBound(FeatureNode from, FeatureNode to) {
        int localMax = calcMaxBetween(from, from.parent)
        if (from.isChildOf(to))
            maxBounds.put(getMaxName(from, to), localMax)
        else
            maxBounds.put(getMaxName(from, to), getMaxBound(from.parent, to) * localMax)
    }

    public int calcMaxBetween(FeatureNode from, FeatureNode to) {
        Cardinality declared = featureModel.getDeclaredCardinality(from, to)
        declared ? declared.max : calcMaxBetween(from, to.parent)
    }


    public CardinalityInferrer(FeatureModel fm) {
        long start = System.currentTimeMillis()
        log.info "Start building cardinality inferrer"

        this.solver = new Solver()
        this.solver.set(new Settings() {
            public boolean enableViews() {
                true
            }
        })

        this.featureModel = fm

        featureModel.features.sort { it.depth }.each { feat ->
            feat.ancestors.each { ancestor ->
                calcMaxBound(feat, ancestor)

                Cardinality card = featureModel.getDeclaredCardinality(feat, ancestor)
                addPair(feat, ancestor, card)
            }
        }

        def valueSelector = new IntValueSelector() {
            @Override
            int selectValue(IntVar var) {
                if (var.name.contains("max(") || var.name.contains("RangeMax") || var.name.contains("maxExcl"))
                    return var.getUB()
                else
                    return var.getLB()
            }
        }

        optimize = VF.bounded("sum", 0, (int) maxVars.sum { it.getUB() }, solver)
        def diffs = maxVars + minVars.collect { VF.minus(it) }
        solver.post(ICF.sum(diffs.toArray() as IntVar[], optimize))

        solver.set(new AllSolutionsRecorder(solver))
        solver.set(ISF.custom(new FirstFail(), valueSelector, solver.vars as IntVar[]))

//        Chatterbox.showDecisions(solver)
//        Chatterbox.showSolutions(solver)

        log.info("Start solving cardinalities")

        solver.findOptimalSolution(ResolutionPolicy.MAXIMIZE, optimize)
        long end = System.currentTimeMillis()

        log.info("Finished solving cardinalities. Total time: ${end - start} ms")
        if (solver.isFeasible() != ESat.TRUE)
            throw new InvalidCardinalitiesException("Invalid cardinalities")
    }

    private Map<String, IntVar> variables = [:]

    private IntVar createVar(String name, int min, int max) {
        IntVar var = VF.bounded(name, min, max, solver)
        log.debug var.toString()
        variables.put(name, var)
        var
    }

    public int getMaxValueMin(FeatureNode from, FeatureNode to) {
        int min = 0
        for (FeatureNode pivot = from.parent; pivot != to; pivot = pivot.parent) {
            String suffix = getSuffix(from, pivot, to)

            IntVar maxRangeMin = solver.vars.find { it.name == "maxRangeMin" + suffix }
            IntVar maxRangeMin2 = solver.vars.find { it.name == "maxRangeMin2" + suffix }

            min = Math.max(min, maxRangeMin.getValue())
            min = Math.max(min, maxRangeMin2.getValue())
        }

        Math.max(min, getMinValue(from, to))
    }

    public int getMaxValueMax(FeatureNode from, FeatureNode to) {
        int max = Integer.MAX_VALUE
        for (FeatureNode pivot = from.parent; pivot != to; pivot = pivot.parent) {
            String suffix = getSuffix(from, pivot, to)

            IntVar maxRangeMax = solver.vars.find { it.name == "maxRangeMax" + suffix }
            max = Math.min(max, maxRangeMax.getValue())
        }
        max
    }

    public int getMinValue(FeatureNode from, FeatureNode to) {
        getMinVar(from, to).getValue()
    }

    public int getMaxValue(FeatureNode from, FeatureNode to) {
        getMaxVar(from, to).getValue()
    }

    private String getMinName(FeatureNode from, FeatureNode to) {
        "min(${from.name}, ${to.name})"
    }

    private String getMaxName(FeatureNode from, FeatureNode to) {
        "max(${from.name}, ${to.name})"
    }

    private String getSuffix(FeatureNode from, FeatureNode pivot, FeatureNode to) {
        "(${from.name}, ${pivot.name}, ${to.name})"
    }

    private IntVar getMinVar(FeatureNode from, FeatureNode to) {
        String varName = getMinName(from, to)
        variables.get(varName) ?: createVar(varName, 0, getMaxBound(from, to))
    }

    private IntVar getMaxVar(FeatureNode from, FeatureNode to) {
        String varName = getMaxName(from, to)
        variables.get(varName) ?: createVar(varName, 1, getMaxBound(from, to))
    }

    private IntVar createConstant(String name, int value) {
        createVar(name, value, value)
    }

    private void addPair(FeatureNode from, FeatureNode to, Cardinality card) {
        if (card != null) {
            if (from.isChildOf(to) && from.isGroupVariant())
                card = 0..card.max as Cardinality

            createConstant(getMinName(from, to), card.min)
            createConstant(getMaxName(from, to), card.max)
        }

        def min = getMinVar(from, to)
        def max = getMaxVar(from, to)

        if (from.isChildOf(to)) {
            minVars << min
            maxVars << max
        }

        solver.post(ICF.arithm(min, "<=", max))
        log.debug "${_(min)} <= ${_(max)}"

        if (from.isChildOf(to))
            return

        for (FeatureNode pivot = from.parent; pivot != to; pivot = pivot.parent) {
            def localMin = getMinVar(from, pivot)
            def localMax = getMaxVar(from, pivot)

            def ancesMin = getMinVar(pivot, to)
            def ancesMax = getMaxVar(pivot, to)

            solver.post(ICF.arithm(localMax, "<=", max))
            log.debug "${_(localMax)} <= ${_(max)}"

            String suffix = getSuffix(from, pivot, to)
            def minRangeMin = VF.bounded("minRangeMin" + suffix, 0, localMax.getUB() * ancesMin.getUB(), solver)
            solver.post(ICF.times(localMin, ancesMin, minRangeMin))

            def minRangeMax = VF.bounded("minRangeMax" + suffix, 0, localMax.getUB() * ancesMin.getUB(), solver)
            solver.post(ICF.times(localMax, ancesMin, minRangeMax))

            solver.post(ICF.arithm(min, ">=", minRangeMin))
            solver.post(ICF.arithm(min, "<=", minRangeMax))
            log.debug "${_(localMin)} * ${_(ancesMin)} <= ${_(min)} <= ${_(localMax)} * ${_(ancesMin)}"


            def maxRangeMin = VF.bounded("maxRangeMin" + suffix, 0, localMin.getUB() * ancesMax.getUB(), solver)
            solver.post(ICF.times(localMin, ancesMax, maxRangeMin))

            def maxRangeMax = VF.bounded("maxRangeMax" + suffix, 1, localMax.getUB() * ancesMax.getUB(), solver)
            solver.post(ICF.times(localMax, ancesMax, maxRangeMax))

            solver.post(ICF.arithm(max, ">=", maxRangeMin))
            solver.post(ICF.arithm(max, "<=", maxRangeMax))
            log.debug "${_(localMin)} * ${_(ancesMax)} <= ${_(max)} <= ${_(localMax)} * ${_(ancesMax)}"


            //    ancMax*localMin <= max <= ancMax * localMac
            //    localMax * ancMin >= min >= localMin * ancMin


            def minExclFirst = VF.bounded("minExclFirst" + suffix, - localMin.getUB(), localMin.getUB() * ancesMin.getUB(), solver)
            def maxRangeMin2 = VF.bounded("maxRangeMin2" + suffix, - localMax.getUB() * ancesMax.getUB(), localMax.getUB() * ancesMax.getUB(), solver)
            def offset = VF.bounded("offset" + ancesMin.name, 0, Math.max(0, ancesMin.UB - 1), solver)
            solver.post(new Constraint("Prop", new PropXEqYPlus1(ancesMin, offset)))
//            solver.post(ICF.arithm(offset, "-", ancesMin, "=", -1))

            solver.post(ICF.times(localMin, offset, minExclFirst))
            solver.post(ICF.sum([localMax, minExclFirst] as IntVar[], maxRangeMin2))

            solver.post(ICF.arithm(max, ">=", maxRangeMin2))
//            LCF.ifThen(ICF.arithm(ancesMin, ">", 0),
//                    ICF.arithm(max, ">=", maxRangeMin2))

            def maxExclFirst = VF.bounded("maxExclFirst" + suffix, 0, localMax.getUB() * ancesMax.getUB(), solver)
            def minRangeMax2 = VF.bounded("minRangeMax2" + suffix, 0, localMax.getUB() * ancesMax.getUB(), solver)
            solver.post(ICF.times(localMax, VF.offset(ancesMax, - 1), maxExclFirst))
            solver.post(ICF.sum([localMin, maxExclFirst] as IntVar[], minRangeMax2))

            solver.post(ICF.arithm(min, "<=", minRangeMax2))


        }
    }

    private static String _(IntVar var) {
        var.isInstantiated() ? var.value : var.name
//        var.name + (!var.isInstantiated() ? "" : " = ${var.value}")
    }

    List<RelativeCardinality> getCardinalities() {
        featureModel.features.collect { feat ->
            feat.ancestors.collect { ancestor ->
                def min = getMinVar(feat, ancestor).getValue()
                def max = getMaxVar(feat, ancestor).getValue()

                new RelativeCardinality(feat, ancestor, new Cardinality(min, max))
            }
        }.flatten()
    }
}
