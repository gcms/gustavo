package fr.inria.spirals.fm.model
/**
 * Created by gustavo on 02/07/15.
 */
public class FeaturePair {
    FeatureNode from
    FeatureNode to

    public FeaturePair(FeatureNode from, FeatureNode to) {
        this.from = from
        this.to = to
    }

    boolean equals(o) {
        if (this.is(o)) return true
        if (!(o instanceof FeaturePair)) return false

        FeaturePair that = (FeaturePair) o

        if (from != that.from) return false
        if (to != that.to) return false

        return true
    }

    int hashCode() {
        int result
        result = from.hashCode()
        result = 31 * result + to.hashCode()
        return result
    }

    String toString() {
        "(${from.name}, ${to.name})"
    }
}