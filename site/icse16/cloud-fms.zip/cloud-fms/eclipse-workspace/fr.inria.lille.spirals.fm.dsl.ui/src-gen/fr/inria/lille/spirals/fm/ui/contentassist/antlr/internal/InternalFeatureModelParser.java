package fr.inria.lille.spirals.fm.ui.contentassist.antlr.internal; 

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ui.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ui.editor.contentassist.antlr.internal.DFA;
import fr.inria.lille.spirals.fm.services.FeatureModelGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalFeatureModelParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_STRING", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'config'", "'from'", "','", "'{'", "'}'", "'['", "']'", "'|'", "'<'", "'>'", "'..'", "'=>'", "'('", "')'", "'&'"
    };
    public static final int RULE_STRING=5;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int RULE_ID=4;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int RULE_INT=6;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalFeatureModelParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalFeatureModelParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalFeatureModelParser.tokenNames; }
    public String getGrammarFileName() { return "../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g"; }


     
     	private FeatureModelGrammarAccess grammarAccess;
     	
        public void setGrammarAccess(FeatureModelGrammarAccess grammarAccess) {
        	this.grammarAccess = grammarAccess;
        }
        
        @Override
        protected Grammar getGrammar() {
        	return grammarAccess.getGrammar();
        }
        
        @Override
        protected String getValueForTokenName(String tokenName) {
        	return tokenName;
        }




    // $ANTLR start "entryRuleElement"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:60:1: entryRuleElement : ruleElement EOF ;
    public final void entryRuleElement() throws RecognitionException {
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:61:1: ( ruleElement EOF )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:62:1: ruleElement EOF
            {
             before(grammarAccess.getElementRule()); 
            pushFollow(FOLLOW_ruleElement_in_entryRuleElement61);
            ruleElement();

            state._fsp--;

             after(grammarAccess.getElementRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleElement68); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleElement"


    // $ANTLR start "ruleElement"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:69:1: ruleElement : ( ( rule__Element__Alternatives ) ) ;
    public final void ruleElement() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:73:2: ( ( ( rule__Element__Alternatives ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:74:1: ( ( rule__Element__Alternatives ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:74:1: ( ( rule__Element__Alternatives ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:75:1: ( rule__Element__Alternatives )
            {
             before(grammarAccess.getElementAccess().getAlternatives()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:76:1: ( rule__Element__Alternatives )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:76:2: rule__Element__Alternatives
            {
            pushFollow(FOLLOW_rule__Element__Alternatives_in_ruleElement94);
            rule__Element__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getElementAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleElement"


    // $ANTLR start "entryRuleConfiguration"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:88:1: entryRuleConfiguration : ruleConfiguration EOF ;
    public final void entryRuleConfiguration() throws RecognitionException {
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:89:1: ( ruleConfiguration EOF )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:90:1: ruleConfiguration EOF
            {
             before(grammarAccess.getConfigurationRule()); 
            pushFollow(FOLLOW_ruleConfiguration_in_entryRuleConfiguration121);
            ruleConfiguration();

            state._fsp--;

             after(grammarAccess.getConfigurationRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleConfiguration128); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleConfiguration"


    // $ANTLR start "ruleConfiguration"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:97:1: ruleConfiguration : ( ( rule__Configuration__Group__0 ) ) ;
    public final void ruleConfiguration() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:101:2: ( ( ( rule__Configuration__Group__0 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:102:1: ( ( rule__Configuration__Group__0 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:102:1: ( ( rule__Configuration__Group__0 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:103:1: ( rule__Configuration__Group__0 )
            {
             before(grammarAccess.getConfigurationAccess().getGroup()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:104:1: ( rule__Configuration__Group__0 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:104:2: rule__Configuration__Group__0
            {
            pushFollow(FOLLOW_rule__Configuration__Group__0_in_ruleConfiguration154);
            rule__Configuration__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getConfigurationAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleConfiguration"


    // $ANTLR start "entryRuleInstance"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:116:1: entryRuleInstance : ruleInstance EOF ;
    public final void entryRuleInstance() throws RecognitionException {
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:117:1: ( ruleInstance EOF )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:118:1: ruleInstance EOF
            {
             before(grammarAccess.getInstanceRule()); 
            pushFollow(FOLLOW_ruleInstance_in_entryRuleInstance181);
            ruleInstance();

            state._fsp--;

             after(grammarAccess.getInstanceRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleInstance188); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleInstance"


    // $ANTLR start "ruleInstance"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:125:1: ruleInstance : ( ( rule__Instance__Group__0 ) ) ;
    public final void ruleInstance() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:129:2: ( ( ( rule__Instance__Group__0 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:130:1: ( ( rule__Instance__Group__0 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:130:1: ( ( rule__Instance__Group__0 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:131:1: ( rule__Instance__Group__0 )
            {
             before(grammarAccess.getInstanceAccess().getGroup()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:132:1: ( rule__Instance__Group__0 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:132:2: rule__Instance__Group__0
            {
            pushFollow(FOLLOW_rule__Instance__Group__0_in_ruleInstance214);
            rule__Instance__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getInstanceAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleInstance"


    // $ANTLR start "entryRuleFeatureModel"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:144:1: entryRuleFeatureModel : ruleFeatureModel EOF ;
    public final void entryRuleFeatureModel() throws RecognitionException {
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:145:1: ( ruleFeatureModel EOF )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:146:1: ruleFeatureModel EOF
            {
             before(grammarAccess.getFeatureModelRule()); 
            pushFollow(FOLLOW_ruleFeatureModel_in_entryRuleFeatureModel241);
            ruleFeatureModel();

            state._fsp--;

             after(grammarAccess.getFeatureModelRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleFeatureModel248); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleFeatureModel"


    // $ANTLR start "ruleFeatureModel"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:153:1: ruleFeatureModel : ( ( rule__FeatureModel__Group__0 ) ) ;
    public final void ruleFeatureModel() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:157:2: ( ( ( rule__FeatureModel__Group__0 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:158:1: ( ( rule__FeatureModel__Group__0 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:158:1: ( ( rule__FeatureModel__Group__0 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:159:1: ( rule__FeatureModel__Group__0 )
            {
             before(grammarAccess.getFeatureModelAccess().getGroup()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:160:1: ( rule__FeatureModel__Group__0 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:160:2: rule__FeatureModel__Group__0
            {
            pushFollow(FOLLOW_rule__FeatureModel__Group__0_in_ruleFeatureModel274);
            rule__FeatureModel__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getFeatureModelAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleFeatureModel"


    // $ANTLR start "entryRuleAbstractFeature"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:172:1: entryRuleAbstractFeature : ruleAbstractFeature EOF ;
    public final void entryRuleAbstractFeature() throws RecognitionException {
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:173:1: ( ruleAbstractFeature EOF )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:174:1: ruleAbstractFeature EOF
            {
             before(grammarAccess.getAbstractFeatureRule()); 
            pushFollow(FOLLOW_ruleAbstractFeature_in_entryRuleAbstractFeature301);
            ruleAbstractFeature();

            state._fsp--;

             after(grammarAccess.getAbstractFeatureRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleAbstractFeature308); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleAbstractFeature"


    // $ANTLR start "ruleAbstractFeature"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:181:1: ruleAbstractFeature : ( ( rule__AbstractFeature__Alternatives ) ) ;
    public final void ruleAbstractFeature() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:185:2: ( ( ( rule__AbstractFeature__Alternatives ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:186:1: ( ( rule__AbstractFeature__Alternatives ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:186:1: ( ( rule__AbstractFeature__Alternatives ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:187:1: ( rule__AbstractFeature__Alternatives )
            {
             before(grammarAccess.getAbstractFeatureAccess().getAlternatives()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:188:1: ( rule__AbstractFeature__Alternatives )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:188:2: rule__AbstractFeature__Alternatives
            {
            pushFollow(FOLLOW_rule__AbstractFeature__Alternatives_in_ruleAbstractFeature334);
            rule__AbstractFeature__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getAbstractFeatureAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleAbstractFeature"


    // $ANTLR start "entryRuleFeature"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:200:1: entryRuleFeature : ruleFeature EOF ;
    public final void entryRuleFeature() throws RecognitionException {
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:201:1: ( ruleFeature EOF )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:202:1: ruleFeature EOF
            {
             before(grammarAccess.getFeatureRule()); 
            pushFollow(FOLLOW_ruleFeature_in_entryRuleFeature361);
            ruleFeature();

            state._fsp--;

             after(grammarAccess.getFeatureRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleFeature368); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleFeature"


    // $ANTLR start "ruleFeature"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:209:1: ruleFeature : ( ( rule__Feature__Group__0 ) ) ;
    public final void ruleFeature() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:213:2: ( ( ( rule__Feature__Group__0 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:214:1: ( ( rule__Feature__Group__0 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:214:1: ( ( rule__Feature__Group__0 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:215:1: ( rule__Feature__Group__0 )
            {
             before(grammarAccess.getFeatureAccess().getGroup()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:216:1: ( rule__Feature__Group__0 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:216:2: rule__Feature__Group__0
            {
            pushFollow(FOLLOW_rule__Feature__Group__0_in_ruleFeature394);
            rule__Feature__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getFeatureAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleFeature"


    // $ANTLR start "entryRuleFeatureGroup"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:228:1: entryRuleFeatureGroup : ruleFeatureGroup EOF ;
    public final void entryRuleFeatureGroup() throws RecognitionException {
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:229:1: ( ruleFeatureGroup EOF )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:230:1: ruleFeatureGroup EOF
            {
             before(grammarAccess.getFeatureGroupRule()); 
            pushFollow(FOLLOW_ruleFeatureGroup_in_entryRuleFeatureGroup421);
            ruleFeatureGroup();

            state._fsp--;

             after(grammarAccess.getFeatureGroupRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleFeatureGroup428); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleFeatureGroup"


    // $ANTLR start "ruleFeatureGroup"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:237:1: ruleFeatureGroup : ( ( rule__FeatureGroup__Group__0 ) ) ;
    public final void ruleFeatureGroup() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:241:2: ( ( ( rule__FeatureGroup__Group__0 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:242:1: ( ( rule__FeatureGroup__Group__0 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:242:1: ( ( rule__FeatureGroup__Group__0 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:243:1: ( rule__FeatureGroup__Group__0 )
            {
             before(grammarAccess.getFeatureGroupAccess().getGroup()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:244:1: ( rule__FeatureGroup__Group__0 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:244:2: rule__FeatureGroup__Group__0
            {
            pushFollow(FOLLOW_rule__FeatureGroup__Group__0_in_ruleFeatureGroup454);
            rule__FeatureGroup__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getFeatureGroupAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleFeatureGroup"


    // $ANTLR start "entryRuleRelativeCardinalityDirect"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:256:1: entryRuleRelativeCardinalityDirect : ruleRelativeCardinalityDirect EOF ;
    public final void entryRuleRelativeCardinalityDirect() throws RecognitionException {
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:257:1: ( ruleRelativeCardinalityDirect EOF )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:258:1: ruleRelativeCardinalityDirect EOF
            {
             before(grammarAccess.getRelativeCardinalityDirectRule()); 
            pushFollow(FOLLOW_ruleRelativeCardinalityDirect_in_entryRuleRelativeCardinalityDirect481);
            ruleRelativeCardinalityDirect();

            state._fsp--;

             after(grammarAccess.getRelativeCardinalityDirectRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleRelativeCardinalityDirect488); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRelativeCardinalityDirect"


    // $ANTLR start "ruleRelativeCardinalityDirect"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:265:1: ruleRelativeCardinalityDirect : ( ( rule__RelativeCardinalityDirect__CardinalityAssignment ) ) ;
    public final void ruleRelativeCardinalityDirect() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:269:2: ( ( ( rule__RelativeCardinalityDirect__CardinalityAssignment ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:270:1: ( ( rule__RelativeCardinalityDirect__CardinalityAssignment ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:270:1: ( ( rule__RelativeCardinalityDirect__CardinalityAssignment ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:271:1: ( rule__RelativeCardinalityDirect__CardinalityAssignment )
            {
             before(grammarAccess.getRelativeCardinalityDirectAccess().getCardinalityAssignment()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:272:1: ( rule__RelativeCardinalityDirect__CardinalityAssignment )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:272:2: rule__RelativeCardinalityDirect__CardinalityAssignment
            {
            pushFollow(FOLLOW_rule__RelativeCardinalityDirect__CardinalityAssignment_in_ruleRelativeCardinalityDirect514);
            rule__RelativeCardinalityDirect__CardinalityAssignment();

            state._fsp--;


            }

             after(grammarAccess.getRelativeCardinalityDirectAccess().getCardinalityAssignment()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRelativeCardinalityDirect"


    // $ANTLR start "entryRuleRelativeCardinalityToUpper"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:284:1: entryRuleRelativeCardinalityToUpper : ruleRelativeCardinalityToUpper EOF ;
    public final void entryRuleRelativeCardinalityToUpper() throws RecognitionException {
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:285:1: ( ruleRelativeCardinalityToUpper EOF )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:286:1: ruleRelativeCardinalityToUpper EOF
            {
             before(grammarAccess.getRelativeCardinalityToUpperRule()); 
            pushFollow(FOLLOW_ruleRelativeCardinalityToUpper_in_entryRuleRelativeCardinalityToUpper541);
            ruleRelativeCardinalityToUpper();

            state._fsp--;

             after(grammarAccess.getRelativeCardinalityToUpperRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleRelativeCardinalityToUpper548); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleRelativeCardinalityToUpper"


    // $ANTLR start "ruleRelativeCardinalityToUpper"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:293:1: ruleRelativeCardinalityToUpper : ( ( rule__RelativeCardinalityToUpper__Group__0 ) ) ;
    public final void ruleRelativeCardinalityToUpper() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:297:2: ( ( ( rule__RelativeCardinalityToUpper__Group__0 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:298:1: ( ( rule__RelativeCardinalityToUpper__Group__0 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:298:1: ( ( rule__RelativeCardinalityToUpper__Group__0 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:299:1: ( rule__RelativeCardinalityToUpper__Group__0 )
            {
             before(grammarAccess.getRelativeCardinalityToUpperAccess().getGroup()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:300:1: ( rule__RelativeCardinalityToUpper__Group__0 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:300:2: rule__RelativeCardinalityToUpper__Group__0
            {
            pushFollow(FOLLOW_rule__RelativeCardinalityToUpper__Group__0_in_ruleRelativeCardinalityToUpper574);
            rule__RelativeCardinalityToUpper__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getRelativeCardinalityToUpperAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleRelativeCardinalityToUpper"


    // $ANTLR start "entryRuleGroupCardinality"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:312:1: entryRuleGroupCardinality : ruleGroupCardinality EOF ;
    public final void entryRuleGroupCardinality() throws RecognitionException {
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:313:1: ( ruleGroupCardinality EOF )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:314:1: ruleGroupCardinality EOF
            {
             before(grammarAccess.getGroupCardinalityRule()); 
            pushFollow(FOLLOW_ruleGroupCardinality_in_entryRuleGroupCardinality601);
            ruleGroupCardinality();

            state._fsp--;

             after(grammarAccess.getGroupCardinalityRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleGroupCardinality608); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleGroupCardinality"


    // $ANTLR start "ruleGroupCardinality"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:321:1: ruleGroupCardinality : ( ( rule__GroupCardinality__Group__0 ) ) ;
    public final void ruleGroupCardinality() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:325:2: ( ( ( rule__GroupCardinality__Group__0 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:326:1: ( ( rule__GroupCardinality__Group__0 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:326:1: ( ( rule__GroupCardinality__Group__0 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:327:1: ( rule__GroupCardinality__Group__0 )
            {
             before(grammarAccess.getGroupCardinalityAccess().getGroup()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:328:1: ( rule__GroupCardinality__Group__0 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:328:2: rule__GroupCardinality__Group__0
            {
            pushFollow(FOLLOW_rule__GroupCardinality__Group__0_in_ruleGroupCardinality634);
            rule__GroupCardinality__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getGroupCardinalityAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleGroupCardinality"


    // $ANTLR start "entryRuleFeatureCardinality"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:340:1: entryRuleFeatureCardinality : ruleFeatureCardinality EOF ;
    public final void entryRuleFeatureCardinality() throws RecognitionException {
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:341:1: ( ruleFeatureCardinality EOF )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:342:1: ruleFeatureCardinality EOF
            {
             before(grammarAccess.getFeatureCardinalityRule()); 
            pushFollow(FOLLOW_ruleFeatureCardinality_in_entryRuleFeatureCardinality661);
            ruleFeatureCardinality();

            state._fsp--;

             after(grammarAccess.getFeatureCardinalityRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleFeatureCardinality668); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleFeatureCardinality"


    // $ANTLR start "ruleFeatureCardinality"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:349:1: ruleFeatureCardinality : ( ( rule__FeatureCardinality__Group__0 ) ) ;
    public final void ruleFeatureCardinality() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:353:2: ( ( ( rule__FeatureCardinality__Group__0 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:354:1: ( ( rule__FeatureCardinality__Group__0 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:354:1: ( ( rule__FeatureCardinality__Group__0 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:355:1: ( rule__FeatureCardinality__Group__0 )
            {
             before(grammarAccess.getFeatureCardinalityAccess().getGroup()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:356:1: ( rule__FeatureCardinality__Group__0 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:356:2: rule__FeatureCardinality__Group__0
            {
            pushFollow(FOLLOW_rule__FeatureCardinality__Group__0_in_ruleFeatureCardinality694);
            rule__FeatureCardinality__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getFeatureCardinalityAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleFeatureCardinality"


    // $ANTLR start "entryRuleCardinality"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:368:1: entryRuleCardinality : ruleCardinality EOF ;
    public final void entryRuleCardinality() throws RecognitionException {
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:369:1: ( ruleCardinality EOF )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:370:1: ruleCardinality EOF
            {
             before(grammarAccess.getCardinalityRule()); 
            pushFollow(FOLLOW_ruleCardinality_in_entryRuleCardinality721);
            ruleCardinality();

            state._fsp--;

             after(grammarAccess.getCardinalityRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleCardinality728); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleCardinality"


    // $ANTLR start "ruleCardinality"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:377:1: ruleCardinality : ( ( rule__Cardinality__Group__0 ) ) ;
    public final void ruleCardinality() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:381:2: ( ( ( rule__Cardinality__Group__0 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:382:1: ( ( rule__Cardinality__Group__0 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:382:1: ( ( rule__Cardinality__Group__0 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:383:1: ( rule__Cardinality__Group__0 )
            {
             before(grammarAccess.getCardinalityAccess().getGroup()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:384:1: ( rule__Cardinality__Group__0 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:384:2: rule__Cardinality__Group__0
            {
            pushFollow(FOLLOW_rule__Cardinality__Group__0_in_ruleCardinality754);
            rule__Cardinality__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getCardinalityAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCardinality"


    // $ANTLR start "entryRuleConstraint"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:396:1: entryRuleConstraint : ruleConstraint EOF ;
    public final void entryRuleConstraint() throws RecognitionException {
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:397:1: ( ruleConstraint EOF )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:398:1: ruleConstraint EOF
            {
             before(grammarAccess.getConstraintRule()); 
            pushFollow(FOLLOW_ruleConstraint_in_entryRuleConstraint781);
            ruleConstraint();

            state._fsp--;

             after(grammarAccess.getConstraintRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleConstraint788); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleConstraint"


    // $ANTLR start "ruleConstraint"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:405:1: ruleConstraint : ( ( rule__Constraint__Group__0 ) ) ;
    public final void ruleConstraint() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:409:2: ( ( ( rule__Constraint__Group__0 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:410:1: ( ( rule__Constraint__Group__0 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:410:1: ( ( rule__Constraint__Group__0 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:411:1: ( rule__Constraint__Group__0 )
            {
             before(grammarAccess.getConstraintAccess().getGroup()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:412:1: ( rule__Constraint__Group__0 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:412:2: rule__Constraint__Group__0
            {
            pushFollow(FOLLOW_rule__Constraint__Group__0_in_ruleConstraint814);
            rule__Constraint__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getConstraintAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleConstraint"


    // $ANTLR start "entryRuleConstrainingExpression"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:424:1: entryRuleConstrainingExpression : ruleConstrainingExpression EOF ;
    public final void entryRuleConstrainingExpression() throws RecognitionException {
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:425:1: ( ruleConstrainingExpression EOF )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:426:1: ruleConstrainingExpression EOF
            {
             before(grammarAccess.getConstrainingExpressionRule()); 
            pushFollow(FOLLOW_ruleConstrainingExpression_in_entryRuleConstrainingExpression841);
            ruleConstrainingExpression();

            state._fsp--;

             after(grammarAccess.getConstrainingExpressionRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleConstrainingExpression848); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleConstrainingExpression"


    // $ANTLR start "ruleConstrainingExpression"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:433:1: ruleConstrainingExpression : ( ( rule__ConstrainingExpression__Group__0 ) ) ;
    public final void ruleConstrainingExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:437:2: ( ( ( rule__ConstrainingExpression__Group__0 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:438:1: ( ( rule__ConstrainingExpression__Group__0 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:438:1: ( ( rule__ConstrainingExpression__Group__0 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:439:1: ( rule__ConstrainingExpression__Group__0 )
            {
             before(grammarAccess.getConstrainingExpressionAccess().getGroup()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:440:1: ( rule__ConstrainingExpression__Group__0 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:440:2: rule__ConstrainingExpression__Group__0
            {
            pushFollow(FOLLOW_rule__ConstrainingExpression__Group__0_in_ruleConstrainingExpression874);
            rule__ConstrainingExpression__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getConstrainingExpressionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleConstrainingExpression"


    // $ANTLR start "entryRuleExpression"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:452:1: entryRuleExpression : ruleExpression EOF ;
    public final void entryRuleExpression() throws RecognitionException {
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:453:1: ( ruleExpression EOF )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:454:1: ruleExpression EOF
            {
             before(grammarAccess.getExpressionRule()); 
            pushFollow(FOLLOW_ruleExpression_in_entryRuleExpression901);
            ruleExpression();

            state._fsp--;

             after(grammarAccess.getExpressionRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleExpression908); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleExpression"


    // $ANTLR start "ruleExpression"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:461:1: ruleExpression : ( ruleOrConstrainingExpression ) ;
    public final void ruleExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:465:2: ( ( ruleOrConstrainingExpression ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:466:1: ( ruleOrConstrainingExpression )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:466:1: ( ruleOrConstrainingExpression )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:467:1: ruleOrConstrainingExpression
            {
             before(grammarAccess.getExpressionAccess().getOrConstrainingExpressionParserRuleCall()); 
            pushFollow(FOLLOW_ruleOrConstrainingExpression_in_ruleExpression934);
            ruleOrConstrainingExpression();

            state._fsp--;

             after(grammarAccess.getExpressionAccess().getOrConstrainingExpressionParserRuleCall()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleExpression"


    // $ANTLR start "entryRuleOrConstrainingExpression"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:480:1: entryRuleOrConstrainingExpression : ruleOrConstrainingExpression EOF ;
    public final void entryRuleOrConstrainingExpression() throws RecognitionException {
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:481:1: ( ruleOrConstrainingExpression EOF )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:482:1: ruleOrConstrainingExpression EOF
            {
             before(grammarAccess.getOrConstrainingExpressionRule()); 
            pushFollow(FOLLOW_ruleOrConstrainingExpression_in_entryRuleOrConstrainingExpression960);
            ruleOrConstrainingExpression();

            state._fsp--;

             after(grammarAccess.getOrConstrainingExpressionRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleOrConstrainingExpression967); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleOrConstrainingExpression"


    // $ANTLR start "ruleOrConstrainingExpression"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:489:1: ruleOrConstrainingExpression : ( ( rule__OrConstrainingExpression__Group__0 ) ) ;
    public final void ruleOrConstrainingExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:493:2: ( ( ( rule__OrConstrainingExpression__Group__0 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:494:1: ( ( rule__OrConstrainingExpression__Group__0 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:494:1: ( ( rule__OrConstrainingExpression__Group__0 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:495:1: ( rule__OrConstrainingExpression__Group__0 )
            {
             before(grammarAccess.getOrConstrainingExpressionAccess().getGroup()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:496:1: ( rule__OrConstrainingExpression__Group__0 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:496:2: rule__OrConstrainingExpression__Group__0
            {
            pushFollow(FOLLOW_rule__OrConstrainingExpression__Group__0_in_ruleOrConstrainingExpression993);
            rule__OrConstrainingExpression__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getOrConstrainingExpressionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleOrConstrainingExpression"


    // $ANTLR start "entryRuleAndConstrainingExpression"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:508:1: entryRuleAndConstrainingExpression : ruleAndConstrainingExpression EOF ;
    public final void entryRuleAndConstrainingExpression() throws RecognitionException {
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:509:1: ( ruleAndConstrainingExpression EOF )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:510:1: ruleAndConstrainingExpression EOF
            {
             before(grammarAccess.getAndConstrainingExpressionRule()); 
            pushFollow(FOLLOW_ruleAndConstrainingExpression_in_entryRuleAndConstrainingExpression1020);
            ruleAndConstrainingExpression();

            state._fsp--;

             after(grammarAccess.getAndConstrainingExpressionRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRuleAndConstrainingExpression1027); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleAndConstrainingExpression"


    // $ANTLR start "ruleAndConstrainingExpression"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:517:1: ruleAndConstrainingExpression : ( ( rule__AndConstrainingExpression__Group__0 ) ) ;
    public final void ruleAndConstrainingExpression() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:521:2: ( ( ( rule__AndConstrainingExpression__Group__0 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:522:1: ( ( rule__AndConstrainingExpression__Group__0 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:522:1: ( ( rule__AndConstrainingExpression__Group__0 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:523:1: ( rule__AndConstrainingExpression__Group__0 )
            {
             before(grammarAccess.getAndConstrainingExpressionAccess().getGroup()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:524:1: ( rule__AndConstrainingExpression__Group__0 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:524:2: rule__AndConstrainingExpression__Group__0
            {
            pushFollow(FOLLOW_rule__AndConstrainingExpression__Group__0_in_ruleAndConstrainingExpression1053);
            rule__AndConstrainingExpression__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getAndConstrainingExpressionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleAndConstrainingExpression"


    // $ANTLR start "entryRulePrimary"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:536:1: entryRulePrimary : rulePrimary EOF ;
    public final void entryRulePrimary() throws RecognitionException {
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:537:1: ( rulePrimary EOF )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:538:1: rulePrimary EOF
            {
             before(grammarAccess.getPrimaryRule()); 
            pushFollow(FOLLOW_rulePrimary_in_entryRulePrimary1080);
            rulePrimary();

            state._fsp--;

             after(grammarAccess.getPrimaryRule()); 
            match(input,EOF,FOLLOW_EOF_in_entryRulePrimary1087); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRulePrimary"


    // $ANTLR start "rulePrimary"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:545:1: rulePrimary : ( ( rule__Primary__Alternatives ) ) ;
    public final void rulePrimary() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:549:2: ( ( ( rule__Primary__Alternatives ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:550:1: ( ( rule__Primary__Alternatives ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:550:1: ( ( rule__Primary__Alternatives ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:551:1: ( rule__Primary__Alternatives )
            {
             before(grammarAccess.getPrimaryAccess().getAlternatives()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:552:1: ( rule__Primary__Alternatives )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:552:2: rule__Primary__Alternatives
            {
            pushFollow(FOLLOW_rule__Primary__Alternatives_in_rulePrimary1113);
            rule__Primary__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getPrimaryAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rulePrimary"


    // $ANTLR start "rule__Element__Alternatives"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:564:1: rule__Element__Alternatives : ( ( ruleFeatureModel ) | ( ruleConfiguration ) );
    public final void rule__Element__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:568:1: ( ( ruleFeatureModel ) | ( ruleConfiguration ) )
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==RULE_ID) ) {
                alt1=1;
            }
            else if ( (LA1_0==11) ) {
                alt1=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:569:1: ( ruleFeatureModel )
                    {
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:569:1: ( ruleFeatureModel )
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:570:1: ruleFeatureModel
                    {
                     before(grammarAccess.getElementAccess().getFeatureModelParserRuleCall_0()); 
                    pushFollow(FOLLOW_ruleFeatureModel_in_rule__Element__Alternatives1149);
                    ruleFeatureModel();

                    state._fsp--;

                     after(grammarAccess.getElementAccess().getFeatureModelParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:575:6: ( ruleConfiguration )
                    {
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:575:6: ( ruleConfiguration )
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:576:1: ruleConfiguration
                    {
                     before(grammarAccess.getElementAccess().getConfigurationParserRuleCall_1()); 
                    pushFollow(FOLLOW_ruleConfiguration_in_rule__Element__Alternatives1166);
                    ruleConfiguration();

                    state._fsp--;

                     after(grammarAccess.getElementAccess().getConfigurationParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Element__Alternatives"


    // $ANTLR start "rule__AbstractFeature__Alternatives"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:586:1: rule__AbstractFeature__Alternatives : ( ( ruleFeature ) | ( ruleFeatureGroup ) );
    public final void rule__AbstractFeature__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:590:1: ( ( ruleFeature ) | ( ruleFeatureGroup ) )
            int alt2=2;
            alt2 = dfa2.predict(input);
            switch (alt2) {
                case 1 :
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:591:1: ( ruleFeature )
                    {
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:591:1: ( ruleFeature )
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:592:1: ruleFeature
                    {
                     before(grammarAccess.getAbstractFeatureAccess().getFeatureParserRuleCall_0()); 
                    pushFollow(FOLLOW_ruleFeature_in_rule__AbstractFeature__Alternatives1198);
                    ruleFeature();

                    state._fsp--;

                     after(grammarAccess.getAbstractFeatureAccess().getFeatureParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:597:6: ( ruleFeatureGroup )
                    {
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:597:6: ( ruleFeatureGroup )
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:598:1: ruleFeatureGroup
                    {
                     before(grammarAccess.getAbstractFeatureAccess().getFeatureGroupParserRuleCall_1()); 
                    pushFollow(FOLLOW_ruleFeatureGroup_in_rule__AbstractFeature__Alternatives1215);
                    ruleFeatureGroup();

                    state._fsp--;

                     after(grammarAccess.getAbstractFeatureAccess().getFeatureGroupParserRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AbstractFeature__Alternatives"


    // $ANTLR start "rule__Primary__Alternatives"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:608:1: rule__Primary__Alternatives : ( ( ruleConstrainingExpression ) | ( ( rule__Primary__Group_1__0 ) ) );
    public final void rule__Primary__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:612:1: ( ( ruleConstrainingExpression ) | ( ( rule__Primary__Group_1__0 ) ) )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==16) ) {
                alt3=1;
            }
            else if ( (LA3_0==23) ) {
                alt3=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:613:1: ( ruleConstrainingExpression )
                    {
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:613:1: ( ruleConstrainingExpression )
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:614:1: ruleConstrainingExpression
                    {
                     before(grammarAccess.getPrimaryAccess().getConstrainingExpressionParserRuleCall_0()); 
                    pushFollow(FOLLOW_ruleConstrainingExpression_in_rule__Primary__Alternatives1247);
                    ruleConstrainingExpression();

                    state._fsp--;

                     after(grammarAccess.getPrimaryAccess().getConstrainingExpressionParserRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:619:6: ( ( rule__Primary__Group_1__0 ) )
                    {
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:619:6: ( ( rule__Primary__Group_1__0 ) )
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:620:1: ( rule__Primary__Group_1__0 )
                    {
                     before(grammarAccess.getPrimaryAccess().getGroup_1()); 
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:621:1: ( rule__Primary__Group_1__0 )
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:621:2: rule__Primary__Group_1__0
                    {
                    pushFollow(FOLLOW_rule__Primary__Group_1__0_in_rule__Primary__Alternatives1264);
                    rule__Primary__Group_1__0();

                    state._fsp--;


                    }

                     after(grammarAccess.getPrimaryAccess().getGroup_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Primary__Alternatives"


    // $ANTLR start "rule__Configuration__Group__0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:632:1: rule__Configuration__Group__0 : rule__Configuration__Group__0__Impl rule__Configuration__Group__1 ;
    public final void rule__Configuration__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:636:1: ( rule__Configuration__Group__0__Impl rule__Configuration__Group__1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:637:2: rule__Configuration__Group__0__Impl rule__Configuration__Group__1
            {
            pushFollow(FOLLOW_rule__Configuration__Group__0__Impl_in_rule__Configuration__Group__01295);
            rule__Configuration__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Configuration__Group__1_in_rule__Configuration__Group__01298);
            rule__Configuration__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Configuration__Group__0"


    // $ANTLR start "rule__Configuration__Group__0__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:644:1: rule__Configuration__Group__0__Impl : ( 'config' ) ;
    public final void rule__Configuration__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:648:1: ( ( 'config' ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:649:1: ( 'config' )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:649:1: ( 'config' )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:650:1: 'config'
            {
             before(grammarAccess.getConfigurationAccess().getConfigKeyword_0()); 
            match(input,11,FOLLOW_11_in_rule__Configuration__Group__0__Impl1326); 
             after(grammarAccess.getConfigurationAccess().getConfigKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Configuration__Group__0__Impl"


    // $ANTLR start "rule__Configuration__Group__1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:663:1: rule__Configuration__Group__1 : rule__Configuration__Group__1__Impl rule__Configuration__Group__2 ;
    public final void rule__Configuration__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:667:1: ( rule__Configuration__Group__1__Impl rule__Configuration__Group__2 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:668:2: rule__Configuration__Group__1__Impl rule__Configuration__Group__2
            {
            pushFollow(FOLLOW_rule__Configuration__Group__1__Impl_in_rule__Configuration__Group__11357);
            rule__Configuration__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Configuration__Group__2_in_rule__Configuration__Group__11360);
            rule__Configuration__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Configuration__Group__1"


    // $ANTLR start "rule__Configuration__Group__1__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:675:1: rule__Configuration__Group__1__Impl : ( ( rule__Configuration__FeatureModelAssignment_1 ) ) ;
    public final void rule__Configuration__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:679:1: ( ( ( rule__Configuration__FeatureModelAssignment_1 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:680:1: ( ( rule__Configuration__FeatureModelAssignment_1 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:680:1: ( ( rule__Configuration__FeatureModelAssignment_1 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:681:1: ( rule__Configuration__FeatureModelAssignment_1 )
            {
             before(grammarAccess.getConfigurationAccess().getFeatureModelAssignment_1()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:682:1: ( rule__Configuration__FeatureModelAssignment_1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:682:2: rule__Configuration__FeatureModelAssignment_1
            {
            pushFollow(FOLLOW_rule__Configuration__FeatureModelAssignment_1_in_rule__Configuration__Group__1__Impl1387);
            rule__Configuration__FeatureModelAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getConfigurationAccess().getFeatureModelAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Configuration__Group__1__Impl"


    // $ANTLR start "rule__Configuration__Group__2"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:692:1: rule__Configuration__Group__2 : rule__Configuration__Group__2__Impl rule__Configuration__Group__3 ;
    public final void rule__Configuration__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:696:1: ( rule__Configuration__Group__2__Impl rule__Configuration__Group__3 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:697:2: rule__Configuration__Group__2__Impl rule__Configuration__Group__3
            {
            pushFollow(FOLLOW_rule__Configuration__Group__2__Impl_in_rule__Configuration__Group__21417);
            rule__Configuration__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Configuration__Group__3_in_rule__Configuration__Group__21420);
            rule__Configuration__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Configuration__Group__2"


    // $ANTLR start "rule__Configuration__Group__2__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:704:1: rule__Configuration__Group__2__Impl : ( ( rule__Configuration__Group_2__0 )? ) ;
    public final void rule__Configuration__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:708:1: ( ( ( rule__Configuration__Group_2__0 )? ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:709:1: ( ( rule__Configuration__Group_2__0 )? )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:709:1: ( ( rule__Configuration__Group_2__0 )? )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:710:1: ( rule__Configuration__Group_2__0 )?
            {
             before(grammarAccess.getConfigurationAccess().getGroup_2()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:711:1: ( rule__Configuration__Group_2__0 )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==12) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:711:2: rule__Configuration__Group_2__0
                    {
                    pushFollow(FOLLOW_rule__Configuration__Group_2__0_in_rule__Configuration__Group__2__Impl1447);
                    rule__Configuration__Group_2__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getConfigurationAccess().getGroup_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Configuration__Group__2__Impl"


    // $ANTLR start "rule__Configuration__Group__3"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:721:1: rule__Configuration__Group__3 : rule__Configuration__Group__3__Impl rule__Configuration__Group__4 ;
    public final void rule__Configuration__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:725:1: ( rule__Configuration__Group__3__Impl rule__Configuration__Group__4 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:726:2: rule__Configuration__Group__3__Impl rule__Configuration__Group__4
            {
            pushFollow(FOLLOW_rule__Configuration__Group__3__Impl_in_rule__Configuration__Group__31478);
            rule__Configuration__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Configuration__Group__4_in_rule__Configuration__Group__31481);
            rule__Configuration__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Configuration__Group__3"


    // $ANTLR start "rule__Configuration__Group__3__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:733:1: rule__Configuration__Group__3__Impl : ( ( rule__Configuration__InstancesAssignment_3 ) ) ;
    public final void rule__Configuration__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:737:1: ( ( ( rule__Configuration__InstancesAssignment_3 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:738:1: ( ( rule__Configuration__InstancesAssignment_3 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:738:1: ( ( rule__Configuration__InstancesAssignment_3 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:739:1: ( rule__Configuration__InstancesAssignment_3 )
            {
             before(grammarAccess.getConfigurationAccess().getInstancesAssignment_3()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:740:1: ( rule__Configuration__InstancesAssignment_3 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:740:2: rule__Configuration__InstancesAssignment_3
            {
            pushFollow(FOLLOW_rule__Configuration__InstancesAssignment_3_in_rule__Configuration__Group__3__Impl1508);
            rule__Configuration__InstancesAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getConfigurationAccess().getInstancesAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Configuration__Group__3__Impl"


    // $ANTLR start "rule__Configuration__Group__4"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:750:1: rule__Configuration__Group__4 : rule__Configuration__Group__4__Impl ;
    public final void rule__Configuration__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:754:1: ( rule__Configuration__Group__4__Impl )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:755:2: rule__Configuration__Group__4__Impl
            {
            pushFollow(FOLLOW_rule__Configuration__Group__4__Impl_in_rule__Configuration__Group__41538);
            rule__Configuration__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Configuration__Group__4"


    // $ANTLR start "rule__Configuration__Group__4__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:761:1: rule__Configuration__Group__4__Impl : ( ( rule__Configuration__Group_4__0 )* ) ;
    public final void rule__Configuration__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:765:1: ( ( ( rule__Configuration__Group_4__0 )* ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:766:1: ( ( rule__Configuration__Group_4__0 )* )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:766:1: ( ( rule__Configuration__Group_4__0 )* )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:767:1: ( rule__Configuration__Group_4__0 )*
            {
             before(grammarAccess.getConfigurationAccess().getGroup_4()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:768:1: ( rule__Configuration__Group_4__0 )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==RULE_ID||LA5_0==RULE_INT||LA5_0==13) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:768:2: rule__Configuration__Group_4__0
            	    {
            	    pushFollow(FOLLOW_rule__Configuration__Group_4__0_in_rule__Configuration__Group__4__Impl1565);
            	    rule__Configuration__Group_4__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

             after(grammarAccess.getConfigurationAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Configuration__Group__4__Impl"


    // $ANTLR start "rule__Configuration__Group_2__0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:788:1: rule__Configuration__Group_2__0 : rule__Configuration__Group_2__0__Impl rule__Configuration__Group_2__1 ;
    public final void rule__Configuration__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:792:1: ( rule__Configuration__Group_2__0__Impl rule__Configuration__Group_2__1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:793:2: rule__Configuration__Group_2__0__Impl rule__Configuration__Group_2__1
            {
            pushFollow(FOLLOW_rule__Configuration__Group_2__0__Impl_in_rule__Configuration__Group_2__01606);
            rule__Configuration__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Configuration__Group_2__1_in_rule__Configuration__Group_2__01609);
            rule__Configuration__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Configuration__Group_2__0"


    // $ANTLR start "rule__Configuration__Group_2__0__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:800:1: rule__Configuration__Group_2__0__Impl : ( 'from' ) ;
    public final void rule__Configuration__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:804:1: ( ( 'from' ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:805:1: ( 'from' )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:805:1: ( 'from' )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:806:1: 'from'
            {
             before(grammarAccess.getConfigurationAccess().getFromKeyword_2_0()); 
            match(input,12,FOLLOW_12_in_rule__Configuration__Group_2__0__Impl1637); 
             after(grammarAccess.getConfigurationAccess().getFromKeyword_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Configuration__Group_2__0__Impl"


    // $ANTLR start "rule__Configuration__Group_2__1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:819:1: rule__Configuration__Group_2__1 : rule__Configuration__Group_2__1__Impl ;
    public final void rule__Configuration__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:823:1: ( rule__Configuration__Group_2__1__Impl )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:824:2: rule__Configuration__Group_2__1__Impl
            {
            pushFollow(FOLLOW_rule__Configuration__Group_2__1__Impl_in_rule__Configuration__Group_2__11668);
            rule__Configuration__Group_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Configuration__Group_2__1"


    // $ANTLR start "rule__Configuration__Group_2__1__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:830:1: rule__Configuration__Group_2__1__Impl : ( ( rule__Configuration__ImportURIAssignment_2_1 ) ) ;
    public final void rule__Configuration__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:834:1: ( ( ( rule__Configuration__ImportURIAssignment_2_1 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:835:1: ( ( rule__Configuration__ImportURIAssignment_2_1 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:835:1: ( ( rule__Configuration__ImportURIAssignment_2_1 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:836:1: ( rule__Configuration__ImportURIAssignment_2_1 )
            {
             before(grammarAccess.getConfigurationAccess().getImportURIAssignment_2_1()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:837:1: ( rule__Configuration__ImportURIAssignment_2_1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:837:2: rule__Configuration__ImportURIAssignment_2_1
            {
            pushFollow(FOLLOW_rule__Configuration__ImportURIAssignment_2_1_in_rule__Configuration__Group_2__1__Impl1695);
            rule__Configuration__ImportURIAssignment_2_1();

            state._fsp--;


            }

             after(grammarAccess.getConfigurationAccess().getImportURIAssignment_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Configuration__Group_2__1__Impl"


    // $ANTLR start "rule__Configuration__Group_4__0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:851:1: rule__Configuration__Group_4__0 : rule__Configuration__Group_4__0__Impl rule__Configuration__Group_4__1 ;
    public final void rule__Configuration__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:855:1: ( rule__Configuration__Group_4__0__Impl rule__Configuration__Group_4__1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:856:2: rule__Configuration__Group_4__0__Impl rule__Configuration__Group_4__1
            {
            pushFollow(FOLLOW_rule__Configuration__Group_4__0__Impl_in_rule__Configuration__Group_4__01729);
            rule__Configuration__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Configuration__Group_4__1_in_rule__Configuration__Group_4__01732);
            rule__Configuration__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Configuration__Group_4__0"


    // $ANTLR start "rule__Configuration__Group_4__0__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:863:1: rule__Configuration__Group_4__0__Impl : ( ( ',' )? ) ;
    public final void rule__Configuration__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:867:1: ( ( ( ',' )? ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:868:1: ( ( ',' )? )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:868:1: ( ( ',' )? )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:869:1: ( ',' )?
            {
             before(grammarAccess.getConfigurationAccess().getCommaKeyword_4_0()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:870:1: ( ',' )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==13) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:871:2: ','
                    {
                    match(input,13,FOLLOW_13_in_rule__Configuration__Group_4__0__Impl1761); 

                    }
                    break;

            }

             after(grammarAccess.getConfigurationAccess().getCommaKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Configuration__Group_4__0__Impl"


    // $ANTLR start "rule__Configuration__Group_4__1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:882:1: rule__Configuration__Group_4__1 : rule__Configuration__Group_4__1__Impl ;
    public final void rule__Configuration__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:886:1: ( rule__Configuration__Group_4__1__Impl )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:887:2: rule__Configuration__Group_4__1__Impl
            {
            pushFollow(FOLLOW_rule__Configuration__Group_4__1__Impl_in_rule__Configuration__Group_4__11794);
            rule__Configuration__Group_4__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Configuration__Group_4__1"


    // $ANTLR start "rule__Configuration__Group_4__1__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:893:1: rule__Configuration__Group_4__1__Impl : ( ( rule__Configuration__InstancesAssignment_4_1 ) ) ;
    public final void rule__Configuration__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:897:1: ( ( ( rule__Configuration__InstancesAssignment_4_1 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:898:1: ( ( rule__Configuration__InstancesAssignment_4_1 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:898:1: ( ( rule__Configuration__InstancesAssignment_4_1 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:899:1: ( rule__Configuration__InstancesAssignment_4_1 )
            {
             before(grammarAccess.getConfigurationAccess().getInstancesAssignment_4_1()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:900:1: ( rule__Configuration__InstancesAssignment_4_1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:900:2: rule__Configuration__InstancesAssignment_4_1
            {
            pushFollow(FOLLOW_rule__Configuration__InstancesAssignment_4_1_in_rule__Configuration__Group_4__1__Impl1821);
            rule__Configuration__InstancesAssignment_4_1();

            state._fsp--;


            }

             after(grammarAccess.getConfigurationAccess().getInstancesAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Configuration__Group_4__1__Impl"


    // $ANTLR start "rule__Instance__Group__0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:914:1: rule__Instance__Group__0 : rule__Instance__Group__0__Impl rule__Instance__Group__1 ;
    public final void rule__Instance__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:918:1: ( rule__Instance__Group__0__Impl rule__Instance__Group__1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:919:2: rule__Instance__Group__0__Impl rule__Instance__Group__1
            {
            pushFollow(FOLLOW_rule__Instance__Group__0__Impl_in_rule__Instance__Group__01855);
            rule__Instance__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Instance__Group__1_in_rule__Instance__Group__01858);
            rule__Instance__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Instance__Group__0"


    // $ANTLR start "rule__Instance__Group__0__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:926:1: rule__Instance__Group__0__Impl : ( ( rule__Instance__NumberAssignment_0 )? ) ;
    public final void rule__Instance__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:930:1: ( ( ( rule__Instance__NumberAssignment_0 )? ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:931:1: ( ( rule__Instance__NumberAssignment_0 )? )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:931:1: ( ( rule__Instance__NumberAssignment_0 )? )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:932:1: ( rule__Instance__NumberAssignment_0 )?
            {
             before(grammarAccess.getInstanceAccess().getNumberAssignment_0()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:933:1: ( rule__Instance__NumberAssignment_0 )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==RULE_INT) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:933:2: rule__Instance__NumberAssignment_0
                    {
                    pushFollow(FOLLOW_rule__Instance__NumberAssignment_0_in_rule__Instance__Group__0__Impl1885);
                    rule__Instance__NumberAssignment_0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getInstanceAccess().getNumberAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Instance__Group__0__Impl"


    // $ANTLR start "rule__Instance__Group__1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:943:1: rule__Instance__Group__1 : rule__Instance__Group__1__Impl rule__Instance__Group__2 ;
    public final void rule__Instance__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:947:1: ( rule__Instance__Group__1__Impl rule__Instance__Group__2 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:948:2: rule__Instance__Group__1__Impl rule__Instance__Group__2
            {
            pushFollow(FOLLOW_rule__Instance__Group__1__Impl_in_rule__Instance__Group__11916);
            rule__Instance__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Instance__Group__2_in_rule__Instance__Group__11919);
            rule__Instance__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Instance__Group__1"


    // $ANTLR start "rule__Instance__Group__1__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:955:1: rule__Instance__Group__1__Impl : ( ( rule__Instance__TypeAssignment_1 ) ) ;
    public final void rule__Instance__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:959:1: ( ( ( rule__Instance__TypeAssignment_1 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:960:1: ( ( rule__Instance__TypeAssignment_1 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:960:1: ( ( rule__Instance__TypeAssignment_1 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:961:1: ( rule__Instance__TypeAssignment_1 )
            {
             before(grammarAccess.getInstanceAccess().getTypeAssignment_1()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:962:1: ( rule__Instance__TypeAssignment_1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:962:2: rule__Instance__TypeAssignment_1
            {
            pushFollow(FOLLOW_rule__Instance__TypeAssignment_1_in_rule__Instance__Group__1__Impl1946);
            rule__Instance__TypeAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getInstanceAccess().getTypeAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Instance__Group__1__Impl"


    // $ANTLR start "rule__Instance__Group__2"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:972:1: rule__Instance__Group__2 : rule__Instance__Group__2__Impl ;
    public final void rule__Instance__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:976:1: ( rule__Instance__Group__2__Impl )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:977:2: rule__Instance__Group__2__Impl
            {
            pushFollow(FOLLOW_rule__Instance__Group__2__Impl_in_rule__Instance__Group__21976);
            rule__Instance__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Instance__Group__2"


    // $ANTLR start "rule__Instance__Group__2__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:983:1: rule__Instance__Group__2__Impl : ( ( rule__Instance__Group_2__0 )? ) ;
    public final void rule__Instance__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:987:1: ( ( ( rule__Instance__Group_2__0 )? ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:988:1: ( ( rule__Instance__Group_2__0 )? )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:988:1: ( ( rule__Instance__Group_2__0 )? )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:989:1: ( rule__Instance__Group_2__0 )?
            {
             before(grammarAccess.getInstanceAccess().getGroup_2()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:990:1: ( rule__Instance__Group_2__0 )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==14) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:990:2: rule__Instance__Group_2__0
                    {
                    pushFollow(FOLLOW_rule__Instance__Group_2__0_in_rule__Instance__Group__2__Impl2003);
                    rule__Instance__Group_2__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getInstanceAccess().getGroup_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Instance__Group__2__Impl"


    // $ANTLR start "rule__Instance__Group_2__0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1006:1: rule__Instance__Group_2__0 : rule__Instance__Group_2__0__Impl rule__Instance__Group_2__1 ;
    public final void rule__Instance__Group_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1010:1: ( rule__Instance__Group_2__0__Impl rule__Instance__Group_2__1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1011:2: rule__Instance__Group_2__0__Impl rule__Instance__Group_2__1
            {
            pushFollow(FOLLOW_rule__Instance__Group_2__0__Impl_in_rule__Instance__Group_2__02040);
            rule__Instance__Group_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Instance__Group_2__1_in_rule__Instance__Group_2__02043);
            rule__Instance__Group_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Instance__Group_2__0"


    // $ANTLR start "rule__Instance__Group_2__0__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1018:1: rule__Instance__Group_2__0__Impl : ( '{' ) ;
    public final void rule__Instance__Group_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1022:1: ( ( '{' ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1023:1: ( '{' )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1023:1: ( '{' )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1024:1: '{'
            {
             before(grammarAccess.getInstanceAccess().getLeftCurlyBracketKeyword_2_0()); 
            match(input,14,FOLLOW_14_in_rule__Instance__Group_2__0__Impl2071); 
             after(grammarAccess.getInstanceAccess().getLeftCurlyBracketKeyword_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Instance__Group_2__0__Impl"


    // $ANTLR start "rule__Instance__Group_2__1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1037:1: rule__Instance__Group_2__1 : rule__Instance__Group_2__1__Impl rule__Instance__Group_2__2 ;
    public final void rule__Instance__Group_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1041:1: ( rule__Instance__Group_2__1__Impl rule__Instance__Group_2__2 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1042:2: rule__Instance__Group_2__1__Impl rule__Instance__Group_2__2
            {
            pushFollow(FOLLOW_rule__Instance__Group_2__1__Impl_in_rule__Instance__Group_2__12102);
            rule__Instance__Group_2__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Instance__Group_2__2_in_rule__Instance__Group_2__12105);
            rule__Instance__Group_2__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Instance__Group_2__1"


    // $ANTLR start "rule__Instance__Group_2__1__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1049:1: rule__Instance__Group_2__1__Impl : ( ( rule__Instance__ChildrenAssignment_2_1 ) ) ;
    public final void rule__Instance__Group_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1053:1: ( ( ( rule__Instance__ChildrenAssignment_2_1 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1054:1: ( ( rule__Instance__ChildrenAssignment_2_1 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1054:1: ( ( rule__Instance__ChildrenAssignment_2_1 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1055:1: ( rule__Instance__ChildrenAssignment_2_1 )
            {
             before(grammarAccess.getInstanceAccess().getChildrenAssignment_2_1()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1056:1: ( rule__Instance__ChildrenAssignment_2_1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1056:2: rule__Instance__ChildrenAssignment_2_1
            {
            pushFollow(FOLLOW_rule__Instance__ChildrenAssignment_2_1_in_rule__Instance__Group_2__1__Impl2132);
            rule__Instance__ChildrenAssignment_2_1();

            state._fsp--;


            }

             after(grammarAccess.getInstanceAccess().getChildrenAssignment_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Instance__Group_2__1__Impl"


    // $ANTLR start "rule__Instance__Group_2__2"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1066:1: rule__Instance__Group_2__2 : rule__Instance__Group_2__2__Impl rule__Instance__Group_2__3 ;
    public final void rule__Instance__Group_2__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1070:1: ( rule__Instance__Group_2__2__Impl rule__Instance__Group_2__3 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1071:2: rule__Instance__Group_2__2__Impl rule__Instance__Group_2__3
            {
            pushFollow(FOLLOW_rule__Instance__Group_2__2__Impl_in_rule__Instance__Group_2__22162);
            rule__Instance__Group_2__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Instance__Group_2__3_in_rule__Instance__Group_2__22165);
            rule__Instance__Group_2__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Instance__Group_2__2"


    // $ANTLR start "rule__Instance__Group_2__2__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1078:1: rule__Instance__Group_2__2__Impl : ( ( rule__Instance__Group_2_2__0 )* ) ;
    public final void rule__Instance__Group_2__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1082:1: ( ( ( rule__Instance__Group_2_2__0 )* ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1083:1: ( ( rule__Instance__Group_2_2__0 )* )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1083:1: ( ( rule__Instance__Group_2_2__0 )* )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1084:1: ( rule__Instance__Group_2_2__0 )*
            {
             before(grammarAccess.getInstanceAccess().getGroup_2_2()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1085:1: ( rule__Instance__Group_2_2__0 )*
            loop9:
            do {
                int alt9=2;
                int LA9_0 = input.LA(1);

                if ( (LA9_0==RULE_ID||LA9_0==RULE_INT||LA9_0==13) ) {
                    alt9=1;
                }


                switch (alt9) {
            	case 1 :
            	    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1085:2: rule__Instance__Group_2_2__0
            	    {
            	    pushFollow(FOLLOW_rule__Instance__Group_2_2__0_in_rule__Instance__Group_2__2__Impl2192);
            	    rule__Instance__Group_2_2__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop9;
                }
            } while (true);

             after(grammarAccess.getInstanceAccess().getGroup_2_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Instance__Group_2__2__Impl"


    // $ANTLR start "rule__Instance__Group_2__3"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1095:1: rule__Instance__Group_2__3 : rule__Instance__Group_2__3__Impl ;
    public final void rule__Instance__Group_2__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1099:1: ( rule__Instance__Group_2__3__Impl )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1100:2: rule__Instance__Group_2__3__Impl
            {
            pushFollow(FOLLOW_rule__Instance__Group_2__3__Impl_in_rule__Instance__Group_2__32223);
            rule__Instance__Group_2__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Instance__Group_2__3"


    // $ANTLR start "rule__Instance__Group_2__3__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1106:1: rule__Instance__Group_2__3__Impl : ( '}' ) ;
    public final void rule__Instance__Group_2__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1110:1: ( ( '}' ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1111:1: ( '}' )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1111:1: ( '}' )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1112:1: '}'
            {
             before(grammarAccess.getInstanceAccess().getRightCurlyBracketKeyword_2_3()); 
            match(input,15,FOLLOW_15_in_rule__Instance__Group_2__3__Impl2251); 
             after(grammarAccess.getInstanceAccess().getRightCurlyBracketKeyword_2_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Instance__Group_2__3__Impl"


    // $ANTLR start "rule__Instance__Group_2_2__0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1133:1: rule__Instance__Group_2_2__0 : rule__Instance__Group_2_2__0__Impl rule__Instance__Group_2_2__1 ;
    public final void rule__Instance__Group_2_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1137:1: ( rule__Instance__Group_2_2__0__Impl rule__Instance__Group_2_2__1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1138:2: rule__Instance__Group_2_2__0__Impl rule__Instance__Group_2_2__1
            {
            pushFollow(FOLLOW_rule__Instance__Group_2_2__0__Impl_in_rule__Instance__Group_2_2__02290);
            rule__Instance__Group_2_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Instance__Group_2_2__1_in_rule__Instance__Group_2_2__02293);
            rule__Instance__Group_2_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Instance__Group_2_2__0"


    // $ANTLR start "rule__Instance__Group_2_2__0__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1145:1: rule__Instance__Group_2_2__0__Impl : ( ( ',' )? ) ;
    public final void rule__Instance__Group_2_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1149:1: ( ( ( ',' )? ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1150:1: ( ( ',' )? )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1150:1: ( ( ',' )? )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1151:1: ( ',' )?
            {
             before(grammarAccess.getInstanceAccess().getCommaKeyword_2_2_0()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1152:1: ( ',' )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==13) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1153:2: ','
                    {
                    match(input,13,FOLLOW_13_in_rule__Instance__Group_2_2__0__Impl2322); 

                    }
                    break;

            }

             after(grammarAccess.getInstanceAccess().getCommaKeyword_2_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Instance__Group_2_2__0__Impl"


    // $ANTLR start "rule__Instance__Group_2_2__1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1164:1: rule__Instance__Group_2_2__1 : rule__Instance__Group_2_2__1__Impl ;
    public final void rule__Instance__Group_2_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1168:1: ( rule__Instance__Group_2_2__1__Impl )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1169:2: rule__Instance__Group_2_2__1__Impl
            {
            pushFollow(FOLLOW_rule__Instance__Group_2_2__1__Impl_in_rule__Instance__Group_2_2__12355);
            rule__Instance__Group_2_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Instance__Group_2_2__1"


    // $ANTLR start "rule__Instance__Group_2_2__1__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1175:1: rule__Instance__Group_2_2__1__Impl : ( ( rule__Instance__ChildrenAssignment_2_2_1 ) ) ;
    public final void rule__Instance__Group_2_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1179:1: ( ( ( rule__Instance__ChildrenAssignment_2_2_1 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1180:1: ( ( rule__Instance__ChildrenAssignment_2_2_1 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1180:1: ( ( rule__Instance__ChildrenAssignment_2_2_1 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1181:1: ( rule__Instance__ChildrenAssignment_2_2_1 )
            {
             before(grammarAccess.getInstanceAccess().getChildrenAssignment_2_2_1()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1182:1: ( rule__Instance__ChildrenAssignment_2_2_1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1182:2: rule__Instance__ChildrenAssignment_2_2_1
            {
            pushFollow(FOLLOW_rule__Instance__ChildrenAssignment_2_2_1_in_rule__Instance__Group_2_2__1__Impl2382);
            rule__Instance__ChildrenAssignment_2_2_1();

            state._fsp--;


            }

             after(grammarAccess.getInstanceAccess().getChildrenAssignment_2_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Instance__Group_2_2__1__Impl"


    // $ANTLR start "rule__FeatureModel__Group__0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1196:1: rule__FeatureModel__Group__0 : rule__FeatureModel__Group__0__Impl rule__FeatureModel__Group__1 ;
    public final void rule__FeatureModel__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1200:1: ( rule__FeatureModel__Group__0__Impl rule__FeatureModel__Group__1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1201:2: rule__FeatureModel__Group__0__Impl rule__FeatureModel__Group__1
            {
            pushFollow(FOLLOW_rule__FeatureModel__Group__0__Impl_in_rule__FeatureModel__Group__02416);
            rule__FeatureModel__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__FeatureModel__Group__1_in_rule__FeatureModel__Group__02419);
            rule__FeatureModel__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureModel__Group__0"


    // $ANTLR start "rule__FeatureModel__Group__0__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1208:1: rule__FeatureModel__Group__0__Impl : ( ( rule__FeatureModel__RootAssignment_0 ) ) ;
    public final void rule__FeatureModel__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1212:1: ( ( ( rule__FeatureModel__RootAssignment_0 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1213:1: ( ( rule__FeatureModel__RootAssignment_0 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1213:1: ( ( rule__FeatureModel__RootAssignment_0 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1214:1: ( rule__FeatureModel__RootAssignment_0 )
            {
             before(grammarAccess.getFeatureModelAccess().getRootAssignment_0()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1215:1: ( rule__FeatureModel__RootAssignment_0 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1215:2: rule__FeatureModel__RootAssignment_0
            {
            pushFollow(FOLLOW_rule__FeatureModel__RootAssignment_0_in_rule__FeatureModel__Group__0__Impl2446);
            rule__FeatureModel__RootAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getFeatureModelAccess().getRootAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureModel__Group__0__Impl"


    // $ANTLR start "rule__FeatureModel__Group__1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1225:1: rule__FeatureModel__Group__1 : rule__FeatureModel__Group__1__Impl ;
    public final void rule__FeatureModel__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1229:1: ( rule__FeatureModel__Group__1__Impl )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1230:2: rule__FeatureModel__Group__1__Impl
            {
            pushFollow(FOLLOW_rule__FeatureModel__Group__1__Impl_in_rule__FeatureModel__Group__12476);
            rule__FeatureModel__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureModel__Group__1"


    // $ANTLR start "rule__FeatureModel__Group__1__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1236:1: rule__FeatureModel__Group__1__Impl : ( ( rule__FeatureModel__ConstraintsAssignment_1 )* ) ;
    public final void rule__FeatureModel__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1240:1: ( ( ( rule__FeatureModel__ConstraintsAssignment_1 )* ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1241:1: ( ( rule__FeatureModel__ConstraintsAssignment_1 )* )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1241:1: ( ( rule__FeatureModel__ConstraintsAssignment_1 )* )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1242:1: ( rule__FeatureModel__ConstraintsAssignment_1 )*
            {
             before(grammarAccess.getFeatureModelAccess().getConstraintsAssignment_1()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1243:1: ( rule__FeatureModel__ConstraintsAssignment_1 )*
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==19) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1243:2: rule__FeatureModel__ConstraintsAssignment_1
            	    {
            	    pushFollow(FOLLOW_rule__FeatureModel__ConstraintsAssignment_1_in_rule__FeatureModel__Group__1__Impl2503);
            	    rule__FeatureModel__ConstraintsAssignment_1();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);

             after(grammarAccess.getFeatureModelAccess().getConstraintsAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureModel__Group__1__Impl"


    // $ANTLR start "rule__Feature__Group__0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1257:1: rule__Feature__Group__0 : rule__Feature__Group__0__Impl rule__Feature__Group__1 ;
    public final void rule__Feature__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1261:1: ( rule__Feature__Group__0__Impl rule__Feature__Group__1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1262:2: rule__Feature__Group__0__Impl rule__Feature__Group__1
            {
            pushFollow(FOLLOW_rule__Feature__Group__0__Impl_in_rule__Feature__Group__02538);
            rule__Feature__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Feature__Group__1_in_rule__Feature__Group__02541);
            rule__Feature__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__Group__0"


    // $ANTLR start "rule__Feature__Group__0__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1269:1: rule__Feature__Group__0__Impl : ( ( rule__Feature__NameAssignment_0 ) ) ;
    public final void rule__Feature__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1273:1: ( ( ( rule__Feature__NameAssignment_0 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1274:1: ( ( rule__Feature__NameAssignment_0 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1274:1: ( ( rule__Feature__NameAssignment_0 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1275:1: ( rule__Feature__NameAssignment_0 )
            {
             before(grammarAccess.getFeatureAccess().getNameAssignment_0()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1276:1: ( rule__Feature__NameAssignment_0 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1276:2: rule__Feature__NameAssignment_0
            {
            pushFollow(FOLLOW_rule__Feature__NameAssignment_0_in_rule__Feature__Group__0__Impl2568);
            rule__Feature__NameAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getFeatureAccess().getNameAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__Group__0__Impl"


    // $ANTLR start "rule__Feature__Group__1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1286:1: rule__Feature__Group__1 : rule__Feature__Group__1__Impl rule__Feature__Group__2 ;
    public final void rule__Feature__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1290:1: ( rule__Feature__Group__1__Impl rule__Feature__Group__2 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1291:2: rule__Feature__Group__1__Impl rule__Feature__Group__2
            {
            pushFollow(FOLLOW_rule__Feature__Group__1__Impl_in_rule__Feature__Group__12598);
            rule__Feature__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Feature__Group__2_in_rule__Feature__Group__12601);
            rule__Feature__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__Group__1"


    // $ANTLR start "rule__Feature__Group__1__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1298:1: rule__Feature__Group__1__Impl : ( ( rule__Feature__CardinalitiesAssignment_1 )? ) ;
    public final void rule__Feature__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1302:1: ( ( ( rule__Feature__CardinalitiesAssignment_1 )? ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1303:1: ( ( rule__Feature__CardinalitiesAssignment_1 )? )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1303:1: ( ( rule__Feature__CardinalitiesAssignment_1 )? )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1304:1: ( rule__Feature__CardinalitiesAssignment_1 )?
            {
             before(grammarAccess.getFeatureAccess().getCardinalitiesAssignment_1()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1305:1: ( rule__Feature__CardinalitiesAssignment_1 )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==16) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1305:2: rule__Feature__CardinalitiesAssignment_1
                    {
                    pushFollow(FOLLOW_rule__Feature__CardinalitiesAssignment_1_in_rule__Feature__Group__1__Impl2628);
                    rule__Feature__CardinalitiesAssignment_1();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getFeatureAccess().getCardinalitiesAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__Group__1__Impl"


    // $ANTLR start "rule__Feature__Group__2"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1315:1: rule__Feature__Group__2 : rule__Feature__Group__2__Impl rule__Feature__Group__3 ;
    public final void rule__Feature__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1319:1: ( rule__Feature__Group__2__Impl rule__Feature__Group__3 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1320:2: rule__Feature__Group__2__Impl rule__Feature__Group__3
            {
            pushFollow(FOLLOW_rule__Feature__Group__2__Impl_in_rule__Feature__Group__22659);
            rule__Feature__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Feature__Group__3_in_rule__Feature__Group__22662);
            rule__Feature__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__Group__2"


    // $ANTLR start "rule__Feature__Group__2__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1327:1: rule__Feature__Group__2__Impl : ( ( rule__Feature__CardinalitiesAssignment_2 )* ) ;
    public final void rule__Feature__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1331:1: ( ( ( rule__Feature__CardinalitiesAssignment_2 )* ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1332:1: ( ( rule__Feature__CardinalitiesAssignment_2 )* )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1332:1: ( ( rule__Feature__CardinalitiesAssignment_2 )* )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1333:1: ( rule__Feature__CardinalitiesAssignment_2 )*
            {
             before(grammarAccess.getFeatureAccess().getCardinalitiesAssignment_2()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1334:1: ( rule__Feature__CardinalitiesAssignment_2 )*
            loop13:
            do {
                int alt13=2;
                alt13 = dfa13.predict(input);
                switch (alt13) {
            	case 1 :
            	    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1334:2: rule__Feature__CardinalitiesAssignment_2
            	    {
            	    pushFollow(FOLLOW_rule__Feature__CardinalitiesAssignment_2_in_rule__Feature__Group__2__Impl2689);
            	    rule__Feature__CardinalitiesAssignment_2();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop13;
                }
            } while (true);

             after(grammarAccess.getFeatureAccess().getCardinalitiesAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__Group__2__Impl"


    // $ANTLR start "rule__Feature__Group__3"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1344:1: rule__Feature__Group__3 : rule__Feature__Group__3__Impl ;
    public final void rule__Feature__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1348:1: ( rule__Feature__Group__3__Impl )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1349:2: rule__Feature__Group__3__Impl
            {
            pushFollow(FOLLOW_rule__Feature__Group__3__Impl_in_rule__Feature__Group__32720);
            rule__Feature__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__Group__3"


    // $ANTLR start "rule__Feature__Group__3__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1355:1: rule__Feature__Group__3__Impl : ( ( rule__Feature__Group_3__0 )? ) ;
    public final void rule__Feature__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1359:1: ( ( ( rule__Feature__Group_3__0 )? ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1360:1: ( ( rule__Feature__Group_3__0 )? )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1360:1: ( ( rule__Feature__Group_3__0 )? )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1361:1: ( rule__Feature__Group_3__0 )?
            {
             before(grammarAccess.getFeatureAccess().getGroup_3()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1362:1: ( rule__Feature__Group_3__0 )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==14) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1362:2: rule__Feature__Group_3__0
                    {
                    pushFollow(FOLLOW_rule__Feature__Group_3__0_in_rule__Feature__Group__3__Impl2747);
                    rule__Feature__Group_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getFeatureAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__Group__3__Impl"


    // $ANTLR start "rule__Feature__Group_3__0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1380:1: rule__Feature__Group_3__0 : rule__Feature__Group_3__0__Impl rule__Feature__Group_3__1 ;
    public final void rule__Feature__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1384:1: ( rule__Feature__Group_3__0__Impl rule__Feature__Group_3__1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1385:2: rule__Feature__Group_3__0__Impl rule__Feature__Group_3__1
            {
            pushFollow(FOLLOW_rule__Feature__Group_3__0__Impl_in_rule__Feature__Group_3__02786);
            rule__Feature__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Feature__Group_3__1_in_rule__Feature__Group_3__02789);
            rule__Feature__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__Group_3__0"


    // $ANTLR start "rule__Feature__Group_3__0__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1392:1: rule__Feature__Group_3__0__Impl : ( '{' ) ;
    public final void rule__Feature__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1396:1: ( ( '{' ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1397:1: ( '{' )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1397:1: ( '{' )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1398:1: '{'
            {
             before(grammarAccess.getFeatureAccess().getLeftCurlyBracketKeyword_3_0()); 
            match(input,14,FOLLOW_14_in_rule__Feature__Group_3__0__Impl2817); 
             after(grammarAccess.getFeatureAccess().getLeftCurlyBracketKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__Group_3__0__Impl"


    // $ANTLR start "rule__Feature__Group_3__1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1411:1: rule__Feature__Group_3__1 : rule__Feature__Group_3__1__Impl rule__Feature__Group_3__2 ;
    public final void rule__Feature__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1415:1: ( rule__Feature__Group_3__1__Impl rule__Feature__Group_3__2 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1416:2: rule__Feature__Group_3__1__Impl rule__Feature__Group_3__2
            {
            pushFollow(FOLLOW_rule__Feature__Group_3__1__Impl_in_rule__Feature__Group_3__12848);
            rule__Feature__Group_3__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Feature__Group_3__2_in_rule__Feature__Group_3__12851);
            rule__Feature__Group_3__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__Group_3__1"


    // $ANTLR start "rule__Feature__Group_3__1__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1423:1: rule__Feature__Group_3__1__Impl : ( ( rule__Feature__SubFeaturesAssignment_3_1 ) ) ;
    public final void rule__Feature__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1427:1: ( ( ( rule__Feature__SubFeaturesAssignment_3_1 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1428:1: ( ( rule__Feature__SubFeaturesAssignment_3_1 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1428:1: ( ( rule__Feature__SubFeaturesAssignment_3_1 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1429:1: ( rule__Feature__SubFeaturesAssignment_3_1 )
            {
             before(grammarAccess.getFeatureAccess().getSubFeaturesAssignment_3_1()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1430:1: ( rule__Feature__SubFeaturesAssignment_3_1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1430:2: rule__Feature__SubFeaturesAssignment_3_1
            {
            pushFollow(FOLLOW_rule__Feature__SubFeaturesAssignment_3_1_in_rule__Feature__Group_3__1__Impl2878);
            rule__Feature__SubFeaturesAssignment_3_1();

            state._fsp--;


            }

             after(grammarAccess.getFeatureAccess().getSubFeaturesAssignment_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__Group_3__1__Impl"


    // $ANTLR start "rule__Feature__Group_3__2"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1440:1: rule__Feature__Group_3__2 : rule__Feature__Group_3__2__Impl rule__Feature__Group_3__3 ;
    public final void rule__Feature__Group_3__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1444:1: ( rule__Feature__Group_3__2__Impl rule__Feature__Group_3__3 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1445:2: rule__Feature__Group_3__2__Impl rule__Feature__Group_3__3
            {
            pushFollow(FOLLOW_rule__Feature__Group_3__2__Impl_in_rule__Feature__Group_3__22908);
            rule__Feature__Group_3__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Feature__Group_3__3_in_rule__Feature__Group_3__22911);
            rule__Feature__Group_3__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__Group_3__2"


    // $ANTLR start "rule__Feature__Group_3__2__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1452:1: rule__Feature__Group_3__2__Impl : ( ( rule__Feature__Group_3_2__0 )* ) ;
    public final void rule__Feature__Group_3__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1456:1: ( ( ( rule__Feature__Group_3_2__0 )* ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1457:1: ( ( rule__Feature__Group_3_2__0 )* )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1457:1: ( ( rule__Feature__Group_3_2__0 )* )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1458:1: ( rule__Feature__Group_3_2__0 )*
            {
             before(grammarAccess.getFeatureAccess().getGroup_3_2()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1459:1: ( rule__Feature__Group_3_2__0 )*
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( (LA15_0==RULE_ID||LA15_0==13) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1459:2: rule__Feature__Group_3_2__0
            	    {
            	    pushFollow(FOLLOW_rule__Feature__Group_3_2__0_in_rule__Feature__Group_3__2__Impl2938);
            	    rule__Feature__Group_3_2__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop15;
                }
            } while (true);

             after(grammarAccess.getFeatureAccess().getGroup_3_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__Group_3__2__Impl"


    // $ANTLR start "rule__Feature__Group_3__3"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1469:1: rule__Feature__Group_3__3 : rule__Feature__Group_3__3__Impl ;
    public final void rule__Feature__Group_3__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1473:1: ( rule__Feature__Group_3__3__Impl )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1474:2: rule__Feature__Group_3__3__Impl
            {
            pushFollow(FOLLOW_rule__Feature__Group_3__3__Impl_in_rule__Feature__Group_3__32969);
            rule__Feature__Group_3__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__Group_3__3"


    // $ANTLR start "rule__Feature__Group_3__3__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1480:1: rule__Feature__Group_3__3__Impl : ( '}' ) ;
    public final void rule__Feature__Group_3__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1484:1: ( ( '}' ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1485:1: ( '}' )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1485:1: ( '}' )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1486:1: '}'
            {
             before(grammarAccess.getFeatureAccess().getRightCurlyBracketKeyword_3_3()); 
            match(input,15,FOLLOW_15_in_rule__Feature__Group_3__3__Impl2997); 
             after(grammarAccess.getFeatureAccess().getRightCurlyBracketKeyword_3_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__Group_3__3__Impl"


    // $ANTLR start "rule__Feature__Group_3_2__0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1507:1: rule__Feature__Group_3_2__0 : rule__Feature__Group_3_2__0__Impl rule__Feature__Group_3_2__1 ;
    public final void rule__Feature__Group_3_2__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1511:1: ( rule__Feature__Group_3_2__0__Impl rule__Feature__Group_3_2__1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1512:2: rule__Feature__Group_3_2__0__Impl rule__Feature__Group_3_2__1
            {
            pushFollow(FOLLOW_rule__Feature__Group_3_2__0__Impl_in_rule__Feature__Group_3_2__03036);
            rule__Feature__Group_3_2__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Feature__Group_3_2__1_in_rule__Feature__Group_3_2__03039);
            rule__Feature__Group_3_2__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__Group_3_2__0"


    // $ANTLR start "rule__Feature__Group_3_2__0__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1519:1: rule__Feature__Group_3_2__0__Impl : ( ( ',' )? ) ;
    public final void rule__Feature__Group_3_2__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1523:1: ( ( ( ',' )? ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1524:1: ( ( ',' )? )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1524:1: ( ( ',' )? )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1525:1: ( ',' )?
            {
             before(grammarAccess.getFeatureAccess().getCommaKeyword_3_2_0()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1526:1: ( ',' )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==13) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1527:2: ','
                    {
                    match(input,13,FOLLOW_13_in_rule__Feature__Group_3_2__0__Impl3068); 

                    }
                    break;

            }

             after(grammarAccess.getFeatureAccess().getCommaKeyword_3_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__Group_3_2__0__Impl"


    // $ANTLR start "rule__Feature__Group_3_2__1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1538:1: rule__Feature__Group_3_2__1 : rule__Feature__Group_3_2__1__Impl ;
    public final void rule__Feature__Group_3_2__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1542:1: ( rule__Feature__Group_3_2__1__Impl )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1543:2: rule__Feature__Group_3_2__1__Impl
            {
            pushFollow(FOLLOW_rule__Feature__Group_3_2__1__Impl_in_rule__Feature__Group_3_2__13101);
            rule__Feature__Group_3_2__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__Group_3_2__1"


    // $ANTLR start "rule__Feature__Group_3_2__1__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1549:1: rule__Feature__Group_3_2__1__Impl : ( ( rule__Feature__SubFeaturesAssignment_3_2_1 ) ) ;
    public final void rule__Feature__Group_3_2__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1553:1: ( ( ( rule__Feature__SubFeaturesAssignment_3_2_1 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1554:1: ( ( rule__Feature__SubFeaturesAssignment_3_2_1 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1554:1: ( ( rule__Feature__SubFeaturesAssignment_3_2_1 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1555:1: ( rule__Feature__SubFeaturesAssignment_3_2_1 )
            {
             before(grammarAccess.getFeatureAccess().getSubFeaturesAssignment_3_2_1()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1556:1: ( rule__Feature__SubFeaturesAssignment_3_2_1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1556:2: rule__Feature__SubFeaturesAssignment_3_2_1
            {
            pushFollow(FOLLOW_rule__Feature__SubFeaturesAssignment_3_2_1_in_rule__Feature__Group_3_2__1__Impl3128);
            rule__Feature__SubFeaturesAssignment_3_2_1();

            state._fsp--;


            }

             after(grammarAccess.getFeatureAccess().getSubFeaturesAssignment_3_2_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__Group_3_2__1__Impl"


    // $ANTLR start "rule__FeatureGroup__Group__0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1570:1: rule__FeatureGroup__Group__0 : rule__FeatureGroup__Group__0__Impl rule__FeatureGroup__Group__1 ;
    public final void rule__FeatureGroup__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1574:1: ( rule__FeatureGroup__Group__0__Impl rule__FeatureGroup__Group__1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1575:2: rule__FeatureGroup__Group__0__Impl rule__FeatureGroup__Group__1
            {
            pushFollow(FOLLOW_rule__FeatureGroup__Group__0__Impl_in_rule__FeatureGroup__Group__03162);
            rule__FeatureGroup__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__FeatureGroup__Group__1_in_rule__FeatureGroup__Group__03165);
            rule__FeatureGroup__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureGroup__Group__0"


    // $ANTLR start "rule__FeatureGroup__Group__0__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1582:1: rule__FeatureGroup__Group__0__Impl : ( ( rule__FeatureGroup__NameAssignment_0 ) ) ;
    public final void rule__FeatureGroup__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1586:1: ( ( ( rule__FeatureGroup__NameAssignment_0 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1587:1: ( ( rule__FeatureGroup__NameAssignment_0 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1587:1: ( ( rule__FeatureGroup__NameAssignment_0 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1588:1: ( rule__FeatureGroup__NameAssignment_0 )
            {
             before(grammarAccess.getFeatureGroupAccess().getNameAssignment_0()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1589:1: ( rule__FeatureGroup__NameAssignment_0 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1589:2: rule__FeatureGroup__NameAssignment_0
            {
            pushFollow(FOLLOW_rule__FeatureGroup__NameAssignment_0_in_rule__FeatureGroup__Group__0__Impl3192);
            rule__FeatureGroup__NameAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getFeatureGroupAccess().getNameAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureGroup__Group__0__Impl"


    // $ANTLR start "rule__FeatureGroup__Group__1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1599:1: rule__FeatureGroup__Group__1 : rule__FeatureGroup__Group__1__Impl rule__FeatureGroup__Group__2 ;
    public final void rule__FeatureGroup__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1603:1: ( rule__FeatureGroup__Group__1__Impl rule__FeatureGroup__Group__2 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1604:2: rule__FeatureGroup__Group__1__Impl rule__FeatureGroup__Group__2
            {
            pushFollow(FOLLOW_rule__FeatureGroup__Group__1__Impl_in_rule__FeatureGroup__Group__13222);
            rule__FeatureGroup__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__FeatureGroup__Group__2_in_rule__FeatureGroup__Group__13225);
            rule__FeatureGroup__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureGroup__Group__1"


    // $ANTLR start "rule__FeatureGroup__Group__1__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1611:1: rule__FeatureGroup__Group__1__Impl : ( ( rule__FeatureGroup__CardinalitiesAssignment_1 )? ) ;
    public final void rule__FeatureGroup__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1615:1: ( ( ( rule__FeatureGroup__CardinalitiesAssignment_1 )? ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1616:1: ( ( rule__FeatureGroup__CardinalitiesAssignment_1 )? )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1616:1: ( ( rule__FeatureGroup__CardinalitiesAssignment_1 )? )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1617:1: ( rule__FeatureGroup__CardinalitiesAssignment_1 )?
            {
             before(grammarAccess.getFeatureGroupAccess().getCardinalitiesAssignment_1()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1618:1: ( rule__FeatureGroup__CardinalitiesAssignment_1 )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==16) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1618:2: rule__FeatureGroup__CardinalitiesAssignment_1
                    {
                    pushFollow(FOLLOW_rule__FeatureGroup__CardinalitiesAssignment_1_in_rule__FeatureGroup__Group__1__Impl3252);
                    rule__FeatureGroup__CardinalitiesAssignment_1();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getFeatureGroupAccess().getCardinalitiesAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureGroup__Group__1__Impl"


    // $ANTLR start "rule__FeatureGroup__Group__2"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1628:1: rule__FeatureGroup__Group__2 : rule__FeatureGroup__Group__2__Impl rule__FeatureGroup__Group__3 ;
    public final void rule__FeatureGroup__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1632:1: ( rule__FeatureGroup__Group__2__Impl rule__FeatureGroup__Group__3 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1633:2: rule__FeatureGroup__Group__2__Impl rule__FeatureGroup__Group__3
            {
            pushFollow(FOLLOW_rule__FeatureGroup__Group__2__Impl_in_rule__FeatureGroup__Group__23283);
            rule__FeatureGroup__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__FeatureGroup__Group__3_in_rule__FeatureGroup__Group__23286);
            rule__FeatureGroup__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureGroup__Group__2"


    // $ANTLR start "rule__FeatureGroup__Group__2__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1640:1: rule__FeatureGroup__Group__2__Impl : ( ( rule__FeatureGroup__CardinalitiesAssignment_2 )* ) ;
    public final void rule__FeatureGroup__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1644:1: ( ( ( rule__FeatureGroup__CardinalitiesAssignment_2 )* ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1645:1: ( ( rule__FeatureGroup__CardinalitiesAssignment_2 )* )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1645:1: ( ( rule__FeatureGroup__CardinalitiesAssignment_2 )* )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1646:1: ( rule__FeatureGroup__CardinalitiesAssignment_2 )*
            {
             before(grammarAccess.getFeatureGroupAccess().getCardinalitiesAssignment_2()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1647:1: ( rule__FeatureGroup__CardinalitiesAssignment_2 )*
            loop18:
            do {
                int alt18=2;
                int LA18_0 = input.LA(1);

                if ( (LA18_0==19) ) {
                    int LA18_1 = input.LA(2);

                    if ( (LA18_1==RULE_ID) ) {
                        alt18=1;
                    }


                }


                switch (alt18) {
            	case 1 :
            	    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1647:2: rule__FeatureGroup__CardinalitiesAssignment_2
            	    {
            	    pushFollow(FOLLOW_rule__FeatureGroup__CardinalitiesAssignment_2_in_rule__FeatureGroup__Group__2__Impl3313);
            	    rule__FeatureGroup__CardinalitiesAssignment_2();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop18;
                }
            } while (true);

             after(grammarAccess.getFeatureGroupAccess().getCardinalitiesAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureGroup__Group__2__Impl"


    // $ANTLR start "rule__FeatureGroup__Group__3"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1657:1: rule__FeatureGroup__Group__3 : rule__FeatureGroup__Group__3__Impl rule__FeatureGroup__Group__4 ;
    public final void rule__FeatureGroup__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1661:1: ( rule__FeatureGroup__Group__3__Impl rule__FeatureGroup__Group__4 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1662:2: rule__FeatureGroup__Group__3__Impl rule__FeatureGroup__Group__4
            {
            pushFollow(FOLLOW_rule__FeatureGroup__Group__3__Impl_in_rule__FeatureGroup__Group__33344);
            rule__FeatureGroup__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__FeatureGroup__Group__4_in_rule__FeatureGroup__Group__33347);
            rule__FeatureGroup__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureGroup__Group__3"


    // $ANTLR start "rule__FeatureGroup__Group__3__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1669:1: rule__FeatureGroup__Group__3__Impl : ( ( rule__FeatureGroup__GroupCardinalityAssignment_3 ) ) ;
    public final void rule__FeatureGroup__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1673:1: ( ( ( rule__FeatureGroup__GroupCardinalityAssignment_3 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1674:1: ( ( rule__FeatureGroup__GroupCardinalityAssignment_3 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1674:1: ( ( rule__FeatureGroup__GroupCardinalityAssignment_3 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1675:1: ( rule__FeatureGroup__GroupCardinalityAssignment_3 )
            {
             before(grammarAccess.getFeatureGroupAccess().getGroupCardinalityAssignment_3()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1676:1: ( rule__FeatureGroup__GroupCardinalityAssignment_3 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1676:2: rule__FeatureGroup__GroupCardinalityAssignment_3
            {
            pushFollow(FOLLOW_rule__FeatureGroup__GroupCardinalityAssignment_3_in_rule__FeatureGroup__Group__3__Impl3374);
            rule__FeatureGroup__GroupCardinalityAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getFeatureGroupAccess().getGroupCardinalityAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureGroup__Group__3__Impl"


    // $ANTLR start "rule__FeatureGroup__Group__4"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1686:1: rule__FeatureGroup__Group__4 : rule__FeatureGroup__Group__4__Impl rule__FeatureGroup__Group__5 ;
    public final void rule__FeatureGroup__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1690:1: ( rule__FeatureGroup__Group__4__Impl rule__FeatureGroup__Group__5 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1691:2: rule__FeatureGroup__Group__4__Impl rule__FeatureGroup__Group__5
            {
            pushFollow(FOLLOW_rule__FeatureGroup__Group__4__Impl_in_rule__FeatureGroup__Group__43404);
            rule__FeatureGroup__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__FeatureGroup__Group__5_in_rule__FeatureGroup__Group__43407);
            rule__FeatureGroup__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureGroup__Group__4"


    // $ANTLR start "rule__FeatureGroup__Group__4__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1698:1: rule__FeatureGroup__Group__4__Impl : ( '[' ) ;
    public final void rule__FeatureGroup__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1702:1: ( ( '[' ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1703:1: ( '[' )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1703:1: ( '[' )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1704:1: '['
            {
             before(grammarAccess.getFeatureGroupAccess().getLeftSquareBracketKeyword_4()); 
            match(input,16,FOLLOW_16_in_rule__FeatureGroup__Group__4__Impl3435); 
             after(grammarAccess.getFeatureGroupAccess().getLeftSquareBracketKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureGroup__Group__4__Impl"


    // $ANTLR start "rule__FeatureGroup__Group__5"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1717:1: rule__FeatureGroup__Group__5 : rule__FeatureGroup__Group__5__Impl rule__FeatureGroup__Group__6 ;
    public final void rule__FeatureGroup__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1721:1: ( rule__FeatureGroup__Group__5__Impl rule__FeatureGroup__Group__6 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1722:2: rule__FeatureGroup__Group__5__Impl rule__FeatureGroup__Group__6
            {
            pushFollow(FOLLOW_rule__FeatureGroup__Group__5__Impl_in_rule__FeatureGroup__Group__53466);
            rule__FeatureGroup__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__FeatureGroup__Group__6_in_rule__FeatureGroup__Group__53469);
            rule__FeatureGroup__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureGroup__Group__5"


    // $ANTLR start "rule__FeatureGroup__Group__5__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1729:1: rule__FeatureGroup__Group__5__Impl : ( ( rule__FeatureGroup__VariantsAssignment_5 ) ) ;
    public final void rule__FeatureGroup__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1733:1: ( ( ( rule__FeatureGroup__VariantsAssignment_5 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1734:1: ( ( rule__FeatureGroup__VariantsAssignment_5 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1734:1: ( ( rule__FeatureGroup__VariantsAssignment_5 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1735:1: ( rule__FeatureGroup__VariantsAssignment_5 )
            {
             before(grammarAccess.getFeatureGroupAccess().getVariantsAssignment_5()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1736:1: ( rule__FeatureGroup__VariantsAssignment_5 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1736:2: rule__FeatureGroup__VariantsAssignment_5
            {
            pushFollow(FOLLOW_rule__FeatureGroup__VariantsAssignment_5_in_rule__FeatureGroup__Group__5__Impl3496);
            rule__FeatureGroup__VariantsAssignment_5();

            state._fsp--;


            }

             after(grammarAccess.getFeatureGroupAccess().getVariantsAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureGroup__Group__5__Impl"


    // $ANTLR start "rule__FeatureGroup__Group__6"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1746:1: rule__FeatureGroup__Group__6 : rule__FeatureGroup__Group__6__Impl rule__FeatureGroup__Group__7 ;
    public final void rule__FeatureGroup__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1750:1: ( rule__FeatureGroup__Group__6__Impl rule__FeatureGroup__Group__7 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1751:2: rule__FeatureGroup__Group__6__Impl rule__FeatureGroup__Group__7
            {
            pushFollow(FOLLOW_rule__FeatureGroup__Group__6__Impl_in_rule__FeatureGroup__Group__63526);
            rule__FeatureGroup__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__FeatureGroup__Group__7_in_rule__FeatureGroup__Group__63529);
            rule__FeatureGroup__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureGroup__Group__6"


    // $ANTLR start "rule__FeatureGroup__Group__6__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1758:1: rule__FeatureGroup__Group__6__Impl : ( ( ( rule__FeatureGroup__Group_6__0 ) ) ( ( rule__FeatureGroup__Group_6__0 )* ) ) ;
    public final void rule__FeatureGroup__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1762:1: ( ( ( ( rule__FeatureGroup__Group_6__0 ) ) ( ( rule__FeatureGroup__Group_6__0 )* ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1763:1: ( ( ( rule__FeatureGroup__Group_6__0 ) ) ( ( rule__FeatureGroup__Group_6__0 )* ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1763:1: ( ( ( rule__FeatureGroup__Group_6__0 ) ) ( ( rule__FeatureGroup__Group_6__0 )* ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1764:1: ( ( rule__FeatureGroup__Group_6__0 ) ) ( ( rule__FeatureGroup__Group_6__0 )* )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1764:1: ( ( rule__FeatureGroup__Group_6__0 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1765:1: ( rule__FeatureGroup__Group_6__0 )
            {
             before(grammarAccess.getFeatureGroupAccess().getGroup_6()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1766:1: ( rule__FeatureGroup__Group_6__0 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1766:2: rule__FeatureGroup__Group_6__0
            {
            pushFollow(FOLLOW_rule__FeatureGroup__Group_6__0_in_rule__FeatureGroup__Group__6__Impl3558);
            rule__FeatureGroup__Group_6__0();

            state._fsp--;


            }

             after(grammarAccess.getFeatureGroupAccess().getGroup_6()); 

            }

            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1769:1: ( ( rule__FeatureGroup__Group_6__0 )* )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1770:1: ( rule__FeatureGroup__Group_6__0 )*
            {
             before(grammarAccess.getFeatureGroupAccess().getGroup_6()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1771:1: ( rule__FeatureGroup__Group_6__0 )*
            loop19:
            do {
                int alt19=2;
                int LA19_0 = input.LA(1);

                if ( (LA19_0==RULE_ID||LA19_0==18) ) {
                    alt19=1;
                }


                switch (alt19) {
            	case 1 :
            	    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1771:2: rule__FeatureGroup__Group_6__0
            	    {
            	    pushFollow(FOLLOW_rule__FeatureGroup__Group_6__0_in_rule__FeatureGroup__Group__6__Impl3570);
            	    rule__FeatureGroup__Group_6__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop19;
                }
            } while (true);

             after(grammarAccess.getFeatureGroupAccess().getGroup_6()); 

            }


            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureGroup__Group__6__Impl"


    // $ANTLR start "rule__FeatureGroup__Group__7"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1782:1: rule__FeatureGroup__Group__7 : rule__FeatureGroup__Group__7__Impl ;
    public final void rule__FeatureGroup__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1786:1: ( rule__FeatureGroup__Group__7__Impl )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1787:2: rule__FeatureGroup__Group__7__Impl
            {
            pushFollow(FOLLOW_rule__FeatureGroup__Group__7__Impl_in_rule__FeatureGroup__Group__73603);
            rule__FeatureGroup__Group__7__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureGroup__Group__7"


    // $ANTLR start "rule__FeatureGroup__Group__7__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1793:1: rule__FeatureGroup__Group__7__Impl : ( ']' ) ;
    public final void rule__FeatureGroup__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1797:1: ( ( ']' ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1798:1: ( ']' )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1798:1: ( ']' )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1799:1: ']'
            {
             before(grammarAccess.getFeatureGroupAccess().getRightSquareBracketKeyword_7()); 
            match(input,17,FOLLOW_17_in_rule__FeatureGroup__Group__7__Impl3631); 
             after(grammarAccess.getFeatureGroupAccess().getRightSquareBracketKeyword_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureGroup__Group__7__Impl"


    // $ANTLR start "rule__FeatureGroup__Group_6__0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1828:1: rule__FeatureGroup__Group_6__0 : rule__FeatureGroup__Group_6__0__Impl rule__FeatureGroup__Group_6__1 ;
    public final void rule__FeatureGroup__Group_6__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1832:1: ( rule__FeatureGroup__Group_6__0__Impl rule__FeatureGroup__Group_6__1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1833:2: rule__FeatureGroup__Group_6__0__Impl rule__FeatureGroup__Group_6__1
            {
            pushFollow(FOLLOW_rule__FeatureGroup__Group_6__0__Impl_in_rule__FeatureGroup__Group_6__03678);
            rule__FeatureGroup__Group_6__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__FeatureGroup__Group_6__1_in_rule__FeatureGroup__Group_6__03681);
            rule__FeatureGroup__Group_6__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureGroup__Group_6__0"


    // $ANTLR start "rule__FeatureGroup__Group_6__0__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1840:1: rule__FeatureGroup__Group_6__0__Impl : ( ( '|' )? ) ;
    public final void rule__FeatureGroup__Group_6__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1844:1: ( ( ( '|' )? ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1845:1: ( ( '|' )? )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1845:1: ( ( '|' )? )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1846:1: ( '|' )?
            {
             before(grammarAccess.getFeatureGroupAccess().getVerticalLineKeyword_6_0()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1847:1: ( '|' )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==18) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1848:2: '|'
                    {
                    match(input,18,FOLLOW_18_in_rule__FeatureGroup__Group_6__0__Impl3710); 

                    }
                    break;

            }

             after(grammarAccess.getFeatureGroupAccess().getVerticalLineKeyword_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureGroup__Group_6__0__Impl"


    // $ANTLR start "rule__FeatureGroup__Group_6__1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1859:1: rule__FeatureGroup__Group_6__1 : rule__FeatureGroup__Group_6__1__Impl ;
    public final void rule__FeatureGroup__Group_6__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1863:1: ( rule__FeatureGroup__Group_6__1__Impl )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1864:2: rule__FeatureGroup__Group_6__1__Impl
            {
            pushFollow(FOLLOW_rule__FeatureGroup__Group_6__1__Impl_in_rule__FeatureGroup__Group_6__13743);
            rule__FeatureGroup__Group_6__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureGroup__Group_6__1"


    // $ANTLR start "rule__FeatureGroup__Group_6__1__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1870:1: rule__FeatureGroup__Group_6__1__Impl : ( ( rule__FeatureGroup__VariantsAssignment_6_1 ) ) ;
    public final void rule__FeatureGroup__Group_6__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1874:1: ( ( ( rule__FeatureGroup__VariantsAssignment_6_1 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1875:1: ( ( rule__FeatureGroup__VariantsAssignment_6_1 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1875:1: ( ( rule__FeatureGroup__VariantsAssignment_6_1 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1876:1: ( rule__FeatureGroup__VariantsAssignment_6_1 )
            {
             before(grammarAccess.getFeatureGroupAccess().getVariantsAssignment_6_1()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1877:1: ( rule__FeatureGroup__VariantsAssignment_6_1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1877:2: rule__FeatureGroup__VariantsAssignment_6_1
            {
            pushFollow(FOLLOW_rule__FeatureGroup__VariantsAssignment_6_1_in_rule__FeatureGroup__Group_6__1__Impl3770);
            rule__FeatureGroup__VariantsAssignment_6_1();

            state._fsp--;


            }

             after(grammarAccess.getFeatureGroupAccess().getVariantsAssignment_6_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureGroup__Group_6__1__Impl"


    // $ANTLR start "rule__RelativeCardinalityToUpper__Group__0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1891:1: rule__RelativeCardinalityToUpper__Group__0 : rule__RelativeCardinalityToUpper__Group__0__Impl rule__RelativeCardinalityToUpper__Group__1 ;
    public final void rule__RelativeCardinalityToUpper__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1895:1: ( rule__RelativeCardinalityToUpper__Group__0__Impl rule__RelativeCardinalityToUpper__Group__1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1896:2: rule__RelativeCardinalityToUpper__Group__0__Impl rule__RelativeCardinalityToUpper__Group__1
            {
            pushFollow(FOLLOW_rule__RelativeCardinalityToUpper__Group__0__Impl_in_rule__RelativeCardinalityToUpper__Group__03804);
            rule__RelativeCardinalityToUpper__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__RelativeCardinalityToUpper__Group__1_in_rule__RelativeCardinalityToUpper__Group__03807);
            rule__RelativeCardinalityToUpper__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RelativeCardinalityToUpper__Group__0"


    // $ANTLR start "rule__RelativeCardinalityToUpper__Group__0__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1903:1: rule__RelativeCardinalityToUpper__Group__0__Impl : ( '<' ) ;
    public final void rule__RelativeCardinalityToUpper__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1907:1: ( ( '<' ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1908:1: ( '<' )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1908:1: ( '<' )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1909:1: '<'
            {
             before(grammarAccess.getRelativeCardinalityToUpperAccess().getLessThanSignKeyword_0()); 
            match(input,19,FOLLOW_19_in_rule__RelativeCardinalityToUpper__Group__0__Impl3835); 
             after(grammarAccess.getRelativeCardinalityToUpperAccess().getLessThanSignKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RelativeCardinalityToUpper__Group__0__Impl"


    // $ANTLR start "rule__RelativeCardinalityToUpper__Group__1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1922:1: rule__RelativeCardinalityToUpper__Group__1 : rule__RelativeCardinalityToUpper__Group__1__Impl rule__RelativeCardinalityToUpper__Group__2 ;
    public final void rule__RelativeCardinalityToUpper__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1926:1: ( rule__RelativeCardinalityToUpper__Group__1__Impl rule__RelativeCardinalityToUpper__Group__2 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1927:2: rule__RelativeCardinalityToUpper__Group__1__Impl rule__RelativeCardinalityToUpper__Group__2
            {
            pushFollow(FOLLOW_rule__RelativeCardinalityToUpper__Group__1__Impl_in_rule__RelativeCardinalityToUpper__Group__13866);
            rule__RelativeCardinalityToUpper__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__RelativeCardinalityToUpper__Group__2_in_rule__RelativeCardinalityToUpper__Group__13869);
            rule__RelativeCardinalityToUpper__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RelativeCardinalityToUpper__Group__1"


    // $ANTLR start "rule__RelativeCardinalityToUpper__Group__1__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1934:1: rule__RelativeCardinalityToUpper__Group__1__Impl : ( ( rule__RelativeCardinalityToUpper__ToAssignment_1 ) ) ;
    public final void rule__RelativeCardinalityToUpper__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1938:1: ( ( ( rule__RelativeCardinalityToUpper__ToAssignment_1 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1939:1: ( ( rule__RelativeCardinalityToUpper__ToAssignment_1 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1939:1: ( ( rule__RelativeCardinalityToUpper__ToAssignment_1 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1940:1: ( rule__RelativeCardinalityToUpper__ToAssignment_1 )
            {
             before(grammarAccess.getRelativeCardinalityToUpperAccess().getToAssignment_1()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1941:1: ( rule__RelativeCardinalityToUpper__ToAssignment_1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1941:2: rule__RelativeCardinalityToUpper__ToAssignment_1
            {
            pushFollow(FOLLOW_rule__RelativeCardinalityToUpper__ToAssignment_1_in_rule__RelativeCardinalityToUpper__Group__1__Impl3896);
            rule__RelativeCardinalityToUpper__ToAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getRelativeCardinalityToUpperAccess().getToAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RelativeCardinalityToUpper__Group__1__Impl"


    // $ANTLR start "rule__RelativeCardinalityToUpper__Group__2"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1951:1: rule__RelativeCardinalityToUpper__Group__2 : rule__RelativeCardinalityToUpper__Group__2__Impl rule__RelativeCardinalityToUpper__Group__3 ;
    public final void rule__RelativeCardinalityToUpper__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1955:1: ( rule__RelativeCardinalityToUpper__Group__2__Impl rule__RelativeCardinalityToUpper__Group__3 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1956:2: rule__RelativeCardinalityToUpper__Group__2__Impl rule__RelativeCardinalityToUpper__Group__3
            {
            pushFollow(FOLLOW_rule__RelativeCardinalityToUpper__Group__2__Impl_in_rule__RelativeCardinalityToUpper__Group__23926);
            rule__RelativeCardinalityToUpper__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__RelativeCardinalityToUpper__Group__3_in_rule__RelativeCardinalityToUpper__Group__23929);
            rule__RelativeCardinalityToUpper__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RelativeCardinalityToUpper__Group__2"


    // $ANTLR start "rule__RelativeCardinalityToUpper__Group__2__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1963:1: rule__RelativeCardinalityToUpper__Group__2__Impl : ( '>' ) ;
    public final void rule__RelativeCardinalityToUpper__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1967:1: ( ( '>' ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1968:1: ( '>' )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1968:1: ( '>' )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1969:1: '>'
            {
             before(grammarAccess.getRelativeCardinalityToUpperAccess().getGreaterThanSignKeyword_2()); 
            match(input,20,FOLLOW_20_in_rule__RelativeCardinalityToUpper__Group__2__Impl3957); 
             after(grammarAccess.getRelativeCardinalityToUpperAccess().getGreaterThanSignKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RelativeCardinalityToUpper__Group__2__Impl"


    // $ANTLR start "rule__RelativeCardinalityToUpper__Group__3"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1982:1: rule__RelativeCardinalityToUpper__Group__3 : rule__RelativeCardinalityToUpper__Group__3__Impl ;
    public final void rule__RelativeCardinalityToUpper__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1986:1: ( rule__RelativeCardinalityToUpper__Group__3__Impl )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1987:2: rule__RelativeCardinalityToUpper__Group__3__Impl
            {
            pushFollow(FOLLOW_rule__RelativeCardinalityToUpper__Group__3__Impl_in_rule__RelativeCardinalityToUpper__Group__33988);
            rule__RelativeCardinalityToUpper__Group__3__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RelativeCardinalityToUpper__Group__3"


    // $ANTLR start "rule__RelativeCardinalityToUpper__Group__3__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1993:1: rule__RelativeCardinalityToUpper__Group__3__Impl : ( ( rule__RelativeCardinalityToUpper__CardinalityAssignment_3 ) ) ;
    public final void rule__RelativeCardinalityToUpper__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1997:1: ( ( ( rule__RelativeCardinalityToUpper__CardinalityAssignment_3 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1998:1: ( ( rule__RelativeCardinalityToUpper__CardinalityAssignment_3 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1998:1: ( ( rule__RelativeCardinalityToUpper__CardinalityAssignment_3 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:1999:1: ( rule__RelativeCardinalityToUpper__CardinalityAssignment_3 )
            {
             before(grammarAccess.getRelativeCardinalityToUpperAccess().getCardinalityAssignment_3()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2000:1: ( rule__RelativeCardinalityToUpper__CardinalityAssignment_3 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2000:2: rule__RelativeCardinalityToUpper__CardinalityAssignment_3
            {
            pushFollow(FOLLOW_rule__RelativeCardinalityToUpper__CardinalityAssignment_3_in_rule__RelativeCardinalityToUpper__Group__3__Impl4015);
            rule__RelativeCardinalityToUpper__CardinalityAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getRelativeCardinalityToUpperAccess().getCardinalityAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RelativeCardinalityToUpper__Group__3__Impl"


    // $ANTLR start "rule__GroupCardinality__Group__0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2018:1: rule__GroupCardinality__Group__0 : rule__GroupCardinality__Group__0__Impl rule__GroupCardinality__Group__1 ;
    public final void rule__GroupCardinality__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2022:1: ( rule__GroupCardinality__Group__0__Impl rule__GroupCardinality__Group__1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2023:2: rule__GroupCardinality__Group__0__Impl rule__GroupCardinality__Group__1
            {
            pushFollow(FOLLOW_rule__GroupCardinality__Group__0__Impl_in_rule__GroupCardinality__Group__04053);
            rule__GroupCardinality__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__GroupCardinality__Group__1_in_rule__GroupCardinality__Group__04056);
            rule__GroupCardinality__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GroupCardinality__Group__0"


    // $ANTLR start "rule__GroupCardinality__Group__0__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2030:1: rule__GroupCardinality__Group__0__Impl : ( '<' ) ;
    public final void rule__GroupCardinality__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2034:1: ( ( '<' ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2035:1: ( '<' )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2035:1: ( '<' )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2036:1: '<'
            {
             before(grammarAccess.getGroupCardinalityAccess().getLessThanSignKeyword_0()); 
            match(input,19,FOLLOW_19_in_rule__GroupCardinality__Group__0__Impl4084); 
             after(grammarAccess.getGroupCardinalityAccess().getLessThanSignKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GroupCardinality__Group__0__Impl"


    // $ANTLR start "rule__GroupCardinality__Group__1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2049:1: rule__GroupCardinality__Group__1 : rule__GroupCardinality__Group__1__Impl rule__GroupCardinality__Group__2 ;
    public final void rule__GroupCardinality__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2053:1: ( rule__GroupCardinality__Group__1__Impl rule__GroupCardinality__Group__2 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2054:2: rule__GroupCardinality__Group__1__Impl rule__GroupCardinality__Group__2
            {
            pushFollow(FOLLOW_rule__GroupCardinality__Group__1__Impl_in_rule__GroupCardinality__Group__14115);
            rule__GroupCardinality__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__GroupCardinality__Group__2_in_rule__GroupCardinality__Group__14118);
            rule__GroupCardinality__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GroupCardinality__Group__1"


    // $ANTLR start "rule__GroupCardinality__Group__1__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2061:1: rule__GroupCardinality__Group__1__Impl : ( ruleCardinality ) ;
    public final void rule__GroupCardinality__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2065:1: ( ( ruleCardinality ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2066:1: ( ruleCardinality )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2066:1: ( ruleCardinality )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2067:1: ruleCardinality
            {
             before(grammarAccess.getGroupCardinalityAccess().getCardinalityParserRuleCall_1()); 
            pushFollow(FOLLOW_ruleCardinality_in_rule__GroupCardinality__Group__1__Impl4145);
            ruleCardinality();

            state._fsp--;

             after(grammarAccess.getGroupCardinalityAccess().getCardinalityParserRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GroupCardinality__Group__1__Impl"


    // $ANTLR start "rule__GroupCardinality__Group__2"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2078:1: rule__GroupCardinality__Group__2 : rule__GroupCardinality__Group__2__Impl ;
    public final void rule__GroupCardinality__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2082:1: ( rule__GroupCardinality__Group__2__Impl )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2083:2: rule__GroupCardinality__Group__2__Impl
            {
            pushFollow(FOLLOW_rule__GroupCardinality__Group__2__Impl_in_rule__GroupCardinality__Group__24174);
            rule__GroupCardinality__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GroupCardinality__Group__2"


    // $ANTLR start "rule__GroupCardinality__Group__2__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2089:1: rule__GroupCardinality__Group__2__Impl : ( '>' ) ;
    public final void rule__GroupCardinality__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2093:1: ( ( '>' ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2094:1: ( '>' )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2094:1: ( '>' )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2095:1: '>'
            {
             before(grammarAccess.getGroupCardinalityAccess().getGreaterThanSignKeyword_2()); 
            match(input,20,FOLLOW_20_in_rule__GroupCardinality__Group__2__Impl4202); 
             after(grammarAccess.getGroupCardinalityAccess().getGreaterThanSignKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GroupCardinality__Group__2__Impl"


    // $ANTLR start "rule__FeatureCardinality__Group__0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2114:1: rule__FeatureCardinality__Group__0 : rule__FeatureCardinality__Group__0__Impl rule__FeatureCardinality__Group__1 ;
    public final void rule__FeatureCardinality__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2118:1: ( rule__FeatureCardinality__Group__0__Impl rule__FeatureCardinality__Group__1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2119:2: rule__FeatureCardinality__Group__0__Impl rule__FeatureCardinality__Group__1
            {
            pushFollow(FOLLOW_rule__FeatureCardinality__Group__0__Impl_in_rule__FeatureCardinality__Group__04239);
            rule__FeatureCardinality__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__FeatureCardinality__Group__1_in_rule__FeatureCardinality__Group__04242);
            rule__FeatureCardinality__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureCardinality__Group__0"


    // $ANTLR start "rule__FeatureCardinality__Group__0__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2126:1: rule__FeatureCardinality__Group__0__Impl : ( '[' ) ;
    public final void rule__FeatureCardinality__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2130:1: ( ( '[' ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2131:1: ( '[' )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2131:1: ( '[' )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2132:1: '['
            {
             before(grammarAccess.getFeatureCardinalityAccess().getLeftSquareBracketKeyword_0()); 
            match(input,16,FOLLOW_16_in_rule__FeatureCardinality__Group__0__Impl4270); 
             after(grammarAccess.getFeatureCardinalityAccess().getLeftSquareBracketKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureCardinality__Group__0__Impl"


    // $ANTLR start "rule__FeatureCardinality__Group__1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2145:1: rule__FeatureCardinality__Group__1 : rule__FeatureCardinality__Group__1__Impl rule__FeatureCardinality__Group__2 ;
    public final void rule__FeatureCardinality__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2149:1: ( rule__FeatureCardinality__Group__1__Impl rule__FeatureCardinality__Group__2 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2150:2: rule__FeatureCardinality__Group__1__Impl rule__FeatureCardinality__Group__2
            {
            pushFollow(FOLLOW_rule__FeatureCardinality__Group__1__Impl_in_rule__FeatureCardinality__Group__14301);
            rule__FeatureCardinality__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__FeatureCardinality__Group__2_in_rule__FeatureCardinality__Group__14304);
            rule__FeatureCardinality__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureCardinality__Group__1"


    // $ANTLR start "rule__FeatureCardinality__Group__1__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2157:1: rule__FeatureCardinality__Group__1__Impl : ( ruleCardinality ) ;
    public final void rule__FeatureCardinality__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2161:1: ( ( ruleCardinality ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2162:1: ( ruleCardinality )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2162:1: ( ruleCardinality )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2163:1: ruleCardinality
            {
             before(grammarAccess.getFeatureCardinalityAccess().getCardinalityParserRuleCall_1()); 
            pushFollow(FOLLOW_ruleCardinality_in_rule__FeatureCardinality__Group__1__Impl4331);
            ruleCardinality();

            state._fsp--;

             after(grammarAccess.getFeatureCardinalityAccess().getCardinalityParserRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureCardinality__Group__1__Impl"


    // $ANTLR start "rule__FeatureCardinality__Group__2"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2174:1: rule__FeatureCardinality__Group__2 : rule__FeatureCardinality__Group__2__Impl ;
    public final void rule__FeatureCardinality__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2178:1: ( rule__FeatureCardinality__Group__2__Impl )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2179:2: rule__FeatureCardinality__Group__2__Impl
            {
            pushFollow(FOLLOW_rule__FeatureCardinality__Group__2__Impl_in_rule__FeatureCardinality__Group__24360);
            rule__FeatureCardinality__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureCardinality__Group__2"


    // $ANTLR start "rule__FeatureCardinality__Group__2__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2185:1: rule__FeatureCardinality__Group__2__Impl : ( ']' ) ;
    public final void rule__FeatureCardinality__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2189:1: ( ( ']' ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2190:1: ( ']' )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2190:1: ( ']' )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2191:1: ']'
            {
             before(grammarAccess.getFeatureCardinalityAccess().getRightSquareBracketKeyword_2()); 
            match(input,17,FOLLOW_17_in_rule__FeatureCardinality__Group__2__Impl4388); 
             after(grammarAccess.getFeatureCardinalityAccess().getRightSquareBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureCardinality__Group__2__Impl"


    // $ANTLR start "rule__Cardinality__Group__0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2210:1: rule__Cardinality__Group__0 : rule__Cardinality__Group__0__Impl rule__Cardinality__Group__1 ;
    public final void rule__Cardinality__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2214:1: ( rule__Cardinality__Group__0__Impl rule__Cardinality__Group__1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2215:2: rule__Cardinality__Group__0__Impl rule__Cardinality__Group__1
            {
            pushFollow(FOLLOW_rule__Cardinality__Group__0__Impl_in_rule__Cardinality__Group__04425);
            rule__Cardinality__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Cardinality__Group__1_in_rule__Cardinality__Group__04428);
            rule__Cardinality__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Cardinality__Group__0"


    // $ANTLR start "rule__Cardinality__Group__0__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2222:1: rule__Cardinality__Group__0__Impl : ( ( rule__Cardinality__MinAssignment_0 ) ) ;
    public final void rule__Cardinality__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2226:1: ( ( ( rule__Cardinality__MinAssignment_0 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2227:1: ( ( rule__Cardinality__MinAssignment_0 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2227:1: ( ( rule__Cardinality__MinAssignment_0 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2228:1: ( rule__Cardinality__MinAssignment_0 )
            {
             before(grammarAccess.getCardinalityAccess().getMinAssignment_0()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2229:1: ( rule__Cardinality__MinAssignment_0 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2229:2: rule__Cardinality__MinAssignment_0
            {
            pushFollow(FOLLOW_rule__Cardinality__MinAssignment_0_in_rule__Cardinality__Group__0__Impl4455);
            rule__Cardinality__MinAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getCardinalityAccess().getMinAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Cardinality__Group__0__Impl"


    // $ANTLR start "rule__Cardinality__Group__1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2239:1: rule__Cardinality__Group__1 : rule__Cardinality__Group__1__Impl rule__Cardinality__Group__2 ;
    public final void rule__Cardinality__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2243:1: ( rule__Cardinality__Group__1__Impl rule__Cardinality__Group__2 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2244:2: rule__Cardinality__Group__1__Impl rule__Cardinality__Group__2
            {
            pushFollow(FOLLOW_rule__Cardinality__Group__1__Impl_in_rule__Cardinality__Group__14485);
            rule__Cardinality__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Cardinality__Group__2_in_rule__Cardinality__Group__14488);
            rule__Cardinality__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Cardinality__Group__1"


    // $ANTLR start "rule__Cardinality__Group__1__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2251:1: rule__Cardinality__Group__1__Impl : ( '..' ) ;
    public final void rule__Cardinality__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2255:1: ( ( '..' ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2256:1: ( '..' )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2256:1: ( '..' )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2257:1: '..'
            {
             before(grammarAccess.getCardinalityAccess().getFullStopFullStopKeyword_1()); 
            match(input,21,FOLLOW_21_in_rule__Cardinality__Group__1__Impl4516); 
             after(grammarAccess.getCardinalityAccess().getFullStopFullStopKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Cardinality__Group__1__Impl"


    // $ANTLR start "rule__Cardinality__Group__2"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2270:1: rule__Cardinality__Group__2 : rule__Cardinality__Group__2__Impl ;
    public final void rule__Cardinality__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2274:1: ( rule__Cardinality__Group__2__Impl )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2275:2: rule__Cardinality__Group__2__Impl
            {
            pushFollow(FOLLOW_rule__Cardinality__Group__2__Impl_in_rule__Cardinality__Group__24547);
            rule__Cardinality__Group__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Cardinality__Group__2"


    // $ANTLR start "rule__Cardinality__Group__2__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2281:1: rule__Cardinality__Group__2__Impl : ( ( rule__Cardinality__MaxAssignment_2 ) ) ;
    public final void rule__Cardinality__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2285:1: ( ( ( rule__Cardinality__MaxAssignment_2 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2286:1: ( ( rule__Cardinality__MaxAssignment_2 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2286:1: ( ( rule__Cardinality__MaxAssignment_2 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2287:1: ( rule__Cardinality__MaxAssignment_2 )
            {
             before(grammarAccess.getCardinalityAccess().getMaxAssignment_2()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2288:1: ( rule__Cardinality__MaxAssignment_2 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2288:2: rule__Cardinality__MaxAssignment_2
            {
            pushFollow(FOLLOW_rule__Cardinality__MaxAssignment_2_in_rule__Cardinality__Group__2__Impl4574);
            rule__Cardinality__MaxAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getCardinalityAccess().getMaxAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Cardinality__Group__2__Impl"


    // $ANTLR start "rule__Constraint__Group__0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2304:1: rule__Constraint__Group__0 : rule__Constraint__Group__0__Impl rule__Constraint__Group__1 ;
    public final void rule__Constraint__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2308:1: ( rule__Constraint__Group__0__Impl rule__Constraint__Group__1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2309:2: rule__Constraint__Group__0__Impl rule__Constraint__Group__1
            {
            pushFollow(FOLLOW_rule__Constraint__Group__0__Impl_in_rule__Constraint__Group__04610);
            rule__Constraint__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Constraint__Group__1_in_rule__Constraint__Group__04613);
            rule__Constraint__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constraint__Group__0"


    // $ANTLR start "rule__Constraint__Group__0__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2316:1: rule__Constraint__Group__0__Impl : ( '<' ) ;
    public final void rule__Constraint__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2320:1: ( ( '<' ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2321:1: ( '<' )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2321:1: ( '<' )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2322:1: '<'
            {
             before(grammarAccess.getConstraintAccess().getLessThanSignKeyword_0()); 
            match(input,19,FOLLOW_19_in_rule__Constraint__Group__0__Impl4641); 
             after(grammarAccess.getConstraintAccess().getLessThanSignKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constraint__Group__0__Impl"


    // $ANTLR start "rule__Constraint__Group__1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2335:1: rule__Constraint__Group__1 : rule__Constraint__Group__1__Impl rule__Constraint__Group__2 ;
    public final void rule__Constraint__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2339:1: ( rule__Constraint__Group__1__Impl rule__Constraint__Group__2 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2340:2: rule__Constraint__Group__1__Impl rule__Constraint__Group__2
            {
            pushFollow(FOLLOW_rule__Constraint__Group__1__Impl_in_rule__Constraint__Group__14672);
            rule__Constraint__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Constraint__Group__2_in_rule__Constraint__Group__14675);
            rule__Constraint__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constraint__Group__1"


    // $ANTLR start "rule__Constraint__Group__1__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2347:1: rule__Constraint__Group__1__Impl : ( ( rule__Constraint__ContextAssignment_1 ) ) ;
    public final void rule__Constraint__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2351:1: ( ( ( rule__Constraint__ContextAssignment_1 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2352:1: ( ( rule__Constraint__ContextAssignment_1 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2352:1: ( ( rule__Constraint__ContextAssignment_1 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2353:1: ( rule__Constraint__ContextAssignment_1 )
            {
             before(grammarAccess.getConstraintAccess().getContextAssignment_1()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2354:1: ( rule__Constraint__ContextAssignment_1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2354:2: rule__Constraint__ContextAssignment_1
            {
            pushFollow(FOLLOW_rule__Constraint__ContextAssignment_1_in_rule__Constraint__Group__1__Impl4702);
            rule__Constraint__ContextAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getConstraintAccess().getContextAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constraint__Group__1__Impl"


    // $ANTLR start "rule__Constraint__Group__2"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2364:1: rule__Constraint__Group__2 : rule__Constraint__Group__2__Impl rule__Constraint__Group__3 ;
    public final void rule__Constraint__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2368:1: ( rule__Constraint__Group__2__Impl rule__Constraint__Group__3 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2369:2: rule__Constraint__Group__2__Impl rule__Constraint__Group__3
            {
            pushFollow(FOLLOW_rule__Constraint__Group__2__Impl_in_rule__Constraint__Group__24732);
            rule__Constraint__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Constraint__Group__3_in_rule__Constraint__Group__24735);
            rule__Constraint__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constraint__Group__2"


    // $ANTLR start "rule__Constraint__Group__2__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2376:1: rule__Constraint__Group__2__Impl : ( '>' ) ;
    public final void rule__Constraint__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2380:1: ( ( '>' ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2381:1: ( '>' )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2381:1: ( '>' )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2382:1: '>'
            {
             before(grammarAccess.getConstraintAccess().getGreaterThanSignKeyword_2()); 
            match(input,20,FOLLOW_20_in_rule__Constraint__Group__2__Impl4763); 
             after(grammarAccess.getConstraintAccess().getGreaterThanSignKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constraint__Group__2__Impl"


    // $ANTLR start "rule__Constraint__Group__3"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2395:1: rule__Constraint__Group__3 : rule__Constraint__Group__3__Impl rule__Constraint__Group__4 ;
    public final void rule__Constraint__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2399:1: ( rule__Constraint__Group__3__Impl rule__Constraint__Group__4 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2400:2: rule__Constraint__Group__3__Impl rule__Constraint__Group__4
            {
            pushFollow(FOLLOW_rule__Constraint__Group__3__Impl_in_rule__Constraint__Group__34794);
            rule__Constraint__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Constraint__Group__4_in_rule__Constraint__Group__34797);
            rule__Constraint__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constraint__Group__3"


    // $ANTLR start "rule__Constraint__Group__3__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2407:1: rule__Constraint__Group__3__Impl : ( ( rule__Constraint__ConditionAssignment_3 ) ) ;
    public final void rule__Constraint__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2411:1: ( ( ( rule__Constraint__ConditionAssignment_3 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2412:1: ( ( rule__Constraint__ConditionAssignment_3 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2412:1: ( ( rule__Constraint__ConditionAssignment_3 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2413:1: ( rule__Constraint__ConditionAssignment_3 )
            {
             before(grammarAccess.getConstraintAccess().getConditionAssignment_3()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2414:1: ( rule__Constraint__ConditionAssignment_3 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2414:2: rule__Constraint__ConditionAssignment_3
            {
            pushFollow(FOLLOW_rule__Constraint__ConditionAssignment_3_in_rule__Constraint__Group__3__Impl4824);
            rule__Constraint__ConditionAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getConstraintAccess().getConditionAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constraint__Group__3__Impl"


    // $ANTLR start "rule__Constraint__Group__4"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2424:1: rule__Constraint__Group__4 : rule__Constraint__Group__4__Impl rule__Constraint__Group__5 ;
    public final void rule__Constraint__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2428:1: ( rule__Constraint__Group__4__Impl rule__Constraint__Group__5 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2429:2: rule__Constraint__Group__4__Impl rule__Constraint__Group__5
            {
            pushFollow(FOLLOW_rule__Constraint__Group__4__Impl_in_rule__Constraint__Group__44854);
            rule__Constraint__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Constraint__Group__5_in_rule__Constraint__Group__44857);
            rule__Constraint__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constraint__Group__4"


    // $ANTLR start "rule__Constraint__Group__4__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2436:1: rule__Constraint__Group__4__Impl : ( '=>' ) ;
    public final void rule__Constraint__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2440:1: ( ( '=>' ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2441:1: ( '=>' )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2441:1: ( '=>' )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2442:1: '=>'
            {
             before(grammarAccess.getConstraintAccess().getEqualsSignGreaterThanSignKeyword_4()); 
            match(input,22,FOLLOW_22_in_rule__Constraint__Group__4__Impl4885); 
             after(grammarAccess.getConstraintAccess().getEqualsSignGreaterThanSignKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constraint__Group__4__Impl"


    // $ANTLR start "rule__Constraint__Group__5"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2455:1: rule__Constraint__Group__5 : rule__Constraint__Group__5__Impl ;
    public final void rule__Constraint__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2459:1: ( rule__Constraint__Group__5__Impl )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2460:2: rule__Constraint__Group__5__Impl
            {
            pushFollow(FOLLOW_rule__Constraint__Group__5__Impl_in_rule__Constraint__Group__54916);
            rule__Constraint__Group__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constraint__Group__5"


    // $ANTLR start "rule__Constraint__Group__5__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2466:1: rule__Constraint__Group__5__Impl : ( ( rule__Constraint__ConsequenceAssignment_5 ) ) ;
    public final void rule__Constraint__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2470:1: ( ( ( rule__Constraint__ConsequenceAssignment_5 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2471:1: ( ( rule__Constraint__ConsequenceAssignment_5 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2471:1: ( ( rule__Constraint__ConsequenceAssignment_5 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2472:1: ( rule__Constraint__ConsequenceAssignment_5 )
            {
             before(grammarAccess.getConstraintAccess().getConsequenceAssignment_5()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2473:1: ( rule__Constraint__ConsequenceAssignment_5 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2473:2: rule__Constraint__ConsequenceAssignment_5
            {
            pushFollow(FOLLOW_rule__Constraint__ConsequenceAssignment_5_in_rule__Constraint__Group__5__Impl4943);
            rule__Constraint__ConsequenceAssignment_5();

            state._fsp--;


            }

             after(grammarAccess.getConstraintAccess().getConsequenceAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constraint__Group__5__Impl"


    // $ANTLR start "rule__ConstrainingExpression__Group__0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2495:1: rule__ConstrainingExpression__Group__0 : rule__ConstrainingExpression__Group__0__Impl rule__ConstrainingExpression__Group__1 ;
    public final void rule__ConstrainingExpression__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2499:1: ( rule__ConstrainingExpression__Group__0__Impl rule__ConstrainingExpression__Group__1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2500:2: rule__ConstrainingExpression__Group__0__Impl rule__ConstrainingExpression__Group__1
            {
            pushFollow(FOLLOW_rule__ConstrainingExpression__Group__0__Impl_in_rule__ConstrainingExpression__Group__04985);
            rule__ConstrainingExpression__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__ConstrainingExpression__Group__1_in_rule__ConstrainingExpression__Group__04988);
            rule__ConstrainingExpression__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ConstrainingExpression__Group__0"


    // $ANTLR start "rule__ConstrainingExpression__Group__0__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2507:1: rule__ConstrainingExpression__Group__0__Impl : ( ( rule__ConstrainingExpression__CardinalityAssignment_0 ) ) ;
    public final void rule__ConstrainingExpression__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2511:1: ( ( ( rule__ConstrainingExpression__CardinalityAssignment_0 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2512:1: ( ( rule__ConstrainingExpression__CardinalityAssignment_0 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2512:1: ( ( rule__ConstrainingExpression__CardinalityAssignment_0 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2513:1: ( rule__ConstrainingExpression__CardinalityAssignment_0 )
            {
             before(grammarAccess.getConstrainingExpressionAccess().getCardinalityAssignment_0()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2514:1: ( rule__ConstrainingExpression__CardinalityAssignment_0 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2514:2: rule__ConstrainingExpression__CardinalityAssignment_0
            {
            pushFollow(FOLLOW_rule__ConstrainingExpression__CardinalityAssignment_0_in_rule__ConstrainingExpression__Group__0__Impl5015);
            rule__ConstrainingExpression__CardinalityAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getConstrainingExpressionAccess().getCardinalityAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ConstrainingExpression__Group__0__Impl"


    // $ANTLR start "rule__ConstrainingExpression__Group__1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2524:1: rule__ConstrainingExpression__Group__1 : rule__ConstrainingExpression__Group__1__Impl rule__ConstrainingExpression__Group__2 ;
    public final void rule__ConstrainingExpression__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2528:1: ( rule__ConstrainingExpression__Group__1__Impl rule__ConstrainingExpression__Group__2 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2529:2: rule__ConstrainingExpression__Group__1__Impl rule__ConstrainingExpression__Group__2
            {
            pushFollow(FOLLOW_rule__ConstrainingExpression__Group__1__Impl_in_rule__ConstrainingExpression__Group__15045);
            rule__ConstrainingExpression__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__ConstrainingExpression__Group__2_in_rule__ConstrainingExpression__Group__15048);
            rule__ConstrainingExpression__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ConstrainingExpression__Group__1"


    // $ANTLR start "rule__ConstrainingExpression__Group__1__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2536:1: rule__ConstrainingExpression__Group__1__Impl : ( '(' ) ;
    public final void rule__ConstrainingExpression__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2540:1: ( ( '(' ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2541:1: ( '(' )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2541:1: ( '(' )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2542:1: '('
            {
             before(grammarAccess.getConstrainingExpressionAccess().getLeftParenthesisKeyword_1()); 
            match(input,23,FOLLOW_23_in_rule__ConstrainingExpression__Group__1__Impl5076); 
             after(grammarAccess.getConstrainingExpressionAccess().getLeftParenthesisKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ConstrainingExpression__Group__1__Impl"


    // $ANTLR start "rule__ConstrainingExpression__Group__2"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2555:1: rule__ConstrainingExpression__Group__2 : rule__ConstrainingExpression__Group__2__Impl rule__ConstrainingExpression__Group__3 ;
    public final void rule__ConstrainingExpression__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2559:1: ( rule__ConstrainingExpression__Group__2__Impl rule__ConstrainingExpression__Group__3 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2560:2: rule__ConstrainingExpression__Group__2__Impl rule__ConstrainingExpression__Group__3
            {
            pushFollow(FOLLOW_rule__ConstrainingExpression__Group__2__Impl_in_rule__ConstrainingExpression__Group__25107);
            rule__ConstrainingExpression__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__ConstrainingExpression__Group__3_in_rule__ConstrainingExpression__Group__25110);
            rule__ConstrainingExpression__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ConstrainingExpression__Group__2"


    // $ANTLR start "rule__ConstrainingExpression__Group__2__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2567:1: rule__ConstrainingExpression__Group__2__Impl : ( ( rule__ConstrainingExpression__FromAssignment_2 ) ) ;
    public final void rule__ConstrainingExpression__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2571:1: ( ( ( rule__ConstrainingExpression__FromAssignment_2 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2572:1: ( ( rule__ConstrainingExpression__FromAssignment_2 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2572:1: ( ( rule__ConstrainingExpression__FromAssignment_2 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2573:1: ( rule__ConstrainingExpression__FromAssignment_2 )
            {
             before(grammarAccess.getConstrainingExpressionAccess().getFromAssignment_2()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2574:1: ( rule__ConstrainingExpression__FromAssignment_2 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2574:2: rule__ConstrainingExpression__FromAssignment_2
            {
            pushFollow(FOLLOW_rule__ConstrainingExpression__FromAssignment_2_in_rule__ConstrainingExpression__Group__2__Impl5137);
            rule__ConstrainingExpression__FromAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getConstrainingExpressionAccess().getFromAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ConstrainingExpression__Group__2__Impl"


    // $ANTLR start "rule__ConstrainingExpression__Group__3"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2584:1: rule__ConstrainingExpression__Group__3 : rule__ConstrainingExpression__Group__3__Impl rule__ConstrainingExpression__Group__4 ;
    public final void rule__ConstrainingExpression__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2588:1: ( rule__ConstrainingExpression__Group__3__Impl rule__ConstrainingExpression__Group__4 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2589:2: rule__ConstrainingExpression__Group__3__Impl rule__ConstrainingExpression__Group__4
            {
            pushFollow(FOLLOW_rule__ConstrainingExpression__Group__3__Impl_in_rule__ConstrainingExpression__Group__35167);
            rule__ConstrainingExpression__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__ConstrainingExpression__Group__4_in_rule__ConstrainingExpression__Group__35170);
            rule__ConstrainingExpression__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ConstrainingExpression__Group__3"


    // $ANTLR start "rule__ConstrainingExpression__Group__3__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2596:1: rule__ConstrainingExpression__Group__3__Impl : ( ',' ) ;
    public final void rule__ConstrainingExpression__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2600:1: ( ( ',' ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2601:1: ( ',' )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2601:1: ( ',' )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2602:1: ','
            {
             before(grammarAccess.getConstrainingExpressionAccess().getCommaKeyword_3()); 
            match(input,13,FOLLOW_13_in_rule__ConstrainingExpression__Group__3__Impl5198); 
             after(grammarAccess.getConstrainingExpressionAccess().getCommaKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ConstrainingExpression__Group__3__Impl"


    // $ANTLR start "rule__ConstrainingExpression__Group__4"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2615:1: rule__ConstrainingExpression__Group__4 : rule__ConstrainingExpression__Group__4__Impl rule__ConstrainingExpression__Group__5 ;
    public final void rule__ConstrainingExpression__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2619:1: ( rule__ConstrainingExpression__Group__4__Impl rule__ConstrainingExpression__Group__5 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2620:2: rule__ConstrainingExpression__Group__4__Impl rule__ConstrainingExpression__Group__5
            {
            pushFollow(FOLLOW_rule__ConstrainingExpression__Group__4__Impl_in_rule__ConstrainingExpression__Group__45229);
            rule__ConstrainingExpression__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__ConstrainingExpression__Group__5_in_rule__ConstrainingExpression__Group__45232);
            rule__ConstrainingExpression__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ConstrainingExpression__Group__4"


    // $ANTLR start "rule__ConstrainingExpression__Group__4__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2627:1: rule__ConstrainingExpression__Group__4__Impl : ( ( rule__ConstrainingExpression__ToAssignment_4 ) ) ;
    public final void rule__ConstrainingExpression__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2631:1: ( ( ( rule__ConstrainingExpression__ToAssignment_4 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2632:1: ( ( rule__ConstrainingExpression__ToAssignment_4 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2632:1: ( ( rule__ConstrainingExpression__ToAssignment_4 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2633:1: ( rule__ConstrainingExpression__ToAssignment_4 )
            {
             before(grammarAccess.getConstrainingExpressionAccess().getToAssignment_4()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2634:1: ( rule__ConstrainingExpression__ToAssignment_4 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2634:2: rule__ConstrainingExpression__ToAssignment_4
            {
            pushFollow(FOLLOW_rule__ConstrainingExpression__ToAssignment_4_in_rule__ConstrainingExpression__Group__4__Impl5259);
            rule__ConstrainingExpression__ToAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getConstrainingExpressionAccess().getToAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ConstrainingExpression__Group__4__Impl"


    // $ANTLR start "rule__ConstrainingExpression__Group__5"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2644:1: rule__ConstrainingExpression__Group__5 : rule__ConstrainingExpression__Group__5__Impl ;
    public final void rule__ConstrainingExpression__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2648:1: ( rule__ConstrainingExpression__Group__5__Impl )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2649:2: rule__ConstrainingExpression__Group__5__Impl
            {
            pushFollow(FOLLOW_rule__ConstrainingExpression__Group__5__Impl_in_rule__ConstrainingExpression__Group__55289);
            rule__ConstrainingExpression__Group__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ConstrainingExpression__Group__5"


    // $ANTLR start "rule__ConstrainingExpression__Group__5__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2655:1: rule__ConstrainingExpression__Group__5__Impl : ( ')' ) ;
    public final void rule__ConstrainingExpression__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2659:1: ( ( ')' ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2660:1: ( ')' )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2660:1: ( ')' )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2661:1: ')'
            {
             before(grammarAccess.getConstrainingExpressionAccess().getRightParenthesisKeyword_5()); 
            match(input,24,FOLLOW_24_in_rule__ConstrainingExpression__Group__5__Impl5317); 
             after(grammarAccess.getConstrainingExpressionAccess().getRightParenthesisKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ConstrainingExpression__Group__5__Impl"


    // $ANTLR start "rule__OrConstrainingExpression__Group__0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2686:1: rule__OrConstrainingExpression__Group__0 : rule__OrConstrainingExpression__Group__0__Impl rule__OrConstrainingExpression__Group__1 ;
    public final void rule__OrConstrainingExpression__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2690:1: ( rule__OrConstrainingExpression__Group__0__Impl rule__OrConstrainingExpression__Group__1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2691:2: rule__OrConstrainingExpression__Group__0__Impl rule__OrConstrainingExpression__Group__1
            {
            pushFollow(FOLLOW_rule__OrConstrainingExpression__Group__0__Impl_in_rule__OrConstrainingExpression__Group__05360);
            rule__OrConstrainingExpression__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__OrConstrainingExpression__Group__1_in_rule__OrConstrainingExpression__Group__05363);
            rule__OrConstrainingExpression__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__OrConstrainingExpression__Group__0"


    // $ANTLR start "rule__OrConstrainingExpression__Group__0__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2698:1: rule__OrConstrainingExpression__Group__0__Impl : ( ( rule__OrConstrainingExpression__ChildrenAssignment_0 ) ) ;
    public final void rule__OrConstrainingExpression__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2702:1: ( ( ( rule__OrConstrainingExpression__ChildrenAssignment_0 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2703:1: ( ( rule__OrConstrainingExpression__ChildrenAssignment_0 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2703:1: ( ( rule__OrConstrainingExpression__ChildrenAssignment_0 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2704:1: ( rule__OrConstrainingExpression__ChildrenAssignment_0 )
            {
             before(grammarAccess.getOrConstrainingExpressionAccess().getChildrenAssignment_0()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2705:1: ( rule__OrConstrainingExpression__ChildrenAssignment_0 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2705:2: rule__OrConstrainingExpression__ChildrenAssignment_0
            {
            pushFollow(FOLLOW_rule__OrConstrainingExpression__ChildrenAssignment_0_in_rule__OrConstrainingExpression__Group__0__Impl5390);
            rule__OrConstrainingExpression__ChildrenAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getOrConstrainingExpressionAccess().getChildrenAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__OrConstrainingExpression__Group__0__Impl"


    // $ANTLR start "rule__OrConstrainingExpression__Group__1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2715:1: rule__OrConstrainingExpression__Group__1 : rule__OrConstrainingExpression__Group__1__Impl ;
    public final void rule__OrConstrainingExpression__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2719:1: ( rule__OrConstrainingExpression__Group__1__Impl )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2720:2: rule__OrConstrainingExpression__Group__1__Impl
            {
            pushFollow(FOLLOW_rule__OrConstrainingExpression__Group__1__Impl_in_rule__OrConstrainingExpression__Group__15420);
            rule__OrConstrainingExpression__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__OrConstrainingExpression__Group__1"


    // $ANTLR start "rule__OrConstrainingExpression__Group__1__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2726:1: rule__OrConstrainingExpression__Group__1__Impl : ( ( rule__OrConstrainingExpression__Group_1__0 )* ) ;
    public final void rule__OrConstrainingExpression__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2730:1: ( ( ( rule__OrConstrainingExpression__Group_1__0 )* ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2731:1: ( ( rule__OrConstrainingExpression__Group_1__0 )* )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2731:1: ( ( rule__OrConstrainingExpression__Group_1__0 )* )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2732:1: ( rule__OrConstrainingExpression__Group_1__0 )*
            {
             before(grammarAccess.getOrConstrainingExpressionAccess().getGroup_1()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2733:1: ( rule__OrConstrainingExpression__Group_1__0 )*
            loop21:
            do {
                int alt21=2;
                int LA21_0 = input.LA(1);

                if ( (LA21_0==18) ) {
                    alt21=1;
                }


                switch (alt21) {
            	case 1 :
            	    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2733:2: rule__OrConstrainingExpression__Group_1__0
            	    {
            	    pushFollow(FOLLOW_rule__OrConstrainingExpression__Group_1__0_in_rule__OrConstrainingExpression__Group__1__Impl5447);
            	    rule__OrConstrainingExpression__Group_1__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop21;
                }
            } while (true);

             after(grammarAccess.getOrConstrainingExpressionAccess().getGroup_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__OrConstrainingExpression__Group__1__Impl"


    // $ANTLR start "rule__OrConstrainingExpression__Group_1__0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2747:1: rule__OrConstrainingExpression__Group_1__0 : rule__OrConstrainingExpression__Group_1__0__Impl rule__OrConstrainingExpression__Group_1__1 ;
    public final void rule__OrConstrainingExpression__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2751:1: ( rule__OrConstrainingExpression__Group_1__0__Impl rule__OrConstrainingExpression__Group_1__1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2752:2: rule__OrConstrainingExpression__Group_1__0__Impl rule__OrConstrainingExpression__Group_1__1
            {
            pushFollow(FOLLOW_rule__OrConstrainingExpression__Group_1__0__Impl_in_rule__OrConstrainingExpression__Group_1__05482);
            rule__OrConstrainingExpression__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__OrConstrainingExpression__Group_1__1_in_rule__OrConstrainingExpression__Group_1__05485);
            rule__OrConstrainingExpression__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__OrConstrainingExpression__Group_1__0"


    // $ANTLR start "rule__OrConstrainingExpression__Group_1__0__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2759:1: rule__OrConstrainingExpression__Group_1__0__Impl : ( '|' ) ;
    public final void rule__OrConstrainingExpression__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2763:1: ( ( '|' ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2764:1: ( '|' )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2764:1: ( '|' )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2765:1: '|'
            {
             before(grammarAccess.getOrConstrainingExpressionAccess().getVerticalLineKeyword_1_0()); 
            match(input,18,FOLLOW_18_in_rule__OrConstrainingExpression__Group_1__0__Impl5513); 
             after(grammarAccess.getOrConstrainingExpressionAccess().getVerticalLineKeyword_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__OrConstrainingExpression__Group_1__0__Impl"


    // $ANTLR start "rule__OrConstrainingExpression__Group_1__1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2778:1: rule__OrConstrainingExpression__Group_1__1 : rule__OrConstrainingExpression__Group_1__1__Impl ;
    public final void rule__OrConstrainingExpression__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2782:1: ( rule__OrConstrainingExpression__Group_1__1__Impl )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2783:2: rule__OrConstrainingExpression__Group_1__1__Impl
            {
            pushFollow(FOLLOW_rule__OrConstrainingExpression__Group_1__1__Impl_in_rule__OrConstrainingExpression__Group_1__15544);
            rule__OrConstrainingExpression__Group_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__OrConstrainingExpression__Group_1__1"


    // $ANTLR start "rule__OrConstrainingExpression__Group_1__1__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2789:1: rule__OrConstrainingExpression__Group_1__1__Impl : ( ( rule__OrConstrainingExpression__ChildrenAssignment_1_1 ) ) ;
    public final void rule__OrConstrainingExpression__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2793:1: ( ( ( rule__OrConstrainingExpression__ChildrenAssignment_1_1 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2794:1: ( ( rule__OrConstrainingExpression__ChildrenAssignment_1_1 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2794:1: ( ( rule__OrConstrainingExpression__ChildrenAssignment_1_1 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2795:1: ( rule__OrConstrainingExpression__ChildrenAssignment_1_1 )
            {
             before(grammarAccess.getOrConstrainingExpressionAccess().getChildrenAssignment_1_1()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2796:1: ( rule__OrConstrainingExpression__ChildrenAssignment_1_1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2796:2: rule__OrConstrainingExpression__ChildrenAssignment_1_1
            {
            pushFollow(FOLLOW_rule__OrConstrainingExpression__ChildrenAssignment_1_1_in_rule__OrConstrainingExpression__Group_1__1__Impl5571);
            rule__OrConstrainingExpression__ChildrenAssignment_1_1();

            state._fsp--;


            }

             after(grammarAccess.getOrConstrainingExpressionAccess().getChildrenAssignment_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__OrConstrainingExpression__Group_1__1__Impl"


    // $ANTLR start "rule__AndConstrainingExpression__Group__0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2810:1: rule__AndConstrainingExpression__Group__0 : rule__AndConstrainingExpression__Group__0__Impl rule__AndConstrainingExpression__Group__1 ;
    public final void rule__AndConstrainingExpression__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2814:1: ( rule__AndConstrainingExpression__Group__0__Impl rule__AndConstrainingExpression__Group__1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2815:2: rule__AndConstrainingExpression__Group__0__Impl rule__AndConstrainingExpression__Group__1
            {
            pushFollow(FOLLOW_rule__AndConstrainingExpression__Group__0__Impl_in_rule__AndConstrainingExpression__Group__05605);
            rule__AndConstrainingExpression__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__AndConstrainingExpression__Group__1_in_rule__AndConstrainingExpression__Group__05608);
            rule__AndConstrainingExpression__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AndConstrainingExpression__Group__0"


    // $ANTLR start "rule__AndConstrainingExpression__Group__0__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2822:1: rule__AndConstrainingExpression__Group__0__Impl : ( ( rule__AndConstrainingExpression__ChildrenAssignment_0 ) ) ;
    public final void rule__AndConstrainingExpression__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2826:1: ( ( ( rule__AndConstrainingExpression__ChildrenAssignment_0 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2827:1: ( ( rule__AndConstrainingExpression__ChildrenAssignment_0 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2827:1: ( ( rule__AndConstrainingExpression__ChildrenAssignment_0 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2828:1: ( rule__AndConstrainingExpression__ChildrenAssignment_0 )
            {
             before(grammarAccess.getAndConstrainingExpressionAccess().getChildrenAssignment_0()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2829:1: ( rule__AndConstrainingExpression__ChildrenAssignment_0 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2829:2: rule__AndConstrainingExpression__ChildrenAssignment_0
            {
            pushFollow(FOLLOW_rule__AndConstrainingExpression__ChildrenAssignment_0_in_rule__AndConstrainingExpression__Group__0__Impl5635);
            rule__AndConstrainingExpression__ChildrenAssignment_0();

            state._fsp--;


            }

             after(grammarAccess.getAndConstrainingExpressionAccess().getChildrenAssignment_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AndConstrainingExpression__Group__0__Impl"


    // $ANTLR start "rule__AndConstrainingExpression__Group__1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2839:1: rule__AndConstrainingExpression__Group__1 : rule__AndConstrainingExpression__Group__1__Impl ;
    public final void rule__AndConstrainingExpression__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2843:1: ( rule__AndConstrainingExpression__Group__1__Impl )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2844:2: rule__AndConstrainingExpression__Group__1__Impl
            {
            pushFollow(FOLLOW_rule__AndConstrainingExpression__Group__1__Impl_in_rule__AndConstrainingExpression__Group__15665);
            rule__AndConstrainingExpression__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AndConstrainingExpression__Group__1"


    // $ANTLR start "rule__AndConstrainingExpression__Group__1__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2850:1: rule__AndConstrainingExpression__Group__1__Impl : ( ( rule__AndConstrainingExpression__Group_1__0 )* ) ;
    public final void rule__AndConstrainingExpression__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2854:1: ( ( ( rule__AndConstrainingExpression__Group_1__0 )* ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2855:1: ( ( rule__AndConstrainingExpression__Group_1__0 )* )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2855:1: ( ( rule__AndConstrainingExpression__Group_1__0 )* )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2856:1: ( rule__AndConstrainingExpression__Group_1__0 )*
            {
             before(grammarAccess.getAndConstrainingExpressionAccess().getGroup_1()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2857:1: ( rule__AndConstrainingExpression__Group_1__0 )*
            loop22:
            do {
                int alt22=2;
                int LA22_0 = input.LA(1);

                if ( (LA22_0==25) ) {
                    alt22=1;
                }


                switch (alt22) {
            	case 1 :
            	    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2857:2: rule__AndConstrainingExpression__Group_1__0
            	    {
            	    pushFollow(FOLLOW_rule__AndConstrainingExpression__Group_1__0_in_rule__AndConstrainingExpression__Group__1__Impl5692);
            	    rule__AndConstrainingExpression__Group_1__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop22;
                }
            } while (true);

             after(grammarAccess.getAndConstrainingExpressionAccess().getGroup_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AndConstrainingExpression__Group__1__Impl"


    // $ANTLR start "rule__AndConstrainingExpression__Group_1__0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2871:1: rule__AndConstrainingExpression__Group_1__0 : rule__AndConstrainingExpression__Group_1__0__Impl rule__AndConstrainingExpression__Group_1__1 ;
    public final void rule__AndConstrainingExpression__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2875:1: ( rule__AndConstrainingExpression__Group_1__0__Impl rule__AndConstrainingExpression__Group_1__1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2876:2: rule__AndConstrainingExpression__Group_1__0__Impl rule__AndConstrainingExpression__Group_1__1
            {
            pushFollow(FOLLOW_rule__AndConstrainingExpression__Group_1__0__Impl_in_rule__AndConstrainingExpression__Group_1__05727);
            rule__AndConstrainingExpression__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__AndConstrainingExpression__Group_1__1_in_rule__AndConstrainingExpression__Group_1__05730);
            rule__AndConstrainingExpression__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AndConstrainingExpression__Group_1__0"


    // $ANTLR start "rule__AndConstrainingExpression__Group_1__0__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2883:1: rule__AndConstrainingExpression__Group_1__0__Impl : ( '&' ) ;
    public final void rule__AndConstrainingExpression__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2887:1: ( ( '&' ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2888:1: ( '&' )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2888:1: ( '&' )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2889:1: '&'
            {
             before(grammarAccess.getAndConstrainingExpressionAccess().getAmpersandKeyword_1_0()); 
            match(input,25,FOLLOW_25_in_rule__AndConstrainingExpression__Group_1__0__Impl5758); 
             after(grammarAccess.getAndConstrainingExpressionAccess().getAmpersandKeyword_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AndConstrainingExpression__Group_1__0__Impl"


    // $ANTLR start "rule__AndConstrainingExpression__Group_1__1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2902:1: rule__AndConstrainingExpression__Group_1__1 : rule__AndConstrainingExpression__Group_1__1__Impl ;
    public final void rule__AndConstrainingExpression__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2906:1: ( rule__AndConstrainingExpression__Group_1__1__Impl )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2907:2: rule__AndConstrainingExpression__Group_1__1__Impl
            {
            pushFollow(FOLLOW_rule__AndConstrainingExpression__Group_1__1__Impl_in_rule__AndConstrainingExpression__Group_1__15789);
            rule__AndConstrainingExpression__Group_1__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AndConstrainingExpression__Group_1__1"


    // $ANTLR start "rule__AndConstrainingExpression__Group_1__1__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2913:1: rule__AndConstrainingExpression__Group_1__1__Impl : ( ( rule__AndConstrainingExpression__ChildrenAssignment_1_1 ) ) ;
    public final void rule__AndConstrainingExpression__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2917:1: ( ( ( rule__AndConstrainingExpression__ChildrenAssignment_1_1 ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2918:1: ( ( rule__AndConstrainingExpression__ChildrenAssignment_1_1 ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2918:1: ( ( rule__AndConstrainingExpression__ChildrenAssignment_1_1 ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2919:1: ( rule__AndConstrainingExpression__ChildrenAssignment_1_1 )
            {
             before(grammarAccess.getAndConstrainingExpressionAccess().getChildrenAssignment_1_1()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2920:1: ( rule__AndConstrainingExpression__ChildrenAssignment_1_1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2920:2: rule__AndConstrainingExpression__ChildrenAssignment_1_1
            {
            pushFollow(FOLLOW_rule__AndConstrainingExpression__ChildrenAssignment_1_1_in_rule__AndConstrainingExpression__Group_1__1__Impl5816);
            rule__AndConstrainingExpression__ChildrenAssignment_1_1();

            state._fsp--;


            }

             after(grammarAccess.getAndConstrainingExpressionAccess().getChildrenAssignment_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AndConstrainingExpression__Group_1__1__Impl"


    // $ANTLR start "rule__Primary__Group_1__0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2934:1: rule__Primary__Group_1__0 : rule__Primary__Group_1__0__Impl rule__Primary__Group_1__1 ;
    public final void rule__Primary__Group_1__0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2938:1: ( rule__Primary__Group_1__0__Impl rule__Primary__Group_1__1 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2939:2: rule__Primary__Group_1__0__Impl rule__Primary__Group_1__1
            {
            pushFollow(FOLLOW_rule__Primary__Group_1__0__Impl_in_rule__Primary__Group_1__05850);
            rule__Primary__Group_1__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Primary__Group_1__1_in_rule__Primary__Group_1__05853);
            rule__Primary__Group_1__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Primary__Group_1__0"


    // $ANTLR start "rule__Primary__Group_1__0__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2946:1: rule__Primary__Group_1__0__Impl : ( '(' ) ;
    public final void rule__Primary__Group_1__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2950:1: ( ( '(' ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2951:1: ( '(' )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2951:1: ( '(' )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2952:1: '('
            {
             before(grammarAccess.getPrimaryAccess().getLeftParenthesisKeyword_1_0()); 
            match(input,23,FOLLOW_23_in_rule__Primary__Group_1__0__Impl5881); 
             after(grammarAccess.getPrimaryAccess().getLeftParenthesisKeyword_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Primary__Group_1__0__Impl"


    // $ANTLR start "rule__Primary__Group_1__1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2965:1: rule__Primary__Group_1__1 : rule__Primary__Group_1__1__Impl rule__Primary__Group_1__2 ;
    public final void rule__Primary__Group_1__1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2969:1: ( rule__Primary__Group_1__1__Impl rule__Primary__Group_1__2 )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2970:2: rule__Primary__Group_1__1__Impl rule__Primary__Group_1__2
            {
            pushFollow(FOLLOW_rule__Primary__Group_1__1__Impl_in_rule__Primary__Group_1__15912);
            rule__Primary__Group_1__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_rule__Primary__Group_1__2_in_rule__Primary__Group_1__15915);
            rule__Primary__Group_1__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Primary__Group_1__1"


    // $ANTLR start "rule__Primary__Group_1__1__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2977:1: rule__Primary__Group_1__1__Impl : ( ruleOrConstrainingExpression ) ;
    public final void rule__Primary__Group_1__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2981:1: ( ( ruleOrConstrainingExpression ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2982:1: ( ruleOrConstrainingExpression )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2982:1: ( ruleOrConstrainingExpression )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2983:1: ruleOrConstrainingExpression
            {
             before(grammarAccess.getPrimaryAccess().getOrConstrainingExpressionParserRuleCall_1_1()); 
            pushFollow(FOLLOW_ruleOrConstrainingExpression_in_rule__Primary__Group_1__1__Impl5942);
            ruleOrConstrainingExpression();

            state._fsp--;

             after(grammarAccess.getPrimaryAccess().getOrConstrainingExpressionParserRuleCall_1_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Primary__Group_1__1__Impl"


    // $ANTLR start "rule__Primary__Group_1__2"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2994:1: rule__Primary__Group_1__2 : rule__Primary__Group_1__2__Impl ;
    public final void rule__Primary__Group_1__2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2998:1: ( rule__Primary__Group_1__2__Impl )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:2999:2: rule__Primary__Group_1__2__Impl
            {
            pushFollow(FOLLOW_rule__Primary__Group_1__2__Impl_in_rule__Primary__Group_1__25971);
            rule__Primary__Group_1__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Primary__Group_1__2"


    // $ANTLR start "rule__Primary__Group_1__2__Impl"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3005:1: rule__Primary__Group_1__2__Impl : ( ')' ) ;
    public final void rule__Primary__Group_1__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3009:1: ( ( ')' ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3010:1: ( ')' )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3010:1: ( ')' )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3011:1: ')'
            {
             before(grammarAccess.getPrimaryAccess().getRightParenthesisKeyword_1_2()); 
            match(input,24,FOLLOW_24_in_rule__Primary__Group_1__2__Impl5999); 
             after(grammarAccess.getPrimaryAccess().getRightParenthesisKeyword_1_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Primary__Group_1__2__Impl"


    // $ANTLR start "rule__Configuration__FeatureModelAssignment_1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3031:1: rule__Configuration__FeatureModelAssignment_1 : ( ( RULE_ID ) ) ;
    public final void rule__Configuration__FeatureModelAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3035:1: ( ( ( RULE_ID ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3036:1: ( ( RULE_ID ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3036:1: ( ( RULE_ID ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3037:1: ( RULE_ID )
            {
             before(grammarAccess.getConfigurationAccess().getFeatureModelFeatureModelCrossReference_1_0()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3038:1: ( RULE_ID )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3039:1: RULE_ID
            {
             before(grammarAccess.getConfigurationAccess().getFeatureModelFeatureModelIDTerminalRuleCall_1_0_1()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Configuration__FeatureModelAssignment_16045); 
             after(grammarAccess.getConfigurationAccess().getFeatureModelFeatureModelIDTerminalRuleCall_1_0_1()); 

            }

             after(grammarAccess.getConfigurationAccess().getFeatureModelFeatureModelCrossReference_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Configuration__FeatureModelAssignment_1"


    // $ANTLR start "rule__Configuration__ImportURIAssignment_2_1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3050:1: rule__Configuration__ImportURIAssignment_2_1 : ( RULE_STRING ) ;
    public final void rule__Configuration__ImportURIAssignment_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3054:1: ( ( RULE_STRING ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3055:1: ( RULE_STRING )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3055:1: ( RULE_STRING )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3056:1: RULE_STRING
            {
             before(grammarAccess.getConfigurationAccess().getImportURISTRINGTerminalRuleCall_2_1_0()); 
            match(input,RULE_STRING,FOLLOW_RULE_STRING_in_rule__Configuration__ImportURIAssignment_2_16080); 
             after(grammarAccess.getConfigurationAccess().getImportURISTRINGTerminalRuleCall_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Configuration__ImportURIAssignment_2_1"


    // $ANTLR start "rule__Configuration__InstancesAssignment_3"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3065:1: rule__Configuration__InstancesAssignment_3 : ( ruleInstance ) ;
    public final void rule__Configuration__InstancesAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3069:1: ( ( ruleInstance ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3070:1: ( ruleInstance )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3070:1: ( ruleInstance )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3071:1: ruleInstance
            {
             before(grammarAccess.getConfigurationAccess().getInstancesInstanceParserRuleCall_3_0()); 
            pushFollow(FOLLOW_ruleInstance_in_rule__Configuration__InstancesAssignment_36111);
            ruleInstance();

            state._fsp--;

             after(grammarAccess.getConfigurationAccess().getInstancesInstanceParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Configuration__InstancesAssignment_3"


    // $ANTLR start "rule__Configuration__InstancesAssignment_4_1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3080:1: rule__Configuration__InstancesAssignment_4_1 : ( ruleInstance ) ;
    public final void rule__Configuration__InstancesAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3084:1: ( ( ruleInstance ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3085:1: ( ruleInstance )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3085:1: ( ruleInstance )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3086:1: ruleInstance
            {
             before(grammarAccess.getConfigurationAccess().getInstancesInstanceParserRuleCall_4_1_0()); 
            pushFollow(FOLLOW_ruleInstance_in_rule__Configuration__InstancesAssignment_4_16142);
            ruleInstance();

            state._fsp--;

             after(grammarAccess.getConfigurationAccess().getInstancesInstanceParserRuleCall_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Configuration__InstancesAssignment_4_1"


    // $ANTLR start "rule__Instance__NumberAssignment_0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3095:1: rule__Instance__NumberAssignment_0 : ( RULE_INT ) ;
    public final void rule__Instance__NumberAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3099:1: ( ( RULE_INT ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3100:1: ( RULE_INT )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3100:1: ( RULE_INT )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3101:1: RULE_INT
            {
             before(grammarAccess.getInstanceAccess().getNumberINTTerminalRuleCall_0_0()); 
            match(input,RULE_INT,FOLLOW_RULE_INT_in_rule__Instance__NumberAssignment_06173); 
             after(grammarAccess.getInstanceAccess().getNumberINTTerminalRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Instance__NumberAssignment_0"


    // $ANTLR start "rule__Instance__TypeAssignment_1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3110:1: rule__Instance__TypeAssignment_1 : ( ( RULE_ID ) ) ;
    public final void rule__Instance__TypeAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3114:1: ( ( ( RULE_ID ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3115:1: ( ( RULE_ID ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3115:1: ( ( RULE_ID ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3116:1: ( RULE_ID )
            {
             before(grammarAccess.getInstanceAccess().getTypeAbstractFeatureCrossReference_1_0()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3117:1: ( RULE_ID )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3118:1: RULE_ID
            {
             before(grammarAccess.getInstanceAccess().getTypeAbstractFeatureIDTerminalRuleCall_1_0_1()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Instance__TypeAssignment_16208); 
             after(grammarAccess.getInstanceAccess().getTypeAbstractFeatureIDTerminalRuleCall_1_0_1()); 

            }

             after(grammarAccess.getInstanceAccess().getTypeAbstractFeatureCrossReference_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Instance__TypeAssignment_1"


    // $ANTLR start "rule__Instance__ChildrenAssignment_2_1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3129:1: rule__Instance__ChildrenAssignment_2_1 : ( ruleInstance ) ;
    public final void rule__Instance__ChildrenAssignment_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3133:1: ( ( ruleInstance ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3134:1: ( ruleInstance )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3134:1: ( ruleInstance )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3135:1: ruleInstance
            {
             before(grammarAccess.getInstanceAccess().getChildrenInstanceParserRuleCall_2_1_0()); 
            pushFollow(FOLLOW_ruleInstance_in_rule__Instance__ChildrenAssignment_2_16243);
            ruleInstance();

            state._fsp--;

             after(grammarAccess.getInstanceAccess().getChildrenInstanceParserRuleCall_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Instance__ChildrenAssignment_2_1"


    // $ANTLR start "rule__Instance__ChildrenAssignment_2_2_1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3144:1: rule__Instance__ChildrenAssignment_2_2_1 : ( ruleInstance ) ;
    public final void rule__Instance__ChildrenAssignment_2_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3148:1: ( ( ruleInstance ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3149:1: ( ruleInstance )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3149:1: ( ruleInstance )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3150:1: ruleInstance
            {
             before(grammarAccess.getInstanceAccess().getChildrenInstanceParserRuleCall_2_2_1_0()); 
            pushFollow(FOLLOW_ruleInstance_in_rule__Instance__ChildrenAssignment_2_2_16274);
            ruleInstance();

            state._fsp--;

             after(grammarAccess.getInstanceAccess().getChildrenInstanceParserRuleCall_2_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Instance__ChildrenAssignment_2_2_1"


    // $ANTLR start "rule__FeatureModel__RootAssignment_0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3159:1: rule__FeatureModel__RootAssignment_0 : ( ruleFeature ) ;
    public final void rule__FeatureModel__RootAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3163:1: ( ( ruleFeature ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3164:1: ( ruleFeature )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3164:1: ( ruleFeature )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3165:1: ruleFeature
            {
             before(grammarAccess.getFeatureModelAccess().getRootFeatureParserRuleCall_0_0()); 
            pushFollow(FOLLOW_ruleFeature_in_rule__FeatureModel__RootAssignment_06305);
            ruleFeature();

            state._fsp--;

             after(grammarAccess.getFeatureModelAccess().getRootFeatureParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureModel__RootAssignment_0"


    // $ANTLR start "rule__FeatureModel__ConstraintsAssignment_1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3174:1: rule__FeatureModel__ConstraintsAssignment_1 : ( ruleConstraint ) ;
    public final void rule__FeatureModel__ConstraintsAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3178:1: ( ( ruleConstraint ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3179:1: ( ruleConstraint )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3179:1: ( ruleConstraint )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3180:1: ruleConstraint
            {
             before(grammarAccess.getFeatureModelAccess().getConstraintsConstraintParserRuleCall_1_0()); 
            pushFollow(FOLLOW_ruleConstraint_in_rule__FeatureModel__ConstraintsAssignment_16336);
            ruleConstraint();

            state._fsp--;

             after(grammarAccess.getFeatureModelAccess().getConstraintsConstraintParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureModel__ConstraintsAssignment_1"


    // $ANTLR start "rule__Feature__NameAssignment_0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3189:1: rule__Feature__NameAssignment_0 : ( RULE_ID ) ;
    public final void rule__Feature__NameAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3193:1: ( ( RULE_ID ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3194:1: ( RULE_ID )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3194:1: ( RULE_ID )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3195:1: RULE_ID
            {
             before(grammarAccess.getFeatureAccess().getNameIDTerminalRuleCall_0_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Feature__NameAssignment_06367); 
             after(grammarAccess.getFeatureAccess().getNameIDTerminalRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__NameAssignment_0"


    // $ANTLR start "rule__Feature__CardinalitiesAssignment_1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3204:1: rule__Feature__CardinalitiesAssignment_1 : ( ruleRelativeCardinalityDirect ) ;
    public final void rule__Feature__CardinalitiesAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3208:1: ( ( ruleRelativeCardinalityDirect ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3209:1: ( ruleRelativeCardinalityDirect )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3209:1: ( ruleRelativeCardinalityDirect )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3210:1: ruleRelativeCardinalityDirect
            {
             before(grammarAccess.getFeatureAccess().getCardinalitiesRelativeCardinalityDirectParserRuleCall_1_0()); 
            pushFollow(FOLLOW_ruleRelativeCardinalityDirect_in_rule__Feature__CardinalitiesAssignment_16398);
            ruleRelativeCardinalityDirect();

            state._fsp--;

             after(grammarAccess.getFeatureAccess().getCardinalitiesRelativeCardinalityDirectParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__CardinalitiesAssignment_1"


    // $ANTLR start "rule__Feature__CardinalitiesAssignment_2"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3219:1: rule__Feature__CardinalitiesAssignment_2 : ( ruleRelativeCardinalityToUpper ) ;
    public final void rule__Feature__CardinalitiesAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3223:1: ( ( ruleRelativeCardinalityToUpper ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3224:1: ( ruleRelativeCardinalityToUpper )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3224:1: ( ruleRelativeCardinalityToUpper )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3225:1: ruleRelativeCardinalityToUpper
            {
             before(grammarAccess.getFeatureAccess().getCardinalitiesRelativeCardinalityToUpperParserRuleCall_2_0()); 
            pushFollow(FOLLOW_ruleRelativeCardinalityToUpper_in_rule__Feature__CardinalitiesAssignment_26429);
            ruleRelativeCardinalityToUpper();

            state._fsp--;

             after(grammarAccess.getFeatureAccess().getCardinalitiesRelativeCardinalityToUpperParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__CardinalitiesAssignment_2"


    // $ANTLR start "rule__Feature__SubFeaturesAssignment_3_1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3234:1: rule__Feature__SubFeaturesAssignment_3_1 : ( ruleAbstractFeature ) ;
    public final void rule__Feature__SubFeaturesAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3238:1: ( ( ruleAbstractFeature ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3239:1: ( ruleAbstractFeature )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3239:1: ( ruleAbstractFeature )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3240:1: ruleAbstractFeature
            {
             before(grammarAccess.getFeatureAccess().getSubFeaturesAbstractFeatureParserRuleCall_3_1_0()); 
            pushFollow(FOLLOW_ruleAbstractFeature_in_rule__Feature__SubFeaturesAssignment_3_16460);
            ruleAbstractFeature();

            state._fsp--;

             after(grammarAccess.getFeatureAccess().getSubFeaturesAbstractFeatureParserRuleCall_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__SubFeaturesAssignment_3_1"


    // $ANTLR start "rule__Feature__SubFeaturesAssignment_3_2_1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3249:1: rule__Feature__SubFeaturesAssignment_3_2_1 : ( ruleAbstractFeature ) ;
    public final void rule__Feature__SubFeaturesAssignment_3_2_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3253:1: ( ( ruleAbstractFeature ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3254:1: ( ruleAbstractFeature )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3254:1: ( ruleAbstractFeature )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3255:1: ruleAbstractFeature
            {
             before(grammarAccess.getFeatureAccess().getSubFeaturesAbstractFeatureParserRuleCall_3_2_1_0()); 
            pushFollow(FOLLOW_ruleAbstractFeature_in_rule__Feature__SubFeaturesAssignment_3_2_16491);
            ruleAbstractFeature();

            state._fsp--;

             after(grammarAccess.getFeatureAccess().getSubFeaturesAbstractFeatureParserRuleCall_3_2_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Feature__SubFeaturesAssignment_3_2_1"


    // $ANTLR start "rule__FeatureGroup__NameAssignment_0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3264:1: rule__FeatureGroup__NameAssignment_0 : ( RULE_ID ) ;
    public final void rule__FeatureGroup__NameAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3268:1: ( ( RULE_ID ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3269:1: ( RULE_ID )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3269:1: ( RULE_ID )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3270:1: RULE_ID
            {
             before(grammarAccess.getFeatureGroupAccess().getNameIDTerminalRuleCall_0_0()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__FeatureGroup__NameAssignment_06522); 
             after(grammarAccess.getFeatureGroupAccess().getNameIDTerminalRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureGroup__NameAssignment_0"


    // $ANTLR start "rule__FeatureGroup__CardinalitiesAssignment_1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3279:1: rule__FeatureGroup__CardinalitiesAssignment_1 : ( ruleRelativeCardinalityDirect ) ;
    public final void rule__FeatureGroup__CardinalitiesAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3283:1: ( ( ruleRelativeCardinalityDirect ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3284:1: ( ruleRelativeCardinalityDirect )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3284:1: ( ruleRelativeCardinalityDirect )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3285:1: ruleRelativeCardinalityDirect
            {
             before(grammarAccess.getFeatureGroupAccess().getCardinalitiesRelativeCardinalityDirectParserRuleCall_1_0()); 
            pushFollow(FOLLOW_ruleRelativeCardinalityDirect_in_rule__FeatureGroup__CardinalitiesAssignment_16553);
            ruleRelativeCardinalityDirect();

            state._fsp--;

             after(grammarAccess.getFeatureGroupAccess().getCardinalitiesRelativeCardinalityDirectParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureGroup__CardinalitiesAssignment_1"


    // $ANTLR start "rule__FeatureGroup__CardinalitiesAssignment_2"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3294:1: rule__FeatureGroup__CardinalitiesAssignment_2 : ( ruleRelativeCardinalityToUpper ) ;
    public final void rule__FeatureGroup__CardinalitiesAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3298:1: ( ( ruleRelativeCardinalityToUpper ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3299:1: ( ruleRelativeCardinalityToUpper )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3299:1: ( ruleRelativeCardinalityToUpper )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3300:1: ruleRelativeCardinalityToUpper
            {
             before(grammarAccess.getFeatureGroupAccess().getCardinalitiesRelativeCardinalityToUpperParserRuleCall_2_0()); 
            pushFollow(FOLLOW_ruleRelativeCardinalityToUpper_in_rule__FeatureGroup__CardinalitiesAssignment_26584);
            ruleRelativeCardinalityToUpper();

            state._fsp--;

             after(grammarAccess.getFeatureGroupAccess().getCardinalitiesRelativeCardinalityToUpperParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureGroup__CardinalitiesAssignment_2"


    // $ANTLR start "rule__FeatureGroup__GroupCardinalityAssignment_3"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3309:1: rule__FeatureGroup__GroupCardinalityAssignment_3 : ( ruleGroupCardinality ) ;
    public final void rule__FeatureGroup__GroupCardinalityAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3313:1: ( ( ruleGroupCardinality ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3314:1: ( ruleGroupCardinality )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3314:1: ( ruleGroupCardinality )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3315:1: ruleGroupCardinality
            {
             before(grammarAccess.getFeatureGroupAccess().getGroupCardinalityGroupCardinalityParserRuleCall_3_0()); 
            pushFollow(FOLLOW_ruleGroupCardinality_in_rule__FeatureGroup__GroupCardinalityAssignment_36615);
            ruleGroupCardinality();

            state._fsp--;

             after(grammarAccess.getFeatureGroupAccess().getGroupCardinalityGroupCardinalityParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureGroup__GroupCardinalityAssignment_3"


    // $ANTLR start "rule__FeatureGroup__VariantsAssignment_5"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3324:1: rule__FeatureGroup__VariantsAssignment_5 : ( ruleAbstractFeature ) ;
    public final void rule__FeatureGroup__VariantsAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3328:1: ( ( ruleAbstractFeature ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3329:1: ( ruleAbstractFeature )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3329:1: ( ruleAbstractFeature )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3330:1: ruleAbstractFeature
            {
             before(grammarAccess.getFeatureGroupAccess().getVariantsAbstractFeatureParserRuleCall_5_0()); 
            pushFollow(FOLLOW_ruleAbstractFeature_in_rule__FeatureGroup__VariantsAssignment_56646);
            ruleAbstractFeature();

            state._fsp--;

             after(grammarAccess.getFeatureGroupAccess().getVariantsAbstractFeatureParserRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureGroup__VariantsAssignment_5"


    // $ANTLR start "rule__FeatureGroup__VariantsAssignment_6_1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3339:1: rule__FeatureGroup__VariantsAssignment_6_1 : ( ruleAbstractFeature ) ;
    public final void rule__FeatureGroup__VariantsAssignment_6_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3343:1: ( ( ruleAbstractFeature ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3344:1: ( ruleAbstractFeature )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3344:1: ( ruleAbstractFeature )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3345:1: ruleAbstractFeature
            {
             before(grammarAccess.getFeatureGroupAccess().getVariantsAbstractFeatureParserRuleCall_6_1_0()); 
            pushFollow(FOLLOW_ruleAbstractFeature_in_rule__FeatureGroup__VariantsAssignment_6_16677);
            ruleAbstractFeature();

            state._fsp--;

             after(grammarAccess.getFeatureGroupAccess().getVariantsAbstractFeatureParserRuleCall_6_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__FeatureGroup__VariantsAssignment_6_1"


    // $ANTLR start "rule__RelativeCardinalityDirect__CardinalityAssignment"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3354:1: rule__RelativeCardinalityDirect__CardinalityAssignment : ( ruleFeatureCardinality ) ;
    public final void rule__RelativeCardinalityDirect__CardinalityAssignment() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3358:1: ( ( ruleFeatureCardinality ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3359:1: ( ruleFeatureCardinality )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3359:1: ( ruleFeatureCardinality )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3360:1: ruleFeatureCardinality
            {
             before(grammarAccess.getRelativeCardinalityDirectAccess().getCardinalityFeatureCardinalityParserRuleCall_0()); 
            pushFollow(FOLLOW_ruleFeatureCardinality_in_rule__RelativeCardinalityDirect__CardinalityAssignment6708);
            ruleFeatureCardinality();

            state._fsp--;

             after(grammarAccess.getRelativeCardinalityDirectAccess().getCardinalityFeatureCardinalityParserRuleCall_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RelativeCardinalityDirect__CardinalityAssignment"


    // $ANTLR start "rule__RelativeCardinalityToUpper__ToAssignment_1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3369:1: rule__RelativeCardinalityToUpper__ToAssignment_1 : ( ( RULE_ID ) ) ;
    public final void rule__RelativeCardinalityToUpper__ToAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3373:1: ( ( ( RULE_ID ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3374:1: ( ( RULE_ID ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3374:1: ( ( RULE_ID ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3375:1: ( RULE_ID )
            {
             before(grammarAccess.getRelativeCardinalityToUpperAccess().getToFeatureCrossReference_1_0()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3376:1: ( RULE_ID )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3377:1: RULE_ID
            {
             before(grammarAccess.getRelativeCardinalityToUpperAccess().getToFeatureIDTerminalRuleCall_1_0_1()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__RelativeCardinalityToUpper__ToAssignment_16743); 
             after(grammarAccess.getRelativeCardinalityToUpperAccess().getToFeatureIDTerminalRuleCall_1_0_1()); 

            }

             after(grammarAccess.getRelativeCardinalityToUpperAccess().getToFeatureCrossReference_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RelativeCardinalityToUpper__ToAssignment_1"


    // $ANTLR start "rule__RelativeCardinalityToUpper__CardinalityAssignment_3"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3388:1: rule__RelativeCardinalityToUpper__CardinalityAssignment_3 : ( ruleFeatureCardinality ) ;
    public final void rule__RelativeCardinalityToUpper__CardinalityAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3392:1: ( ( ruleFeatureCardinality ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3393:1: ( ruleFeatureCardinality )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3393:1: ( ruleFeatureCardinality )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3394:1: ruleFeatureCardinality
            {
             before(grammarAccess.getRelativeCardinalityToUpperAccess().getCardinalityFeatureCardinalityParserRuleCall_3_0()); 
            pushFollow(FOLLOW_ruleFeatureCardinality_in_rule__RelativeCardinalityToUpper__CardinalityAssignment_36778);
            ruleFeatureCardinality();

            state._fsp--;

             after(grammarAccess.getRelativeCardinalityToUpperAccess().getCardinalityFeatureCardinalityParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__RelativeCardinalityToUpper__CardinalityAssignment_3"


    // $ANTLR start "rule__Cardinality__MinAssignment_0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3403:1: rule__Cardinality__MinAssignment_0 : ( RULE_INT ) ;
    public final void rule__Cardinality__MinAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3407:1: ( ( RULE_INT ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3408:1: ( RULE_INT )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3408:1: ( RULE_INT )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3409:1: RULE_INT
            {
             before(grammarAccess.getCardinalityAccess().getMinINTTerminalRuleCall_0_0()); 
            match(input,RULE_INT,FOLLOW_RULE_INT_in_rule__Cardinality__MinAssignment_06809); 
             after(grammarAccess.getCardinalityAccess().getMinINTTerminalRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Cardinality__MinAssignment_0"


    // $ANTLR start "rule__Cardinality__MaxAssignment_2"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3418:1: rule__Cardinality__MaxAssignment_2 : ( RULE_INT ) ;
    public final void rule__Cardinality__MaxAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3422:1: ( ( RULE_INT ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3423:1: ( RULE_INT )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3423:1: ( RULE_INT )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3424:1: RULE_INT
            {
             before(grammarAccess.getCardinalityAccess().getMaxINTTerminalRuleCall_2_0()); 
            match(input,RULE_INT,FOLLOW_RULE_INT_in_rule__Cardinality__MaxAssignment_26840); 
             after(grammarAccess.getCardinalityAccess().getMaxINTTerminalRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Cardinality__MaxAssignment_2"


    // $ANTLR start "rule__Constraint__ContextAssignment_1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3433:1: rule__Constraint__ContextAssignment_1 : ( ( RULE_ID ) ) ;
    public final void rule__Constraint__ContextAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3437:1: ( ( ( RULE_ID ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3438:1: ( ( RULE_ID ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3438:1: ( ( RULE_ID ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3439:1: ( RULE_ID )
            {
             before(grammarAccess.getConstraintAccess().getContextAbstractFeatureCrossReference_1_0()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3440:1: ( RULE_ID )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3441:1: RULE_ID
            {
             before(grammarAccess.getConstraintAccess().getContextAbstractFeatureIDTerminalRuleCall_1_0_1()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__Constraint__ContextAssignment_16875); 
             after(grammarAccess.getConstraintAccess().getContextAbstractFeatureIDTerminalRuleCall_1_0_1()); 

            }

             after(grammarAccess.getConstraintAccess().getContextAbstractFeatureCrossReference_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constraint__ContextAssignment_1"


    // $ANTLR start "rule__Constraint__ConditionAssignment_3"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3452:1: rule__Constraint__ConditionAssignment_3 : ( ruleExpression ) ;
    public final void rule__Constraint__ConditionAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3456:1: ( ( ruleExpression ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3457:1: ( ruleExpression )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3457:1: ( ruleExpression )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3458:1: ruleExpression
            {
             before(grammarAccess.getConstraintAccess().getConditionExpressionParserRuleCall_3_0()); 
            pushFollow(FOLLOW_ruleExpression_in_rule__Constraint__ConditionAssignment_36910);
            ruleExpression();

            state._fsp--;

             after(grammarAccess.getConstraintAccess().getConditionExpressionParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constraint__ConditionAssignment_3"


    // $ANTLR start "rule__Constraint__ConsequenceAssignment_5"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3467:1: rule__Constraint__ConsequenceAssignment_5 : ( ruleExpression ) ;
    public final void rule__Constraint__ConsequenceAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3471:1: ( ( ruleExpression ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3472:1: ( ruleExpression )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3472:1: ( ruleExpression )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3473:1: ruleExpression
            {
             before(grammarAccess.getConstraintAccess().getConsequenceExpressionParserRuleCall_5_0()); 
            pushFollow(FOLLOW_ruleExpression_in_rule__Constraint__ConsequenceAssignment_56941);
            ruleExpression();

            state._fsp--;

             after(grammarAccess.getConstraintAccess().getConsequenceExpressionParserRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Constraint__ConsequenceAssignment_5"


    // $ANTLR start "rule__ConstrainingExpression__CardinalityAssignment_0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3482:1: rule__ConstrainingExpression__CardinalityAssignment_0 : ( ruleFeatureCardinality ) ;
    public final void rule__ConstrainingExpression__CardinalityAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3486:1: ( ( ruleFeatureCardinality ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3487:1: ( ruleFeatureCardinality )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3487:1: ( ruleFeatureCardinality )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3488:1: ruleFeatureCardinality
            {
             before(grammarAccess.getConstrainingExpressionAccess().getCardinalityFeatureCardinalityParserRuleCall_0_0()); 
            pushFollow(FOLLOW_ruleFeatureCardinality_in_rule__ConstrainingExpression__CardinalityAssignment_06972);
            ruleFeatureCardinality();

            state._fsp--;

             after(grammarAccess.getConstrainingExpressionAccess().getCardinalityFeatureCardinalityParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ConstrainingExpression__CardinalityAssignment_0"


    // $ANTLR start "rule__ConstrainingExpression__FromAssignment_2"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3497:1: rule__ConstrainingExpression__FromAssignment_2 : ( ( RULE_ID ) ) ;
    public final void rule__ConstrainingExpression__FromAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3501:1: ( ( ( RULE_ID ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3502:1: ( ( RULE_ID ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3502:1: ( ( RULE_ID ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3503:1: ( RULE_ID )
            {
             before(grammarAccess.getConstrainingExpressionAccess().getFromAbstractFeatureCrossReference_2_0()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3504:1: ( RULE_ID )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3505:1: RULE_ID
            {
             before(grammarAccess.getConstrainingExpressionAccess().getFromAbstractFeatureIDTerminalRuleCall_2_0_1()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__ConstrainingExpression__FromAssignment_27007); 
             after(grammarAccess.getConstrainingExpressionAccess().getFromAbstractFeatureIDTerminalRuleCall_2_0_1()); 

            }

             after(grammarAccess.getConstrainingExpressionAccess().getFromAbstractFeatureCrossReference_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ConstrainingExpression__FromAssignment_2"


    // $ANTLR start "rule__ConstrainingExpression__ToAssignment_4"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3516:1: rule__ConstrainingExpression__ToAssignment_4 : ( ( RULE_ID ) ) ;
    public final void rule__ConstrainingExpression__ToAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3520:1: ( ( ( RULE_ID ) ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3521:1: ( ( RULE_ID ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3521:1: ( ( RULE_ID ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3522:1: ( RULE_ID )
            {
             before(grammarAccess.getConstrainingExpressionAccess().getToAbstractFeatureCrossReference_4_0()); 
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3523:1: ( RULE_ID )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3524:1: RULE_ID
            {
             before(grammarAccess.getConstrainingExpressionAccess().getToAbstractFeatureIDTerminalRuleCall_4_0_1()); 
            match(input,RULE_ID,FOLLOW_RULE_ID_in_rule__ConstrainingExpression__ToAssignment_47046); 
             after(grammarAccess.getConstrainingExpressionAccess().getToAbstractFeatureIDTerminalRuleCall_4_0_1()); 

            }

             after(grammarAccess.getConstrainingExpressionAccess().getToAbstractFeatureCrossReference_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ConstrainingExpression__ToAssignment_4"


    // $ANTLR start "rule__OrConstrainingExpression__ChildrenAssignment_0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3535:1: rule__OrConstrainingExpression__ChildrenAssignment_0 : ( ruleAndConstrainingExpression ) ;
    public final void rule__OrConstrainingExpression__ChildrenAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3539:1: ( ( ruleAndConstrainingExpression ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3540:1: ( ruleAndConstrainingExpression )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3540:1: ( ruleAndConstrainingExpression )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3541:1: ruleAndConstrainingExpression
            {
             before(grammarAccess.getOrConstrainingExpressionAccess().getChildrenAndConstrainingExpressionParserRuleCall_0_0()); 
            pushFollow(FOLLOW_ruleAndConstrainingExpression_in_rule__OrConstrainingExpression__ChildrenAssignment_07081);
            ruleAndConstrainingExpression();

            state._fsp--;

             after(grammarAccess.getOrConstrainingExpressionAccess().getChildrenAndConstrainingExpressionParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__OrConstrainingExpression__ChildrenAssignment_0"


    // $ANTLR start "rule__OrConstrainingExpression__ChildrenAssignment_1_1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3550:1: rule__OrConstrainingExpression__ChildrenAssignment_1_1 : ( ruleAndConstrainingExpression ) ;
    public final void rule__OrConstrainingExpression__ChildrenAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3554:1: ( ( ruleAndConstrainingExpression ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3555:1: ( ruleAndConstrainingExpression )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3555:1: ( ruleAndConstrainingExpression )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3556:1: ruleAndConstrainingExpression
            {
             before(grammarAccess.getOrConstrainingExpressionAccess().getChildrenAndConstrainingExpressionParserRuleCall_1_1_0()); 
            pushFollow(FOLLOW_ruleAndConstrainingExpression_in_rule__OrConstrainingExpression__ChildrenAssignment_1_17112);
            ruleAndConstrainingExpression();

            state._fsp--;

             after(grammarAccess.getOrConstrainingExpressionAccess().getChildrenAndConstrainingExpressionParserRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__OrConstrainingExpression__ChildrenAssignment_1_1"


    // $ANTLR start "rule__AndConstrainingExpression__ChildrenAssignment_0"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3565:1: rule__AndConstrainingExpression__ChildrenAssignment_0 : ( rulePrimary ) ;
    public final void rule__AndConstrainingExpression__ChildrenAssignment_0() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3569:1: ( ( rulePrimary ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3570:1: ( rulePrimary )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3570:1: ( rulePrimary )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3571:1: rulePrimary
            {
             before(grammarAccess.getAndConstrainingExpressionAccess().getChildrenPrimaryParserRuleCall_0_0()); 
            pushFollow(FOLLOW_rulePrimary_in_rule__AndConstrainingExpression__ChildrenAssignment_07143);
            rulePrimary();

            state._fsp--;

             after(grammarAccess.getAndConstrainingExpressionAccess().getChildrenPrimaryParserRuleCall_0_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AndConstrainingExpression__ChildrenAssignment_0"


    // $ANTLR start "rule__AndConstrainingExpression__ChildrenAssignment_1_1"
    // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3580:1: rule__AndConstrainingExpression__ChildrenAssignment_1_1 : ( rulePrimary ) ;
    public final void rule__AndConstrainingExpression__ChildrenAssignment_1_1() throws RecognitionException {

        		int stackSize = keepStackSize();
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3584:1: ( ( rulePrimary ) )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3585:1: ( rulePrimary )
            {
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3585:1: ( rulePrimary )
            // ../fr.inria.lille.spirals.fm.dsl.ui/src-gen/fr/inria/lille/spirals/fm/ui/contentassist/antlr/internal/InternalFeatureModel.g:3586:1: rulePrimary
            {
             before(grammarAccess.getAndConstrainingExpressionAccess().getChildrenPrimaryParserRuleCall_1_1_0()); 
            pushFollow(FOLLOW_rulePrimary_in_rule__AndConstrainingExpression__ChildrenAssignment_1_17174);
            rulePrimary();

            state._fsp--;

             after(grammarAccess.getAndConstrainingExpressionAccess().getChildrenPrimaryParserRuleCall_1_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AndConstrainingExpression__ChildrenAssignment_1_1"

    // Delegated rules


    protected DFA2 dfa2 = new DFA2(this);
    protected DFA13 dfa13 = new DFA13(this);
    static final String DFA2_eotS =
        "\21\uffff";
    static final String DFA2_eofS =
        "\1\uffff\1\4\12\uffff\1\4\3\uffff\1\4";
    static final String DFA2_minS =
        "\2\4\1\6\1\4\1\uffff\1\25\1\uffff\1\24\1\6\1\20\1\21\1\6\1\4\1\25\1\6\1\21\1\4";
    static final String DFA2_maxS =
        "\1\4\1\23\2\6\1\uffff\1\25\1\uffff\1\24\1\6\1\20\1\21\1\6\1\23\1\25\1\6\1\21\1\23";
    static final String DFA2_acceptS =
        "\4\uffff\1\1\1\uffff\1\2\12\uffff";
    static final String DFA2_specialS =
        "\21\uffff}>";
    static final String[] DFA2_transitionS = {
            "\1\1",
            "\1\4\10\uffff\3\4\1\2\2\4\1\3",
            "\1\5",
            "\1\7\1\uffff\1\6",
            "",
            "\1\10",
            "",
            "\1\11",
            "\1\12",
            "\1\13",
            "\1\14",
            "\1\15",
            "\1\4\10\uffff\3\4\1\uffff\2\4\1\3",
            "\1\16",
            "\1\17",
            "\1\20",
            "\1\4\10\uffff\3\4\1\uffff\2\4\1\3"
    };

    static final short[] DFA2_eot = DFA.unpackEncodedString(DFA2_eotS);
    static final short[] DFA2_eof = DFA.unpackEncodedString(DFA2_eofS);
    static final char[] DFA2_min = DFA.unpackEncodedStringToUnsignedChars(DFA2_minS);
    static final char[] DFA2_max = DFA.unpackEncodedStringToUnsignedChars(DFA2_maxS);
    static final short[] DFA2_accept = DFA.unpackEncodedString(DFA2_acceptS);
    static final short[] DFA2_special = DFA.unpackEncodedString(DFA2_specialS);
    static final short[][] DFA2_transition;

    static {
        int numStates = DFA2_transitionS.length;
        DFA2_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA2_transition[i] = DFA.unpackEncodedString(DFA2_transitionS[i]);
        }
    }

    class DFA2 extends DFA {

        public DFA2(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 2;
            this.eot = DFA2_eot;
            this.eof = DFA2_eof;
            this.min = DFA2_min;
            this.max = DFA2_max;
            this.accept = DFA2_accept;
            this.special = DFA2_special;
            this.transition = DFA2_transition;
        }
        public String getDescription() {
            return "586:1: rule__AbstractFeature__Alternatives : ( ( ruleFeature ) | ( ruleFeatureGroup ) );";
        }
    }
    static final String DFA13_eotS =
        "\13\uffff";
    static final String DFA13_eofS =
        "\1\1\10\uffff\1\12\1\uffff";
    static final String DFA13_minS =
        "\1\4\1\uffff\1\4\1\24\1\20\1\6\1\25\1\6\1\21\1\4\1\uffff";
    static final String DFA13_maxS =
        "\1\23\1\uffff\1\4\1\24\1\27\1\6\1\25\1\6\1\21\1\27\1\uffff";
    static final String DFA13_acceptS =
        "\1\uffff\1\2\10\uffff\1\1";
    static final String DFA13_specialS =
        "\13\uffff}>";
    static final String[] DFA13_transitionS = {
            "\1\1\10\uffff\3\1\1\uffff\2\1\1\2",
            "",
            "\1\3",
            "\1\4",
            "\1\5\6\uffff\1\1",
            "\1\6",
            "\1\7",
            "\1\10",
            "\1\11",
            "\1\12\10\uffff\3\12\1\uffff\3\12\3\uffff\1\1",
            ""
    };

    static final short[] DFA13_eot = DFA.unpackEncodedString(DFA13_eotS);
    static final short[] DFA13_eof = DFA.unpackEncodedString(DFA13_eofS);
    static final char[] DFA13_min = DFA.unpackEncodedStringToUnsignedChars(DFA13_minS);
    static final char[] DFA13_max = DFA.unpackEncodedStringToUnsignedChars(DFA13_maxS);
    static final short[] DFA13_accept = DFA.unpackEncodedString(DFA13_acceptS);
    static final short[] DFA13_special = DFA.unpackEncodedString(DFA13_specialS);
    static final short[][] DFA13_transition;

    static {
        int numStates = DFA13_transitionS.length;
        DFA13_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA13_transition[i] = DFA.unpackEncodedString(DFA13_transitionS[i]);
        }
    }

    class DFA13 extends DFA {

        public DFA13(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 13;
            this.eot = DFA13_eot;
            this.eof = DFA13_eof;
            this.min = DFA13_min;
            this.max = DFA13_max;
            this.accept = DFA13_accept;
            this.special = DFA13_special;
            this.transition = DFA13_transition;
        }
        public String getDescription() {
            return "()* loopback of 1334:1: ( rule__Feature__CardinalitiesAssignment_2 )*";
        }
    }
 

    public static final BitSet FOLLOW_ruleElement_in_entryRuleElement61 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleElement68 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Element__Alternatives_in_ruleElement94 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleConfiguration_in_entryRuleConfiguration121 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleConfiguration128 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Configuration__Group__0_in_ruleConfiguration154 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleInstance_in_entryRuleInstance181 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleInstance188 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Instance__Group__0_in_ruleInstance214 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureModel_in_entryRuleFeatureModel241 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleFeatureModel248 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureModel__Group__0_in_ruleFeatureModel274 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAbstractFeature_in_entryRuleAbstractFeature301 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleAbstractFeature308 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__AbstractFeature__Alternatives_in_ruleAbstractFeature334 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeature_in_entryRuleFeature361 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleFeature368 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Feature__Group__0_in_ruleFeature394 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureGroup_in_entryRuleFeatureGroup421 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleFeatureGroup428 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureGroup__Group__0_in_ruleFeatureGroup454 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleRelativeCardinalityDirect_in_entryRuleRelativeCardinalityDirect481 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleRelativeCardinalityDirect488 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__RelativeCardinalityDirect__CardinalityAssignment_in_ruleRelativeCardinalityDirect514 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleRelativeCardinalityToUpper_in_entryRuleRelativeCardinalityToUpper541 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleRelativeCardinalityToUpper548 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__RelativeCardinalityToUpper__Group__0_in_ruleRelativeCardinalityToUpper574 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleGroupCardinality_in_entryRuleGroupCardinality601 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleGroupCardinality608 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__GroupCardinality__Group__0_in_ruleGroupCardinality634 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureCardinality_in_entryRuleFeatureCardinality661 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleFeatureCardinality668 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureCardinality__Group__0_in_ruleFeatureCardinality694 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleCardinality_in_entryRuleCardinality721 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleCardinality728 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Cardinality__Group__0_in_ruleCardinality754 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleConstraint_in_entryRuleConstraint781 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleConstraint788 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Constraint__Group__0_in_ruleConstraint814 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleConstrainingExpression_in_entryRuleConstrainingExpression841 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleConstrainingExpression848 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ConstrainingExpression__Group__0_in_ruleConstrainingExpression874 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleExpression_in_entryRuleExpression901 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleExpression908 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleOrConstrainingExpression_in_ruleExpression934 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleOrConstrainingExpression_in_entryRuleOrConstrainingExpression960 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleOrConstrainingExpression967 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__OrConstrainingExpression__Group__0_in_ruleOrConstrainingExpression993 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAndConstrainingExpression_in_entryRuleAndConstrainingExpression1020 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleAndConstrainingExpression1027 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__AndConstrainingExpression__Group__0_in_ruleAndConstrainingExpression1053 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulePrimary_in_entryRulePrimary1080 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRulePrimary1087 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Primary__Alternatives_in_rulePrimary1113 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureModel_in_rule__Element__Alternatives1149 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleConfiguration_in_rule__Element__Alternatives1166 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeature_in_rule__AbstractFeature__Alternatives1198 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureGroup_in_rule__AbstractFeature__Alternatives1215 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleConstrainingExpression_in_rule__Primary__Alternatives1247 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Primary__Group_1__0_in_rule__Primary__Alternatives1264 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Configuration__Group__0__Impl_in_rule__Configuration__Group__01295 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Configuration__Group__1_in_rule__Configuration__Group__01298 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_11_in_rule__Configuration__Group__0__Impl1326 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Configuration__Group__1__Impl_in_rule__Configuration__Group__11357 = new BitSet(new long[]{0x0000000000001050L});
    public static final BitSet FOLLOW_rule__Configuration__Group__2_in_rule__Configuration__Group__11360 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Configuration__FeatureModelAssignment_1_in_rule__Configuration__Group__1__Impl1387 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Configuration__Group__2__Impl_in_rule__Configuration__Group__21417 = new BitSet(new long[]{0x0000000000001050L});
    public static final BitSet FOLLOW_rule__Configuration__Group__3_in_rule__Configuration__Group__21420 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Configuration__Group_2__0_in_rule__Configuration__Group__2__Impl1447 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Configuration__Group__3__Impl_in_rule__Configuration__Group__31478 = new BitSet(new long[]{0x0000000000003050L});
    public static final BitSet FOLLOW_rule__Configuration__Group__4_in_rule__Configuration__Group__31481 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Configuration__InstancesAssignment_3_in_rule__Configuration__Group__3__Impl1508 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Configuration__Group__4__Impl_in_rule__Configuration__Group__41538 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Configuration__Group_4__0_in_rule__Configuration__Group__4__Impl1565 = new BitSet(new long[]{0x0000000000003052L});
    public static final BitSet FOLLOW_rule__Configuration__Group_2__0__Impl_in_rule__Configuration__Group_2__01606 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_rule__Configuration__Group_2__1_in_rule__Configuration__Group_2__01609 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_12_in_rule__Configuration__Group_2__0__Impl1637 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Configuration__Group_2__1__Impl_in_rule__Configuration__Group_2__11668 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Configuration__ImportURIAssignment_2_1_in_rule__Configuration__Group_2__1__Impl1695 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Configuration__Group_4__0__Impl_in_rule__Configuration__Group_4__01729 = new BitSet(new long[]{0x0000000000003050L});
    public static final BitSet FOLLOW_rule__Configuration__Group_4__1_in_rule__Configuration__Group_4__01732 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_13_in_rule__Configuration__Group_4__0__Impl1761 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Configuration__Group_4__1__Impl_in_rule__Configuration__Group_4__11794 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Configuration__InstancesAssignment_4_1_in_rule__Configuration__Group_4__1__Impl1821 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Instance__Group__0__Impl_in_rule__Instance__Group__01855 = new BitSet(new long[]{0x0000000000001050L});
    public static final BitSet FOLLOW_rule__Instance__Group__1_in_rule__Instance__Group__01858 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Instance__NumberAssignment_0_in_rule__Instance__Group__0__Impl1885 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Instance__Group__1__Impl_in_rule__Instance__Group__11916 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_rule__Instance__Group__2_in_rule__Instance__Group__11919 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Instance__TypeAssignment_1_in_rule__Instance__Group__1__Impl1946 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Instance__Group__2__Impl_in_rule__Instance__Group__21976 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Instance__Group_2__0_in_rule__Instance__Group__2__Impl2003 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Instance__Group_2__0__Impl_in_rule__Instance__Group_2__02040 = new BitSet(new long[]{0x0000000000001050L});
    public static final BitSet FOLLOW_rule__Instance__Group_2__1_in_rule__Instance__Group_2__02043 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_14_in_rule__Instance__Group_2__0__Impl2071 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Instance__Group_2__1__Impl_in_rule__Instance__Group_2__12102 = new BitSet(new long[]{0x000000000000B050L});
    public static final BitSet FOLLOW_rule__Instance__Group_2__2_in_rule__Instance__Group_2__12105 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Instance__ChildrenAssignment_2_1_in_rule__Instance__Group_2__1__Impl2132 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Instance__Group_2__2__Impl_in_rule__Instance__Group_2__22162 = new BitSet(new long[]{0x000000000000B050L});
    public static final BitSet FOLLOW_rule__Instance__Group_2__3_in_rule__Instance__Group_2__22165 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Instance__Group_2_2__0_in_rule__Instance__Group_2__2__Impl2192 = new BitSet(new long[]{0x0000000000003052L});
    public static final BitSet FOLLOW_rule__Instance__Group_2__3__Impl_in_rule__Instance__Group_2__32223 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_15_in_rule__Instance__Group_2__3__Impl2251 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Instance__Group_2_2__0__Impl_in_rule__Instance__Group_2_2__02290 = new BitSet(new long[]{0x0000000000003050L});
    public static final BitSet FOLLOW_rule__Instance__Group_2_2__1_in_rule__Instance__Group_2_2__02293 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_13_in_rule__Instance__Group_2_2__0__Impl2322 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Instance__Group_2_2__1__Impl_in_rule__Instance__Group_2_2__12355 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Instance__ChildrenAssignment_2_2_1_in_rule__Instance__Group_2_2__1__Impl2382 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureModel__Group__0__Impl_in_rule__FeatureModel__Group__02416 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_rule__FeatureModel__Group__1_in_rule__FeatureModel__Group__02419 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureModel__RootAssignment_0_in_rule__FeatureModel__Group__0__Impl2446 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureModel__Group__1__Impl_in_rule__FeatureModel__Group__12476 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureModel__ConstraintsAssignment_1_in_rule__FeatureModel__Group__1__Impl2503 = new BitSet(new long[]{0x0000000000080002L});
    public static final BitSet FOLLOW_rule__Feature__Group__0__Impl_in_rule__Feature__Group__02538 = new BitSet(new long[]{0x0000000000094000L});
    public static final BitSet FOLLOW_rule__Feature__Group__1_in_rule__Feature__Group__02541 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Feature__NameAssignment_0_in_rule__Feature__Group__0__Impl2568 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Feature__Group__1__Impl_in_rule__Feature__Group__12598 = new BitSet(new long[]{0x0000000000094000L});
    public static final BitSet FOLLOW_rule__Feature__Group__2_in_rule__Feature__Group__12601 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Feature__CardinalitiesAssignment_1_in_rule__Feature__Group__1__Impl2628 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Feature__Group__2__Impl_in_rule__Feature__Group__22659 = new BitSet(new long[]{0x0000000000094000L});
    public static final BitSet FOLLOW_rule__Feature__Group__3_in_rule__Feature__Group__22662 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Feature__CardinalitiesAssignment_2_in_rule__Feature__Group__2__Impl2689 = new BitSet(new long[]{0x0000000000080002L});
    public static final BitSet FOLLOW_rule__Feature__Group__3__Impl_in_rule__Feature__Group__32720 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Feature__Group_3__0_in_rule__Feature__Group__3__Impl2747 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Feature__Group_3__0__Impl_in_rule__Feature__Group_3__02786 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Feature__Group_3__1_in_rule__Feature__Group_3__02789 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_14_in_rule__Feature__Group_3__0__Impl2817 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Feature__Group_3__1__Impl_in_rule__Feature__Group_3__12848 = new BitSet(new long[]{0x000000000000A010L});
    public static final BitSet FOLLOW_rule__Feature__Group_3__2_in_rule__Feature__Group_3__12851 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Feature__SubFeaturesAssignment_3_1_in_rule__Feature__Group_3__1__Impl2878 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Feature__Group_3__2__Impl_in_rule__Feature__Group_3__22908 = new BitSet(new long[]{0x000000000000A010L});
    public static final BitSet FOLLOW_rule__Feature__Group_3__3_in_rule__Feature__Group_3__22911 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Feature__Group_3_2__0_in_rule__Feature__Group_3__2__Impl2938 = new BitSet(new long[]{0x0000000000002012L});
    public static final BitSet FOLLOW_rule__Feature__Group_3__3__Impl_in_rule__Feature__Group_3__32969 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_15_in_rule__Feature__Group_3__3__Impl2997 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Feature__Group_3_2__0__Impl_in_rule__Feature__Group_3_2__03036 = new BitSet(new long[]{0x0000000000002010L});
    public static final BitSet FOLLOW_rule__Feature__Group_3_2__1_in_rule__Feature__Group_3_2__03039 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_13_in_rule__Feature__Group_3_2__0__Impl3068 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Feature__Group_3_2__1__Impl_in_rule__Feature__Group_3_2__13101 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Feature__SubFeaturesAssignment_3_2_1_in_rule__Feature__Group_3_2__1__Impl3128 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureGroup__Group__0__Impl_in_rule__FeatureGroup__Group__03162 = new BitSet(new long[]{0x0000000000090000L});
    public static final BitSet FOLLOW_rule__FeatureGroup__Group__1_in_rule__FeatureGroup__Group__03165 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureGroup__NameAssignment_0_in_rule__FeatureGroup__Group__0__Impl3192 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureGroup__Group__1__Impl_in_rule__FeatureGroup__Group__13222 = new BitSet(new long[]{0x0000000000090000L});
    public static final BitSet FOLLOW_rule__FeatureGroup__Group__2_in_rule__FeatureGroup__Group__13225 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureGroup__CardinalitiesAssignment_1_in_rule__FeatureGroup__Group__1__Impl3252 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureGroup__Group__2__Impl_in_rule__FeatureGroup__Group__23283 = new BitSet(new long[]{0x0000000000090000L});
    public static final BitSet FOLLOW_rule__FeatureGroup__Group__3_in_rule__FeatureGroup__Group__23286 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureGroup__CardinalitiesAssignment_2_in_rule__FeatureGroup__Group__2__Impl3313 = new BitSet(new long[]{0x0000000000080002L});
    public static final BitSet FOLLOW_rule__FeatureGroup__Group__3__Impl_in_rule__FeatureGroup__Group__33344 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_rule__FeatureGroup__Group__4_in_rule__FeatureGroup__Group__33347 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureGroup__GroupCardinalityAssignment_3_in_rule__FeatureGroup__Group__3__Impl3374 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureGroup__Group__4__Impl_in_rule__FeatureGroup__Group__43404 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__FeatureGroup__Group__5_in_rule__FeatureGroup__Group__43407 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_16_in_rule__FeatureGroup__Group__4__Impl3435 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureGroup__Group__5__Impl_in_rule__FeatureGroup__Group__53466 = new BitSet(new long[]{0x0000000000040010L});
    public static final BitSet FOLLOW_rule__FeatureGroup__Group__6_in_rule__FeatureGroup__Group__53469 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureGroup__VariantsAssignment_5_in_rule__FeatureGroup__Group__5__Impl3496 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureGroup__Group__6__Impl_in_rule__FeatureGroup__Group__63526 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_rule__FeatureGroup__Group__7_in_rule__FeatureGroup__Group__63529 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureGroup__Group_6__0_in_rule__FeatureGroup__Group__6__Impl3558 = new BitSet(new long[]{0x0000000000040012L});
    public static final BitSet FOLLOW_rule__FeatureGroup__Group_6__0_in_rule__FeatureGroup__Group__6__Impl3570 = new BitSet(new long[]{0x0000000000040012L});
    public static final BitSet FOLLOW_rule__FeatureGroup__Group__7__Impl_in_rule__FeatureGroup__Group__73603 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_17_in_rule__FeatureGroup__Group__7__Impl3631 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureGroup__Group_6__0__Impl_in_rule__FeatureGroup__Group_6__03678 = new BitSet(new long[]{0x0000000000040010L});
    public static final BitSet FOLLOW_rule__FeatureGroup__Group_6__1_in_rule__FeatureGroup__Group_6__03681 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_18_in_rule__FeatureGroup__Group_6__0__Impl3710 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureGroup__Group_6__1__Impl_in_rule__FeatureGroup__Group_6__13743 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureGroup__VariantsAssignment_6_1_in_rule__FeatureGroup__Group_6__1__Impl3770 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__RelativeCardinalityToUpper__Group__0__Impl_in_rule__RelativeCardinalityToUpper__Group__03804 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__RelativeCardinalityToUpper__Group__1_in_rule__RelativeCardinalityToUpper__Group__03807 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_19_in_rule__RelativeCardinalityToUpper__Group__0__Impl3835 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__RelativeCardinalityToUpper__Group__1__Impl_in_rule__RelativeCardinalityToUpper__Group__13866 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_rule__RelativeCardinalityToUpper__Group__2_in_rule__RelativeCardinalityToUpper__Group__13869 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__RelativeCardinalityToUpper__ToAssignment_1_in_rule__RelativeCardinalityToUpper__Group__1__Impl3896 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__RelativeCardinalityToUpper__Group__2__Impl_in_rule__RelativeCardinalityToUpper__Group__23926 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_rule__RelativeCardinalityToUpper__Group__3_in_rule__RelativeCardinalityToUpper__Group__23929 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_20_in_rule__RelativeCardinalityToUpper__Group__2__Impl3957 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__RelativeCardinalityToUpper__Group__3__Impl_in_rule__RelativeCardinalityToUpper__Group__33988 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__RelativeCardinalityToUpper__CardinalityAssignment_3_in_rule__RelativeCardinalityToUpper__Group__3__Impl4015 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__GroupCardinality__Group__0__Impl_in_rule__GroupCardinality__Group__04053 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_rule__GroupCardinality__Group__1_in_rule__GroupCardinality__Group__04056 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_19_in_rule__GroupCardinality__Group__0__Impl4084 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__GroupCardinality__Group__1__Impl_in_rule__GroupCardinality__Group__14115 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_rule__GroupCardinality__Group__2_in_rule__GroupCardinality__Group__14118 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleCardinality_in_rule__GroupCardinality__Group__1__Impl4145 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__GroupCardinality__Group__2__Impl_in_rule__GroupCardinality__Group__24174 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_20_in_rule__GroupCardinality__Group__2__Impl4202 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureCardinality__Group__0__Impl_in_rule__FeatureCardinality__Group__04239 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_rule__FeatureCardinality__Group__1_in_rule__FeatureCardinality__Group__04242 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_16_in_rule__FeatureCardinality__Group__0__Impl4270 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureCardinality__Group__1__Impl_in_rule__FeatureCardinality__Group__14301 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_rule__FeatureCardinality__Group__2_in_rule__FeatureCardinality__Group__14304 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleCardinality_in_rule__FeatureCardinality__Group__1__Impl4331 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__FeatureCardinality__Group__2__Impl_in_rule__FeatureCardinality__Group__24360 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_17_in_rule__FeatureCardinality__Group__2__Impl4388 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Cardinality__Group__0__Impl_in_rule__Cardinality__Group__04425 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_rule__Cardinality__Group__1_in_rule__Cardinality__Group__04428 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Cardinality__MinAssignment_0_in_rule__Cardinality__Group__0__Impl4455 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Cardinality__Group__1__Impl_in_rule__Cardinality__Group__14485 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_rule__Cardinality__Group__2_in_rule__Cardinality__Group__14488 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_21_in_rule__Cardinality__Group__1__Impl4516 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Cardinality__Group__2__Impl_in_rule__Cardinality__Group__24547 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Cardinality__MaxAssignment_2_in_rule__Cardinality__Group__2__Impl4574 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Constraint__Group__0__Impl_in_rule__Constraint__Group__04610 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__Constraint__Group__1_in_rule__Constraint__Group__04613 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_19_in_rule__Constraint__Group__0__Impl4641 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Constraint__Group__1__Impl_in_rule__Constraint__Group__14672 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_rule__Constraint__Group__2_in_rule__Constraint__Group__14675 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Constraint__ContextAssignment_1_in_rule__Constraint__Group__1__Impl4702 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Constraint__Group__2__Impl_in_rule__Constraint__Group__24732 = new BitSet(new long[]{0x0000000000810000L});
    public static final BitSet FOLLOW_rule__Constraint__Group__3_in_rule__Constraint__Group__24735 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_20_in_rule__Constraint__Group__2__Impl4763 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Constraint__Group__3__Impl_in_rule__Constraint__Group__34794 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_rule__Constraint__Group__4_in_rule__Constraint__Group__34797 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Constraint__ConditionAssignment_3_in_rule__Constraint__Group__3__Impl4824 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Constraint__Group__4__Impl_in_rule__Constraint__Group__44854 = new BitSet(new long[]{0x0000000000810000L});
    public static final BitSet FOLLOW_rule__Constraint__Group__5_in_rule__Constraint__Group__44857 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_22_in_rule__Constraint__Group__4__Impl4885 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Constraint__Group__5__Impl_in_rule__Constraint__Group__54916 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Constraint__ConsequenceAssignment_5_in_rule__Constraint__Group__5__Impl4943 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ConstrainingExpression__Group__0__Impl_in_rule__ConstrainingExpression__Group__04985 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_rule__ConstrainingExpression__Group__1_in_rule__ConstrainingExpression__Group__04988 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ConstrainingExpression__CardinalityAssignment_0_in_rule__ConstrainingExpression__Group__0__Impl5015 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ConstrainingExpression__Group__1__Impl_in_rule__ConstrainingExpression__Group__15045 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__ConstrainingExpression__Group__2_in_rule__ConstrainingExpression__Group__15048 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_23_in_rule__ConstrainingExpression__Group__1__Impl5076 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ConstrainingExpression__Group__2__Impl_in_rule__ConstrainingExpression__Group__25107 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_rule__ConstrainingExpression__Group__3_in_rule__ConstrainingExpression__Group__25110 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ConstrainingExpression__FromAssignment_2_in_rule__ConstrainingExpression__Group__2__Impl5137 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ConstrainingExpression__Group__3__Impl_in_rule__ConstrainingExpression__Group__35167 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_rule__ConstrainingExpression__Group__4_in_rule__ConstrainingExpression__Group__35170 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_13_in_rule__ConstrainingExpression__Group__3__Impl5198 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ConstrainingExpression__Group__4__Impl_in_rule__ConstrainingExpression__Group__45229 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_rule__ConstrainingExpression__Group__5_in_rule__ConstrainingExpression__Group__45232 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ConstrainingExpression__ToAssignment_4_in_rule__ConstrainingExpression__Group__4__Impl5259 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__ConstrainingExpression__Group__5__Impl_in_rule__ConstrainingExpression__Group__55289 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_24_in_rule__ConstrainingExpression__Group__5__Impl5317 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__OrConstrainingExpression__Group__0__Impl_in_rule__OrConstrainingExpression__Group__05360 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_rule__OrConstrainingExpression__Group__1_in_rule__OrConstrainingExpression__Group__05363 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__OrConstrainingExpression__ChildrenAssignment_0_in_rule__OrConstrainingExpression__Group__0__Impl5390 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__OrConstrainingExpression__Group__1__Impl_in_rule__OrConstrainingExpression__Group__15420 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__OrConstrainingExpression__Group_1__0_in_rule__OrConstrainingExpression__Group__1__Impl5447 = new BitSet(new long[]{0x0000000000040002L});
    public static final BitSet FOLLOW_rule__OrConstrainingExpression__Group_1__0__Impl_in_rule__OrConstrainingExpression__Group_1__05482 = new BitSet(new long[]{0x0000000000810000L});
    public static final BitSet FOLLOW_rule__OrConstrainingExpression__Group_1__1_in_rule__OrConstrainingExpression__Group_1__05485 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_18_in_rule__OrConstrainingExpression__Group_1__0__Impl5513 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__OrConstrainingExpression__Group_1__1__Impl_in_rule__OrConstrainingExpression__Group_1__15544 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__OrConstrainingExpression__ChildrenAssignment_1_1_in_rule__OrConstrainingExpression__Group_1__1__Impl5571 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__AndConstrainingExpression__Group__0__Impl_in_rule__AndConstrainingExpression__Group__05605 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_rule__AndConstrainingExpression__Group__1_in_rule__AndConstrainingExpression__Group__05608 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__AndConstrainingExpression__ChildrenAssignment_0_in_rule__AndConstrainingExpression__Group__0__Impl5635 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__AndConstrainingExpression__Group__1__Impl_in_rule__AndConstrainingExpression__Group__15665 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__AndConstrainingExpression__Group_1__0_in_rule__AndConstrainingExpression__Group__1__Impl5692 = new BitSet(new long[]{0x0000000002000002L});
    public static final BitSet FOLLOW_rule__AndConstrainingExpression__Group_1__0__Impl_in_rule__AndConstrainingExpression__Group_1__05727 = new BitSet(new long[]{0x0000000000810000L});
    public static final BitSet FOLLOW_rule__AndConstrainingExpression__Group_1__1_in_rule__AndConstrainingExpression__Group_1__05730 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_25_in_rule__AndConstrainingExpression__Group_1__0__Impl5758 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__AndConstrainingExpression__Group_1__1__Impl_in_rule__AndConstrainingExpression__Group_1__15789 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__AndConstrainingExpression__ChildrenAssignment_1_1_in_rule__AndConstrainingExpression__Group_1__1__Impl5816 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Primary__Group_1__0__Impl_in_rule__Primary__Group_1__05850 = new BitSet(new long[]{0x0000000000810000L});
    public static final BitSet FOLLOW_rule__Primary__Group_1__1_in_rule__Primary__Group_1__05853 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_23_in_rule__Primary__Group_1__0__Impl5881 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Primary__Group_1__1__Impl_in_rule__Primary__Group_1__15912 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_rule__Primary__Group_1__2_in_rule__Primary__Group_1__15915 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleOrConstrainingExpression_in_rule__Primary__Group_1__1__Impl5942 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rule__Primary__Group_1__2__Impl_in_rule__Primary__Group_1__25971 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_24_in_rule__Primary__Group_1__2__Impl5999 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Configuration__FeatureModelAssignment_16045 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_STRING_in_rule__Configuration__ImportURIAssignment_2_16080 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleInstance_in_rule__Configuration__InstancesAssignment_36111 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleInstance_in_rule__Configuration__InstancesAssignment_4_16142 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_INT_in_rule__Instance__NumberAssignment_06173 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Instance__TypeAssignment_16208 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleInstance_in_rule__Instance__ChildrenAssignment_2_16243 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleInstance_in_rule__Instance__ChildrenAssignment_2_2_16274 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeature_in_rule__FeatureModel__RootAssignment_06305 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleConstraint_in_rule__FeatureModel__ConstraintsAssignment_16336 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Feature__NameAssignment_06367 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleRelativeCardinalityDirect_in_rule__Feature__CardinalitiesAssignment_16398 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleRelativeCardinalityToUpper_in_rule__Feature__CardinalitiesAssignment_26429 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAbstractFeature_in_rule__Feature__SubFeaturesAssignment_3_16460 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAbstractFeature_in_rule__Feature__SubFeaturesAssignment_3_2_16491 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__FeatureGroup__NameAssignment_06522 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleRelativeCardinalityDirect_in_rule__FeatureGroup__CardinalitiesAssignment_16553 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleRelativeCardinalityToUpper_in_rule__FeatureGroup__CardinalitiesAssignment_26584 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleGroupCardinality_in_rule__FeatureGroup__GroupCardinalityAssignment_36615 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAbstractFeature_in_rule__FeatureGroup__VariantsAssignment_56646 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAbstractFeature_in_rule__FeatureGroup__VariantsAssignment_6_16677 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureCardinality_in_rule__RelativeCardinalityDirect__CardinalityAssignment6708 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__RelativeCardinalityToUpper__ToAssignment_16743 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureCardinality_in_rule__RelativeCardinalityToUpper__CardinalityAssignment_36778 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_INT_in_rule__Cardinality__MinAssignment_06809 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_INT_in_rule__Cardinality__MaxAssignment_26840 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__Constraint__ContextAssignment_16875 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleExpression_in_rule__Constraint__ConditionAssignment_36910 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleExpression_in_rule__Constraint__ConsequenceAssignment_56941 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureCardinality_in_rule__ConstrainingExpression__CardinalityAssignment_06972 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__ConstrainingExpression__FromAssignment_27007 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_rule__ConstrainingExpression__ToAssignment_47046 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAndConstrainingExpression_in_rule__OrConstrainingExpression__ChildrenAssignment_07081 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAndConstrainingExpression_in_rule__OrConstrainingExpression__ChildrenAssignment_1_17112 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulePrimary_in_rule__AndConstrainingExpression__ChildrenAssignment_07143 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulePrimary_in_rule__AndConstrainingExpression__ChildrenAssignment_1_17174 = new BitSet(new long[]{0x0000000000000002L});

}