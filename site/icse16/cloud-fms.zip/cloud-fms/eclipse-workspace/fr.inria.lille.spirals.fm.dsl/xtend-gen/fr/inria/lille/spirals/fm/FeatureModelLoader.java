package fr.inria.lille.spirals.fm;

import com.google.common.base.Objects;
import com.google.inject.Injector;
import com.google.inject.Singleton;
import fr.inria.lille.spirals.fm.FeatureModelStandaloneSetup;
import fr.inria.lille.spirals.fm.featuremodel.Configuration;
import fr.inria.lille.spirals.fm.featuremodel.FeatureModel;
import fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage;
import java.io.File;
import java.net.URI;
import java.net.URL;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Consumer;
import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.DiagnosticException;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.util.Diagnostician;
import org.eclipse.ocl.examples.pivot.delegate.OCLDelegateDomain;
import org.eclipse.ocl.examples.xtext.oclinecore.OCLinEcoreStandaloneSetup;
import org.eclipse.xtext.resource.XtextResource;
import org.eclipse.xtext.resource.XtextResourceSet;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.InputOutput;

@Singleton
@SuppressWarnings("all")
public class FeatureModelLoader {
  private static Injector injector;
  
  private static FeatureModelLoader loader;
  
  public static Injector getInjector() {
    Injector _xblockexpression = null;
    {
      boolean _equals = Objects.equal(FeatureModelLoader.injector, null);
      if (_equals) {
        OCLinEcoreStandaloneSetup.doSetup();
        FeatureModelStandaloneSetup ss = new FeatureModelStandaloneSetup();
        Injector _createInjectorAndDoEMFRegistration = ss.createInjectorAndDoEMFRegistration();
        FeatureModelLoader.injector = _createInjectorAndDoEMFRegistration;
        FeatureModelLoader _instance = FeatureModelLoader.injector.<FeatureModelLoader>getInstance(FeatureModelLoader.class);
        FeatureModelLoader.loader = _instance;
      }
      _xblockexpression = FeatureModelLoader.injector;
    }
    return _xblockexpression;
  }
  
  public static void addClassPath(final URL url) {
    try {
      Injector _injector = FeatureModelLoader.getInjector();
      FeatureModelLoader _instance = _injector.<FeatureModelLoader>getInstance(FeatureModelLoader.class);
      URI _uRI = url.toURI();
      String _string = _uRI.toString();
      org.eclipse.emf.common.util.URI _createURI = org.eclipse.emf.common.util.URI.createURI(_string);
      _instance.addClassPath(_createURI);
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  private static ResourceSet resourceSet;
  
  public static ResourceSet getResourceSet() {
    ResourceSet _xblockexpression = null;
    {
      boolean _equals = Objects.equal(FeatureModelLoader.resourceSet, null);
      if (_equals) {
        ResourceSet _initResourceSet = FeatureModelLoader.initResourceSet();
        FeatureModelLoader.resourceSet = _initResourceSet;
      }
      _xblockexpression = FeatureModelLoader.resourceSet;
    }
    return _xblockexpression;
  }
  
  public static ResourceSet initResourceSet() {
    XtextResourceSet _xblockexpression = null;
    {
      Injector _injector = FeatureModelLoader.getInjector();
      XtextResourceSet resourceSet = _injector.<XtextResourceSet>getInstance(XtextResourceSet.class);
      OCLDelegateDomain.initialize(resourceSet);
      EPackage.Registry _packageRegistry = resourceSet.getPackageRegistry();
      _packageRegistry.put(FeatureModelPackage.eNS_URI, FeatureModelPackage.eINSTANCE);
      resourceSet.addLoadOption(XtextResource.OPTION_RESOLVE_ALL, Boolean.TRUE);
      _xblockexpression = resourceSet;
    }
    return _xblockexpression;
  }
  
  public static EObject load(final List<org.eclipse.emf.common.util.URI> classpath, final org.eclipse.emf.common.util.URI uri) {
    return FeatureModelLoader.load(uri);
  }
  
  public static EObject load(final org.eclipse.emf.common.util.URI uri) {
    ResourceSet _resourceSet = FeatureModelLoader.getResourceSet();
    Resource resource = _resourceSet.getResource(uri, true);
    EList<EObject> _contents = resource.getContents();
    EObject content = _contents.get(0);
    FeatureModelLoader.validate(content);
    return content;
  }
  
  public static FeatureModel loadFeatureModel(final org.eclipse.emf.common.util.URI uri) {
    EObject _load = FeatureModelLoader.load(uri);
    return ((FeatureModel) _load);
  }
  
  public static Configuration loadConfiguration(final org.eclipse.emf.common.util.URI uri) {
    EObject _load = FeatureModelLoader.load(uri);
    return ((Configuration) _load);
  }
  
  public static void validate(final EObject object) {
    try {
      Injector _injector = FeatureModelLoader.getInjector();
      Diagnostician _instance = _injector.<Diagnostician>getInstance(Diagnostician.class);
      Diagnostic diag = _instance.validate(object);
      int _severity = diag.getSeverity();
      int _bitwiseAnd = (_severity & Diagnostic.ERROR);
      boolean _notEquals = (_bitwiseAnd != 0);
      if (_notEquals) {
        throw new DiagnosticException(diag);
      }
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  private List<org.eclipse.emf.common.util.URI> classPath = new LinkedList<org.eclipse.emf.common.util.URI>();
  
  public void addClassPath(final org.eclipse.emf.common.util.URI uri) {
    this.classPath.add(uri);
  }
  
  public List<org.eclipse.emf.common.util.URI> getClassPath() {
    return this.classPath;
  }
  
  public static void main(final String[] args) {
    try {
      File classPath = new File("/Users/gustavo/Downloads/runtime-EclipseApplication/teste/src/");
      URI _uRI = classPath.toURI();
      URL _uRL = _uRI.toURL();
      FeatureModelLoader.addClassPath(_uRL);
      File file = new File("teste.fm");
      try {
        URI _uRI_1 = file.toURI();
        String _string = _uRI_1.toString();
        org.eclipse.emf.common.util.URI _createURI = org.eclipse.emf.common.util.URI.createURI(_string);
        EObject _load = FeatureModelLoader.load(_createURI);
        Configuration config = ((Configuration) _load);
        InputOutput.<Configuration>println(config);
        FeatureModel _featureModel = config.getFeatureModel();
        InputOutput.<FeatureModel>println(_featureModel);
        FeatureModel _featureModel_1 = config.getFeatureModel();
        String _name = _featureModel_1.getName();
        InputOutput.<String>println(_name);
      } catch (final Throwable _t) {
        if (_t instanceof DiagnosticException) {
          final DiagnosticException ex = (DiagnosticException)_t;
          Diagnostic _diagnostic = ex.getDiagnostic();
          List<Diagnostic> _children = _diagnostic.getChildren();
          final Consumer<Diagnostic> _function = new Consumer<Diagnostic>() {
            public void accept(final Diagnostic it) {
              InputOutput.<Diagnostic>println(it);
            }
          };
          _children.forEach(_function);
        } else {
          throw Exceptions.sneakyThrow(_t);
        }
      }
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
}
