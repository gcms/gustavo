package fr.inria.lille.spirals.fm;

import java.util.List;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.xtext.EcoreUtil2;
import org.eclipse.xtext.linking.impl.DefaultLinkingService;
import org.eclipse.xtext.linking.impl.IllegalNodeException;
import org.eclipse.xtext.nodemodel.INode;

import com.google.inject.Inject;

import fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage;

public class FeatureModelLinkingService extends DefaultLinkingService {
	
	public List<EObject> getLinkedObjects(EObject context, EReference ref, INode node)
			throws IllegalNodeException {				
		// Checks the name of the feature model described in the first line "config fmName"
		// and adds this name to importURI so that the file with the same name is loaded
		
		final EClass requiredType = ref.getEReferenceType();
		if (requiredType == FeatureModelPackage.eINSTANCE.getFeatureModel()
				&& context.eClass() == FeatureModelPackage.eINSTANCE.getConfiguration()) {
			
			String crossRefString = getCrossRefNodeAsString(node);
			
			if (crossRefString != null) {
				String fileName = crossRefString + ".fm";
				String importURI = getImportURI(context, fileName);
				
				EAttribute importURIAttribute = FeatureModelPackage.eINSTANCE.getConfiguration_ImportURI();
				Object current = context.eGet(importURIAttribute);
				
				if (current == null || (current instanceof String && ((String)current).trim().length() == 0))
					context.eSet(importURIAttribute, importURI);
			}
				
		}
		
		return super.getLinkedObjects(context, ref, node);
	}
	
	@Inject
	private FeatureModelLoader loader;
	
	public String getImportURI(EObject context, String fileName) {		
		for (URI path : loader.getClassPath()) {
			String result = getImportURI(path, context, fileName);
			if (result != null)
				return result;
		}
		
		return fileName;		
	}
	
	private String getImportURI(URI classPathURI, EObject context, String fileName) {
		if (classPathURI.path().endsWith(fileName)) {
			if (EcoreUtil2.isValidUri(context, classPathURI)) {
				return fileName;
			}
		} else {
			URI result = URI.createURI(fileName).resolve(classPathURI);
					
			if (EcoreUtil2.isValidUri(context, result)) {
				return result.toString();
			}
		}
			
		
		return null;
	}	

}
