package fr.inria.lille.spirals.fm;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.eclipse.xtext.common.services.DefaultTerminalConverters;
import org.eclipse.xtext.conversion.IValueConverter;
import org.eclipse.xtext.conversion.ValueConverter;
import org.eclipse.xtext.conversion.ValueConverterException;
import org.eclipse.xtext.nodemodel.INode;

import fr.inria.lille.spirals.fm.datatypes.Cardinality;

public class FeatureModelValueConverter extends DefaultTerminalConverters {
	private final Pattern FEATURE_CARDINALITY_PATTERN = Pattern.compile("\\[([0-9]+)\\.\\.([0-9]+)\\]");
	
	@ValueConverter(rule = "FEATURE_CARDINALITY_RULE")
	 public IValueConverter<Cardinality> FEATURE_CARDINALITY_RULE() {
	   return new IValueConverter<Cardinality>() {
	     @Override
	     public Cardinality toValue(String string, INode node) {
	    	 System.out.printf("Converting %s%n", string);
	    	 if (string.equals("?"))
	    		 return new Cardinality(0, 1);
	    	 
	    	 if (string.equals("!"))
	    		 return new Cardinality(1, 1);	    	 
	    	 
	    	 Matcher m = FEATURE_CARDINALITY_PATTERN.matcher(string);
	    	 if (m.matches()) {
	    		 int min = Integer.parseInt(m.group(1));
	    		 int max = Integer.parseInt(m.group(2));
	    		 
	    		 if (min < 0 || min > max)
    				 throw new ValueConverterException("Invalid cardinality range", node, null);
	    		 	    			    		
	    		 return new Cardinality(min, max);
	    	 }
	    	 
	    	 throw new ValueConverterException("Couldn't convert feature cardinality", node, null);
	     }	

		@Override
		public String toString(Cardinality value)
				throws ValueConverterException {
			return value.getMin() + ".." + value.getMax();
		}	
	   };
	 }
	
	private final Pattern GROUP_CARDINALITY_PATTERN = Pattern.compile("<([0-9]+)\\.\\.([0-9]+)>");
	
	@ValueConverter(rule = "GROUP_CARDINALITY_RULE")
	 public IValueConverter<Cardinality> GROUP_CARDINALITY_RULE() {
	   return new IValueConverter<Cardinality>() {
	     @Override
	     public Cardinality toValue(String string, INode node) {    	 	    		    	 
	    	 Matcher m = GROUP_CARDINALITY_PATTERN.matcher(string);
	    	 if (m.matches()) {
	    		 int min = Integer.parseInt(m.group(1));
	    		 int max = Integer.parseInt(m.group(2));
	    		 
	    		 // check if it exceeds maximum number of child
	    		 if (min < 1 || min > max)
	    			 throw new ValueConverterException("Invalid cardinality range", node, null);
	    		 	    			    		
	    		 return new Cardinality(min, max);
	    	 }
	    	 
	    	 throw new ValueConverterException("Couldn't convert feature cardinality", node, null);
	     }	

		@Override
		public String toString(Cardinality value)
				throws ValueConverterException {
			return value.getMin() + ".." + value.getMax();
		}	
	   };
	 }
}
