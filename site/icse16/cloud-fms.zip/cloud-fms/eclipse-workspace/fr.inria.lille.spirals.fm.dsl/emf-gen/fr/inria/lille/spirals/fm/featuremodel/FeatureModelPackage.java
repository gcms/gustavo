/**
 */
package fr.inria.lille.spirals.fm.featuremodel;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModelFactory
 * @model kind="package"
 *        annotation="http://www.eclipse.org/OCL/Import ecore='http://www.eclipse.org/emf/2002/Ecore'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore invocationDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot' settingDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot' validationDelegates='http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot'"
 * @generated
 */
public interface FeatureModelPackage extends EPackage
{
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "featuremodel";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.inria.fr/lille/spirals/fm/FeatureModel";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "featuremodel";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	FeatureModelPackage eINSTANCE = fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl.init();

	/**
	 * The meta object id for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.ElementImpl <em>Element</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.ElementImpl
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getElement()
	 * @generated
	 */
	int ELEMENT = 0;

	/**
	 * The number of structural features of the '<em>Element</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ELEMENT_FEATURE_COUNT = 0;

	/**
	 * The meta object id for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelImpl <em>Feature Model</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelImpl
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getFeatureModel()
	 * @generated
	 */
	int FEATURE_MODEL = 1;

	/**
	 * The feature id for the '<em><b>Root</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE_MODEL__ROOT = ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Constraints</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE_MODEL__CONSTRAINTS = ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE_MODEL__NAME = ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Feature Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE_MODEL_FEATURE_COUNT = ELEMENT_FEATURE_COUNT + 3;

	/**
	 * The meta object id for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.AbstractFeatureImpl <em>Abstract Feature</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.AbstractFeatureImpl
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getAbstractFeature()
	 * @generated
	 */
	int ABSTRACT_FEATURE = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_FEATURE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Parent</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_FEATURE__PARENT = 1;

	/**
	 * The feature id for the '<em><b>Group</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_FEATURE__GROUP = 2;

	/**
	 * The feature id for the '<em><b>Cardinalities</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_FEATURE__CARDINALITIES = 3;

	/**
	 * The number of structural features of the '<em>Abstract Feature</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_FEATURE_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.RelativeCardinalityImpl <em>Relative Cardinality</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.RelativeCardinalityImpl
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getRelativeCardinality()
	 * @generated
	 */
	int RELATIVE_CARDINALITY = 3;

	/**
	 * The feature id for the '<em><b>To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RELATIVE_CARDINALITY__TO = 0;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RELATIVE_CARDINALITY__CARDINALITY = 1;

	/**
	 * The feature id for the '<em><b>From</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RELATIVE_CARDINALITY__FROM = 2;

	/**
	 * The number of structural features of the '<em>Relative Cardinality</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RELATIVE_CARDINALITY_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.FeatureGroupImpl <em>Feature Group</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureGroupImpl
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getFeatureGroup()
	 * @generated
	 */
	int FEATURE_GROUP = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE_GROUP__NAME = ABSTRACT_FEATURE__NAME;

	/**
	 * The feature id for the '<em><b>Parent</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE_GROUP__PARENT = ABSTRACT_FEATURE__PARENT;

	/**
	 * The feature id for the '<em><b>Group</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE_GROUP__GROUP = ABSTRACT_FEATURE__GROUP;

	/**
	 * The feature id for the '<em><b>Cardinalities</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE_GROUP__CARDINALITIES = ABSTRACT_FEATURE__CARDINALITIES;

	/**
	 * The feature id for the '<em><b>Variants</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE_GROUP__VARIANTS = ABSTRACT_FEATURE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Group Cardinality</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE_GROUP__GROUP_CARDINALITY = ABSTRACT_FEATURE_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Feature Group</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE_GROUP_FEATURE_COUNT = ABSTRACT_FEATURE_FEATURE_COUNT + 2;

	/**
	 * The meta object id for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.FeatureImpl <em>Feature</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureImpl
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getFeature()
	 * @generated
	 */
	int FEATURE = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE__NAME = ABSTRACT_FEATURE__NAME;

	/**
	 * The feature id for the '<em><b>Parent</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE__PARENT = ABSTRACT_FEATURE__PARENT;

	/**
	 * The feature id for the '<em><b>Group</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE__GROUP = ABSTRACT_FEATURE__GROUP;

	/**
	 * The feature id for the '<em><b>Cardinalities</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE__CARDINALITIES = ABSTRACT_FEATURE__CARDINALITIES;

	/**
	 * The feature id for the '<em><b>Sub Features</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE__SUB_FEATURES = ABSTRACT_FEATURE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Feature</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FEATURE_FEATURE_COUNT = ABSTRACT_FEATURE_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.ConstraintImpl <em>Constraint</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.ConstraintImpl
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getConstraint()
	 * @generated
	 */
	int CONSTRAINT = 6;

	/**
	 * The feature id for the '<em><b>Context</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSTRAINT__CONTEXT = 0;

	/**
	 * The feature id for the '<em><b>Condition</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSTRAINT__CONDITION = 1;

	/**
	 * The feature id for the '<em><b>Consequence</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSTRAINT__CONSEQUENCE = 2;

	/**
	 * The number of structural features of the '<em>Constraint</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSTRAINT_FEATURE_COUNT = 3;

	/**
	 * The meta object id for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.AbstractConstrainingExpressionImpl <em>Abstract Constraining Expression</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.AbstractConstrainingExpressionImpl
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getAbstractConstrainingExpression()
	 * @generated
	 */
	int ABSTRACT_CONSTRAINING_EXPRESSION = 7;

	/**
	 * The number of structural features of the '<em>Abstract Constraining Expression</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABSTRACT_CONSTRAINING_EXPRESSION_FEATURE_COUNT = 0;

	/**
	 * The meta object id for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.ComposedConstrainingExpressionImpl <em>Composed Constraining Expression</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.ComposedConstrainingExpressionImpl
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getComposedConstrainingExpression()
	 * @generated
	 */
	int COMPOSED_CONSTRAINING_EXPRESSION = 8;

	/**
	 * The feature id for the '<em><b>Children</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSED_CONSTRAINING_EXPRESSION__CHILDREN = ABSTRACT_CONSTRAINING_EXPRESSION_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Composed Constraining Expression</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COMPOSED_CONSTRAINING_EXPRESSION_FEATURE_COUNT = ABSTRACT_CONSTRAINING_EXPRESSION_FEATURE_COUNT + 1;

	/**
	 * The meta object id for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.ConstrainingExpressionImpl <em>Constraining Expression</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.ConstrainingExpressionImpl
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getConstrainingExpression()
	 * @generated
	 */
	int CONSTRAINING_EXPRESSION = 9;

	/**
	 * The feature id for the '<em><b>Cardinality</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSTRAINING_EXPRESSION__CARDINALITY = ABSTRACT_CONSTRAINING_EXPRESSION_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSTRAINING_EXPRESSION__FROM = ABSTRACT_CONSTRAINING_EXPRESSION_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSTRAINING_EXPRESSION__TO = ABSTRACT_CONSTRAINING_EXPRESSION_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Constraining Expression</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONSTRAINING_EXPRESSION_FEATURE_COUNT = ABSTRACT_CONSTRAINING_EXPRESSION_FEATURE_COUNT + 3;

	/**
	 * The meta object id for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.CardinalityImpl <em>Cardinality</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.CardinalityImpl
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getCardinality()
	 * @generated
	 */
	int CARDINALITY = 10;

	/**
	 * The feature id for the '<em><b>Min</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARDINALITY__MIN = 0;

	/**
	 * The feature id for the '<em><b>Max</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARDINALITY__MAX = 1;

	/**
	 * The number of structural features of the '<em>Cardinality</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CARDINALITY_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.AndConstrainingExpressionImpl <em>And Constraining Expression</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.AndConstrainingExpressionImpl
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getAndConstrainingExpression()
	 * @generated
	 */
	int AND_CONSTRAINING_EXPRESSION = 11;

	/**
	 * The feature id for the '<em><b>Children</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AND_CONSTRAINING_EXPRESSION__CHILDREN = COMPOSED_CONSTRAINING_EXPRESSION__CHILDREN;

	/**
	 * The number of structural features of the '<em>And Constraining Expression</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AND_CONSTRAINING_EXPRESSION_FEATURE_COUNT = COMPOSED_CONSTRAINING_EXPRESSION_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.OrConstrainingExpressionImpl <em>Or Constraining Expression</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.OrConstrainingExpressionImpl
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getOrConstrainingExpression()
	 * @generated
	 */
	int OR_CONSTRAINING_EXPRESSION = 12;

	/**
	 * The feature id for the '<em><b>Children</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OR_CONSTRAINING_EXPRESSION__CHILDREN = COMPOSED_CONSTRAINING_EXPRESSION__CHILDREN;

	/**
	 * The number of structural features of the '<em>Or Constraining Expression</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OR_CONSTRAINING_EXPRESSION_FEATURE_COUNT = COMPOSED_CONSTRAINING_EXPRESSION_FEATURE_COUNT + 0;

	/**
	 * The meta object id for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.ConfigurationImpl <em>Configuration</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.ConfigurationImpl
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getConfiguration()
	 * @generated
	 */
	int CONFIGURATION = 13;

	/**
	 * The feature id for the '<em><b>Import URI</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION__IMPORT_URI = ELEMENT_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Feature Model</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION__FEATURE_MODEL = ELEMENT_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Instances</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION__INSTANCES = ELEMENT_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Configuration</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONFIGURATION_FEATURE_COUNT = ELEMENT_FEATURE_COUNT + 3;

	/**
	 * The meta object id for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.InstanceImpl <em>Instance</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.InstanceImpl
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getInstance()
	 * @generated
	 */
	int INSTANCE = 14;

	/**
	 * The feature id for the '<em><b>Type</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE__TYPE = 0;

	/**
	 * The feature id for the '<em><b>Children</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE__CHILDREN = 1;

	/**
	 * The feature id for the '<em><b>Number</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE__NUMBER = 2;

	/**
	 * The feature id for the '<em><b>Parent</b></em>' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE__PARENT = 3;

	/**
	 * The number of structural features of the '<em>Instance</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INSTANCE_FEATURE_COUNT = 4;

	/**
	 * The meta object id for the '<em>My Cardinality</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see fr.inria.lille.spirals.fm.datatypes.Cardinality
	 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getMyCardinality()
	 * @generated
	 */
	int MY_CARDINALITY = 15;


	/**
	 * Returns the meta object for class '{@link fr.inria.lille.spirals.fm.featuremodel.Element <em>Element</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Element</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.Element
	 * @generated
	 */
	EClass getElement();

	/**
	 * Returns the meta object for class '{@link fr.inria.lille.spirals.fm.featuremodel.FeatureModel <em>Feature Model</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Feature Model</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModel
	 * @generated
	 */
	EClass getFeatureModel();

	/**
	 * Returns the meta object for the containment reference '{@link fr.inria.lille.spirals.fm.featuremodel.FeatureModel#getRoot <em>Root</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Root</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModel#getRoot()
	 * @see #getFeatureModel()
	 * @generated
	 */
	EReference getFeatureModel_Root();

	/**
	 * Returns the meta object for the containment reference list '{@link fr.inria.lille.spirals.fm.featuremodel.FeatureModel#getConstraints <em>Constraints</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Constraints</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModel#getConstraints()
	 * @see #getFeatureModel()
	 * @generated
	 */
	EReference getFeatureModel_Constraints();

	/**
	 * Returns the meta object for the attribute '{@link fr.inria.lille.spirals.fm.featuremodel.FeatureModel#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModel#getName()
	 * @see #getFeatureModel()
	 * @generated
	 */
	EAttribute getFeatureModel_Name();

	/**
	 * Returns the meta object for class '{@link fr.inria.lille.spirals.fm.featuremodel.AbstractFeature <em>Abstract Feature</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Abstract Feature</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.AbstractFeature
	 * @generated
	 */
	EClass getAbstractFeature();

	/**
	 * Returns the meta object for the attribute '{@link fr.inria.lille.spirals.fm.featuremodel.AbstractFeature#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.AbstractFeature#getName()
	 * @see #getAbstractFeature()
	 * @generated
	 */
	EAttribute getAbstractFeature_Name();

	/**
	 * Returns the meta object for the container reference '{@link fr.inria.lille.spirals.fm.featuremodel.AbstractFeature#getParent <em>Parent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the container reference '<em>Parent</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.AbstractFeature#getParent()
	 * @see #getAbstractFeature()
	 * @generated
	 */
	EReference getAbstractFeature_Parent();

	/**
	 * Returns the meta object for the container reference '{@link fr.inria.lille.spirals.fm.featuremodel.AbstractFeature#getGroup <em>Group</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the container reference '<em>Group</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.AbstractFeature#getGroup()
	 * @see #getAbstractFeature()
	 * @generated
	 */
	EReference getAbstractFeature_Group();

	/**
	 * Returns the meta object for the containment reference list '{@link fr.inria.lille.spirals.fm.featuremodel.AbstractFeature#getCardinalities <em>Cardinalities</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Cardinalities</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.AbstractFeature#getCardinalities()
	 * @see #getAbstractFeature()
	 * @generated
	 */
	EReference getAbstractFeature_Cardinalities();

	/**
	 * Returns the meta object for class '{@link fr.inria.lille.spirals.fm.featuremodel.RelativeCardinality <em>Relative Cardinality</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Relative Cardinality</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.RelativeCardinality
	 * @generated
	 */
	EClass getRelativeCardinality();

	/**
	 * Returns the meta object for the reference '{@link fr.inria.lille.spirals.fm.featuremodel.RelativeCardinality#getTo <em>To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>To</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.RelativeCardinality#getTo()
	 * @see #getRelativeCardinality()
	 * @generated
	 */
	EReference getRelativeCardinality_To();

	/**
	 * Returns the meta object for the containment reference '{@link fr.inria.lille.spirals.fm.featuremodel.RelativeCardinality#getCardinality <em>Cardinality</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Cardinality</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.RelativeCardinality#getCardinality()
	 * @see #getRelativeCardinality()
	 * @generated
	 */
	EReference getRelativeCardinality_Cardinality();

	/**
	 * Returns the meta object for the container reference '{@link fr.inria.lille.spirals.fm.featuremodel.RelativeCardinality#getFrom <em>From</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the container reference '<em>From</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.RelativeCardinality#getFrom()
	 * @see #getRelativeCardinality()
	 * @generated
	 */
	EReference getRelativeCardinality_From();

	/**
	 * Returns the meta object for class '{@link fr.inria.lille.spirals.fm.featuremodel.FeatureGroup <em>Feature Group</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Feature Group</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureGroup
	 * @generated
	 */
	EClass getFeatureGroup();

	/**
	 * Returns the meta object for the containment reference list '{@link fr.inria.lille.spirals.fm.featuremodel.FeatureGroup#getVariants <em>Variants</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Variants</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureGroup#getVariants()
	 * @see #getFeatureGroup()
	 * @generated
	 */
	EReference getFeatureGroup_Variants();

	/**
	 * Returns the meta object for the containment reference '{@link fr.inria.lille.spirals.fm.featuremodel.FeatureGroup#getGroupCardinality <em>Group Cardinality</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Group Cardinality</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureGroup#getGroupCardinality()
	 * @see #getFeatureGroup()
	 * @generated
	 */
	EReference getFeatureGroup_GroupCardinality();

	/**
	 * Returns the meta object for class '{@link fr.inria.lille.spirals.fm.featuremodel.Feature <em>Feature</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Feature</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.Feature
	 * @generated
	 */
	EClass getFeature();

	/**
	 * Returns the meta object for the containment reference list '{@link fr.inria.lille.spirals.fm.featuremodel.Feature#getSubFeatures <em>Sub Features</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Sub Features</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.Feature#getSubFeatures()
	 * @see #getFeature()
	 * @generated
	 */
	EReference getFeature_SubFeatures();

	/**
	 * Returns the meta object for class '{@link fr.inria.lille.spirals.fm.featuremodel.Constraint <em>Constraint</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Constraint</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.Constraint
	 * @generated
	 */
	EClass getConstraint();

	/**
	 * Returns the meta object for the reference '{@link fr.inria.lille.spirals.fm.featuremodel.Constraint#getContext <em>Context</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Context</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.Constraint#getContext()
	 * @see #getConstraint()
	 * @generated
	 */
	EReference getConstraint_Context();

	/**
	 * Returns the meta object for the containment reference '{@link fr.inria.lille.spirals.fm.featuremodel.Constraint#getCondition <em>Condition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Condition</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.Constraint#getCondition()
	 * @see #getConstraint()
	 * @generated
	 */
	EReference getConstraint_Condition();

	/**
	 * Returns the meta object for the containment reference '{@link fr.inria.lille.spirals.fm.featuremodel.Constraint#getConsequence <em>Consequence</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Consequence</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.Constraint#getConsequence()
	 * @see #getConstraint()
	 * @generated
	 */
	EReference getConstraint_Consequence();

	/**
	 * Returns the meta object for class '{@link fr.inria.lille.spirals.fm.featuremodel.AbstractConstrainingExpression <em>Abstract Constraining Expression</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Abstract Constraining Expression</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.AbstractConstrainingExpression
	 * @generated
	 */
	EClass getAbstractConstrainingExpression();

	/**
	 * Returns the meta object for class '{@link fr.inria.lille.spirals.fm.featuremodel.ComposedConstrainingExpression <em>Composed Constraining Expression</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Composed Constraining Expression</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.ComposedConstrainingExpression
	 * @generated
	 */
	EClass getComposedConstrainingExpression();

	/**
	 * Returns the meta object for the containment reference list '{@link fr.inria.lille.spirals.fm.featuremodel.ComposedConstrainingExpression#getChildren <em>Children</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Children</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.ComposedConstrainingExpression#getChildren()
	 * @see #getComposedConstrainingExpression()
	 * @generated
	 */
	EReference getComposedConstrainingExpression_Children();

	/**
	 * Returns the meta object for class '{@link fr.inria.lille.spirals.fm.featuremodel.ConstrainingExpression <em>Constraining Expression</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Constraining Expression</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.ConstrainingExpression
	 * @generated
	 */
	EClass getConstrainingExpression();

	/**
	 * Returns the meta object for the containment reference '{@link fr.inria.lille.spirals.fm.featuremodel.ConstrainingExpression#getCardinality <em>Cardinality</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Cardinality</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.ConstrainingExpression#getCardinality()
	 * @see #getConstrainingExpression()
	 * @generated
	 */
	EReference getConstrainingExpression_Cardinality();

	/**
	 * Returns the meta object for the reference '{@link fr.inria.lille.spirals.fm.featuremodel.ConstrainingExpression#getFrom <em>From</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>From</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.ConstrainingExpression#getFrom()
	 * @see #getConstrainingExpression()
	 * @generated
	 */
	EReference getConstrainingExpression_From();

	/**
	 * Returns the meta object for the reference '{@link fr.inria.lille.spirals.fm.featuremodel.ConstrainingExpression#getTo <em>To</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>To</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.ConstrainingExpression#getTo()
	 * @see #getConstrainingExpression()
	 * @generated
	 */
	EReference getConstrainingExpression_To();

	/**
	 * Returns the meta object for class '{@link fr.inria.lille.spirals.fm.featuremodel.Cardinality <em>Cardinality</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Cardinality</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.Cardinality
	 * @generated
	 */
	EClass getCardinality();

	/**
	 * Returns the meta object for the attribute '{@link fr.inria.lille.spirals.fm.featuremodel.Cardinality#getMin <em>Min</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Min</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.Cardinality#getMin()
	 * @see #getCardinality()
	 * @generated
	 */
	EAttribute getCardinality_Min();

	/**
	 * Returns the meta object for the attribute '{@link fr.inria.lille.spirals.fm.featuremodel.Cardinality#getMax <em>Max</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Max</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.Cardinality#getMax()
	 * @see #getCardinality()
	 * @generated
	 */
	EAttribute getCardinality_Max();

	/**
	 * Returns the meta object for class '{@link fr.inria.lille.spirals.fm.featuremodel.AndConstrainingExpression <em>And Constraining Expression</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>And Constraining Expression</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.AndConstrainingExpression
	 * @generated
	 */
	EClass getAndConstrainingExpression();

	/**
	 * Returns the meta object for class '{@link fr.inria.lille.spirals.fm.featuremodel.OrConstrainingExpression <em>Or Constraining Expression</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Or Constraining Expression</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.OrConstrainingExpression
	 * @generated
	 */
	EClass getOrConstrainingExpression();

	/**
	 * Returns the meta object for class '{@link fr.inria.lille.spirals.fm.featuremodel.Configuration <em>Configuration</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Configuration</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.Configuration
	 * @generated
	 */
	EClass getConfiguration();

	/**
	 * Returns the meta object for the attribute '{@link fr.inria.lille.spirals.fm.featuremodel.Configuration#getImportURI <em>Import URI</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Import URI</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.Configuration#getImportURI()
	 * @see #getConfiguration()
	 * @generated
	 */
	EAttribute getConfiguration_ImportURI();

	/**
	 * Returns the meta object for the reference '{@link fr.inria.lille.spirals.fm.featuremodel.Configuration#getFeatureModel <em>Feature Model</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Feature Model</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.Configuration#getFeatureModel()
	 * @see #getConfiguration()
	 * @generated
	 */
	EReference getConfiguration_FeatureModel();

	/**
	 * Returns the meta object for the containment reference list '{@link fr.inria.lille.spirals.fm.featuremodel.Configuration#getInstances <em>Instances</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Instances</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.Configuration#getInstances()
	 * @see #getConfiguration()
	 * @generated
	 */
	EReference getConfiguration_Instances();

	/**
	 * Returns the meta object for class '{@link fr.inria.lille.spirals.fm.featuremodel.Instance <em>Instance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Instance</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.Instance
	 * @generated
	 */
	EClass getInstance();

	/**
	 * Returns the meta object for the reference '{@link fr.inria.lille.spirals.fm.featuremodel.Instance#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Type</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.Instance#getType()
	 * @see #getInstance()
	 * @generated
	 */
	EReference getInstance_Type();

	/**
	 * Returns the meta object for the containment reference list '{@link fr.inria.lille.spirals.fm.featuremodel.Instance#getChildren <em>Children</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Children</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.Instance#getChildren()
	 * @see #getInstance()
	 * @generated
	 */
	EReference getInstance_Children();

	/**
	 * Returns the meta object for the attribute '{@link fr.inria.lille.spirals.fm.featuremodel.Instance#getNumber <em>Number</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Number</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.Instance#getNumber()
	 * @see #getInstance()
	 * @generated
	 */
	EAttribute getInstance_Number();

	/**
	 * Returns the meta object for the container reference '{@link fr.inria.lille.spirals.fm.featuremodel.Instance#getParent <em>Parent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the container reference '<em>Parent</em>'.
	 * @see fr.inria.lille.spirals.fm.featuremodel.Instance#getParent()
	 * @see #getInstance()
	 * @generated
	 */
	EReference getInstance_Parent();

	/**
	 * Returns the meta object for data type '{@link fr.inria.lille.spirals.fm.datatypes.Cardinality <em>My Cardinality</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>My Cardinality</em>'.
	 * @see fr.inria.lille.spirals.fm.datatypes.Cardinality
	 * @model instanceClass="fr.inria.lille.spirals.fm.datatypes.Cardinality"
	 * @generated
	 */
	EDataType getMyCardinality();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	FeatureModelFactory getFeatureModelFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals
	{
		/**
		 * The meta object literal for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.ElementImpl <em>Element</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.ElementImpl
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getElement()
		 * @generated
		 */
		EClass ELEMENT = eINSTANCE.getElement();

		/**
		 * The meta object literal for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelImpl <em>Feature Model</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelImpl
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getFeatureModel()
		 * @generated
		 */
		EClass FEATURE_MODEL = eINSTANCE.getFeatureModel();

		/**
		 * The meta object literal for the '<em><b>Root</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FEATURE_MODEL__ROOT = eINSTANCE.getFeatureModel_Root();

		/**
		 * The meta object literal for the '<em><b>Constraints</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FEATURE_MODEL__CONSTRAINTS = eINSTANCE.getFeatureModel_Constraints();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FEATURE_MODEL__NAME = eINSTANCE.getFeatureModel_Name();

		/**
		 * The meta object literal for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.AbstractFeatureImpl <em>Abstract Feature</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.AbstractFeatureImpl
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getAbstractFeature()
		 * @generated
		 */
		EClass ABSTRACT_FEATURE = eINSTANCE.getAbstractFeature();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ABSTRACT_FEATURE__NAME = eINSTANCE.getAbstractFeature_Name();

		/**
		 * The meta object literal for the '<em><b>Parent</b></em>' container reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ABSTRACT_FEATURE__PARENT = eINSTANCE.getAbstractFeature_Parent();

		/**
		 * The meta object literal for the '<em><b>Group</b></em>' container reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ABSTRACT_FEATURE__GROUP = eINSTANCE.getAbstractFeature_Group();

		/**
		 * The meta object literal for the '<em><b>Cardinalities</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ABSTRACT_FEATURE__CARDINALITIES = eINSTANCE.getAbstractFeature_Cardinalities();

		/**
		 * The meta object literal for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.RelativeCardinalityImpl <em>Relative Cardinality</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.RelativeCardinalityImpl
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getRelativeCardinality()
		 * @generated
		 */
		EClass RELATIVE_CARDINALITY = eINSTANCE.getRelativeCardinality();

		/**
		 * The meta object literal for the '<em><b>To</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RELATIVE_CARDINALITY__TO = eINSTANCE.getRelativeCardinality_To();

		/**
		 * The meta object literal for the '<em><b>Cardinality</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RELATIVE_CARDINALITY__CARDINALITY = eINSTANCE.getRelativeCardinality_Cardinality();

		/**
		 * The meta object literal for the '<em><b>From</b></em>' container reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RELATIVE_CARDINALITY__FROM = eINSTANCE.getRelativeCardinality_From();

		/**
		 * The meta object literal for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.FeatureGroupImpl <em>Feature Group</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureGroupImpl
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getFeatureGroup()
		 * @generated
		 */
		EClass FEATURE_GROUP = eINSTANCE.getFeatureGroup();

		/**
		 * The meta object literal for the '<em><b>Variants</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FEATURE_GROUP__VARIANTS = eINSTANCE.getFeatureGroup_Variants();

		/**
		 * The meta object literal for the '<em><b>Group Cardinality</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FEATURE_GROUP__GROUP_CARDINALITY = eINSTANCE.getFeatureGroup_GroupCardinality();

		/**
		 * The meta object literal for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.FeatureImpl <em>Feature</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureImpl
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getFeature()
		 * @generated
		 */
		EClass FEATURE = eINSTANCE.getFeature();

		/**
		 * The meta object literal for the '<em><b>Sub Features</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FEATURE__SUB_FEATURES = eINSTANCE.getFeature_SubFeatures();

		/**
		 * The meta object literal for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.ConstraintImpl <em>Constraint</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.ConstraintImpl
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getConstraint()
		 * @generated
		 */
		EClass CONSTRAINT = eINSTANCE.getConstraint();

		/**
		 * The meta object literal for the '<em><b>Context</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONSTRAINT__CONTEXT = eINSTANCE.getConstraint_Context();

		/**
		 * The meta object literal for the '<em><b>Condition</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONSTRAINT__CONDITION = eINSTANCE.getConstraint_Condition();

		/**
		 * The meta object literal for the '<em><b>Consequence</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONSTRAINT__CONSEQUENCE = eINSTANCE.getConstraint_Consequence();

		/**
		 * The meta object literal for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.AbstractConstrainingExpressionImpl <em>Abstract Constraining Expression</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.AbstractConstrainingExpressionImpl
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getAbstractConstrainingExpression()
		 * @generated
		 */
		EClass ABSTRACT_CONSTRAINING_EXPRESSION = eINSTANCE.getAbstractConstrainingExpression();

		/**
		 * The meta object literal for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.ComposedConstrainingExpressionImpl <em>Composed Constraining Expression</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.ComposedConstrainingExpressionImpl
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getComposedConstrainingExpression()
		 * @generated
		 */
		EClass COMPOSED_CONSTRAINING_EXPRESSION = eINSTANCE.getComposedConstrainingExpression();

		/**
		 * The meta object literal for the '<em><b>Children</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference COMPOSED_CONSTRAINING_EXPRESSION__CHILDREN = eINSTANCE.getComposedConstrainingExpression_Children();

		/**
		 * The meta object literal for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.ConstrainingExpressionImpl <em>Constraining Expression</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.ConstrainingExpressionImpl
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getConstrainingExpression()
		 * @generated
		 */
		EClass CONSTRAINING_EXPRESSION = eINSTANCE.getConstrainingExpression();

		/**
		 * The meta object literal for the '<em><b>Cardinality</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONSTRAINING_EXPRESSION__CARDINALITY = eINSTANCE.getConstrainingExpression_Cardinality();

		/**
		 * The meta object literal for the '<em><b>From</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONSTRAINING_EXPRESSION__FROM = eINSTANCE.getConstrainingExpression_From();

		/**
		 * The meta object literal for the '<em><b>To</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONSTRAINING_EXPRESSION__TO = eINSTANCE.getConstrainingExpression_To();

		/**
		 * The meta object literal for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.CardinalityImpl <em>Cardinality</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.CardinalityImpl
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getCardinality()
		 * @generated
		 */
		EClass CARDINALITY = eINSTANCE.getCardinality();

		/**
		 * The meta object literal for the '<em><b>Min</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CARDINALITY__MIN = eINSTANCE.getCardinality_Min();

		/**
		 * The meta object literal for the '<em><b>Max</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CARDINALITY__MAX = eINSTANCE.getCardinality_Max();

		/**
		 * The meta object literal for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.AndConstrainingExpressionImpl <em>And Constraining Expression</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.AndConstrainingExpressionImpl
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getAndConstrainingExpression()
		 * @generated
		 */
		EClass AND_CONSTRAINING_EXPRESSION = eINSTANCE.getAndConstrainingExpression();

		/**
		 * The meta object literal for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.OrConstrainingExpressionImpl <em>Or Constraining Expression</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.OrConstrainingExpressionImpl
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getOrConstrainingExpression()
		 * @generated
		 */
		EClass OR_CONSTRAINING_EXPRESSION = eINSTANCE.getOrConstrainingExpression();

		/**
		 * The meta object literal for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.ConfigurationImpl <em>Configuration</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.ConfigurationImpl
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getConfiguration()
		 * @generated
		 */
		EClass CONFIGURATION = eINSTANCE.getConfiguration();

		/**
		 * The meta object literal for the '<em><b>Import URI</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONFIGURATION__IMPORT_URI = eINSTANCE.getConfiguration_ImportURI();

		/**
		 * The meta object literal for the '<em><b>Feature Model</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONFIGURATION__FEATURE_MODEL = eINSTANCE.getConfiguration_FeatureModel();

		/**
		 * The meta object literal for the '<em><b>Instances</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CONFIGURATION__INSTANCES = eINSTANCE.getConfiguration_Instances();

		/**
		 * The meta object literal for the '{@link fr.inria.lille.spirals.fm.featuremodel.impl.InstanceImpl <em>Instance</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.InstanceImpl
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getInstance()
		 * @generated
		 */
		EClass INSTANCE = eINSTANCE.getInstance();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INSTANCE__TYPE = eINSTANCE.getInstance_Type();

		/**
		 * The meta object literal for the '<em><b>Children</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INSTANCE__CHILDREN = eINSTANCE.getInstance_Children();

		/**
		 * The meta object literal for the '<em><b>Number</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INSTANCE__NUMBER = eINSTANCE.getInstance_Number();

		/**
		 * The meta object literal for the '<em><b>Parent</b></em>' container reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INSTANCE__PARENT = eINSTANCE.getInstance_Parent();

		/**
		 * The meta object literal for the '<em>My Cardinality</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see fr.inria.lille.spirals.fm.datatypes.Cardinality
		 * @see fr.inria.lille.spirals.fm.featuremodel.impl.FeatureModelPackageImpl#getMyCardinality()
		 * @generated
		 */
		EDataType MY_CARDINALITY = eINSTANCE.getMyCardinality();

	}

} //FeatureModelPackage
