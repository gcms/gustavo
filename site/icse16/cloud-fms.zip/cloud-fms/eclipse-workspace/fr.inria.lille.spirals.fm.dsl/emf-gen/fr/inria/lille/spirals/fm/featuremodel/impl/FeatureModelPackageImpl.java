/**
 */
package fr.inria.lille.spirals.fm.featuremodel.impl;

import fr.inria.lille.spirals.fm.featuremodel.AbstractConstrainingExpression;
import fr.inria.lille.spirals.fm.featuremodel.AbstractFeature;
import fr.inria.lille.spirals.fm.featuremodel.AndConstrainingExpression;
import fr.inria.lille.spirals.fm.featuremodel.Cardinality;
import fr.inria.lille.spirals.fm.featuremodel.ComposedConstrainingExpression;
import fr.inria.lille.spirals.fm.featuremodel.Configuration;
import fr.inria.lille.spirals.fm.featuremodel.ConstrainingExpression;
import fr.inria.lille.spirals.fm.featuremodel.Constraint;
import fr.inria.lille.spirals.fm.featuremodel.Element;
import fr.inria.lille.spirals.fm.featuremodel.Feature;
import fr.inria.lille.spirals.fm.featuremodel.FeatureGroup;
import fr.inria.lille.spirals.fm.featuremodel.FeatureModel;
import fr.inria.lille.spirals.fm.featuremodel.FeatureModelFactory;
import fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage;
import fr.inria.lille.spirals.fm.featuremodel.Instance;
import fr.inria.lille.spirals.fm.featuremodel.OrConstrainingExpression;
import fr.inria.lille.spirals.fm.featuremodel.RelativeCardinality;

import fr.inria.lille.spirals.fm.featuremodel.util.FeatureModelValidator;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EValidator;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class FeatureModelPackageImpl extends EPackageImpl implements FeatureModelPackage
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass elementEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass featureModelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass abstractFeatureEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass relativeCardinalityEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass featureGroupEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass featureEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass constraintEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass abstractConstrainingExpressionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass composedConstrainingExpressionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass constrainingExpressionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cardinalityEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass andConstrainingExpressionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass orConstrainingExpressionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass configurationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass instanceEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType myCardinalityEDataType = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private FeatureModelPackageImpl()
	{
		super(eNS_URI, FeatureModelFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link FeatureModelPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static FeatureModelPackage init()
	{
		if (isInited) return (FeatureModelPackage)EPackage.Registry.INSTANCE.getEPackage(FeatureModelPackage.eNS_URI);

		// Obtain or create and register package
		FeatureModelPackageImpl theFeatureModelPackage = (FeatureModelPackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof FeatureModelPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new FeatureModelPackageImpl());

		isInited = true;

		// Create package meta-data objects
		theFeatureModelPackage.createPackageContents();

		// Initialize created meta-data
		theFeatureModelPackage.initializePackageContents();

		// Register package validator
		EValidator.Registry.INSTANCE.put
			(theFeatureModelPackage, 
			 new EValidator.Descriptor()
			 {
				 public EValidator getEValidator()
				 {
					 return FeatureModelValidator.INSTANCE;
				 }
			 });

		// Mark meta-data to indicate it can't be changed
		theFeatureModelPackage.freeze();

  
		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(FeatureModelPackage.eNS_URI, theFeatureModelPackage);
		return theFeatureModelPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getElement()
	{
		return elementEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFeatureModel()
	{
		return featureModelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFeatureModel_Root()
	{
		return (EReference)featureModelEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFeatureModel_Constraints()
	{
		return (EReference)featureModelEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getFeatureModel_Name()
	{
		return (EAttribute)featureModelEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAbstractFeature()
	{
		return abstractFeatureEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAbstractFeature_Name()
	{
		return (EAttribute)abstractFeatureEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAbstractFeature_Parent()
	{
		return (EReference)abstractFeatureEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAbstractFeature_Group()
	{
		return (EReference)abstractFeatureEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAbstractFeature_Cardinalities()
	{
		return (EReference)abstractFeatureEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRelativeCardinality()
	{
		return relativeCardinalityEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRelativeCardinality_To()
	{
		return (EReference)relativeCardinalityEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRelativeCardinality_Cardinality()
	{
		return (EReference)relativeCardinalityEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRelativeCardinality_From()
	{
		return (EReference)relativeCardinalityEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFeatureGroup()
	{
		return featureGroupEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFeatureGroup_Variants()
	{
		return (EReference)featureGroupEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFeatureGroup_GroupCardinality()
	{
		return (EReference)featureGroupEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getFeature()
	{
		return featureEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getFeature_SubFeatures()
	{
		return (EReference)featureEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getConstraint()
	{
		return constraintEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getConstraint_Context()
	{
		return (EReference)constraintEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getConstraint_Condition()
	{
		return (EReference)constraintEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getConstraint_Consequence()
	{
		return (EReference)constraintEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAbstractConstrainingExpression()
	{
		return abstractConstrainingExpressionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getComposedConstrainingExpression()
	{
		return composedConstrainingExpressionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getComposedConstrainingExpression_Children()
	{
		return (EReference)composedConstrainingExpressionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getConstrainingExpression()
	{
		return constrainingExpressionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getConstrainingExpression_Cardinality()
	{
		return (EReference)constrainingExpressionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getConstrainingExpression_From()
	{
		return (EReference)constrainingExpressionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getConstrainingExpression_To()
	{
		return (EReference)constrainingExpressionEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getCardinality()
	{
		return cardinalityEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCardinality_Min()
	{
		return (EAttribute)cardinalityEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getCardinality_Max()
	{
		return (EAttribute)cardinalityEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAndConstrainingExpression()
	{
		return andConstrainingExpressionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getOrConstrainingExpression()
	{
		return orConstrainingExpressionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getConfiguration()
	{
		return configurationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getConfiguration_ImportURI()
	{
		return (EAttribute)configurationEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getConfiguration_FeatureModel()
	{
		return (EReference)configurationEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getConfiguration_Instances()
	{
		return (EReference)configurationEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getInstance()
	{
		return instanceEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getInstance_Type()
	{
		return (EReference)instanceEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getInstance_Children()
	{
		return (EReference)instanceEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getInstance_Number()
	{
		return (EAttribute)instanceEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getInstance_Parent()
	{
		return (EReference)instanceEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EDataType getMyCardinality()
	{
		return myCardinalityEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FeatureModelFactory getFeatureModelFactory()
	{
		return (FeatureModelFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents()
	{
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		elementEClass = createEClass(ELEMENT);

		featureModelEClass = createEClass(FEATURE_MODEL);
		createEReference(featureModelEClass, FEATURE_MODEL__ROOT);
		createEReference(featureModelEClass, FEATURE_MODEL__CONSTRAINTS);
		createEAttribute(featureModelEClass, FEATURE_MODEL__NAME);

		abstractFeatureEClass = createEClass(ABSTRACT_FEATURE);
		createEAttribute(abstractFeatureEClass, ABSTRACT_FEATURE__NAME);
		createEReference(abstractFeatureEClass, ABSTRACT_FEATURE__PARENT);
		createEReference(abstractFeatureEClass, ABSTRACT_FEATURE__GROUP);
		createEReference(abstractFeatureEClass, ABSTRACT_FEATURE__CARDINALITIES);

		relativeCardinalityEClass = createEClass(RELATIVE_CARDINALITY);
		createEReference(relativeCardinalityEClass, RELATIVE_CARDINALITY__TO);
		createEReference(relativeCardinalityEClass, RELATIVE_CARDINALITY__CARDINALITY);
		createEReference(relativeCardinalityEClass, RELATIVE_CARDINALITY__FROM);

		featureGroupEClass = createEClass(FEATURE_GROUP);
		createEReference(featureGroupEClass, FEATURE_GROUP__VARIANTS);
		createEReference(featureGroupEClass, FEATURE_GROUP__GROUP_CARDINALITY);

		featureEClass = createEClass(FEATURE);
		createEReference(featureEClass, FEATURE__SUB_FEATURES);

		constraintEClass = createEClass(CONSTRAINT);
		createEReference(constraintEClass, CONSTRAINT__CONTEXT);
		createEReference(constraintEClass, CONSTRAINT__CONDITION);
		createEReference(constraintEClass, CONSTRAINT__CONSEQUENCE);

		abstractConstrainingExpressionEClass = createEClass(ABSTRACT_CONSTRAINING_EXPRESSION);

		composedConstrainingExpressionEClass = createEClass(COMPOSED_CONSTRAINING_EXPRESSION);
		createEReference(composedConstrainingExpressionEClass, COMPOSED_CONSTRAINING_EXPRESSION__CHILDREN);

		constrainingExpressionEClass = createEClass(CONSTRAINING_EXPRESSION);
		createEReference(constrainingExpressionEClass, CONSTRAINING_EXPRESSION__CARDINALITY);
		createEReference(constrainingExpressionEClass, CONSTRAINING_EXPRESSION__FROM);
		createEReference(constrainingExpressionEClass, CONSTRAINING_EXPRESSION__TO);

		cardinalityEClass = createEClass(CARDINALITY);
		createEAttribute(cardinalityEClass, CARDINALITY__MIN);
		createEAttribute(cardinalityEClass, CARDINALITY__MAX);

		andConstrainingExpressionEClass = createEClass(AND_CONSTRAINING_EXPRESSION);

		orConstrainingExpressionEClass = createEClass(OR_CONSTRAINING_EXPRESSION);

		configurationEClass = createEClass(CONFIGURATION);
		createEAttribute(configurationEClass, CONFIGURATION__IMPORT_URI);
		createEReference(configurationEClass, CONFIGURATION__FEATURE_MODEL);
		createEReference(configurationEClass, CONFIGURATION__INSTANCES);

		instanceEClass = createEClass(INSTANCE);
		createEReference(instanceEClass, INSTANCE__TYPE);
		createEReference(instanceEClass, INSTANCE__CHILDREN);
		createEAttribute(instanceEClass, INSTANCE__NUMBER);
		createEReference(instanceEClass, INSTANCE__PARENT);

		// Create data types
		myCardinalityEDataType = createEDataType(MY_CARDINALITY);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents()
	{
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		featureModelEClass.getESuperTypes().add(this.getElement());
		featureGroupEClass.getESuperTypes().add(this.getAbstractFeature());
		featureEClass.getESuperTypes().add(this.getAbstractFeature());
		composedConstrainingExpressionEClass.getESuperTypes().add(this.getAbstractConstrainingExpression());
		constrainingExpressionEClass.getESuperTypes().add(this.getAbstractConstrainingExpression());
		andConstrainingExpressionEClass.getESuperTypes().add(this.getComposedConstrainingExpression());
		orConstrainingExpressionEClass.getESuperTypes().add(this.getComposedConstrainingExpression());
		configurationEClass.getESuperTypes().add(this.getElement());

		// Initialize classes and features; add operations and parameters
		initEClass(elementEClass, Element.class, "Element", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(featureModelEClass, FeatureModel.class, "FeatureModel", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getFeatureModel_Root(), this.getFeature(), null, "root", null, 1, 1, FeatureModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFeatureModel_Constraints(), this.getConstraint(), null, "constraints", null, 0, -1, FeatureModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getFeatureModel_Name(), ecorePackage.getEString(), "name", null, 1, 1, FeatureModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, IS_DERIVED, IS_ORDERED);

		addEOperation(featureModelEClass, this.getAbstractFeature(), "getAllFeatures", 0, -1, IS_UNIQUE, !IS_ORDERED);

		initEClass(abstractFeatureEClass, AbstractFeature.class, "AbstractFeature", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getAbstractFeature_Name(), ecorePackage.getEString(), "name", null, 1, 1, AbstractFeature.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAbstractFeature_Parent(), this.getFeature(), this.getFeature_SubFeatures(), "parent", null, 0, 1, AbstractFeature.class, !IS_TRANSIENT, !IS_VOLATILE, !IS_CHANGEABLE, !IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
		initEReference(getAbstractFeature_Group(), this.getFeatureGroup(), this.getFeatureGroup_Variants(), "group", null, 0, 1, AbstractFeature.class, !IS_TRANSIENT, !IS_VOLATILE, !IS_CHANGEABLE, !IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
		initEReference(getAbstractFeature_Cardinalities(), this.getRelativeCardinality(), this.getRelativeCardinality_From(), "cardinalities", null, 0, -1, AbstractFeature.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		addEOperation(abstractFeatureEClass, this.getAbstractFeature(), "getAncestors", 0, -1, IS_UNIQUE, !IS_ORDERED);

		addEOperation(abstractFeatureEClass, this.getAbstractFeature(), "getSubTree", 0, -1, IS_UNIQUE, !IS_ORDERED);

		EOperation op = addEOperation(abstractFeatureEClass, ecorePackage.getEBoolean(), "isDescendantOf", 1, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, this.getAbstractFeature(), "feature", 1, 1, IS_UNIQUE, IS_ORDERED);

		addEOperation(abstractFeatureEClass, this.getAbstractFeature(), "doGetParent", 0, 1, IS_UNIQUE, IS_ORDERED);

		op = addEOperation(abstractFeatureEClass, this.getRelativeCardinality(), "doGetRelativeCardinalityTo", 1, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, this.getAbstractFeature(), "feature", 1, 1, IS_UNIQUE, IS_ORDERED);

		addEOperation(abstractFeatureEClass, this.getRelativeCardinality(), "doGetRelativeCardinalityToParent", 1, 1, IS_UNIQUE, IS_ORDERED);

		op = addEOperation(abstractFeatureEClass, ecorePackage.getEBoolean(), "areConsistent", 1, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, this.getRelativeCardinality(), "c1", 1, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, this.getRelativeCardinality(), "c2", 1, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(relativeCardinalityEClass, RelativeCardinality.class, "RelativeCardinality", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getRelativeCardinality_To(), this.getAbstractFeature(), null, "to", null, 0, 1, RelativeCardinality.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRelativeCardinality_Cardinality(), this.getCardinality(), null, "cardinality", null, 1, 1, RelativeCardinality.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRelativeCardinality_From(), this.getAbstractFeature(), this.getAbstractFeature_Cardinalities(), "from", null, 1, 1, RelativeCardinality.class, !IS_TRANSIENT, !IS_VOLATILE, !IS_CHANGEABLE, !IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);

		addEOperation(relativeCardinalityEClass, this.getAbstractFeature(), "doGetTo", 1, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(featureGroupEClass, FeatureGroup.class, "FeatureGroup", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getFeatureGroup_Variants(), this.getAbstractFeature(), this.getAbstractFeature_Group(), "variants", null, 2, -1, FeatureGroup.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getFeatureGroup_GroupCardinality(), this.getCardinality(), null, "groupCardinality", null, 1, 1, FeatureGroup.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		addEOperation(featureGroupEClass, this.getAbstractFeature(), "getSubTree", 0, -1, IS_UNIQUE, !IS_ORDERED);

		initEClass(featureEClass, Feature.class, "Feature", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getFeature_SubFeatures(), this.getAbstractFeature(), this.getAbstractFeature_Parent(), "subFeatures", null, 0, -1, Feature.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		addEOperation(featureEClass, this.getAbstractFeature(), "getSubTree", 0, -1, IS_UNIQUE, !IS_ORDERED);

		initEClass(constraintEClass, Constraint.class, "Constraint", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getConstraint_Context(), this.getAbstractFeature(), null, "context", null, 1, 1, Constraint.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getConstraint_Condition(), this.getAbstractConstrainingExpression(), null, "condition", null, 1, 1, Constraint.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getConstraint_Consequence(), this.getAbstractConstrainingExpression(), null, "consequence", null, 1, 1, Constraint.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(abstractConstrainingExpressionEClass, AbstractConstrainingExpression.class, "AbstractConstrainingExpression", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(composedConstrainingExpressionEClass, ComposedConstrainingExpression.class, "ComposedConstrainingExpression", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getComposedConstrainingExpression_Children(), this.getAbstractConstrainingExpression(), null, "children", null, 1, -1, ComposedConstrainingExpression.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(constrainingExpressionEClass, ConstrainingExpression.class, "ConstrainingExpression", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getConstrainingExpression_Cardinality(), this.getCardinality(), null, "cardinality", null, 1, 1, ConstrainingExpression.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getConstrainingExpression_From(), this.getAbstractFeature(), null, "from", null, 1, 1, ConstrainingExpression.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getConstrainingExpression_To(), this.getAbstractFeature(), null, "to", null, 1, 1, ConstrainingExpression.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(cardinalityEClass, Cardinality.class, "Cardinality", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getCardinality_Min(), ecorePackage.getEInt(), "min", null, 1, 1, Cardinality.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCardinality_Max(), ecorePackage.getEInt(), "max", null, 1, 1, Cardinality.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(andConstrainingExpressionEClass, AndConstrainingExpression.class, "AndConstrainingExpression", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(orConstrainingExpressionEClass, OrConstrainingExpression.class, "OrConstrainingExpression", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(configurationEClass, Configuration.class, "Configuration", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getConfiguration_ImportURI(), ecorePackage.getEString(), "importURI", null, 0, 1, Configuration.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getConfiguration_FeatureModel(), this.getFeatureModel(), null, "featureModel", null, 1, 1, Configuration.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getConfiguration_Instances(), this.getInstance(), null, "instances", null, 0, -1, Configuration.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(instanceEClass, Instance.class, "Instance", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getInstance_Type(), this.getAbstractFeature(), null, "type", null, 1, 1, Instance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getInstance_Children(), this.getInstance(), this.getInstance_Parent(), "children", null, 0, -1, Instance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getInstance_Number(), ecorePackage.getEInt(), "number", null, 1, 1, Instance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getInstance_Parent(), this.getInstance(), this.getInstance_Children(), "parent", null, 0, 1, Instance.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);

		// Initialize data types
		initEDataType(myCardinalityEDataType, fr.inria.lille.spirals.fm.datatypes.Cardinality.class, "MyCardinality", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);

		// Create resource
		createResource(eNS_URI);

		// Create annotations
		// http://www.eclipse.org/OCL/Import
		createImportAnnotations();
		// http://www.eclipse.org/emf/2002/Ecore
		createEcoreAnnotations();
		// http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot
		createPivotAnnotations();
		// http://schema.omg.org/spec/MOF/2.0/emof.xml#Property.oppositeRoleName
		createEmofAnnotations();
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/OCL/Import</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createImportAnnotations()
	{
		String source = "http://www.eclipse.org/OCL/Import";	
		addAnnotation
		  (this, 
		   source, 
		   new String[] 
		   {
			 "ecore", "http://www.eclipse.org/emf/2002/Ecore"
		   });
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createEcoreAnnotations()
	{
		String source = "http://www.eclipse.org/emf/2002/Ecore";	
		addAnnotation
		  (this, 
		   source, 
		   new String[] 
		   {
			 "invocationDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
			 "settingDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
			 "validationDelegates", "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot"
		   });	
		addAnnotation
		  (featureModelEClass, 
		   source, 
		   new String[] 
		   {
			 "constraints", "MustHaveRoot"
		   });	
		addAnnotation
		  (abstractFeatureEClass, 
		   source, 
		   new String[] 
		   {
			 "constraints", "NoRepeatedRelativeCardinalities GroupVariantCardinalityGreaterThan0 ConsistentRelativeCardinalities"
		   });	
		addAnnotation
		  (relativeCardinalityEClass, 
		   source, 
		   new String[] 
		   {
			 "constraints", "RelativeCardinalityToAncestor ValidCardinality"
		   });	
		addAnnotation
		  (featureGroupEClass, 
		   source, 
		   new String[] 
		   {
			 "constraints", "ValidGroupCardinality"
		   });	
		addAnnotation
		  (featureEClass, 
		   source, 
		   new String[] 
		   {
			 "constraints", "RootHasNoCardinalities"
		   });	
		addAnnotation
		  (constrainingExpressionEClass, 
		   source, 
		   new String[] 
		   {
			 "constraints", "FeaturesAreAncestorsDescendant"
		   });	
		addAnnotation
		  (cardinalityEClass, 
		   source, 
		   new String[] 
		   {
			 "constraints", "Consistency"
		   });	
		addAnnotation
		  (instanceEClass, 
		   source, 
		   new String[] 
		   {
			 "constraints", "HierarchyFollowed"
		   });
	}

	/**
	 * Initializes the annotations for <b>http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createPivotAnnotations()
	{
		String source = "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot";	
		addAnnotation
		  (featureModelEClass, 
		   source, 
		   new String[] 
		   {
			 "MustHaveRoot", "\n\t\t\troot <> null"
		   });	
		addAnnotation
		  (featureModelEClass.getEOperations().get(0), 
		   source, 
		   new String[] 
		   {
			 "body", "root.getSubTree()"
		   });	
		addAnnotation
		  (getFeatureModel_Name(), 
		   source, 
		   new String[] 
		   {
			 "derivation", "if root = null then null else root.name endif"
		   });	
		addAnnotation
		  (abstractFeatureEClass, 
		   source, 
		   new String[] 
		   {
			 "NoRepeatedRelativeCardinalities", "\n\t\t\tcardinalities->isUnique(doGetTo())",
			 "GroupVariantCardinalityGreaterThan0", "\n\t\t\tlet relativeToParent : RelativeCardinality = doGetRelativeCardinalityToParent() in\n\t\t\tgroup = null or relativeToParent = null or relativeToParent.cardinality.min > 0\n\t\t",
			 "ConsistentRelativeCardinalities", "\n\t\t\tcardinalities = null or\n\t\t\tcardinalities->forAll(c1 : RelativeCardinality |\n\t\t\t\tcardinalities->forAll(c2 : RelativeCardinality|\n\t\t\t\t\tc1 = c2 or areConsistent(c1, c2)\t\t\t\t\t\n\t\t\t\t)\n\t\t\t)\n\t\t"
		   });	
		addAnnotation
		  (abstractFeatureEClass.getEOperations().get(0), 
		   source, 
		   new String[] 
		   {
			 "body", "\n\t\t\tlet parent : AbstractFeature = doGetParent() in\n\t\t\tif parent = null then Sequence{} else parent.getAncestors()->asSequence()->append(parent) endif"
		   });	
		addAnnotation
		  (abstractFeatureEClass.getEOperations().get(2), 
		   source, 
		   new String[] 
		   {
			 "body", "\n\t\t\tif self.doGetParent() = null then \n\t\t\t\tfalse\n\t\t\telse\n\t\t\t\tself.doGetParent() = feature or self.doGetParent().isDescendantOf(feature)\n\t\t\tendif"
		   });	
		addAnnotation
		  (abstractFeatureEClass.getEOperations().get(3), 
		   source, 
		   new String[] 
		   {
			 "body", "if group <> null then group else parent endif"
		   });	
		addAnnotation
		  (abstractFeatureEClass.getEOperations().get(4), 
		   source, 
		   new String[] 
		   {
			 "body", "\n\t\t\tif cardinalities = null then null else\n\t\t\tlet selected = cardinalities->select(c | c.doGetTo() = feature) in\n\t\t\tif selected <> null and not selected->isEmpty() then selected->first() else null endif\n\t\t\tendif"
		   });	
		addAnnotation
		  (abstractFeatureEClass.getEOperations().get(5), 
		   source, 
		   new String[] 
		   {
			 "body", "\n\t\t\tlet parent = doGetParent() in\n\t\t\tif parent = null then null else doGetRelativeCardinalityTo(parent) endif"
		   });	
		addAnnotation
		  (abstractFeatureEClass.getEOperations().get(6), 
		   source, 
		   new String[] 
		   {
			 "body", "(not c1.doGetTo().isDescendantOf(c2.doGetTo())) or (c1.cardinality.max <= c2.cardinality.max)"
		   });	
		addAnnotation
		  (relativeCardinalityEClass, 
		   source, 
		   new String[] 
		   {
			 "RelativeCardinalityToAncestor", "\n\t\t\tfrom.isDescendantOf(doGetTo())",
			 "ValidCardinality", "\n\t\t\tcardinality <> null and cardinality.max > 0"
		   });	
		addAnnotation
		  (relativeCardinalityEClass.getEOperations().get(0), 
		   source, 
		   new String[] 
		   {
			 "body", "if to <> null then to else from.doGetParent() endif"
		   });	
		addAnnotation
		  (featureGroupEClass, 
		   source, 
		   new String[] 
		   {
			 "ValidGroupCardinality", "\n\t\tgroupCardinality.min >= 1\n\t\tand groupCardinality.max >= groupCardinality.min\n\t\tand groupCardinality.max <= variants->size()\n\t\tand groupCardinality.min < variants->size()\n\t\t"
		   });	
		addAnnotation
		  (featureGroupEClass.getEOperations().get(0), 
		   source, 
		   new String[] 
		   {
			 "body", "variants->collect(getSubTree())->flatten()->append(self)"
		   });	
		addAnnotation
		  (featureEClass, 
		   source, 
		   new String[] 
		   {
			 "RootHasNoCardinalities", "\n\t\t\tdoGetParent() <> null or cardinalities = null or cardinalities->size() = 0\n\t\t"
		   });	
		addAnnotation
		  (featureEClass.getEOperations().get(0), 
		   source, 
		   new String[] 
		   {
			 "body", "subFeatures->collect(getSubTree())->flatten()->append(self)"
		   });	
		addAnnotation
		  (constrainingExpressionEClass, 
		   source, 
		   new String[] 
		   {
			 "FeaturesAreAncestorsDescendant", "\n\t\t\tfrom.isDescendantOf(to)"
		   });	
		addAnnotation
		  (cardinalityEClass, 
		   source, 
		   new String[] 
		   {
			 "Consistency", "\n\t\t\tmin <= max and min >= 0"
		   });	
		addAnnotation
		  (instanceEClass, 
		   source, 
		   new String[] 
		   {
			 "HierarchyFollowed", "\n\t\t\tparent = null or type.isDescendantOf(parent.type)"
		   });
	}

	/**
	 * Initializes the annotations for <b>http://schema.omg.org/spec/MOF/2.0/emof.xml#Property.oppositeRoleName</b>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void createEmofAnnotations()
	{
		String source = "http://schema.omg.org/spec/MOF/2.0/emof.xml#Property.oppositeRoleName";	
		addAnnotation
		  (getAbstractFeature_Name(), 
		   source, 
		   new String[] 
		   {
			 "body", "RelativeCardinality",
			 "unique", "false",
			 "upper", "*"
		   });
	}

} //FeatureModelPackageImpl
