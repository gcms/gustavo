/**
 */
package fr.inria.lille.spirals.fm.featuremodel;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Or Constraining Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage#getOrConstrainingExpression()
 * @model
 * @generated
 */
public interface OrConstrainingExpression extends ComposedConstrainingExpression
{
} // OrConstrainingExpression
