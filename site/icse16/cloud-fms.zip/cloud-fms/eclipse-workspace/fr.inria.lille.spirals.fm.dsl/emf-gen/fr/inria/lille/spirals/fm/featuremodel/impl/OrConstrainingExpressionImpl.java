/**
 */
package fr.inria.lille.spirals.fm.featuremodel.impl;

import fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage;
import fr.inria.lille.spirals.fm.featuremodel.OrConstrainingExpression;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Or Constraining Expression</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class OrConstrainingExpressionImpl extends ComposedConstrainingExpressionImpl implements OrConstrainingExpression
{
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected OrConstrainingExpressionImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return FeatureModelPackage.Literals.OR_CONSTRAINING_EXPRESSION;
	}

} //OrConstrainingExpressionImpl
