/**
 */
package fr.inria.lille.spirals.fm.featuremodel.impl;

import fr.inria.lille.spirals.fm.featuremodel.AbstractFeature;
import fr.inria.lille.spirals.fm.featuremodel.Cardinality;
import fr.inria.lille.spirals.fm.featuremodel.FeatureGroup;
import fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage;

import java.lang.reflect.InvocationTargetException;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.WrappedException;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentWithInverseEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Feature Group</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link fr.inria.lille.spirals.fm.featuremodel.impl.FeatureGroupImpl#getVariants <em>Variants</em>}</li>
 *   <li>{@link fr.inria.lille.spirals.fm.featuremodel.impl.FeatureGroupImpl#getGroupCardinality <em>Group Cardinality</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class FeatureGroupImpl extends AbstractFeatureImpl implements FeatureGroup
{
	/**
	 * The cached value of the '{@link #getVariants() <em>Variants</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVariants()
	 * @generated
	 * @ordered
	 */
	protected EList<AbstractFeature> variants;

	/**
	 * The cached value of the '{@link #getGroupCardinality() <em>Group Cardinality</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGroupCardinality()
	 * @generated
	 * @ordered
	 */
	protected Cardinality groupCardinality;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FeatureGroupImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return FeatureModelPackage.Literals.FEATURE_GROUP;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<AbstractFeature> getVariants()
	{
		if (variants == null)
		{
			variants = new EObjectContainmentWithInverseEList<AbstractFeature>(AbstractFeature.class, this, FeatureModelPackage.FEATURE_GROUP__VARIANTS, FeatureModelPackage.ABSTRACT_FEATURE__GROUP);
		}
		return variants;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Cardinality getGroupCardinality()
	{
		return groupCardinality;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetGroupCardinality(Cardinality newGroupCardinality, NotificationChain msgs)
	{
		Cardinality oldGroupCardinality = groupCardinality;
		groupCardinality = newGroupCardinality;
		if (eNotificationRequired())
		{
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, FeatureModelPackage.FEATURE_GROUP__GROUP_CARDINALITY, oldGroupCardinality, newGroupCardinality);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setGroupCardinality(Cardinality newGroupCardinality)
	{
		if (newGroupCardinality != groupCardinality)
		{
			NotificationChain msgs = null;
			if (groupCardinality != null)
				msgs = ((InternalEObject)groupCardinality).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - FeatureModelPackage.FEATURE_GROUP__GROUP_CARDINALITY, null, msgs);
			if (newGroupCardinality != null)
				msgs = ((InternalEObject)newGroupCardinality).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - FeatureModelPackage.FEATURE_GROUP__GROUP_CARDINALITY, null, msgs);
			msgs = basicSetGroupCardinality(newGroupCardinality, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FeatureModelPackage.FEATURE_GROUP__GROUP_CARDINALITY, newGroupCardinality, newGroupCardinality));
	}

	/**
	 * The cached invocation delegate for the '{@link #getSubTree() <em>Get Sub Tree</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSubTree()
	 * @generated
	 * @ordered
	 */
	protected static final EOperation.Internal.InvocationDelegate GET_SUB_TREE__EINVOCATION_DELEGATE = ((EOperation.Internal)FeatureModelPackage.Literals.FEATURE_GROUP.getEOperations().get(0)).getInvocationDelegate();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	public EList<AbstractFeature> getSubTree()
	{
		try
		{
			return (EList<AbstractFeature>)GET_SUB_TREE__EINVOCATION_DELEGATE.dynamicInvoke(this, null);
		}
		catch (InvocationTargetException ite)
		{
			throw new WrappedException(ite);
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs)
	{
		switch (featureID)
		{
			case FeatureModelPackage.FEATURE_GROUP__VARIANTS:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)getVariants()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
	{
		switch (featureID)
		{
			case FeatureModelPackage.FEATURE_GROUP__VARIANTS:
				return ((InternalEList<?>)getVariants()).basicRemove(otherEnd, msgs);
			case FeatureModelPackage.FEATURE_GROUP__GROUP_CARDINALITY:
				return basicSetGroupCardinality(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType)
	{
		switch (featureID)
		{
			case FeatureModelPackage.FEATURE_GROUP__VARIANTS:
				return getVariants();
			case FeatureModelPackage.FEATURE_GROUP__GROUP_CARDINALITY:
				return getGroupCardinality();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue)
	{
		switch (featureID)
		{
			case FeatureModelPackage.FEATURE_GROUP__VARIANTS:
				getVariants().clear();
				getVariants().addAll((Collection<? extends AbstractFeature>)newValue);
				return;
			case FeatureModelPackage.FEATURE_GROUP__GROUP_CARDINALITY:
				setGroupCardinality((Cardinality)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID)
	{
		switch (featureID)
		{
			case FeatureModelPackage.FEATURE_GROUP__VARIANTS:
				getVariants().clear();
				return;
			case FeatureModelPackage.FEATURE_GROUP__GROUP_CARDINALITY:
				setGroupCardinality((Cardinality)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID)
	{
		switch (featureID)
		{
			case FeatureModelPackage.FEATURE_GROUP__VARIANTS:
				return variants != null && !variants.isEmpty();
			case FeatureModelPackage.FEATURE_GROUP__GROUP_CARDINALITY:
				return groupCardinality != null;
		}
		return super.eIsSet(featureID);
	}

} //FeatureGroupImpl
