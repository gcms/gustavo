/**
 */
package fr.inria.lille.spirals.fm.featuremodel.util;

import fr.inria.lille.spirals.fm.featuremodel.*;

import java.util.Map;

import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.ResourceLocator;

import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.EObjectValidator;

/**
 * <!-- begin-user-doc -->
 * The <b>Validator</b> for the model.
 * <!-- end-user-doc -->
 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage
 * @generated
 */
public class FeatureModelValidator extends EObjectValidator
{
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final FeatureModelValidator INSTANCE = new FeatureModelValidator();

	/**
	 * A constant for the {@link org.eclipse.emf.common.util.Diagnostic#getSource() source} of diagnostic {@link org.eclipse.emf.common.util.Diagnostic#getCode() codes} from this package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.common.util.Diagnostic#getSource()
	 * @see org.eclipse.emf.common.util.Diagnostic#getCode()
	 * @generated
	 */
	public static final String DIAGNOSTIC_SOURCE = "fr.inria.lille.spirals.fm.featuremodel";

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final int GENERATED_DIAGNOSTIC_CODE_COUNT = 0;

	/**
	 * A constant with a fixed name that can be used as the base value for additional hand written constants in a derived class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final int DIAGNOSTIC_CODE_COUNT = GENERATED_DIAGNOSTIC_CODE_COUNT;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FeatureModelValidator()
	{
		super();
	}

	/**
	 * Returns the package of this validator switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EPackage getEPackage()
	{
	  return FeatureModelPackage.eINSTANCE;
	}

	/**
	 * Calls <code>validateXXX</code> for the corresponding classifier of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected boolean validate(int classifierID, Object value, DiagnosticChain diagnostics, Map<Object, Object> context)
	{
		switch (classifierID)
		{
			case FeatureModelPackage.ELEMENT:
				return validateElement((Element)value, diagnostics, context);
			case FeatureModelPackage.FEATURE_MODEL:
				return validateFeatureModel((FeatureModel)value, diagnostics, context);
			case FeatureModelPackage.ABSTRACT_FEATURE:
				return validateAbstractFeature((AbstractFeature)value, diagnostics, context);
			case FeatureModelPackage.RELATIVE_CARDINALITY:
				return validateRelativeCardinality((RelativeCardinality)value, diagnostics, context);
			case FeatureModelPackage.FEATURE_GROUP:
				return validateFeatureGroup((FeatureGroup)value, diagnostics, context);
			case FeatureModelPackage.FEATURE:
				return validateFeature((Feature)value, diagnostics, context);
			case FeatureModelPackage.CONSTRAINT:
				return validateConstraint((Constraint)value, diagnostics, context);
			case FeatureModelPackage.ABSTRACT_CONSTRAINING_EXPRESSION:
				return validateAbstractConstrainingExpression((AbstractConstrainingExpression)value, diagnostics, context);
			case FeatureModelPackage.COMPOSED_CONSTRAINING_EXPRESSION:
				return validateComposedConstrainingExpression((ComposedConstrainingExpression)value, diagnostics, context);
			case FeatureModelPackage.CONSTRAINING_EXPRESSION:
				return validateConstrainingExpression((ConstrainingExpression)value, diagnostics, context);
			case FeatureModelPackage.CARDINALITY:
				return validateCardinality((Cardinality)value, diagnostics, context);
			case FeatureModelPackage.AND_CONSTRAINING_EXPRESSION:
				return validateAndConstrainingExpression((AndConstrainingExpression)value, diagnostics, context);
			case FeatureModelPackage.OR_CONSTRAINING_EXPRESSION:
				return validateOrConstrainingExpression((OrConstrainingExpression)value, diagnostics, context);
			case FeatureModelPackage.CONFIGURATION:
				return validateConfiguration((Configuration)value, diagnostics, context);
			case FeatureModelPackage.INSTANCE:
				return validateInstance((Instance)value, diagnostics, context);
			case FeatureModelPackage.MY_CARDINALITY:
				return validateMyCardinality((fr.inria.lille.spirals.fm.datatypes.Cardinality)value, diagnostics, context);
			default:
				return true;
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateElement(Element element, DiagnosticChain diagnostics, Map<Object, Object> context)
	{
		return validate_EveryDefaultConstraint(element, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateFeatureModel(FeatureModel featureModel, DiagnosticChain diagnostics, Map<Object, Object> context)
	{
		if (!validate_NoCircularContainment(featureModel, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(featureModel, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(featureModel, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(featureModel, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(featureModel, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(featureModel, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(featureModel, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(featureModel, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(featureModel, diagnostics, context);
		if (result || diagnostics != null) result &= validateFeatureModel_MustHaveRoot(featureModel, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the MustHaveRoot constraint of '<em>Feature Model</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String FEATURE_MODEL__MUST_HAVE_ROOT__EEXPRESSION = "\n" +
		"\t\t\troot <> null";

	/**
	 * Validates the MustHaveRoot constraint of '<em>Feature Model</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateFeatureModel_MustHaveRoot(FeatureModel featureModel, DiagnosticChain diagnostics, Map<Object, Object> context)
	{
		return
			validate
				(FeatureModelPackage.Literals.FEATURE_MODEL,
				 featureModel,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "MustHaveRoot",
				 FEATURE_MODEL__MUST_HAVE_ROOT__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateAbstractFeature(AbstractFeature abstractFeature, DiagnosticChain diagnostics, Map<Object, Object> context)
	{
		if (!validate_NoCircularContainment(abstractFeature, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(abstractFeature, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(abstractFeature, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(abstractFeature, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(abstractFeature, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(abstractFeature, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(abstractFeature, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(abstractFeature, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(abstractFeature, diagnostics, context);
		if (result || diagnostics != null) result &= validateAbstractFeature_NoRepeatedRelativeCardinalities(abstractFeature, diagnostics, context);
		if (result || diagnostics != null) result &= validateAbstractFeature_GroupVariantCardinalityGreaterThan0(abstractFeature, diagnostics, context);
		if (result || diagnostics != null) result &= validateAbstractFeature_ConsistentRelativeCardinalities(abstractFeature, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the NoRepeatedRelativeCardinalities constraint of '<em>Abstract Feature</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String ABSTRACT_FEATURE__NO_REPEATED_RELATIVE_CARDINALITIES__EEXPRESSION = "\n" +
		"\t\t\tcardinalities->isUnique(doGetTo())";

	/**
	 * Validates the NoRepeatedRelativeCardinalities constraint of '<em>Abstract Feature</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateAbstractFeature_NoRepeatedRelativeCardinalities(AbstractFeature abstractFeature, DiagnosticChain diagnostics, Map<Object, Object> context)
	{
		return
			validate
				(FeatureModelPackage.Literals.ABSTRACT_FEATURE,
				 abstractFeature,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "NoRepeatedRelativeCardinalities",
				 ABSTRACT_FEATURE__NO_REPEATED_RELATIVE_CARDINALITIES__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the GroupVariantCardinalityGreaterThan0 constraint of '<em>Abstract Feature</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String ABSTRACT_FEATURE__GROUP_VARIANT_CARDINALITY_GREATER_THAN0__EEXPRESSION = "\n" +
		"\t\t\tlet relativeToParent : RelativeCardinality = doGetRelativeCardinalityToParent() in\n" +
		"\t\t\tgroup = null or relativeToParent = null or relativeToParent.cardinality.min > 0\n" +
		"\t\t";

	/**
	 * Validates the GroupVariantCardinalityGreaterThan0 constraint of '<em>Abstract Feature</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateAbstractFeature_GroupVariantCardinalityGreaterThan0(AbstractFeature abstractFeature, DiagnosticChain diagnostics, Map<Object, Object> context)
	{
		return
			validate
				(FeatureModelPackage.Literals.ABSTRACT_FEATURE,
				 abstractFeature,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "GroupVariantCardinalityGreaterThan0",
				 ABSTRACT_FEATURE__GROUP_VARIANT_CARDINALITY_GREATER_THAN0__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the ConsistentRelativeCardinalities constraint of '<em>Abstract Feature</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String ABSTRACT_FEATURE__CONSISTENT_RELATIVE_CARDINALITIES__EEXPRESSION = "\n" +
		"\t\t\tcardinalities = null or\n" +
		"\t\t\tcardinalities->forAll(c1 : RelativeCardinality |\n" +
		"\t\t\t\tcardinalities->forAll(c2 : RelativeCardinality|\n" +
		"\t\t\t\t\tc1 = c2 or areConsistent(c1, c2)\t\t\t\t\t\n" +
		"\t\t\t\t)\n" +
		"\t\t\t)\n" +
		"\t\t";

	/**
	 * Validates the ConsistentRelativeCardinalities constraint of '<em>Abstract Feature</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateAbstractFeature_ConsistentRelativeCardinalities(AbstractFeature abstractFeature, DiagnosticChain diagnostics, Map<Object, Object> context)
	{
		return
			validate
				(FeatureModelPackage.Literals.ABSTRACT_FEATURE,
				 abstractFeature,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "ConsistentRelativeCardinalities",
				 ABSTRACT_FEATURE__CONSISTENT_RELATIVE_CARDINALITIES__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateRelativeCardinality(RelativeCardinality relativeCardinality, DiagnosticChain diagnostics, Map<Object, Object> context)
	{
		if (!validate_NoCircularContainment(relativeCardinality, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(relativeCardinality, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(relativeCardinality, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(relativeCardinality, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(relativeCardinality, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(relativeCardinality, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(relativeCardinality, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(relativeCardinality, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(relativeCardinality, diagnostics, context);
		if (result || diagnostics != null) result &= validateRelativeCardinality_RelativeCardinalityToAncestor(relativeCardinality, diagnostics, context);
		if (result || diagnostics != null) result &= validateRelativeCardinality_ValidCardinality(relativeCardinality, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the RelativeCardinalityToAncestor constraint of '<em>Relative Cardinality</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String RELATIVE_CARDINALITY__RELATIVE_CARDINALITY_TO_ANCESTOR__EEXPRESSION = "\n" +
		"\t\t\tfrom.isDescendantOf(doGetTo())";

	/**
	 * Validates the RelativeCardinalityToAncestor constraint of '<em>Relative Cardinality</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateRelativeCardinality_RelativeCardinalityToAncestor(RelativeCardinality relativeCardinality, DiagnosticChain diagnostics, Map<Object, Object> context)
	{
		return
			validate
				(FeatureModelPackage.Literals.RELATIVE_CARDINALITY,
				 relativeCardinality,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "RelativeCardinalityToAncestor",
				 RELATIVE_CARDINALITY__RELATIVE_CARDINALITY_TO_ANCESTOR__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * The cached validation expression for the ValidCardinality constraint of '<em>Relative Cardinality</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String RELATIVE_CARDINALITY__VALID_CARDINALITY__EEXPRESSION = "\n" +
		"\t\t\tcardinality <> null and cardinality.max > 0";

	/**
	 * Validates the ValidCardinality constraint of '<em>Relative Cardinality</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateRelativeCardinality_ValidCardinality(RelativeCardinality relativeCardinality, DiagnosticChain diagnostics, Map<Object, Object> context)
	{
		return
			validate
				(FeatureModelPackage.Literals.RELATIVE_CARDINALITY,
				 relativeCardinality,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "ValidCardinality",
				 RELATIVE_CARDINALITY__VALID_CARDINALITY__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateFeatureGroup(FeatureGroup featureGroup, DiagnosticChain diagnostics, Map<Object, Object> context)
	{
		if (!validate_NoCircularContainment(featureGroup, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(featureGroup, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(featureGroup, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(featureGroup, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(featureGroup, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(featureGroup, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(featureGroup, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(featureGroup, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(featureGroup, diagnostics, context);
		if (result || diagnostics != null) result &= validateAbstractFeature_NoRepeatedRelativeCardinalities(featureGroup, diagnostics, context);
		if (result || diagnostics != null) result &= validateAbstractFeature_GroupVariantCardinalityGreaterThan0(featureGroup, diagnostics, context);
		if (result || diagnostics != null) result &= validateAbstractFeature_ConsistentRelativeCardinalities(featureGroup, diagnostics, context);
		if (result || diagnostics != null) result &= validateFeatureGroup_ValidGroupCardinality(featureGroup, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the ValidGroupCardinality constraint of '<em>Feature Group</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String FEATURE_GROUP__VALID_GROUP_CARDINALITY__EEXPRESSION = "\n" +
		"\t\tgroupCardinality.min >= 1\n" +
		"\t\tand groupCardinality.max >= groupCardinality.min\n" +
		"\t\tand groupCardinality.max <= variants->size()\n" +
		"\t\tand groupCardinality.min < variants->size()\n" +
		"\t\t";

	/**
	 * Validates the ValidGroupCardinality constraint of '<em>Feature Group</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateFeatureGroup_ValidGroupCardinality(FeatureGroup featureGroup, DiagnosticChain diagnostics, Map<Object, Object> context)
	{
		return
			validate
				(FeatureModelPackage.Literals.FEATURE_GROUP,
				 featureGroup,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "ValidGroupCardinality",
				 FEATURE_GROUP__VALID_GROUP_CARDINALITY__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateFeature(Feature feature, DiagnosticChain diagnostics, Map<Object, Object> context)
	{
		if (!validate_NoCircularContainment(feature, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(feature, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(feature, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(feature, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(feature, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(feature, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(feature, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(feature, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(feature, diagnostics, context);
		if (result || diagnostics != null) result &= validateAbstractFeature_NoRepeatedRelativeCardinalities(feature, diagnostics, context);
		if (result || diagnostics != null) result &= validateAbstractFeature_GroupVariantCardinalityGreaterThan0(feature, diagnostics, context);
		if (result || diagnostics != null) result &= validateAbstractFeature_ConsistentRelativeCardinalities(feature, diagnostics, context);
		if (result || diagnostics != null) result &= validateFeature_RootHasNoCardinalities(feature, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the RootHasNoCardinalities constraint of '<em>Feature</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String FEATURE__ROOT_HAS_NO_CARDINALITIES__EEXPRESSION = "\n" +
		"\t\t\tdoGetParent() <> null or cardinalities = null or cardinalities->size() = 0\n" +
		"\t\t";

	/**
	 * Validates the RootHasNoCardinalities constraint of '<em>Feature</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateFeature_RootHasNoCardinalities(Feature feature, DiagnosticChain diagnostics, Map<Object, Object> context)
	{
		return
			validate
				(FeatureModelPackage.Literals.FEATURE,
				 feature,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "RootHasNoCardinalities",
				 FEATURE__ROOT_HAS_NO_CARDINALITIES__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateConstraint(Constraint constraint, DiagnosticChain diagnostics, Map<Object, Object> context)
	{
		return validate_EveryDefaultConstraint(constraint, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateAbstractConstrainingExpression(AbstractConstrainingExpression abstractConstrainingExpression, DiagnosticChain diagnostics, Map<Object, Object> context)
	{
		return validate_EveryDefaultConstraint(abstractConstrainingExpression, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateComposedConstrainingExpression(ComposedConstrainingExpression composedConstrainingExpression, DiagnosticChain diagnostics, Map<Object, Object> context)
	{
		return validate_EveryDefaultConstraint(composedConstrainingExpression, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateConstrainingExpression(ConstrainingExpression constrainingExpression, DiagnosticChain diagnostics, Map<Object, Object> context)
	{
		if (!validate_NoCircularContainment(constrainingExpression, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(constrainingExpression, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(constrainingExpression, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(constrainingExpression, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(constrainingExpression, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(constrainingExpression, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(constrainingExpression, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(constrainingExpression, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(constrainingExpression, diagnostics, context);
		if (result || diagnostics != null) result &= validateConstrainingExpression_FeaturesAreAncestorsDescendant(constrainingExpression, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the FeaturesAreAncestorsDescendant constraint of '<em>Constraining Expression</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String CONSTRAINING_EXPRESSION__FEATURES_ARE_ANCESTORS_DESCENDANT__EEXPRESSION = "\n" +
		"\t\t\tfrom.isDescendantOf(to)";

	/**
	 * Validates the FeaturesAreAncestorsDescendant constraint of '<em>Constraining Expression</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateConstrainingExpression_FeaturesAreAncestorsDescendant(ConstrainingExpression constrainingExpression, DiagnosticChain diagnostics, Map<Object, Object> context)
	{
		return
			validate
				(FeatureModelPackage.Literals.CONSTRAINING_EXPRESSION,
				 constrainingExpression,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "FeaturesAreAncestorsDescendant",
				 CONSTRAINING_EXPRESSION__FEATURES_ARE_ANCESTORS_DESCENDANT__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCardinality(Cardinality cardinality, DiagnosticChain diagnostics, Map<Object, Object> context)
	{
		if (!validate_NoCircularContainment(cardinality, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(cardinality, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(cardinality, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(cardinality, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(cardinality, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(cardinality, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(cardinality, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(cardinality, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(cardinality, diagnostics, context);
		if (result || diagnostics != null) result &= validateCardinality_Consistency(cardinality, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the Consistency constraint of '<em>Cardinality</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String CARDINALITY__CONSISTENCY__EEXPRESSION = "\n" +
		"\t\t\tmin <= max and min >= 0";

	/**
	 * Validates the Consistency constraint of '<em>Cardinality</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateCardinality_Consistency(Cardinality cardinality, DiagnosticChain diagnostics, Map<Object, Object> context)
	{
		return
			validate
				(FeatureModelPackage.Literals.CARDINALITY,
				 cardinality,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "Consistency",
				 CARDINALITY__CONSISTENCY__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateAndConstrainingExpression(AndConstrainingExpression andConstrainingExpression, DiagnosticChain diagnostics, Map<Object, Object> context)
	{
		return validate_EveryDefaultConstraint(andConstrainingExpression, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateOrConstrainingExpression(OrConstrainingExpression orConstrainingExpression, DiagnosticChain diagnostics, Map<Object, Object> context)
	{
		return validate_EveryDefaultConstraint(orConstrainingExpression, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateConfiguration(Configuration configuration, DiagnosticChain diagnostics, Map<Object, Object> context)
	{
		return validate_EveryDefaultConstraint(configuration, diagnostics, context);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateInstance(Instance instance, DiagnosticChain diagnostics, Map<Object, Object> context)
	{
		if (!validate_NoCircularContainment(instance, diagnostics, context)) return false;
		boolean result = validate_EveryMultiplicityConforms(instance, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryDataValueConforms(instance, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryReferenceIsContained(instance, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryBidirectionalReferenceIsPaired(instance, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryProxyResolves(instance, diagnostics, context);
		if (result || diagnostics != null) result &= validate_UniqueID(instance, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryKeyUnique(instance, diagnostics, context);
		if (result || diagnostics != null) result &= validate_EveryMapEntryUnique(instance, diagnostics, context);
		if (result || diagnostics != null) result &= validateInstance_HierarchyFollowed(instance, diagnostics, context);
		return result;
	}

	/**
	 * The cached validation expression for the HierarchyFollowed constraint of '<em>Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static final String INSTANCE__HIERARCHY_FOLLOWED__EEXPRESSION = "\n" +
		"\t\t\tparent = null or type.isDescendantOf(parent.type)";

	/**
	 * Validates the HierarchyFollowed constraint of '<em>Instance</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateInstance_HierarchyFollowed(Instance instance, DiagnosticChain diagnostics, Map<Object, Object> context)
	{
		return
			validate
				(FeatureModelPackage.Literals.INSTANCE,
				 instance,
				 diagnostics,
				 context,
				 "http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot",
				 "HierarchyFollowed",
				 INSTANCE__HIERARCHY_FOLLOWED__EEXPRESSION,
				 Diagnostic.ERROR,
				 DIAGNOSTIC_SOURCE,
				 0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean validateMyCardinality(fr.inria.lille.spirals.fm.datatypes.Cardinality myCardinality, DiagnosticChain diagnostics, Map<Object, Object> context)
	{
		return true;
	}

	/**
	 * Returns the resource locator that will be used to fetch messages for this validator's diagnostics.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResourceLocator getResourceLocator()
	{
		// TODO
		// Specialize this to return a resource locator for messages specific to this validator.
		// Ensure that you remove @generated or mark it @generated NOT
		return super.getResourceLocator();
	}

} //FeatureModelValidator
