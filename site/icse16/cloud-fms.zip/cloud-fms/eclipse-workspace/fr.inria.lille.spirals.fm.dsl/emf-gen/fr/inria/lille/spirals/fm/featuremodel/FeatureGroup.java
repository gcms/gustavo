/**
 */
package fr.inria.lille.spirals.fm.featuremodel;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Feature Group</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link fr.inria.lille.spirals.fm.featuremodel.FeatureGroup#getVariants <em>Variants</em>}</li>
 *   <li>{@link fr.inria.lille.spirals.fm.featuremodel.FeatureGroup#getGroupCardinality <em>Group Cardinality</em>}</li>
 * </ul>
 * </p>
 *
 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage#getFeatureGroup()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='ValidGroupCardinality'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot ValidGroupCardinality='\n\t\tgroupCardinality.min >= 1\n\t\tand groupCardinality.max >= groupCardinality.min\n\t\tand groupCardinality.max <= variants->size()\n\t\tand groupCardinality.min < variants->size()\n\t\t'"
 * @generated
 */
public interface FeatureGroup extends AbstractFeature
{
	/**
	 * Returns the value of the '<em><b>Variants</b></em>' containment reference list.
	 * The list contents are of type {@link fr.inria.lille.spirals.fm.featuremodel.AbstractFeature}.
	 * It is bidirectional and its opposite is '{@link fr.inria.lille.spirals.fm.featuremodel.AbstractFeature#getGroup <em>Group</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Variants</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Variants</em>' containment reference list.
	 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage#getFeatureGroup_Variants()
	 * @see fr.inria.lille.spirals.fm.featuremodel.AbstractFeature#getGroup
	 * @model opposite="group" containment="true" lower="2"
	 * @generated
	 */
	EList<AbstractFeature> getVariants();

	/**
	 * Returns the value of the '<em><b>Group Cardinality</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Group Cardinality</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Group Cardinality</em>' containment reference.
	 * @see #setGroupCardinality(Cardinality)
	 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage#getFeatureGroup_GroupCardinality()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Cardinality getGroupCardinality();

	/**
	 * Sets the value of the '{@link fr.inria.lille.spirals.fm.featuremodel.FeatureGroup#getGroupCardinality <em>Group Cardinality</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Group Cardinality</em>' containment reference.
	 * @see #getGroupCardinality()
	 * @generated
	 */
	void setGroupCardinality(Cardinality value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model kind="operation" ordered="false"
	 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='variants->collect(getSubTree())->flatten()->append(self)'"
	 * @generated
	 */
	EList<AbstractFeature> getSubTree();

} // FeatureGroup
