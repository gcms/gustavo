/**
 */
package fr.inria.lille.spirals.fm.featuremodel;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Abstract Feature</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link fr.inria.lille.spirals.fm.featuremodel.AbstractFeature#getName <em>Name</em>}</li>
 *   <li>{@link fr.inria.lille.spirals.fm.featuremodel.AbstractFeature#getParent <em>Parent</em>}</li>
 *   <li>{@link fr.inria.lille.spirals.fm.featuremodel.AbstractFeature#getGroup <em>Group</em>}</li>
 *   <li>{@link fr.inria.lille.spirals.fm.featuremodel.AbstractFeature#getCardinalities <em>Cardinalities</em>}</li>
 * </ul>
 * </p>
 *
 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage#getAbstractFeature()
 * @model abstract="true"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore constraints='NoRepeatedRelativeCardinalities GroupVariantCardinalityGreaterThan0 ConsistentRelativeCardinalities'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot NoRepeatedRelativeCardinalities='\n\t\t\tcardinalities->isUnique(doGetTo())' GroupVariantCardinalityGreaterThan0='\n\t\t\tlet relativeToParent : RelativeCardinality = doGetRelativeCardinalityToParent() in\n\t\t\tgroup = null or relativeToParent = null or relativeToParent.cardinality.min > 0\n\t\t' ConsistentRelativeCardinalities='\n\t\t\tcardinalities = null or\n\t\t\tcardinalities->forAll(c1 : RelativeCardinality |\n\t\t\t\tcardinalities->forAll(c2 : RelativeCardinality|\n\t\t\t\t\tc1 = c2 or areConsistent(c1, c2)\t\t\t\t\t\n\t\t\t\t)\n\t\t\t)\n\t\t'"
 * @generated
 */
public interface AbstractFeature extends EObject
{
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage#getAbstractFeature_Name()
	 * @model id="true" required="true"
	 *        annotation="http://schema.omg.org/spec/MOF/2.0/emof.xml#Property.oppositeRoleName body='RelativeCardinality' unique='false' upper='*'"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link fr.inria.lille.spirals.fm.featuremodel.AbstractFeature#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Parent</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link fr.inria.lille.spirals.fm.featuremodel.Feature#getSubFeatures <em>Sub Features</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Parent</em>' container reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Parent</em>' container reference.
	 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage#getAbstractFeature_Parent()
	 * @see fr.inria.lille.spirals.fm.featuremodel.Feature#getSubFeatures
	 * @model opposite="subFeatures" transient="false" changeable="false" derived="true"
	 * @generated
	 */
	Feature getParent();

	/**
	 * Returns the value of the '<em><b>Group</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link fr.inria.lille.spirals.fm.featuremodel.FeatureGroup#getVariants <em>Variants</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Group</em>' container reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Group</em>' container reference.
	 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage#getAbstractFeature_Group()
	 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureGroup#getVariants
	 * @model opposite="variants" transient="false" changeable="false" derived="true"
	 * @generated
	 */
	FeatureGroup getGroup();

	/**
	 * Returns the value of the '<em><b>Cardinalities</b></em>' containment reference list.
	 * The list contents are of type {@link fr.inria.lille.spirals.fm.featuremodel.RelativeCardinality}.
	 * It is bidirectional and its opposite is '{@link fr.inria.lille.spirals.fm.featuremodel.RelativeCardinality#getFrom <em>From</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Cardinalities</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cardinalities</em>' containment reference list.
	 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage#getAbstractFeature_Cardinalities()
	 * @see fr.inria.lille.spirals.fm.featuremodel.RelativeCardinality#getFrom
	 * @model opposite="from" containment="true"
	 * @generated
	 */
	EList<RelativeCardinality> getCardinalities();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model kind="operation" ordered="false"
	 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='\n\t\t\tlet parent : AbstractFeature = doGetParent() in\n\t\t\tif parent = null then Sequence{} else parent.getAncestors()->asSequence()->append(parent) endif'"
	 * @generated
	 */
	EList<AbstractFeature> getAncestors();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model kind="operation" ordered="false"
	 * @generated
	 */
	EList<AbstractFeature> getSubTree();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model required="true" featureRequired="true"
	 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='\n\t\t\tif self.doGetParent() = null then \n\t\t\t\tfalse\n\t\t\telse\n\t\t\t\tself.doGetParent() = feature or self.doGetParent().isDescendantOf(feature)\n\t\t\tendif'"
	 * @generated
	 */
	boolean isDescendantOf(AbstractFeature feature);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='if group <> null then group else parent endif'"
	 * @generated
	 */
	AbstractFeature doGetParent();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model required="true" featureRequired="true"
	 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='\n\t\t\tif cardinalities = null then null else\n\t\t\tlet selected = cardinalities->select(c | c.doGetTo() = feature) in\n\t\t\tif selected <> null and not selected->isEmpty() then selected->first() else null endif\n\t\t\tendif'"
	 * @generated
	 */
	RelativeCardinality doGetRelativeCardinalityTo(AbstractFeature feature);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model required="true"
	 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='\n\t\t\tlet parent = doGetParent() in\n\t\t\tif parent = null then null else doGetRelativeCardinalityTo(parent) endif'"
	 * @generated
	 */
	RelativeCardinality doGetRelativeCardinalityToParent();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model required="true" c1Required="true" c2Required="true"
	 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='(not c1.doGetTo().isDescendantOf(c2.doGetTo())) or (c1.cardinality.max <= c2.cardinality.max)'"
	 * @generated
	 */
	boolean areConsistent(RelativeCardinality c1, RelativeCardinality c2);

} // AbstractFeature
