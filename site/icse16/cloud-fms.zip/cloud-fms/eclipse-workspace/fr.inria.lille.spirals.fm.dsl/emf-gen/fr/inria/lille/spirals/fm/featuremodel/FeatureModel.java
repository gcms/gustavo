/**
 */
package fr.inria.lille.spirals.fm.featuremodel;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Feature Model</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link fr.inria.lille.spirals.fm.featuremodel.FeatureModel#getRoot <em>Root</em>}</li>
 *   <li>{@link fr.inria.lille.spirals.fm.featuremodel.FeatureModel#getConstraints <em>Constraints</em>}</li>
 *   <li>{@link fr.inria.lille.spirals.fm.featuremodel.FeatureModel#getName <em>Name</em>}</li>
 * </ul>
 * </p>
 *
 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage#getFeatureModel()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='MustHaveRoot'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot MustHaveRoot='\n\t\t\troot <> null'"
 * @generated
 */
public interface FeatureModel extends Element
{
	/**
	 * Returns the value of the '<em><b>Root</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Root</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Root</em>' containment reference.
	 * @see #setRoot(Feature)
	 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage#getFeatureModel_Root()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Feature getRoot();

	/**
	 * Sets the value of the '{@link fr.inria.lille.spirals.fm.featuremodel.FeatureModel#getRoot <em>Root</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Root</em>' containment reference.
	 * @see #getRoot()
	 * @generated
	 */
	void setRoot(Feature value);

	/**
	 * Returns the value of the '<em><b>Constraints</b></em>' containment reference list.
	 * The list contents are of type {@link fr.inria.lille.spirals.fm.featuremodel.Constraint}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Constraints</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Constraints</em>' containment reference list.
	 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage#getFeatureModel_Constraints()
	 * @model containment="true"
	 * @generated
	 */
	EList<Constraint> getConstraints();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage#getFeatureModel_Name()
	 * @model required="true" derived="true"
	 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot derivation='if root = null then null else root.name endif'"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link fr.inria.lille.spirals.fm.featuremodel.FeatureModel#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model kind="operation" ordered="false"
	 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='root.getSubTree()'"
	 * @generated
	 */
	EList<AbstractFeature> getAllFeatures();

} // FeatureModel
