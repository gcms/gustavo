/**
 */
package fr.inria.lille.spirals.fm.featuremodel;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Feature</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link fr.inria.lille.spirals.fm.featuremodel.Feature#getSubFeatures <em>Sub Features</em>}</li>
 * </ul>
 * </p>
 *
 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage#getFeature()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='RootHasNoCardinalities'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot RootHasNoCardinalities='\n\t\t\tdoGetParent() <> null or cardinalities = null or cardinalities->size() = 0\n\t\t'"
 * @generated
 */
public interface Feature extends AbstractFeature
{
	/**
	 * Returns the value of the '<em><b>Sub Features</b></em>' containment reference list.
	 * The list contents are of type {@link fr.inria.lille.spirals.fm.featuremodel.AbstractFeature}.
	 * It is bidirectional and its opposite is '{@link fr.inria.lille.spirals.fm.featuremodel.AbstractFeature#getParent <em>Parent</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sub Features</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sub Features</em>' containment reference list.
	 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage#getFeature_SubFeatures()
	 * @see fr.inria.lille.spirals.fm.featuremodel.AbstractFeature#getParent
	 * @model opposite="parent" containment="true"
	 * @generated
	 */
	EList<AbstractFeature> getSubFeatures();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model kind="operation" ordered="false"
	 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='subFeatures->collect(getSubTree())->flatten()->append(self)'"
	 * @generated
	 */
	EList<AbstractFeature> getSubTree();

} // Feature
