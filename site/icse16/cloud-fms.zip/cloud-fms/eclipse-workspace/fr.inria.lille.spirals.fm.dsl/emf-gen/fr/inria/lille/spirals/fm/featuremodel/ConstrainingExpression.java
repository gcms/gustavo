/**
 */
package fr.inria.lille.spirals.fm.featuremodel;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Constraining Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link fr.inria.lille.spirals.fm.featuremodel.ConstrainingExpression#getCardinality <em>Cardinality</em>}</li>
 *   <li>{@link fr.inria.lille.spirals.fm.featuremodel.ConstrainingExpression#getFrom <em>From</em>}</li>
 *   <li>{@link fr.inria.lille.spirals.fm.featuremodel.ConstrainingExpression#getTo <em>To</em>}</li>
 * </ul>
 * </p>
 *
 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage#getConstrainingExpression()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='FeaturesAreAncestorsDescendant'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot FeaturesAreAncestorsDescendant='\n\t\t\tfrom.isDescendantOf(to)'"
 * @generated
 */
public interface ConstrainingExpression extends AbstractConstrainingExpression
{
	/**
	 * Returns the value of the '<em><b>Cardinality</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Cardinality</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cardinality</em>' containment reference.
	 * @see #setCardinality(Cardinality)
	 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage#getConstrainingExpression_Cardinality()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Cardinality getCardinality();

	/**
	 * Sets the value of the '{@link fr.inria.lille.spirals.fm.featuremodel.ConstrainingExpression#getCardinality <em>Cardinality</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Cardinality</em>' containment reference.
	 * @see #getCardinality()
	 * @generated
	 */
	void setCardinality(Cardinality value);

	/**
	 * Returns the value of the '<em><b>From</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>From</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>From</em>' reference.
	 * @see #setFrom(AbstractFeature)
	 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage#getConstrainingExpression_From()
	 * @model required="true"
	 * @generated
	 */
	AbstractFeature getFrom();

	/**
	 * Sets the value of the '{@link fr.inria.lille.spirals.fm.featuremodel.ConstrainingExpression#getFrom <em>From</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>From</em>' reference.
	 * @see #getFrom()
	 * @generated
	 */
	void setFrom(AbstractFeature value);

	/**
	 * Returns the value of the '<em><b>To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>To</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>To</em>' reference.
	 * @see #setTo(AbstractFeature)
	 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage#getConstrainingExpression_To()
	 * @model required="true"
	 * @generated
	 */
	AbstractFeature getTo();

	/**
	 * Sets the value of the '{@link fr.inria.lille.spirals.fm.featuremodel.ConstrainingExpression#getTo <em>To</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>To</em>' reference.
	 * @see #getTo()
	 * @generated
	 */
	void setTo(AbstractFeature value);

} // ConstrainingExpression
