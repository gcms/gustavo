/**
 */
package fr.inria.lille.spirals.fm.featuremodel;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Abstract Constraining Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage#getAbstractConstrainingExpression()
 * @model abstract="true"
 * @generated
 */
public interface AbstractConstrainingExpression extends EObject
{
} // AbstractConstrainingExpression
