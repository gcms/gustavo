/**
 */
package fr.inria.lille.spirals.fm.featuremodel.impl;

import fr.inria.lille.spirals.fm.featuremodel.AbstractFeature;
import fr.inria.lille.spirals.fm.featuremodel.Feature;
import fr.inria.lille.spirals.fm.featuremodel.FeatureGroup;
import fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage;
import fr.inria.lille.spirals.fm.featuremodel.RelativeCardinality;

import java.lang.reflect.InvocationTargetException;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.WrappedException;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentWithInverseEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Abstract Feature</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link fr.inria.lille.spirals.fm.featuremodel.impl.AbstractFeatureImpl#getName <em>Name</em>}</li>
 *   <li>{@link fr.inria.lille.spirals.fm.featuremodel.impl.AbstractFeatureImpl#getParent <em>Parent</em>}</li>
 *   <li>{@link fr.inria.lille.spirals.fm.featuremodel.impl.AbstractFeatureImpl#getGroup <em>Group</em>}</li>
 *   <li>{@link fr.inria.lille.spirals.fm.featuremodel.impl.AbstractFeatureImpl#getCardinalities <em>Cardinalities</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public abstract class AbstractFeatureImpl extends MinimalEObjectImpl.Container implements AbstractFeature
{
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getCardinalities() <em>Cardinalities</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCardinalities()
	 * @generated
	 * @ordered
	 */
	protected EList<RelativeCardinality> cardinalities;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AbstractFeatureImpl()
	{
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass()
	{
		return FeatureModelPackage.Literals.ABSTRACT_FEATURE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName()
	{
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName)
	{
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, FeatureModelPackage.ABSTRACT_FEATURE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Feature getParent()
	{
		if (eContainerFeatureID() != FeatureModelPackage.ABSTRACT_FEATURE__PARENT) return null;
		return (Feature)eInternalContainer();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FeatureGroup getGroup()
	{
		if (eContainerFeatureID() != FeatureModelPackage.ABSTRACT_FEATURE__GROUP) return null;
		return (FeatureGroup)eInternalContainer();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<RelativeCardinality> getCardinalities()
	{
		if (cardinalities == null)
		{
			cardinalities = new EObjectContainmentWithInverseEList<RelativeCardinality>(RelativeCardinality.class, this, FeatureModelPackage.ABSTRACT_FEATURE__CARDINALITIES, FeatureModelPackage.RELATIVE_CARDINALITY__FROM);
		}
		return cardinalities;
	}

	/**
	 * The cached invocation delegate for the '{@link #getAncestors() <em>Get Ancestors</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAncestors()
	 * @generated
	 * @ordered
	 */
	protected static final EOperation.Internal.InvocationDelegate GET_ANCESTORS__EINVOCATION_DELEGATE = ((EOperation.Internal)FeatureModelPackage.Literals.ABSTRACT_FEATURE.getEOperations().get(0)).getInvocationDelegate();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	public EList<AbstractFeature> getAncestors()
	{
		try
		{
			return (EList<AbstractFeature>)GET_ANCESTORS__EINVOCATION_DELEGATE.dynamicInvoke(this, null);
		}
		catch (InvocationTargetException ite)
		{
			throw new WrappedException(ite);
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<AbstractFeature> getSubTree()
	{
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * The cached invocation delegate for the '{@link #isDescendantOf(fr.inria.lille.spirals.fm.featuremodel.AbstractFeature) <em>Is Descendant Of</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isDescendantOf(fr.inria.lille.spirals.fm.featuremodel.AbstractFeature)
	 * @generated
	 * @ordered
	 */
	protected static final EOperation.Internal.InvocationDelegate IS_DESCENDANT_OF_ABSTRACT_FEATURE__EINVOCATION_DELEGATE = ((EOperation.Internal)FeatureModelPackage.Literals.ABSTRACT_FEATURE.getEOperations().get(2)).getInvocationDelegate();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean isDescendantOf(AbstractFeature feature)
	{
		try
		{
			return (Boolean)IS_DESCENDANT_OF_ABSTRACT_FEATURE__EINVOCATION_DELEGATE.dynamicInvoke(this, new BasicEList.UnmodifiableEList<Object>(1, new Object[]{feature}));
		}
		catch (InvocationTargetException ite)
		{
			throw new WrappedException(ite);
		}
	}

	/**
	 * The cached invocation delegate for the '{@link #doGetParent() <em>Do Get Parent</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #doGetParent()
	 * @generated
	 * @ordered
	 */
	protected static final EOperation.Internal.InvocationDelegate DO_GET_PARENT__EINVOCATION_DELEGATE = ((EOperation.Internal)FeatureModelPackage.Literals.ABSTRACT_FEATURE.getEOperations().get(3)).getInvocationDelegate();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public AbstractFeature doGetParent()
	{
		try
		{
			return (AbstractFeature)DO_GET_PARENT__EINVOCATION_DELEGATE.dynamicInvoke(this, null);
		}
		catch (InvocationTargetException ite)
		{
			throw new WrappedException(ite);
		}
	}

	/**
	 * The cached invocation delegate for the '{@link #doGetRelativeCardinalityTo(fr.inria.lille.spirals.fm.featuremodel.AbstractFeature) <em>Do Get Relative Cardinality To</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #doGetRelativeCardinalityTo(fr.inria.lille.spirals.fm.featuremodel.AbstractFeature)
	 * @generated
	 * @ordered
	 */
	protected static final EOperation.Internal.InvocationDelegate DO_GET_RELATIVE_CARDINALITY_TO_ABSTRACT_FEATURE__EINVOCATION_DELEGATE = ((EOperation.Internal)FeatureModelPackage.Literals.ABSTRACT_FEATURE.getEOperations().get(4)).getInvocationDelegate();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RelativeCardinality doGetRelativeCardinalityTo(AbstractFeature feature)
	{
		try
		{
			return (RelativeCardinality)DO_GET_RELATIVE_CARDINALITY_TO_ABSTRACT_FEATURE__EINVOCATION_DELEGATE.dynamicInvoke(this, new BasicEList.UnmodifiableEList<Object>(1, new Object[]{feature}));
		}
		catch (InvocationTargetException ite)
		{
			throw new WrappedException(ite);
		}
	}

	/**
	 * The cached invocation delegate for the '{@link #doGetRelativeCardinalityToParent() <em>Do Get Relative Cardinality To Parent</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #doGetRelativeCardinalityToParent()
	 * @generated
	 * @ordered
	 */
	protected static final EOperation.Internal.InvocationDelegate DO_GET_RELATIVE_CARDINALITY_TO_PARENT__EINVOCATION_DELEGATE = ((EOperation.Internal)FeatureModelPackage.Literals.ABSTRACT_FEATURE.getEOperations().get(5)).getInvocationDelegate();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RelativeCardinality doGetRelativeCardinalityToParent()
	{
		try
		{
			return (RelativeCardinality)DO_GET_RELATIVE_CARDINALITY_TO_PARENT__EINVOCATION_DELEGATE.dynamicInvoke(this, null);
		}
		catch (InvocationTargetException ite)
		{
			throw new WrappedException(ite);
		}
	}

	/**
	 * The cached invocation delegate for the '{@link #areConsistent(fr.inria.lille.spirals.fm.featuremodel.RelativeCardinality, fr.inria.lille.spirals.fm.featuremodel.RelativeCardinality) <em>Are Consistent</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #areConsistent(fr.inria.lille.spirals.fm.featuremodel.RelativeCardinality, fr.inria.lille.spirals.fm.featuremodel.RelativeCardinality)
	 * @generated
	 * @ordered
	 */
	protected static final EOperation.Internal.InvocationDelegate ARE_CONSISTENT_RELATIVE_CARDINALITY_RELATIVE_CARDINALITY__EINVOCATION_DELEGATE = ((EOperation.Internal)FeatureModelPackage.Literals.ABSTRACT_FEATURE.getEOperations().get(6)).getInvocationDelegate();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean areConsistent(RelativeCardinality c1, RelativeCardinality c2)
	{
		try
		{
			return (Boolean)ARE_CONSISTENT_RELATIVE_CARDINALITY_RELATIVE_CARDINALITY__EINVOCATION_DELEGATE.dynamicInvoke(this, new BasicEList.UnmodifiableEList<Object>(2, new Object[]{c1, c2}));
		}
		catch (InvocationTargetException ite)
		{
			throw new WrappedException(ite);
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs)
	{
		switch (featureID)
		{
			case FeatureModelPackage.ABSTRACT_FEATURE__PARENT:
				if (eInternalContainer() != null)
					msgs = eBasicRemoveFromContainer(msgs);
				return eBasicSetContainer(otherEnd, FeatureModelPackage.ABSTRACT_FEATURE__PARENT, msgs);
			case FeatureModelPackage.ABSTRACT_FEATURE__GROUP:
				if (eInternalContainer() != null)
					msgs = eBasicRemoveFromContainer(msgs);
				return eBasicSetContainer(otherEnd, FeatureModelPackage.ABSTRACT_FEATURE__GROUP, msgs);
			case FeatureModelPackage.ABSTRACT_FEATURE__CARDINALITIES:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)getCardinalities()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
	{
		switch (featureID)
		{
			case FeatureModelPackage.ABSTRACT_FEATURE__PARENT:
				return eBasicSetContainer(null, FeatureModelPackage.ABSTRACT_FEATURE__PARENT, msgs);
			case FeatureModelPackage.ABSTRACT_FEATURE__GROUP:
				return eBasicSetContainer(null, FeatureModelPackage.ABSTRACT_FEATURE__GROUP, msgs);
			case FeatureModelPackage.ABSTRACT_FEATURE__CARDINALITIES:
				return ((InternalEList<?>)getCardinalities()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eBasicRemoveFromContainerFeature(NotificationChain msgs)
	{
		switch (eContainerFeatureID())
		{
			case FeatureModelPackage.ABSTRACT_FEATURE__PARENT:
				return eInternalContainer().eInverseRemove(this, FeatureModelPackage.FEATURE__SUB_FEATURES, Feature.class, msgs);
			case FeatureModelPackage.ABSTRACT_FEATURE__GROUP:
				return eInternalContainer().eInverseRemove(this, FeatureModelPackage.FEATURE_GROUP__VARIANTS, FeatureGroup.class, msgs);
		}
		return super.eBasicRemoveFromContainerFeature(msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType)
	{
		switch (featureID)
		{
			case FeatureModelPackage.ABSTRACT_FEATURE__NAME:
				return getName();
			case FeatureModelPackage.ABSTRACT_FEATURE__PARENT:
				return getParent();
			case FeatureModelPackage.ABSTRACT_FEATURE__GROUP:
				return getGroup();
			case FeatureModelPackage.ABSTRACT_FEATURE__CARDINALITIES:
				return getCardinalities();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue)
	{
		switch (featureID)
		{
			case FeatureModelPackage.ABSTRACT_FEATURE__NAME:
				setName((String)newValue);
				return;
			case FeatureModelPackage.ABSTRACT_FEATURE__CARDINALITIES:
				getCardinalities().clear();
				getCardinalities().addAll((Collection<? extends RelativeCardinality>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID)
	{
		switch (featureID)
		{
			case FeatureModelPackage.ABSTRACT_FEATURE__NAME:
				setName(NAME_EDEFAULT);
				return;
			case FeatureModelPackage.ABSTRACT_FEATURE__CARDINALITIES:
				getCardinalities().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID)
	{
		switch (featureID)
		{
			case FeatureModelPackage.ABSTRACT_FEATURE__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case FeatureModelPackage.ABSTRACT_FEATURE__PARENT:
				return getParent() != null;
			case FeatureModelPackage.ABSTRACT_FEATURE__GROUP:
				return getGroup() != null;
			case FeatureModelPackage.ABSTRACT_FEATURE__CARDINALITIES:
				return cardinalities != null && !cardinalities.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString()
	{
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //AbstractFeatureImpl
