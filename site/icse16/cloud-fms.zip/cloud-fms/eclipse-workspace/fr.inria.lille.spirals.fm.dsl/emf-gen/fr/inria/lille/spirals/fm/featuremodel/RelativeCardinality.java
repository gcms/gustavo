/**
 */
package fr.inria.lille.spirals.fm.featuremodel;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Relative Cardinality</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link fr.inria.lille.spirals.fm.featuremodel.RelativeCardinality#getTo <em>To</em>}</li>
 *   <li>{@link fr.inria.lille.spirals.fm.featuremodel.RelativeCardinality#getCardinality <em>Cardinality</em>}</li>
 *   <li>{@link fr.inria.lille.spirals.fm.featuremodel.RelativeCardinality#getFrom <em>From</em>}</li>
 * </ul>
 * </p>
 *
 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage#getRelativeCardinality()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='RelativeCardinalityToAncestor ValidCardinality'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot RelativeCardinalityToAncestor='\n\t\t\tfrom.isDescendantOf(doGetTo())' ValidCardinality='\n\t\t\tcardinality <> null and cardinality.max > 0'"
 * @generated
 */
public interface RelativeCardinality extends EObject
{
	/**
	 * Returns the value of the '<em><b>To</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>To</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>To</em>' reference.
	 * @see #setTo(AbstractFeature)
	 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage#getRelativeCardinality_To()
	 * @model
	 * @generated
	 */
	AbstractFeature getTo();

	/**
	 * Sets the value of the '{@link fr.inria.lille.spirals.fm.featuremodel.RelativeCardinality#getTo <em>To</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>To</em>' reference.
	 * @see #getTo()
	 * @generated
	 */
	void setTo(AbstractFeature value);

	/**
	 * Returns the value of the '<em><b>Cardinality</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Cardinality</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cardinality</em>' containment reference.
	 * @see #setCardinality(Cardinality)
	 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage#getRelativeCardinality_Cardinality()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Cardinality getCardinality();

	/**
	 * Sets the value of the '{@link fr.inria.lille.spirals.fm.featuremodel.RelativeCardinality#getCardinality <em>Cardinality</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Cardinality</em>' containment reference.
	 * @see #getCardinality()
	 * @generated
	 */
	void setCardinality(Cardinality value);

	/**
	 * Returns the value of the '<em><b>From</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link fr.inria.lille.spirals.fm.featuremodel.AbstractFeature#getCardinalities <em>Cardinalities</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>From</em>' container reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>From</em>' container reference.
	 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage#getRelativeCardinality_From()
	 * @see fr.inria.lille.spirals.fm.featuremodel.AbstractFeature#getCardinalities
	 * @model opposite="cardinalities" required="true" transient="false" changeable="false" derived="true"
	 * @generated
	 */
	AbstractFeature getFrom();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model required="true"
	 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='if to <> null then to else from.doGetParent() endif'"
	 * @generated
	 */
	AbstractFeature doGetTo();

} // RelativeCardinality
