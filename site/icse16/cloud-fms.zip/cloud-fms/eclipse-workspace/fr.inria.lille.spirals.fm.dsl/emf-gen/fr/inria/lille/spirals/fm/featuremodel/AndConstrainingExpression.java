/**
 */
package fr.inria.lille.spirals.fm.featuremodel;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>And Constraining Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage#getAndConstrainingExpression()
 * @model
 * @generated
 */
public interface AndConstrainingExpression extends ComposedConstrainingExpression
{
} // AndConstrainingExpression
