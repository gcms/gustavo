package fr.inria.lille.spirals.fm.parser.antlr.internal; 

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import fr.inria.lille.spirals.fm.services.FeatureModelGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalFeatureModelParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_STRING", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'config'", "'from'", "','", "'{'", "'}'", "'['", "'|'", "']'", "'<'", "'>'", "'..'", "'=>'", "'('", "')'", "'&'"
    };
    public static final int RULE_STRING=5;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int RULE_ID=4;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int RULE_INT=6;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalFeatureModelParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalFeatureModelParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalFeatureModelParser.tokenNames; }
    public String getGrammarFileName() { return "../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g"; }



     	private FeatureModelGrammarAccess grammarAccess;
     	
        public InternalFeatureModelParser(TokenStream input, FeatureModelGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }
        
        @Override
        protected String getFirstRuleName() {
        	return "Element";	
       	}
       	
       	@Override
       	protected FeatureModelGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}



    // $ANTLR start "entryRuleElement"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:67:1: entryRuleElement returns [EObject current=null] : iv_ruleElement= ruleElement EOF ;
    public final EObject entryRuleElement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleElement = null;


        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:68:2: (iv_ruleElement= ruleElement EOF )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:69:2: iv_ruleElement= ruleElement EOF
            {
             newCompositeNode(grammarAccess.getElementRule()); 
            pushFollow(FOLLOW_ruleElement_in_entryRuleElement75);
            iv_ruleElement=ruleElement();

            state._fsp--;

             current =iv_ruleElement; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleElement85); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleElement"


    // $ANTLR start "ruleElement"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:76:1: ruleElement returns [EObject current=null] : (this_FeatureModel_0= ruleFeatureModel | this_Configuration_1= ruleConfiguration ) ;
    public final EObject ruleElement() throws RecognitionException {
        EObject current = null;

        EObject this_FeatureModel_0 = null;

        EObject this_Configuration_1 = null;


         enterRule(); 
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:79:28: ( (this_FeatureModel_0= ruleFeatureModel | this_Configuration_1= ruleConfiguration ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:80:1: (this_FeatureModel_0= ruleFeatureModel | this_Configuration_1= ruleConfiguration )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:80:1: (this_FeatureModel_0= ruleFeatureModel | this_Configuration_1= ruleConfiguration )
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==RULE_ID) ) {
                alt1=1;
            }
            else if ( (LA1_0==11) ) {
                alt1=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }
            switch (alt1) {
                case 1 :
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:81:5: this_FeatureModel_0= ruleFeatureModel
                    {
                     
                            newCompositeNode(grammarAccess.getElementAccess().getFeatureModelParserRuleCall_0()); 
                        
                    pushFollow(FOLLOW_ruleFeatureModel_in_ruleElement132);
                    this_FeatureModel_0=ruleFeatureModel();

                    state._fsp--;

                     
                            current = this_FeatureModel_0; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;
                case 2 :
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:91:5: this_Configuration_1= ruleConfiguration
                    {
                     
                            newCompositeNode(grammarAccess.getElementAccess().getConfigurationParserRuleCall_1()); 
                        
                    pushFollow(FOLLOW_ruleConfiguration_in_ruleElement159);
                    this_Configuration_1=ruleConfiguration();

                    state._fsp--;

                     
                            current = this_Configuration_1; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleElement"


    // $ANTLR start "entryRuleConfiguration"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:107:1: entryRuleConfiguration returns [EObject current=null] : iv_ruleConfiguration= ruleConfiguration EOF ;
    public final EObject entryRuleConfiguration() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConfiguration = null;


        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:108:2: (iv_ruleConfiguration= ruleConfiguration EOF )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:109:2: iv_ruleConfiguration= ruleConfiguration EOF
            {
             newCompositeNode(grammarAccess.getConfigurationRule()); 
            pushFollow(FOLLOW_ruleConfiguration_in_entryRuleConfiguration194);
            iv_ruleConfiguration=ruleConfiguration();

            state._fsp--;

             current =iv_ruleConfiguration; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleConfiguration204); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConfiguration"


    // $ANTLR start "ruleConfiguration"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:116:1: ruleConfiguration returns [EObject current=null] : (otherlv_0= 'config' ( (otherlv_1= RULE_ID ) ) (otherlv_2= 'from' ( (lv_importURI_3_0= RULE_STRING ) ) )? ( (lv_instances_4_0= ruleInstance ) ) ( (otherlv_5= ',' )? ( (lv_instances_6_0= ruleInstance ) ) )* ) ;
    public final EObject ruleConfiguration() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token lv_importURI_3_0=null;
        Token otherlv_5=null;
        EObject lv_instances_4_0 = null;

        EObject lv_instances_6_0 = null;


         enterRule(); 
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:119:28: ( (otherlv_0= 'config' ( (otherlv_1= RULE_ID ) ) (otherlv_2= 'from' ( (lv_importURI_3_0= RULE_STRING ) ) )? ( (lv_instances_4_0= ruleInstance ) ) ( (otherlv_5= ',' )? ( (lv_instances_6_0= ruleInstance ) ) )* ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:120:1: (otherlv_0= 'config' ( (otherlv_1= RULE_ID ) ) (otherlv_2= 'from' ( (lv_importURI_3_0= RULE_STRING ) ) )? ( (lv_instances_4_0= ruleInstance ) ) ( (otherlv_5= ',' )? ( (lv_instances_6_0= ruleInstance ) ) )* )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:120:1: (otherlv_0= 'config' ( (otherlv_1= RULE_ID ) ) (otherlv_2= 'from' ( (lv_importURI_3_0= RULE_STRING ) ) )? ( (lv_instances_4_0= ruleInstance ) ) ( (otherlv_5= ',' )? ( (lv_instances_6_0= ruleInstance ) ) )* )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:120:3: otherlv_0= 'config' ( (otherlv_1= RULE_ID ) ) (otherlv_2= 'from' ( (lv_importURI_3_0= RULE_STRING ) ) )? ( (lv_instances_4_0= ruleInstance ) ) ( (otherlv_5= ',' )? ( (lv_instances_6_0= ruleInstance ) ) )*
            {
            otherlv_0=(Token)match(input,11,FOLLOW_11_in_ruleConfiguration241); 

                	newLeafNode(otherlv_0, grammarAccess.getConfigurationAccess().getConfigKeyword_0());
                
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:124:1: ( (otherlv_1= RULE_ID ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:125:1: (otherlv_1= RULE_ID )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:125:1: (otherlv_1= RULE_ID )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:126:3: otherlv_1= RULE_ID
            {

            			if (current==null) {
            	            current = createModelElement(grammarAccess.getConfigurationRule());
            	        }
                    
            otherlv_1=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleConfiguration261); 

            		newLeafNode(otherlv_1, grammarAccess.getConfigurationAccess().getFeatureModelFeatureModelCrossReference_1_0()); 
            	

            }


            }

            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:137:2: (otherlv_2= 'from' ( (lv_importURI_3_0= RULE_STRING ) ) )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==12) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:137:4: otherlv_2= 'from' ( (lv_importURI_3_0= RULE_STRING ) )
                    {
                    otherlv_2=(Token)match(input,12,FOLLOW_12_in_ruleConfiguration274); 

                        	newLeafNode(otherlv_2, grammarAccess.getConfigurationAccess().getFromKeyword_2_0());
                        
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:141:1: ( (lv_importURI_3_0= RULE_STRING ) )
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:142:1: (lv_importURI_3_0= RULE_STRING )
                    {
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:142:1: (lv_importURI_3_0= RULE_STRING )
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:143:3: lv_importURI_3_0= RULE_STRING
                    {
                    lv_importURI_3_0=(Token)match(input,RULE_STRING,FOLLOW_RULE_STRING_in_ruleConfiguration291); 

                    			newLeafNode(lv_importURI_3_0, grammarAccess.getConfigurationAccess().getImportURISTRINGTerminalRuleCall_2_1_0()); 
                    		

                    	        if (current==null) {
                    	            current = createModelElement(grammarAccess.getConfigurationRule());
                    	        }
                           		setWithLastConsumed(
                           			current, 
                           			"importURI",
                            		lv_importURI_3_0, 
                            		"STRING");
                    	    

                    }


                    }


                    }
                    break;

            }

            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:159:4: ( (lv_instances_4_0= ruleInstance ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:160:1: (lv_instances_4_0= ruleInstance )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:160:1: (lv_instances_4_0= ruleInstance )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:161:3: lv_instances_4_0= ruleInstance
            {
             
            	        newCompositeNode(grammarAccess.getConfigurationAccess().getInstancesInstanceParserRuleCall_3_0()); 
            	    
            pushFollow(FOLLOW_ruleInstance_in_ruleConfiguration319);
            lv_instances_4_0=ruleInstance();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getConfigurationRule());
            	        }
                   		add(
                   			current, 
                   			"instances",
                    		lv_instances_4_0, 
                    		"Instance");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:177:2: ( (otherlv_5= ',' )? ( (lv_instances_6_0= ruleInstance ) ) )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0==RULE_ID||LA4_0==RULE_INT||LA4_0==13) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:177:3: (otherlv_5= ',' )? ( (lv_instances_6_0= ruleInstance ) )
            	    {
            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:177:3: (otherlv_5= ',' )?
            	    int alt3=2;
            	    int LA3_0 = input.LA(1);

            	    if ( (LA3_0==13) ) {
            	        alt3=1;
            	    }
            	    switch (alt3) {
            	        case 1 :
            	            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:177:5: otherlv_5= ','
            	            {
            	            otherlv_5=(Token)match(input,13,FOLLOW_13_in_ruleConfiguration333); 

            	                	newLeafNode(otherlv_5, grammarAccess.getConfigurationAccess().getCommaKeyword_4_0());
            	                

            	            }
            	            break;

            	    }

            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:181:3: ( (lv_instances_6_0= ruleInstance ) )
            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:182:1: (lv_instances_6_0= ruleInstance )
            	    {
            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:182:1: (lv_instances_6_0= ruleInstance )
            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:183:3: lv_instances_6_0= ruleInstance
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getConfigurationAccess().getInstancesInstanceParserRuleCall_4_1_0()); 
            	    	    
            	    pushFollow(FOLLOW_ruleInstance_in_ruleConfiguration356);
            	    lv_instances_6_0=ruleInstance();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getConfigurationRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"instances",
            	            		lv_instances_6_0, 
            	            		"Instance");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConfiguration"


    // $ANTLR start "entryRuleInstance"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:207:1: entryRuleInstance returns [EObject current=null] : iv_ruleInstance= ruleInstance EOF ;
    public final EObject entryRuleInstance() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInstance = null;


        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:208:2: (iv_ruleInstance= ruleInstance EOF )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:209:2: iv_ruleInstance= ruleInstance EOF
            {
             newCompositeNode(grammarAccess.getInstanceRule()); 
            pushFollow(FOLLOW_ruleInstance_in_entryRuleInstance394);
            iv_ruleInstance=ruleInstance();

            state._fsp--;

             current =iv_ruleInstance; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleInstance404); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInstance"


    // $ANTLR start "ruleInstance"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:216:1: ruleInstance returns [EObject current=null] : ( ( (lv_number_0_0= RULE_INT ) )? ( (otherlv_1= RULE_ID ) ) (otherlv_2= '{' ( (lv_children_3_0= ruleInstance ) ) ( (otherlv_4= ',' )? ( (lv_children_5_0= ruleInstance ) ) )* otherlv_6= '}' )? ) ;
    public final EObject ruleInstance() throws RecognitionException {
        EObject current = null;

        Token lv_number_0_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        EObject lv_children_3_0 = null;

        EObject lv_children_5_0 = null;


         enterRule(); 
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:219:28: ( ( ( (lv_number_0_0= RULE_INT ) )? ( (otherlv_1= RULE_ID ) ) (otherlv_2= '{' ( (lv_children_3_0= ruleInstance ) ) ( (otherlv_4= ',' )? ( (lv_children_5_0= ruleInstance ) ) )* otherlv_6= '}' )? ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:220:1: ( ( (lv_number_0_0= RULE_INT ) )? ( (otherlv_1= RULE_ID ) ) (otherlv_2= '{' ( (lv_children_3_0= ruleInstance ) ) ( (otherlv_4= ',' )? ( (lv_children_5_0= ruleInstance ) ) )* otherlv_6= '}' )? )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:220:1: ( ( (lv_number_0_0= RULE_INT ) )? ( (otherlv_1= RULE_ID ) ) (otherlv_2= '{' ( (lv_children_3_0= ruleInstance ) ) ( (otherlv_4= ',' )? ( (lv_children_5_0= ruleInstance ) ) )* otherlv_6= '}' )? )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:220:2: ( (lv_number_0_0= RULE_INT ) )? ( (otherlv_1= RULE_ID ) ) (otherlv_2= '{' ( (lv_children_3_0= ruleInstance ) ) ( (otherlv_4= ',' )? ( (lv_children_5_0= ruleInstance ) ) )* otherlv_6= '}' )?
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:220:2: ( (lv_number_0_0= RULE_INT ) )?
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==RULE_INT) ) {
                alt5=1;
            }
            switch (alt5) {
                case 1 :
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:221:1: (lv_number_0_0= RULE_INT )
                    {
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:221:1: (lv_number_0_0= RULE_INT )
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:222:3: lv_number_0_0= RULE_INT
                    {
                    lv_number_0_0=(Token)match(input,RULE_INT,FOLLOW_RULE_INT_in_ruleInstance446); 

                    			newLeafNode(lv_number_0_0, grammarAccess.getInstanceAccess().getNumberINTTerminalRuleCall_0_0()); 
                    		

                    	        if (current==null) {
                    	            current = createModelElement(grammarAccess.getInstanceRule());
                    	        }
                           		setWithLastConsumed(
                           			current, 
                           			"number",
                            		lv_number_0_0, 
                            		"INT");
                    	    

                    }


                    }
                    break;

            }

            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:238:3: ( (otherlv_1= RULE_ID ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:239:1: (otherlv_1= RULE_ID )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:239:1: (otherlv_1= RULE_ID )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:240:3: otherlv_1= RULE_ID
            {

            			if (current==null) {
            	            current = createModelElement(grammarAccess.getInstanceRule());
            	        }
                    
            otherlv_1=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleInstance472); 

            		newLeafNode(otherlv_1, grammarAccess.getInstanceAccess().getTypeAbstractFeatureCrossReference_1_0()); 
            	

            }


            }

            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:251:2: (otherlv_2= '{' ( (lv_children_3_0= ruleInstance ) ) ( (otherlv_4= ',' )? ( (lv_children_5_0= ruleInstance ) ) )* otherlv_6= '}' )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==14) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:251:4: otherlv_2= '{' ( (lv_children_3_0= ruleInstance ) ) ( (otherlv_4= ',' )? ( (lv_children_5_0= ruleInstance ) ) )* otherlv_6= '}'
                    {
                    otherlv_2=(Token)match(input,14,FOLLOW_14_in_ruleInstance485); 

                        	newLeafNode(otherlv_2, grammarAccess.getInstanceAccess().getLeftCurlyBracketKeyword_2_0());
                        
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:255:1: ( (lv_children_3_0= ruleInstance ) )
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:256:1: (lv_children_3_0= ruleInstance )
                    {
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:256:1: (lv_children_3_0= ruleInstance )
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:257:3: lv_children_3_0= ruleInstance
                    {
                     
                    	        newCompositeNode(grammarAccess.getInstanceAccess().getChildrenInstanceParserRuleCall_2_1_0()); 
                    	    
                    pushFollow(FOLLOW_ruleInstance_in_ruleInstance506);
                    lv_children_3_0=ruleInstance();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getInstanceRule());
                    	        }
                           		add(
                           			current, 
                           			"children",
                            		lv_children_3_0, 
                            		"Instance");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }

                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:273:2: ( (otherlv_4= ',' )? ( (lv_children_5_0= ruleInstance ) ) )*
                    loop7:
                    do {
                        int alt7=2;
                        int LA7_0 = input.LA(1);

                        if ( (LA7_0==RULE_ID||LA7_0==RULE_INT||LA7_0==13) ) {
                            alt7=1;
                        }


                        switch (alt7) {
                    	case 1 :
                    	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:273:3: (otherlv_4= ',' )? ( (lv_children_5_0= ruleInstance ) )
                    	    {
                    	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:273:3: (otherlv_4= ',' )?
                    	    int alt6=2;
                    	    int LA6_0 = input.LA(1);

                    	    if ( (LA6_0==13) ) {
                    	        alt6=1;
                    	    }
                    	    switch (alt6) {
                    	        case 1 :
                    	            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:273:5: otherlv_4= ','
                    	            {
                    	            otherlv_4=(Token)match(input,13,FOLLOW_13_in_ruleInstance520); 

                    	                	newLeafNode(otherlv_4, grammarAccess.getInstanceAccess().getCommaKeyword_2_2_0());
                    	                

                    	            }
                    	            break;

                    	    }

                    	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:277:3: ( (lv_children_5_0= ruleInstance ) )
                    	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:278:1: (lv_children_5_0= ruleInstance )
                    	    {
                    	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:278:1: (lv_children_5_0= ruleInstance )
                    	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:279:3: lv_children_5_0= ruleInstance
                    	    {
                    	     
                    	    	        newCompositeNode(grammarAccess.getInstanceAccess().getChildrenInstanceParserRuleCall_2_2_1_0()); 
                    	    	    
                    	    pushFollow(FOLLOW_ruleInstance_in_ruleInstance543);
                    	    lv_children_5_0=ruleInstance();

                    	    state._fsp--;


                    	    	        if (current==null) {
                    	    	            current = createModelElementForParent(grammarAccess.getInstanceRule());
                    	    	        }
                    	           		add(
                    	           			current, 
                    	           			"children",
                    	            		lv_children_5_0, 
                    	            		"Instance");
                    	    	        afterParserOrEnumRuleCall();
                    	    	    

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop7;
                        }
                    } while (true);

                    otherlv_6=(Token)match(input,15,FOLLOW_15_in_ruleInstance557); 

                        	newLeafNode(otherlv_6, grammarAccess.getInstanceAccess().getRightCurlyBracketKeyword_2_3());
                        

                    }
                    break;

            }


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInstance"


    // $ANTLR start "entryRuleFeatureModel"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:307:1: entryRuleFeatureModel returns [EObject current=null] : iv_ruleFeatureModel= ruleFeatureModel EOF ;
    public final EObject entryRuleFeatureModel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFeatureModel = null;


        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:308:2: (iv_ruleFeatureModel= ruleFeatureModel EOF )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:309:2: iv_ruleFeatureModel= ruleFeatureModel EOF
            {
             newCompositeNode(grammarAccess.getFeatureModelRule()); 
            pushFollow(FOLLOW_ruleFeatureModel_in_entryRuleFeatureModel595);
            iv_ruleFeatureModel=ruleFeatureModel();

            state._fsp--;

             current =iv_ruleFeatureModel; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleFeatureModel605); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFeatureModel"


    // $ANTLR start "ruleFeatureModel"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:316:1: ruleFeatureModel returns [EObject current=null] : ( ( (lv_root_0_0= ruleFeature ) ) ( (lv_constraints_1_0= ruleConstraint ) )* ) ;
    public final EObject ruleFeatureModel() throws RecognitionException {
        EObject current = null;

        EObject lv_root_0_0 = null;

        EObject lv_constraints_1_0 = null;


         enterRule(); 
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:319:28: ( ( ( (lv_root_0_0= ruleFeature ) ) ( (lv_constraints_1_0= ruleConstraint ) )* ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:320:1: ( ( (lv_root_0_0= ruleFeature ) ) ( (lv_constraints_1_0= ruleConstraint ) )* )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:320:1: ( ( (lv_root_0_0= ruleFeature ) ) ( (lv_constraints_1_0= ruleConstraint ) )* )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:320:2: ( (lv_root_0_0= ruleFeature ) ) ( (lv_constraints_1_0= ruleConstraint ) )*
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:320:2: ( (lv_root_0_0= ruleFeature ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:321:1: (lv_root_0_0= ruleFeature )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:321:1: (lv_root_0_0= ruleFeature )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:322:3: lv_root_0_0= ruleFeature
            {
             
            	        newCompositeNode(grammarAccess.getFeatureModelAccess().getRootFeatureParserRuleCall_0_0()); 
            	    
            pushFollow(FOLLOW_ruleFeature_in_ruleFeatureModel651);
            lv_root_0_0=ruleFeature();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getFeatureModelRule());
            	        }
                   		set(
                   			current, 
                   			"root",
                    		lv_root_0_0, 
                    		"Feature");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:338:2: ( (lv_constraints_1_0= ruleConstraint ) )*
            loop9:
            do {
                int alt9=2;
                int LA9_0 = input.LA(1);

                if ( (LA9_0==19) ) {
                    alt9=1;
                }


                switch (alt9) {
            	case 1 :
            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:339:1: (lv_constraints_1_0= ruleConstraint )
            	    {
            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:339:1: (lv_constraints_1_0= ruleConstraint )
            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:340:3: lv_constraints_1_0= ruleConstraint
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getFeatureModelAccess().getConstraintsConstraintParserRuleCall_1_0()); 
            	    	    
            	    pushFollow(FOLLOW_ruleConstraint_in_ruleFeatureModel672);
            	    lv_constraints_1_0=ruleConstraint();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getFeatureModelRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"constraints",
            	            		lv_constraints_1_0, 
            	            		"Constraint");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    break loop9;
                }
            } while (true);


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFeatureModel"


    // $ANTLR start "entryRuleAbstractFeature"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:364:1: entryRuleAbstractFeature returns [EObject current=null] : iv_ruleAbstractFeature= ruleAbstractFeature EOF ;
    public final EObject entryRuleAbstractFeature() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAbstractFeature = null;


        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:365:2: (iv_ruleAbstractFeature= ruleAbstractFeature EOF )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:366:2: iv_ruleAbstractFeature= ruleAbstractFeature EOF
            {
             newCompositeNode(grammarAccess.getAbstractFeatureRule()); 
            pushFollow(FOLLOW_ruleAbstractFeature_in_entryRuleAbstractFeature709);
            iv_ruleAbstractFeature=ruleAbstractFeature();

            state._fsp--;

             current =iv_ruleAbstractFeature; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleAbstractFeature719); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAbstractFeature"


    // $ANTLR start "ruleAbstractFeature"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:373:1: ruleAbstractFeature returns [EObject current=null] : (this_Feature_0= ruleFeature | this_FeatureGroup_1= ruleFeatureGroup ) ;
    public final EObject ruleAbstractFeature() throws RecognitionException {
        EObject current = null;

        EObject this_Feature_0 = null;

        EObject this_FeatureGroup_1 = null;


         enterRule(); 
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:376:28: ( (this_Feature_0= ruleFeature | this_FeatureGroup_1= ruleFeatureGroup ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:377:1: (this_Feature_0= ruleFeature | this_FeatureGroup_1= ruleFeatureGroup )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:377:1: (this_Feature_0= ruleFeature | this_FeatureGroup_1= ruleFeatureGroup )
            int alt10=2;
            alt10 = dfa10.predict(input);
            switch (alt10) {
                case 1 :
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:378:5: this_Feature_0= ruleFeature
                    {
                     
                            newCompositeNode(grammarAccess.getAbstractFeatureAccess().getFeatureParserRuleCall_0()); 
                        
                    pushFollow(FOLLOW_ruleFeature_in_ruleAbstractFeature766);
                    this_Feature_0=ruleFeature();

                    state._fsp--;

                     
                            current = this_Feature_0; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;
                case 2 :
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:388:5: this_FeatureGroup_1= ruleFeatureGroup
                    {
                     
                            newCompositeNode(grammarAccess.getAbstractFeatureAccess().getFeatureGroupParserRuleCall_1()); 
                        
                    pushFollow(FOLLOW_ruleFeatureGroup_in_ruleAbstractFeature793);
                    this_FeatureGroup_1=ruleFeatureGroup();

                    state._fsp--;

                     
                            current = this_FeatureGroup_1; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAbstractFeature"


    // $ANTLR start "entryRuleFeature"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:404:1: entryRuleFeature returns [EObject current=null] : iv_ruleFeature= ruleFeature EOF ;
    public final EObject entryRuleFeature() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFeature = null;


        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:405:2: (iv_ruleFeature= ruleFeature EOF )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:406:2: iv_ruleFeature= ruleFeature EOF
            {
             newCompositeNode(grammarAccess.getFeatureRule()); 
            pushFollow(FOLLOW_ruleFeature_in_entryRuleFeature828);
            iv_ruleFeature=ruleFeature();

            state._fsp--;

             current =iv_ruleFeature; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleFeature838); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFeature"


    // $ANTLR start "ruleFeature"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:413:1: ruleFeature returns [EObject current=null] : ( ( (lv_name_0_0= RULE_ID ) ) ( (lv_cardinalities_1_0= ruleRelativeCardinalityDirect ) )? ( (lv_cardinalities_2_0= ruleRelativeCardinalityToUpper ) )* (otherlv_3= '{' ( (lv_subFeatures_4_0= ruleAbstractFeature ) ) ( (otherlv_5= ',' )? ( (lv_subFeatures_6_0= ruleAbstractFeature ) ) )* otherlv_7= '}' )? ) ;
    public final EObject ruleFeature() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_0=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        EObject lv_cardinalities_1_0 = null;

        EObject lv_cardinalities_2_0 = null;

        EObject lv_subFeatures_4_0 = null;

        EObject lv_subFeatures_6_0 = null;


         enterRule(); 
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:416:28: ( ( ( (lv_name_0_0= RULE_ID ) ) ( (lv_cardinalities_1_0= ruleRelativeCardinalityDirect ) )? ( (lv_cardinalities_2_0= ruleRelativeCardinalityToUpper ) )* (otherlv_3= '{' ( (lv_subFeatures_4_0= ruleAbstractFeature ) ) ( (otherlv_5= ',' )? ( (lv_subFeatures_6_0= ruleAbstractFeature ) ) )* otherlv_7= '}' )? ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:417:1: ( ( (lv_name_0_0= RULE_ID ) ) ( (lv_cardinalities_1_0= ruleRelativeCardinalityDirect ) )? ( (lv_cardinalities_2_0= ruleRelativeCardinalityToUpper ) )* (otherlv_3= '{' ( (lv_subFeatures_4_0= ruleAbstractFeature ) ) ( (otherlv_5= ',' )? ( (lv_subFeatures_6_0= ruleAbstractFeature ) ) )* otherlv_7= '}' )? )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:417:1: ( ( (lv_name_0_0= RULE_ID ) ) ( (lv_cardinalities_1_0= ruleRelativeCardinalityDirect ) )? ( (lv_cardinalities_2_0= ruleRelativeCardinalityToUpper ) )* (otherlv_3= '{' ( (lv_subFeatures_4_0= ruleAbstractFeature ) ) ( (otherlv_5= ',' )? ( (lv_subFeatures_6_0= ruleAbstractFeature ) ) )* otherlv_7= '}' )? )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:417:2: ( (lv_name_0_0= RULE_ID ) ) ( (lv_cardinalities_1_0= ruleRelativeCardinalityDirect ) )? ( (lv_cardinalities_2_0= ruleRelativeCardinalityToUpper ) )* (otherlv_3= '{' ( (lv_subFeatures_4_0= ruleAbstractFeature ) ) ( (otherlv_5= ',' )? ( (lv_subFeatures_6_0= ruleAbstractFeature ) ) )* otherlv_7= '}' )?
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:417:2: ( (lv_name_0_0= RULE_ID ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:418:1: (lv_name_0_0= RULE_ID )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:418:1: (lv_name_0_0= RULE_ID )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:419:3: lv_name_0_0= RULE_ID
            {
            lv_name_0_0=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleFeature880); 

            			newLeafNode(lv_name_0_0, grammarAccess.getFeatureAccess().getNameIDTerminalRuleCall_0_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getFeatureRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_0_0, 
                    		"ID");
            	    

            }


            }

            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:435:2: ( (lv_cardinalities_1_0= ruleRelativeCardinalityDirect ) )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==16) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:436:1: (lv_cardinalities_1_0= ruleRelativeCardinalityDirect )
                    {
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:436:1: (lv_cardinalities_1_0= ruleRelativeCardinalityDirect )
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:437:3: lv_cardinalities_1_0= ruleRelativeCardinalityDirect
                    {
                     
                    	        newCompositeNode(grammarAccess.getFeatureAccess().getCardinalitiesRelativeCardinalityDirectParserRuleCall_1_0()); 
                    	    
                    pushFollow(FOLLOW_ruleRelativeCardinalityDirect_in_ruleFeature906);
                    lv_cardinalities_1_0=ruleRelativeCardinalityDirect();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getFeatureRule());
                    	        }
                           		add(
                           			current, 
                           			"cardinalities",
                            		lv_cardinalities_1_0, 
                            		"RelativeCardinalityDirect");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }
                    break;

            }

            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:453:3: ( (lv_cardinalities_2_0= ruleRelativeCardinalityToUpper ) )*
            loop12:
            do {
                int alt12=2;
                alt12 = dfa12.predict(input);
                switch (alt12) {
            	case 1 :
            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:454:1: (lv_cardinalities_2_0= ruleRelativeCardinalityToUpper )
            	    {
            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:454:1: (lv_cardinalities_2_0= ruleRelativeCardinalityToUpper )
            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:455:3: lv_cardinalities_2_0= ruleRelativeCardinalityToUpper
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getFeatureAccess().getCardinalitiesRelativeCardinalityToUpperParserRuleCall_2_0()); 
            	    	    
            	    pushFollow(FOLLOW_ruleRelativeCardinalityToUpper_in_ruleFeature928);
            	    lv_cardinalities_2_0=ruleRelativeCardinalityToUpper();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getFeatureRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"cardinalities",
            	            		lv_cardinalities_2_0, 
            	            		"RelativeCardinalityToUpper");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);

            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:471:3: (otherlv_3= '{' ( (lv_subFeatures_4_0= ruleAbstractFeature ) ) ( (otherlv_5= ',' )? ( (lv_subFeatures_6_0= ruleAbstractFeature ) ) )* otherlv_7= '}' )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==14) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:471:5: otherlv_3= '{' ( (lv_subFeatures_4_0= ruleAbstractFeature ) ) ( (otherlv_5= ',' )? ( (lv_subFeatures_6_0= ruleAbstractFeature ) ) )* otherlv_7= '}'
                    {
                    otherlv_3=(Token)match(input,14,FOLLOW_14_in_ruleFeature942); 

                        	newLeafNode(otherlv_3, grammarAccess.getFeatureAccess().getLeftCurlyBracketKeyword_3_0());
                        
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:475:1: ( (lv_subFeatures_4_0= ruleAbstractFeature ) )
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:476:1: (lv_subFeatures_4_0= ruleAbstractFeature )
                    {
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:476:1: (lv_subFeatures_4_0= ruleAbstractFeature )
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:477:3: lv_subFeatures_4_0= ruleAbstractFeature
                    {
                     
                    	        newCompositeNode(grammarAccess.getFeatureAccess().getSubFeaturesAbstractFeatureParserRuleCall_3_1_0()); 
                    	    
                    pushFollow(FOLLOW_ruleAbstractFeature_in_ruleFeature963);
                    lv_subFeatures_4_0=ruleAbstractFeature();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getFeatureRule());
                    	        }
                           		add(
                           			current, 
                           			"subFeatures",
                            		lv_subFeatures_4_0, 
                            		"AbstractFeature");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }

                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:493:2: ( (otherlv_5= ',' )? ( (lv_subFeatures_6_0= ruleAbstractFeature ) ) )*
                    loop14:
                    do {
                        int alt14=2;
                        int LA14_0 = input.LA(1);

                        if ( (LA14_0==RULE_ID||LA14_0==13) ) {
                            alt14=1;
                        }


                        switch (alt14) {
                    	case 1 :
                    	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:493:3: (otherlv_5= ',' )? ( (lv_subFeatures_6_0= ruleAbstractFeature ) )
                    	    {
                    	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:493:3: (otherlv_5= ',' )?
                    	    int alt13=2;
                    	    int LA13_0 = input.LA(1);

                    	    if ( (LA13_0==13) ) {
                    	        alt13=1;
                    	    }
                    	    switch (alt13) {
                    	        case 1 :
                    	            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:493:5: otherlv_5= ','
                    	            {
                    	            otherlv_5=(Token)match(input,13,FOLLOW_13_in_ruleFeature977); 

                    	                	newLeafNode(otherlv_5, grammarAccess.getFeatureAccess().getCommaKeyword_3_2_0());
                    	                

                    	            }
                    	            break;

                    	    }

                    	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:497:3: ( (lv_subFeatures_6_0= ruleAbstractFeature ) )
                    	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:498:1: (lv_subFeatures_6_0= ruleAbstractFeature )
                    	    {
                    	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:498:1: (lv_subFeatures_6_0= ruleAbstractFeature )
                    	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:499:3: lv_subFeatures_6_0= ruleAbstractFeature
                    	    {
                    	     
                    	    	        newCompositeNode(grammarAccess.getFeatureAccess().getSubFeaturesAbstractFeatureParserRuleCall_3_2_1_0()); 
                    	    	    
                    	    pushFollow(FOLLOW_ruleAbstractFeature_in_ruleFeature1000);
                    	    lv_subFeatures_6_0=ruleAbstractFeature();

                    	    state._fsp--;


                    	    	        if (current==null) {
                    	    	            current = createModelElementForParent(grammarAccess.getFeatureRule());
                    	    	        }
                    	           		add(
                    	           			current, 
                    	           			"subFeatures",
                    	            		lv_subFeatures_6_0, 
                    	            		"AbstractFeature");
                    	    	        afterParserOrEnumRuleCall();
                    	    	    

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop14;
                        }
                    } while (true);

                    otherlv_7=(Token)match(input,15,FOLLOW_15_in_ruleFeature1014); 

                        	newLeafNode(otherlv_7, grammarAccess.getFeatureAccess().getRightCurlyBracketKeyword_3_3());
                        

                    }
                    break;

            }


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFeature"


    // $ANTLR start "entryRuleFeatureGroup"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:527:1: entryRuleFeatureGroup returns [EObject current=null] : iv_ruleFeatureGroup= ruleFeatureGroup EOF ;
    public final EObject entryRuleFeatureGroup() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFeatureGroup = null;


        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:528:2: (iv_ruleFeatureGroup= ruleFeatureGroup EOF )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:529:2: iv_ruleFeatureGroup= ruleFeatureGroup EOF
            {
             newCompositeNode(grammarAccess.getFeatureGroupRule()); 
            pushFollow(FOLLOW_ruleFeatureGroup_in_entryRuleFeatureGroup1052);
            iv_ruleFeatureGroup=ruleFeatureGroup();

            state._fsp--;

             current =iv_ruleFeatureGroup; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleFeatureGroup1062); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFeatureGroup"


    // $ANTLR start "ruleFeatureGroup"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:536:1: ruleFeatureGroup returns [EObject current=null] : ( ( (lv_name_0_0= RULE_ID ) ) ( (lv_cardinalities_1_0= ruleRelativeCardinalityDirect ) )? ( (lv_cardinalities_2_0= ruleRelativeCardinalityToUpper ) )* ( (lv_groupCardinality_3_0= ruleGroupCardinality ) ) otherlv_4= '[' ( (lv_variants_5_0= ruleAbstractFeature ) ) ( (otherlv_6= '|' )? ( (lv_variants_7_0= ruleAbstractFeature ) ) )+ otherlv_8= ']' ) ;
    public final EObject ruleFeatureGroup() throws RecognitionException {
        EObject current = null;

        Token lv_name_0_0=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        EObject lv_cardinalities_1_0 = null;

        EObject lv_cardinalities_2_0 = null;

        EObject lv_groupCardinality_3_0 = null;

        EObject lv_variants_5_0 = null;

        EObject lv_variants_7_0 = null;


         enterRule(); 
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:539:28: ( ( ( (lv_name_0_0= RULE_ID ) ) ( (lv_cardinalities_1_0= ruleRelativeCardinalityDirect ) )? ( (lv_cardinalities_2_0= ruleRelativeCardinalityToUpper ) )* ( (lv_groupCardinality_3_0= ruleGroupCardinality ) ) otherlv_4= '[' ( (lv_variants_5_0= ruleAbstractFeature ) ) ( (otherlv_6= '|' )? ( (lv_variants_7_0= ruleAbstractFeature ) ) )+ otherlv_8= ']' ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:540:1: ( ( (lv_name_0_0= RULE_ID ) ) ( (lv_cardinalities_1_0= ruleRelativeCardinalityDirect ) )? ( (lv_cardinalities_2_0= ruleRelativeCardinalityToUpper ) )* ( (lv_groupCardinality_3_0= ruleGroupCardinality ) ) otherlv_4= '[' ( (lv_variants_5_0= ruleAbstractFeature ) ) ( (otherlv_6= '|' )? ( (lv_variants_7_0= ruleAbstractFeature ) ) )+ otherlv_8= ']' )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:540:1: ( ( (lv_name_0_0= RULE_ID ) ) ( (lv_cardinalities_1_0= ruleRelativeCardinalityDirect ) )? ( (lv_cardinalities_2_0= ruleRelativeCardinalityToUpper ) )* ( (lv_groupCardinality_3_0= ruleGroupCardinality ) ) otherlv_4= '[' ( (lv_variants_5_0= ruleAbstractFeature ) ) ( (otherlv_6= '|' )? ( (lv_variants_7_0= ruleAbstractFeature ) ) )+ otherlv_8= ']' )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:540:2: ( (lv_name_0_0= RULE_ID ) ) ( (lv_cardinalities_1_0= ruleRelativeCardinalityDirect ) )? ( (lv_cardinalities_2_0= ruleRelativeCardinalityToUpper ) )* ( (lv_groupCardinality_3_0= ruleGroupCardinality ) ) otherlv_4= '[' ( (lv_variants_5_0= ruleAbstractFeature ) ) ( (otherlv_6= '|' )? ( (lv_variants_7_0= ruleAbstractFeature ) ) )+ otherlv_8= ']'
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:540:2: ( (lv_name_0_0= RULE_ID ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:541:1: (lv_name_0_0= RULE_ID )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:541:1: (lv_name_0_0= RULE_ID )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:542:3: lv_name_0_0= RULE_ID
            {
            lv_name_0_0=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleFeatureGroup1104); 

            			newLeafNode(lv_name_0_0, grammarAccess.getFeatureGroupAccess().getNameIDTerminalRuleCall_0_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getFeatureGroupRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"name",
                    		lv_name_0_0, 
                    		"ID");
            	    

            }


            }

            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:558:2: ( (lv_cardinalities_1_0= ruleRelativeCardinalityDirect ) )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==16) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:559:1: (lv_cardinalities_1_0= ruleRelativeCardinalityDirect )
                    {
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:559:1: (lv_cardinalities_1_0= ruleRelativeCardinalityDirect )
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:560:3: lv_cardinalities_1_0= ruleRelativeCardinalityDirect
                    {
                     
                    	        newCompositeNode(grammarAccess.getFeatureGroupAccess().getCardinalitiesRelativeCardinalityDirectParserRuleCall_1_0()); 
                    	    
                    pushFollow(FOLLOW_ruleRelativeCardinalityDirect_in_ruleFeatureGroup1130);
                    lv_cardinalities_1_0=ruleRelativeCardinalityDirect();

                    state._fsp--;


                    	        if (current==null) {
                    	            current = createModelElementForParent(grammarAccess.getFeatureGroupRule());
                    	        }
                           		add(
                           			current, 
                           			"cardinalities",
                            		lv_cardinalities_1_0, 
                            		"RelativeCardinalityDirect");
                    	        afterParserOrEnumRuleCall();
                    	    

                    }


                    }
                    break;

            }

            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:576:3: ( (lv_cardinalities_2_0= ruleRelativeCardinalityToUpper ) )*
            loop17:
            do {
                int alt17=2;
                int LA17_0 = input.LA(1);

                if ( (LA17_0==19) ) {
                    int LA17_1 = input.LA(2);

                    if ( (LA17_1==RULE_ID) ) {
                        alt17=1;
                    }


                }


                switch (alt17) {
            	case 1 :
            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:577:1: (lv_cardinalities_2_0= ruleRelativeCardinalityToUpper )
            	    {
            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:577:1: (lv_cardinalities_2_0= ruleRelativeCardinalityToUpper )
            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:578:3: lv_cardinalities_2_0= ruleRelativeCardinalityToUpper
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getFeatureGroupAccess().getCardinalitiesRelativeCardinalityToUpperParserRuleCall_2_0()); 
            	    	    
            	    pushFollow(FOLLOW_ruleRelativeCardinalityToUpper_in_ruleFeatureGroup1152);
            	    lv_cardinalities_2_0=ruleRelativeCardinalityToUpper();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getFeatureGroupRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"cardinalities",
            	            		lv_cardinalities_2_0, 
            	            		"RelativeCardinalityToUpper");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }
            	    break;

            	default :
            	    break loop17;
                }
            } while (true);

            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:594:3: ( (lv_groupCardinality_3_0= ruleGroupCardinality ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:595:1: (lv_groupCardinality_3_0= ruleGroupCardinality )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:595:1: (lv_groupCardinality_3_0= ruleGroupCardinality )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:596:3: lv_groupCardinality_3_0= ruleGroupCardinality
            {
             
            	        newCompositeNode(grammarAccess.getFeatureGroupAccess().getGroupCardinalityGroupCardinalityParserRuleCall_3_0()); 
            	    
            pushFollow(FOLLOW_ruleGroupCardinality_in_ruleFeatureGroup1174);
            lv_groupCardinality_3_0=ruleGroupCardinality();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getFeatureGroupRule());
            	        }
                   		set(
                   			current, 
                   			"groupCardinality",
                    		lv_groupCardinality_3_0, 
                    		"GroupCardinality");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_4=(Token)match(input,16,FOLLOW_16_in_ruleFeatureGroup1186); 

                	newLeafNode(otherlv_4, grammarAccess.getFeatureGroupAccess().getLeftSquareBracketKeyword_4());
                
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:616:1: ( (lv_variants_5_0= ruleAbstractFeature ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:617:1: (lv_variants_5_0= ruleAbstractFeature )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:617:1: (lv_variants_5_0= ruleAbstractFeature )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:618:3: lv_variants_5_0= ruleAbstractFeature
            {
             
            	        newCompositeNode(grammarAccess.getFeatureGroupAccess().getVariantsAbstractFeatureParserRuleCall_5_0()); 
            	    
            pushFollow(FOLLOW_ruleAbstractFeature_in_ruleFeatureGroup1207);
            lv_variants_5_0=ruleAbstractFeature();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getFeatureGroupRule());
            	        }
                   		add(
                   			current, 
                   			"variants",
                    		lv_variants_5_0, 
                    		"AbstractFeature");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:634:2: ( (otherlv_6= '|' )? ( (lv_variants_7_0= ruleAbstractFeature ) ) )+
            int cnt19=0;
            loop19:
            do {
                int alt19=2;
                int LA19_0 = input.LA(1);

                if ( (LA19_0==RULE_ID||LA19_0==17) ) {
                    alt19=1;
                }


                switch (alt19) {
            	case 1 :
            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:634:3: (otherlv_6= '|' )? ( (lv_variants_7_0= ruleAbstractFeature ) )
            	    {
            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:634:3: (otherlv_6= '|' )?
            	    int alt18=2;
            	    int LA18_0 = input.LA(1);

            	    if ( (LA18_0==17) ) {
            	        alt18=1;
            	    }
            	    switch (alt18) {
            	        case 1 :
            	            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:634:5: otherlv_6= '|'
            	            {
            	            otherlv_6=(Token)match(input,17,FOLLOW_17_in_ruleFeatureGroup1221); 

            	                	newLeafNode(otherlv_6, grammarAccess.getFeatureGroupAccess().getVerticalLineKeyword_6_0());
            	                

            	            }
            	            break;

            	    }

            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:638:3: ( (lv_variants_7_0= ruleAbstractFeature ) )
            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:639:1: (lv_variants_7_0= ruleAbstractFeature )
            	    {
            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:639:1: (lv_variants_7_0= ruleAbstractFeature )
            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:640:3: lv_variants_7_0= ruleAbstractFeature
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getFeatureGroupAccess().getVariantsAbstractFeatureParserRuleCall_6_1_0()); 
            	    	    
            	    pushFollow(FOLLOW_ruleAbstractFeature_in_ruleFeatureGroup1244);
            	    lv_variants_7_0=ruleAbstractFeature();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getFeatureGroupRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"variants",
            	            		lv_variants_7_0, 
            	            		"AbstractFeature");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt19 >= 1 ) break loop19;
                        EarlyExitException eee =
                            new EarlyExitException(19, input);
                        throw eee;
                }
                cnt19++;
            } while (true);

            otherlv_8=(Token)match(input,18,FOLLOW_18_in_ruleFeatureGroup1258); 

                	newLeafNode(otherlv_8, grammarAccess.getFeatureGroupAccess().getRightSquareBracketKeyword_7());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFeatureGroup"


    // $ANTLR start "entryRuleRelativeCardinalityDirect"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:668:1: entryRuleRelativeCardinalityDirect returns [EObject current=null] : iv_ruleRelativeCardinalityDirect= ruleRelativeCardinalityDirect EOF ;
    public final EObject entryRuleRelativeCardinalityDirect() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRelativeCardinalityDirect = null;


        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:669:2: (iv_ruleRelativeCardinalityDirect= ruleRelativeCardinalityDirect EOF )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:670:2: iv_ruleRelativeCardinalityDirect= ruleRelativeCardinalityDirect EOF
            {
             newCompositeNode(grammarAccess.getRelativeCardinalityDirectRule()); 
            pushFollow(FOLLOW_ruleRelativeCardinalityDirect_in_entryRuleRelativeCardinalityDirect1294);
            iv_ruleRelativeCardinalityDirect=ruleRelativeCardinalityDirect();

            state._fsp--;

             current =iv_ruleRelativeCardinalityDirect; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleRelativeCardinalityDirect1304); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRelativeCardinalityDirect"


    // $ANTLR start "ruleRelativeCardinalityDirect"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:677:1: ruleRelativeCardinalityDirect returns [EObject current=null] : ( (lv_cardinality_0_0= ruleFeatureCardinality ) ) ;
    public final EObject ruleRelativeCardinalityDirect() throws RecognitionException {
        EObject current = null;

        EObject lv_cardinality_0_0 = null;


         enterRule(); 
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:680:28: ( ( (lv_cardinality_0_0= ruleFeatureCardinality ) ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:681:1: ( (lv_cardinality_0_0= ruleFeatureCardinality ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:681:1: ( (lv_cardinality_0_0= ruleFeatureCardinality ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:682:1: (lv_cardinality_0_0= ruleFeatureCardinality )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:682:1: (lv_cardinality_0_0= ruleFeatureCardinality )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:683:3: lv_cardinality_0_0= ruleFeatureCardinality
            {
             
            	        newCompositeNode(grammarAccess.getRelativeCardinalityDirectAccess().getCardinalityFeatureCardinalityParserRuleCall_0()); 
            	    
            pushFollow(FOLLOW_ruleFeatureCardinality_in_ruleRelativeCardinalityDirect1349);
            lv_cardinality_0_0=ruleFeatureCardinality();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getRelativeCardinalityDirectRule());
            	        }
                   		set(
                   			current, 
                   			"cardinality",
                    		lv_cardinality_0_0, 
                    		"FeatureCardinality");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRelativeCardinalityDirect"


    // $ANTLR start "entryRuleRelativeCardinalityToUpper"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:707:1: entryRuleRelativeCardinalityToUpper returns [EObject current=null] : iv_ruleRelativeCardinalityToUpper= ruleRelativeCardinalityToUpper EOF ;
    public final EObject entryRuleRelativeCardinalityToUpper() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRelativeCardinalityToUpper = null;


        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:708:2: (iv_ruleRelativeCardinalityToUpper= ruleRelativeCardinalityToUpper EOF )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:709:2: iv_ruleRelativeCardinalityToUpper= ruleRelativeCardinalityToUpper EOF
            {
             newCompositeNode(grammarAccess.getRelativeCardinalityToUpperRule()); 
            pushFollow(FOLLOW_ruleRelativeCardinalityToUpper_in_entryRuleRelativeCardinalityToUpper1384);
            iv_ruleRelativeCardinalityToUpper=ruleRelativeCardinalityToUpper();

            state._fsp--;

             current =iv_ruleRelativeCardinalityToUpper; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleRelativeCardinalityToUpper1394); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRelativeCardinalityToUpper"


    // $ANTLR start "ruleRelativeCardinalityToUpper"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:716:1: ruleRelativeCardinalityToUpper returns [EObject current=null] : (otherlv_0= '<' ( (otherlv_1= RULE_ID ) ) otherlv_2= '>' ( (lv_cardinality_3_0= ruleFeatureCardinality ) ) ) ;
    public final EObject ruleRelativeCardinalityToUpper() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        EObject lv_cardinality_3_0 = null;


         enterRule(); 
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:719:28: ( (otherlv_0= '<' ( (otherlv_1= RULE_ID ) ) otherlv_2= '>' ( (lv_cardinality_3_0= ruleFeatureCardinality ) ) ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:720:1: (otherlv_0= '<' ( (otherlv_1= RULE_ID ) ) otherlv_2= '>' ( (lv_cardinality_3_0= ruleFeatureCardinality ) ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:720:1: (otherlv_0= '<' ( (otherlv_1= RULE_ID ) ) otherlv_2= '>' ( (lv_cardinality_3_0= ruleFeatureCardinality ) ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:720:3: otherlv_0= '<' ( (otherlv_1= RULE_ID ) ) otherlv_2= '>' ( (lv_cardinality_3_0= ruleFeatureCardinality ) )
            {
            otherlv_0=(Token)match(input,19,FOLLOW_19_in_ruleRelativeCardinalityToUpper1431); 

                	newLeafNode(otherlv_0, grammarAccess.getRelativeCardinalityToUpperAccess().getLessThanSignKeyword_0());
                
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:724:1: ( (otherlv_1= RULE_ID ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:725:1: (otherlv_1= RULE_ID )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:725:1: (otherlv_1= RULE_ID )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:726:3: otherlv_1= RULE_ID
            {

            			if (current==null) {
            	            current = createModelElement(grammarAccess.getRelativeCardinalityToUpperRule());
            	        }
                    
            otherlv_1=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleRelativeCardinalityToUpper1451); 

            		newLeafNode(otherlv_1, grammarAccess.getRelativeCardinalityToUpperAccess().getToFeatureCrossReference_1_0()); 
            	

            }


            }

            otherlv_2=(Token)match(input,20,FOLLOW_20_in_ruleRelativeCardinalityToUpper1463); 

                	newLeafNode(otherlv_2, grammarAccess.getRelativeCardinalityToUpperAccess().getGreaterThanSignKeyword_2());
                
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:741:1: ( (lv_cardinality_3_0= ruleFeatureCardinality ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:742:1: (lv_cardinality_3_0= ruleFeatureCardinality )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:742:1: (lv_cardinality_3_0= ruleFeatureCardinality )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:743:3: lv_cardinality_3_0= ruleFeatureCardinality
            {
             
            	        newCompositeNode(grammarAccess.getRelativeCardinalityToUpperAccess().getCardinalityFeatureCardinalityParserRuleCall_3_0()); 
            	    
            pushFollow(FOLLOW_ruleFeatureCardinality_in_ruleRelativeCardinalityToUpper1484);
            lv_cardinality_3_0=ruleFeatureCardinality();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getRelativeCardinalityToUpperRule());
            	        }
                   		set(
                   			current, 
                   			"cardinality",
                    		lv_cardinality_3_0, 
                    		"FeatureCardinality");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRelativeCardinalityToUpper"


    // $ANTLR start "entryRuleGroupCardinality"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:767:1: entryRuleGroupCardinality returns [EObject current=null] : iv_ruleGroupCardinality= ruleGroupCardinality EOF ;
    public final EObject entryRuleGroupCardinality() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleGroupCardinality = null;


        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:768:2: (iv_ruleGroupCardinality= ruleGroupCardinality EOF )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:769:2: iv_ruleGroupCardinality= ruleGroupCardinality EOF
            {
             newCompositeNode(grammarAccess.getGroupCardinalityRule()); 
            pushFollow(FOLLOW_ruleGroupCardinality_in_entryRuleGroupCardinality1520);
            iv_ruleGroupCardinality=ruleGroupCardinality();

            state._fsp--;

             current =iv_ruleGroupCardinality; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleGroupCardinality1530); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleGroupCardinality"


    // $ANTLR start "ruleGroupCardinality"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:776:1: ruleGroupCardinality returns [EObject current=null] : (otherlv_0= '<' this_Cardinality_1= ruleCardinality otherlv_2= '>' ) ;
    public final EObject ruleGroupCardinality() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        EObject this_Cardinality_1 = null;


         enterRule(); 
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:779:28: ( (otherlv_0= '<' this_Cardinality_1= ruleCardinality otherlv_2= '>' ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:780:1: (otherlv_0= '<' this_Cardinality_1= ruleCardinality otherlv_2= '>' )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:780:1: (otherlv_0= '<' this_Cardinality_1= ruleCardinality otherlv_2= '>' )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:780:3: otherlv_0= '<' this_Cardinality_1= ruleCardinality otherlv_2= '>'
            {
            otherlv_0=(Token)match(input,19,FOLLOW_19_in_ruleGroupCardinality1567); 

                	newLeafNode(otherlv_0, grammarAccess.getGroupCardinalityAccess().getLessThanSignKeyword_0());
                
             
                    newCompositeNode(grammarAccess.getGroupCardinalityAccess().getCardinalityParserRuleCall_1()); 
                
            pushFollow(FOLLOW_ruleCardinality_in_ruleGroupCardinality1589);
            this_Cardinality_1=ruleCardinality();

            state._fsp--;

             
                    current = this_Cardinality_1; 
                    afterParserOrEnumRuleCall();
                
            otherlv_2=(Token)match(input,20,FOLLOW_20_in_ruleGroupCardinality1600); 

                	newLeafNode(otherlv_2, grammarAccess.getGroupCardinalityAccess().getGreaterThanSignKeyword_2());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleGroupCardinality"


    // $ANTLR start "entryRuleFeatureCardinality"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:805:1: entryRuleFeatureCardinality returns [EObject current=null] : iv_ruleFeatureCardinality= ruleFeatureCardinality EOF ;
    public final EObject entryRuleFeatureCardinality() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFeatureCardinality = null;


        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:806:2: (iv_ruleFeatureCardinality= ruleFeatureCardinality EOF )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:807:2: iv_ruleFeatureCardinality= ruleFeatureCardinality EOF
            {
             newCompositeNode(grammarAccess.getFeatureCardinalityRule()); 
            pushFollow(FOLLOW_ruleFeatureCardinality_in_entryRuleFeatureCardinality1636);
            iv_ruleFeatureCardinality=ruleFeatureCardinality();

            state._fsp--;

             current =iv_ruleFeatureCardinality; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleFeatureCardinality1646); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFeatureCardinality"


    // $ANTLR start "ruleFeatureCardinality"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:814:1: ruleFeatureCardinality returns [EObject current=null] : (otherlv_0= '[' this_Cardinality_1= ruleCardinality otherlv_2= ']' ) ;
    public final EObject ruleFeatureCardinality() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        EObject this_Cardinality_1 = null;


         enterRule(); 
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:817:28: ( (otherlv_0= '[' this_Cardinality_1= ruleCardinality otherlv_2= ']' ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:818:1: (otherlv_0= '[' this_Cardinality_1= ruleCardinality otherlv_2= ']' )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:818:1: (otherlv_0= '[' this_Cardinality_1= ruleCardinality otherlv_2= ']' )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:818:3: otherlv_0= '[' this_Cardinality_1= ruleCardinality otherlv_2= ']'
            {
            otherlv_0=(Token)match(input,16,FOLLOW_16_in_ruleFeatureCardinality1683); 

                	newLeafNode(otherlv_0, grammarAccess.getFeatureCardinalityAccess().getLeftSquareBracketKeyword_0());
                
             
                    newCompositeNode(grammarAccess.getFeatureCardinalityAccess().getCardinalityParserRuleCall_1()); 
                
            pushFollow(FOLLOW_ruleCardinality_in_ruleFeatureCardinality1705);
            this_Cardinality_1=ruleCardinality();

            state._fsp--;

             
                    current = this_Cardinality_1; 
                    afterParserOrEnumRuleCall();
                
            otherlv_2=(Token)match(input,18,FOLLOW_18_in_ruleFeatureCardinality1716); 

                	newLeafNode(otherlv_2, grammarAccess.getFeatureCardinalityAccess().getRightSquareBracketKeyword_2());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFeatureCardinality"


    // $ANTLR start "entryRuleCardinality"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:843:1: entryRuleCardinality returns [EObject current=null] : iv_ruleCardinality= ruleCardinality EOF ;
    public final EObject entryRuleCardinality() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCardinality = null;


        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:844:2: (iv_ruleCardinality= ruleCardinality EOF )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:845:2: iv_ruleCardinality= ruleCardinality EOF
            {
             newCompositeNode(grammarAccess.getCardinalityRule()); 
            pushFollow(FOLLOW_ruleCardinality_in_entryRuleCardinality1752);
            iv_ruleCardinality=ruleCardinality();

            state._fsp--;

             current =iv_ruleCardinality; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleCardinality1762); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCardinality"


    // $ANTLR start "ruleCardinality"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:852:1: ruleCardinality returns [EObject current=null] : ( ( (lv_min_0_0= RULE_INT ) ) otherlv_1= '..' ( (lv_max_2_0= RULE_INT ) ) ) ;
    public final EObject ruleCardinality() throws RecognitionException {
        EObject current = null;

        Token lv_min_0_0=null;
        Token otherlv_1=null;
        Token lv_max_2_0=null;

         enterRule(); 
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:855:28: ( ( ( (lv_min_0_0= RULE_INT ) ) otherlv_1= '..' ( (lv_max_2_0= RULE_INT ) ) ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:856:1: ( ( (lv_min_0_0= RULE_INT ) ) otherlv_1= '..' ( (lv_max_2_0= RULE_INT ) ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:856:1: ( ( (lv_min_0_0= RULE_INT ) ) otherlv_1= '..' ( (lv_max_2_0= RULE_INT ) ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:856:2: ( (lv_min_0_0= RULE_INT ) ) otherlv_1= '..' ( (lv_max_2_0= RULE_INT ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:856:2: ( (lv_min_0_0= RULE_INT ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:857:1: (lv_min_0_0= RULE_INT )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:857:1: (lv_min_0_0= RULE_INT )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:858:3: lv_min_0_0= RULE_INT
            {
            lv_min_0_0=(Token)match(input,RULE_INT,FOLLOW_RULE_INT_in_ruleCardinality1804); 

            			newLeafNode(lv_min_0_0, grammarAccess.getCardinalityAccess().getMinINTTerminalRuleCall_0_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getCardinalityRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"min",
                    		lv_min_0_0, 
                    		"INT");
            	    

            }


            }

            otherlv_1=(Token)match(input,21,FOLLOW_21_in_ruleCardinality1821); 

                	newLeafNode(otherlv_1, grammarAccess.getCardinalityAccess().getFullStopFullStopKeyword_1());
                
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:878:1: ( (lv_max_2_0= RULE_INT ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:879:1: (lv_max_2_0= RULE_INT )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:879:1: (lv_max_2_0= RULE_INT )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:880:3: lv_max_2_0= RULE_INT
            {
            lv_max_2_0=(Token)match(input,RULE_INT,FOLLOW_RULE_INT_in_ruleCardinality1838); 

            			newLeafNode(lv_max_2_0, grammarAccess.getCardinalityAccess().getMaxINTTerminalRuleCall_2_0()); 
            		

            	        if (current==null) {
            	            current = createModelElement(grammarAccess.getCardinalityRule());
            	        }
                   		setWithLastConsumed(
                   			current, 
                   			"max",
                    		lv_max_2_0, 
                    		"INT");
            	    

            }


            }


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCardinality"


    // $ANTLR start "entryRuleConstraint"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:904:1: entryRuleConstraint returns [EObject current=null] : iv_ruleConstraint= ruleConstraint EOF ;
    public final EObject entryRuleConstraint() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConstraint = null;


        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:905:2: (iv_ruleConstraint= ruleConstraint EOF )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:906:2: iv_ruleConstraint= ruleConstraint EOF
            {
             newCompositeNode(grammarAccess.getConstraintRule()); 
            pushFollow(FOLLOW_ruleConstraint_in_entryRuleConstraint1879);
            iv_ruleConstraint=ruleConstraint();

            state._fsp--;

             current =iv_ruleConstraint; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleConstraint1889); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConstraint"


    // $ANTLR start "ruleConstraint"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:913:1: ruleConstraint returns [EObject current=null] : (otherlv_0= '<' ( (otherlv_1= RULE_ID ) ) otherlv_2= '>' ( (lv_condition_3_0= ruleExpression ) ) otherlv_4= '=>' ( (lv_consequence_5_0= ruleExpression ) ) ) ;
    public final EObject ruleConstraint() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        EObject lv_condition_3_0 = null;

        EObject lv_consequence_5_0 = null;


         enterRule(); 
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:916:28: ( (otherlv_0= '<' ( (otherlv_1= RULE_ID ) ) otherlv_2= '>' ( (lv_condition_3_0= ruleExpression ) ) otherlv_4= '=>' ( (lv_consequence_5_0= ruleExpression ) ) ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:917:1: (otherlv_0= '<' ( (otherlv_1= RULE_ID ) ) otherlv_2= '>' ( (lv_condition_3_0= ruleExpression ) ) otherlv_4= '=>' ( (lv_consequence_5_0= ruleExpression ) ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:917:1: (otherlv_0= '<' ( (otherlv_1= RULE_ID ) ) otherlv_2= '>' ( (lv_condition_3_0= ruleExpression ) ) otherlv_4= '=>' ( (lv_consequence_5_0= ruleExpression ) ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:917:3: otherlv_0= '<' ( (otherlv_1= RULE_ID ) ) otherlv_2= '>' ( (lv_condition_3_0= ruleExpression ) ) otherlv_4= '=>' ( (lv_consequence_5_0= ruleExpression ) )
            {
            otherlv_0=(Token)match(input,19,FOLLOW_19_in_ruleConstraint1926); 

                	newLeafNode(otherlv_0, grammarAccess.getConstraintAccess().getLessThanSignKeyword_0());
                
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:921:1: ( (otherlv_1= RULE_ID ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:922:1: (otherlv_1= RULE_ID )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:922:1: (otherlv_1= RULE_ID )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:923:3: otherlv_1= RULE_ID
            {

            			if (current==null) {
            	            current = createModelElement(grammarAccess.getConstraintRule());
            	        }
                    
            otherlv_1=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleConstraint1946); 

            		newLeafNode(otherlv_1, grammarAccess.getConstraintAccess().getContextAbstractFeatureCrossReference_1_0()); 
            	

            }


            }

            otherlv_2=(Token)match(input,20,FOLLOW_20_in_ruleConstraint1958); 

                	newLeafNode(otherlv_2, grammarAccess.getConstraintAccess().getGreaterThanSignKeyword_2());
                
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:938:1: ( (lv_condition_3_0= ruleExpression ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:939:1: (lv_condition_3_0= ruleExpression )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:939:1: (lv_condition_3_0= ruleExpression )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:940:3: lv_condition_3_0= ruleExpression
            {
             
            	        newCompositeNode(grammarAccess.getConstraintAccess().getConditionExpressionParserRuleCall_3_0()); 
            	    
            pushFollow(FOLLOW_ruleExpression_in_ruleConstraint1979);
            lv_condition_3_0=ruleExpression();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getConstraintRule());
            	        }
                   		set(
                   			current, 
                   			"condition",
                    		lv_condition_3_0, 
                    		"Expression");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_4=(Token)match(input,22,FOLLOW_22_in_ruleConstraint1991); 

                	newLeafNode(otherlv_4, grammarAccess.getConstraintAccess().getEqualsSignGreaterThanSignKeyword_4());
                
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:960:1: ( (lv_consequence_5_0= ruleExpression ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:961:1: (lv_consequence_5_0= ruleExpression )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:961:1: (lv_consequence_5_0= ruleExpression )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:962:3: lv_consequence_5_0= ruleExpression
            {
             
            	        newCompositeNode(grammarAccess.getConstraintAccess().getConsequenceExpressionParserRuleCall_5_0()); 
            	    
            pushFollow(FOLLOW_ruleExpression_in_ruleConstraint2012);
            lv_consequence_5_0=ruleExpression();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getConstraintRule());
            	        }
                   		set(
                   			current, 
                   			"consequence",
                    		lv_consequence_5_0, 
                    		"Expression");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConstraint"


    // $ANTLR start "entryRuleConstrainingExpression"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:986:1: entryRuleConstrainingExpression returns [EObject current=null] : iv_ruleConstrainingExpression= ruleConstrainingExpression EOF ;
    public final EObject entryRuleConstrainingExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConstrainingExpression = null;


        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:987:2: (iv_ruleConstrainingExpression= ruleConstrainingExpression EOF )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:988:2: iv_ruleConstrainingExpression= ruleConstrainingExpression EOF
            {
             newCompositeNode(grammarAccess.getConstrainingExpressionRule()); 
            pushFollow(FOLLOW_ruleConstrainingExpression_in_entryRuleConstrainingExpression2048);
            iv_ruleConstrainingExpression=ruleConstrainingExpression();

            state._fsp--;

             current =iv_ruleConstrainingExpression; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleConstrainingExpression2058); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConstrainingExpression"


    // $ANTLR start "ruleConstrainingExpression"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:995:1: ruleConstrainingExpression returns [EObject current=null] : ( ( (lv_cardinality_0_0= ruleFeatureCardinality ) ) otherlv_1= '(' ( (otherlv_2= RULE_ID ) ) otherlv_3= ',' ( (otherlv_4= RULE_ID ) ) otherlv_5= ')' ) ;
    public final EObject ruleConstrainingExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        EObject lv_cardinality_0_0 = null;


         enterRule(); 
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:998:28: ( ( ( (lv_cardinality_0_0= ruleFeatureCardinality ) ) otherlv_1= '(' ( (otherlv_2= RULE_ID ) ) otherlv_3= ',' ( (otherlv_4= RULE_ID ) ) otherlv_5= ')' ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:999:1: ( ( (lv_cardinality_0_0= ruleFeatureCardinality ) ) otherlv_1= '(' ( (otherlv_2= RULE_ID ) ) otherlv_3= ',' ( (otherlv_4= RULE_ID ) ) otherlv_5= ')' )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:999:1: ( ( (lv_cardinality_0_0= ruleFeatureCardinality ) ) otherlv_1= '(' ( (otherlv_2= RULE_ID ) ) otherlv_3= ',' ( (otherlv_4= RULE_ID ) ) otherlv_5= ')' )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:999:2: ( (lv_cardinality_0_0= ruleFeatureCardinality ) ) otherlv_1= '(' ( (otherlv_2= RULE_ID ) ) otherlv_3= ',' ( (otherlv_4= RULE_ID ) ) otherlv_5= ')'
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:999:2: ( (lv_cardinality_0_0= ruleFeatureCardinality ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1000:1: (lv_cardinality_0_0= ruleFeatureCardinality )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1000:1: (lv_cardinality_0_0= ruleFeatureCardinality )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1001:3: lv_cardinality_0_0= ruleFeatureCardinality
            {
             
            	        newCompositeNode(grammarAccess.getConstrainingExpressionAccess().getCardinalityFeatureCardinalityParserRuleCall_0_0()); 
            	    
            pushFollow(FOLLOW_ruleFeatureCardinality_in_ruleConstrainingExpression2104);
            lv_cardinality_0_0=ruleFeatureCardinality();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getConstrainingExpressionRule());
            	        }
                   		set(
                   			current, 
                   			"cardinality",
                    		lv_cardinality_0_0, 
                    		"FeatureCardinality");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            otherlv_1=(Token)match(input,23,FOLLOW_23_in_ruleConstrainingExpression2116); 

                	newLeafNode(otherlv_1, grammarAccess.getConstrainingExpressionAccess().getLeftParenthesisKeyword_1());
                
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1021:1: ( (otherlv_2= RULE_ID ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1022:1: (otherlv_2= RULE_ID )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1022:1: (otherlv_2= RULE_ID )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1023:3: otherlv_2= RULE_ID
            {

            			if (current==null) {
            	            current = createModelElement(grammarAccess.getConstrainingExpressionRule());
            	        }
                    
            otherlv_2=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleConstrainingExpression2136); 

            		newLeafNode(otherlv_2, grammarAccess.getConstrainingExpressionAccess().getFromAbstractFeatureCrossReference_2_0()); 
            	

            }


            }

            otherlv_3=(Token)match(input,13,FOLLOW_13_in_ruleConstrainingExpression2148); 

                	newLeafNode(otherlv_3, grammarAccess.getConstrainingExpressionAccess().getCommaKeyword_3());
                
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1038:1: ( (otherlv_4= RULE_ID ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1039:1: (otherlv_4= RULE_ID )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1039:1: (otherlv_4= RULE_ID )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1040:3: otherlv_4= RULE_ID
            {

            			if (current==null) {
            	            current = createModelElement(grammarAccess.getConstrainingExpressionRule());
            	        }
                    
            otherlv_4=(Token)match(input,RULE_ID,FOLLOW_RULE_ID_in_ruleConstrainingExpression2168); 

            		newLeafNode(otherlv_4, grammarAccess.getConstrainingExpressionAccess().getToAbstractFeatureCrossReference_4_0()); 
            	

            }


            }

            otherlv_5=(Token)match(input,24,FOLLOW_24_in_ruleConstrainingExpression2180); 

                	newLeafNode(otherlv_5, grammarAccess.getConstrainingExpressionAccess().getRightParenthesisKeyword_5());
                

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConstrainingExpression"


    // $ANTLR start "entryRuleExpression"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1063:1: entryRuleExpression returns [EObject current=null] : iv_ruleExpression= ruleExpression EOF ;
    public final EObject entryRuleExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleExpression = null;


        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1064:2: (iv_ruleExpression= ruleExpression EOF )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1065:2: iv_ruleExpression= ruleExpression EOF
            {
             newCompositeNode(grammarAccess.getExpressionRule()); 
            pushFollow(FOLLOW_ruleExpression_in_entryRuleExpression2216);
            iv_ruleExpression=ruleExpression();

            state._fsp--;

             current =iv_ruleExpression; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleExpression2226); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleExpression"


    // $ANTLR start "ruleExpression"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1072:1: ruleExpression returns [EObject current=null] : this_OrConstrainingExpression_0= ruleOrConstrainingExpression ;
    public final EObject ruleExpression() throws RecognitionException {
        EObject current = null;

        EObject this_OrConstrainingExpression_0 = null;


         enterRule(); 
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1075:28: (this_OrConstrainingExpression_0= ruleOrConstrainingExpression )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1077:5: this_OrConstrainingExpression_0= ruleOrConstrainingExpression
            {
             
                    newCompositeNode(grammarAccess.getExpressionAccess().getOrConstrainingExpressionParserRuleCall()); 
                
            pushFollow(FOLLOW_ruleOrConstrainingExpression_in_ruleExpression2272);
            this_OrConstrainingExpression_0=ruleOrConstrainingExpression();

            state._fsp--;

             
                    current = this_OrConstrainingExpression_0; 
                    afterParserOrEnumRuleCall();
                

            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleExpression"


    // $ANTLR start "entryRuleOrConstrainingExpression"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1093:1: entryRuleOrConstrainingExpression returns [EObject current=null] : iv_ruleOrConstrainingExpression= ruleOrConstrainingExpression EOF ;
    public final EObject entryRuleOrConstrainingExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOrConstrainingExpression = null;


        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1094:2: (iv_ruleOrConstrainingExpression= ruleOrConstrainingExpression EOF )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1095:2: iv_ruleOrConstrainingExpression= ruleOrConstrainingExpression EOF
            {
             newCompositeNode(grammarAccess.getOrConstrainingExpressionRule()); 
            pushFollow(FOLLOW_ruleOrConstrainingExpression_in_entryRuleOrConstrainingExpression2306);
            iv_ruleOrConstrainingExpression=ruleOrConstrainingExpression();

            state._fsp--;

             current =iv_ruleOrConstrainingExpression; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleOrConstrainingExpression2316); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOrConstrainingExpression"


    // $ANTLR start "ruleOrConstrainingExpression"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1102:1: ruleOrConstrainingExpression returns [EObject current=null] : ( ( (lv_children_0_0= ruleAndConstrainingExpression ) ) (otherlv_1= '|' ( (lv_children_2_0= ruleAndConstrainingExpression ) ) )* ) ;
    public final EObject ruleOrConstrainingExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        EObject lv_children_0_0 = null;

        EObject lv_children_2_0 = null;


         enterRule(); 
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1105:28: ( ( ( (lv_children_0_0= ruleAndConstrainingExpression ) ) (otherlv_1= '|' ( (lv_children_2_0= ruleAndConstrainingExpression ) ) )* ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1106:1: ( ( (lv_children_0_0= ruleAndConstrainingExpression ) ) (otherlv_1= '|' ( (lv_children_2_0= ruleAndConstrainingExpression ) ) )* )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1106:1: ( ( (lv_children_0_0= ruleAndConstrainingExpression ) ) (otherlv_1= '|' ( (lv_children_2_0= ruleAndConstrainingExpression ) ) )* )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1106:2: ( (lv_children_0_0= ruleAndConstrainingExpression ) ) (otherlv_1= '|' ( (lv_children_2_0= ruleAndConstrainingExpression ) ) )*
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1106:2: ( (lv_children_0_0= ruleAndConstrainingExpression ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1107:1: (lv_children_0_0= ruleAndConstrainingExpression )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1107:1: (lv_children_0_0= ruleAndConstrainingExpression )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1108:3: lv_children_0_0= ruleAndConstrainingExpression
            {
             
            	        newCompositeNode(grammarAccess.getOrConstrainingExpressionAccess().getChildrenAndConstrainingExpressionParserRuleCall_0_0()); 
            	    
            pushFollow(FOLLOW_ruleAndConstrainingExpression_in_ruleOrConstrainingExpression2362);
            lv_children_0_0=ruleAndConstrainingExpression();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getOrConstrainingExpressionRule());
            	        }
                   		add(
                   			current, 
                   			"children",
                    		lv_children_0_0, 
                    		"AndConstrainingExpression");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1124:2: (otherlv_1= '|' ( (lv_children_2_0= ruleAndConstrainingExpression ) ) )*
            loop20:
            do {
                int alt20=2;
                int LA20_0 = input.LA(1);

                if ( (LA20_0==17) ) {
                    alt20=1;
                }


                switch (alt20) {
            	case 1 :
            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1124:4: otherlv_1= '|' ( (lv_children_2_0= ruleAndConstrainingExpression ) )
            	    {
            	    otherlv_1=(Token)match(input,17,FOLLOW_17_in_ruleOrConstrainingExpression2375); 

            	        	newLeafNode(otherlv_1, grammarAccess.getOrConstrainingExpressionAccess().getVerticalLineKeyword_1_0());
            	        
            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1128:1: ( (lv_children_2_0= ruleAndConstrainingExpression ) )
            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1129:1: (lv_children_2_0= ruleAndConstrainingExpression )
            	    {
            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1129:1: (lv_children_2_0= ruleAndConstrainingExpression )
            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1130:3: lv_children_2_0= ruleAndConstrainingExpression
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getOrConstrainingExpressionAccess().getChildrenAndConstrainingExpressionParserRuleCall_1_1_0()); 
            	    	    
            	    pushFollow(FOLLOW_ruleAndConstrainingExpression_in_ruleOrConstrainingExpression2396);
            	    lv_children_2_0=ruleAndConstrainingExpression();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getOrConstrainingExpressionRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"children",
            	            		lv_children_2_0, 
            	            		"AndConstrainingExpression");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop20;
                }
            } while (true);


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOrConstrainingExpression"


    // $ANTLR start "entryRuleAndConstrainingExpression"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1154:1: entryRuleAndConstrainingExpression returns [EObject current=null] : iv_ruleAndConstrainingExpression= ruleAndConstrainingExpression EOF ;
    public final EObject entryRuleAndConstrainingExpression() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAndConstrainingExpression = null;


        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1155:2: (iv_ruleAndConstrainingExpression= ruleAndConstrainingExpression EOF )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1156:2: iv_ruleAndConstrainingExpression= ruleAndConstrainingExpression EOF
            {
             newCompositeNode(grammarAccess.getAndConstrainingExpressionRule()); 
            pushFollow(FOLLOW_ruleAndConstrainingExpression_in_entryRuleAndConstrainingExpression2434);
            iv_ruleAndConstrainingExpression=ruleAndConstrainingExpression();

            state._fsp--;

             current =iv_ruleAndConstrainingExpression; 
            match(input,EOF,FOLLOW_EOF_in_entryRuleAndConstrainingExpression2444); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAndConstrainingExpression"


    // $ANTLR start "ruleAndConstrainingExpression"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1163:1: ruleAndConstrainingExpression returns [EObject current=null] : ( ( (lv_children_0_0= rulePrimary ) ) (otherlv_1= '&' ( (lv_children_2_0= rulePrimary ) ) )* ) ;
    public final EObject ruleAndConstrainingExpression() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        EObject lv_children_0_0 = null;

        EObject lv_children_2_0 = null;


         enterRule(); 
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1166:28: ( ( ( (lv_children_0_0= rulePrimary ) ) (otherlv_1= '&' ( (lv_children_2_0= rulePrimary ) ) )* ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1167:1: ( ( (lv_children_0_0= rulePrimary ) ) (otherlv_1= '&' ( (lv_children_2_0= rulePrimary ) ) )* )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1167:1: ( ( (lv_children_0_0= rulePrimary ) ) (otherlv_1= '&' ( (lv_children_2_0= rulePrimary ) ) )* )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1167:2: ( (lv_children_0_0= rulePrimary ) ) (otherlv_1= '&' ( (lv_children_2_0= rulePrimary ) ) )*
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1167:2: ( (lv_children_0_0= rulePrimary ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1168:1: (lv_children_0_0= rulePrimary )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1168:1: (lv_children_0_0= rulePrimary )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1169:3: lv_children_0_0= rulePrimary
            {
             
            	        newCompositeNode(grammarAccess.getAndConstrainingExpressionAccess().getChildrenPrimaryParserRuleCall_0_0()); 
            	    
            pushFollow(FOLLOW_rulePrimary_in_ruleAndConstrainingExpression2490);
            lv_children_0_0=rulePrimary();

            state._fsp--;


            	        if (current==null) {
            	            current = createModelElementForParent(grammarAccess.getAndConstrainingExpressionRule());
            	        }
                   		add(
                   			current, 
                   			"children",
                    		lv_children_0_0, 
                    		"Primary");
            	        afterParserOrEnumRuleCall();
            	    

            }


            }

            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1185:2: (otherlv_1= '&' ( (lv_children_2_0= rulePrimary ) ) )*
            loop21:
            do {
                int alt21=2;
                int LA21_0 = input.LA(1);

                if ( (LA21_0==25) ) {
                    alt21=1;
                }


                switch (alt21) {
            	case 1 :
            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1185:4: otherlv_1= '&' ( (lv_children_2_0= rulePrimary ) )
            	    {
            	    otherlv_1=(Token)match(input,25,FOLLOW_25_in_ruleAndConstrainingExpression2503); 

            	        	newLeafNode(otherlv_1, grammarAccess.getAndConstrainingExpressionAccess().getAmpersandKeyword_1_0());
            	        
            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1189:1: ( (lv_children_2_0= rulePrimary ) )
            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1190:1: (lv_children_2_0= rulePrimary )
            	    {
            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1190:1: (lv_children_2_0= rulePrimary )
            	    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1191:3: lv_children_2_0= rulePrimary
            	    {
            	     
            	    	        newCompositeNode(grammarAccess.getAndConstrainingExpressionAccess().getChildrenPrimaryParserRuleCall_1_1_0()); 
            	    	    
            	    pushFollow(FOLLOW_rulePrimary_in_ruleAndConstrainingExpression2524);
            	    lv_children_2_0=rulePrimary();

            	    state._fsp--;


            	    	        if (current==null) {
            	    	            current = createModelElementForParent(grammarAccess.getAndConstrainingExpressionRule());
            	    	        }
            	           		add(
            	           			current, 
            	           			"children",
            	            		lv_children_2_0, 
            	            		"Primary");
            	    	        afterParserOrEnumRuleCall();
            	    	    

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop21;
                }
            } while (true);


            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAndConstrainingExpression"


    // $ANTLR start "entryRulePrimary"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1215:1: entryRulePrimary returns [EObject current=null] : iv_rulePrimary= rulePrimary EOF ;
    public final EObject entryRulePrimary() throws RecognitionException {
        EObject current = null;

        EObject iv_rulePrimary = null;


        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1216:2: (iv_rulePrimary= rulePrimary EOF )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1217:2: iv_rulePrimary= rulePrimary EOF
            {
             newCompositeNode(grammarAccess.getPrimaryRule()); 
            pushFollow(FOLLOW_rulePrimary_in_entryRulePrimary2562);
            iv_rulePrimary=rulePrimary();

            state._fsp--;

             current =iv_rulePrimary; 
            match(input,EOF,FOLLOW_EOF_in_entryRulePrimary2572); 

            }

        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRulePrimary"


    // $ANTLR start "rulePrimary"
    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1224:1: rulePrimary returns [EObject current=null] : (this_ConstrainingExpression_0= ruleConstrainingExpression | (otherlv_1= '(' this_OrConstrainingExpression_2= ruleOrConstrainingExpression otherlv_3= ')' ) ) ;
    public final EObject rulePrimary() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        EObject this_ConstrainingExpression_0 = null;

        EObject this_OrConstrainingExpression_2 = null;


         enterRule(); 
            
        try {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1227:28: ( (this_ConstrainingExpression_0= ruleConstrainingExpression | (otherlv_1= '(' this_OrConstrainingExpression_2= ruleOrConstrainingExpression otherlv_3= ')' ) ) )
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1228:1: (this_ConstrainingExpression_0= ruleConstrainingExpression | (otherlv_1= '(' this_OrConstrainingExpression_2= ruleOrConstrainingExpression otherlv_3= ')' ) )
            {
            // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1228:1: (this_ConstrainingExpression_0= ruleConstrainingExpression | (otherlv_1= '(' this_OrConstrainingExpression_2= ruleOrConstrainingExpression otherlv_3= ')' ) )
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==16) ) {
                alt22=1;
            }
            else if ( (LA22_0==23) ) {
                alt22=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 22, 0, input);

                throw nvae;
            }
            switch (alt22) {
                case 1 :
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1229:5: this_ConstrainingExpression_0= ruleConstrainingExpression
                    {
                     
                            newCompositeNode(grammarAccess.getPrimaryAccess().getConstrainingExpressionParserRuleCall_0()); 
                        
                    pushFollow(FOLLOW_ruleConstrainingExpression_in_rulePrimary2619);
                    this_ConstrainingExpression_0=ruleConstrainingExpression();

                    state._fsp--;

                     
                            current = this_ConstrainingExpression_0; 
                            afterParserOrEnumRuleCall();
                        

                    }
                    break;
                case 2 :
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1238:6: (otherlv_1= '(' this_OrConstrainingExpression_2= ruleOrConstrainingExpression otherlv_3= ')' )
                    {
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1238:6: (otherlv_1= '(' this_OrConstrainingExpression_2= ruleOrConstrainingExpression otherlv_3= ')' )
                    // ../fr.inria.lille.spirals.fm.dsl/src-gen/fr/inria/lille/spirals/fm/parser/antlr/internal/InternalFeatureModel.g:1238:8: otherlv_1= '(' this_OrConstrainingExpression_2= ruleOrConstrainingExpression otherlv_3= ')'
                    {
                    otherlv_1=(Token)match(input,23,FOLLOW_23_in_rulePrimary2637); 

                        	newLeafNode(otherlv_1, grammarAccess.getPrimaryAccess().getLeftParenthesisKeyword_1_0());
                        
                     
                            newCompositeNode(grammarAccess.getPrimaryAccess().getOrConstrainingExpressionParserRuleCall_1_1()); 
                        
                    pushFollow(FOLLOW_ruleOrConstrainingExpression_in_rulePrimary2659);
                    this_OrConstrainingExpression_2=ruleOrConstrainingExpression();

                    state._fsp--;

                     
                            current = this_OrConstrainingExpression_2; 
                            afterParserOrEnumRuleCall();
                        
                    otherlv_3=(Token)match(input,24,FOLLOW_24_in_rulePrimary2670); 

                        	newLeafNode(otherlv_3, grammarAccess.getPrimaryAccess().getRightParenthesisKeyword_1_2());
                        

                    }


                    }
                    break;

            }


            }

             leaveRule(); 
        }
         
            catch (RecognitionException re) { 
                recover(input,re); 
                appendSkippedTokens();
            } 
        finally {
        }
        return current;
    }
    // $ANTLR end "rulePrimary"

    // Delegated rules


    protected DFA10 dfa10 = new DFA10(this);
    protected DFA12 dfa12 = new DFA12(this);
    static final String DFA10_eotS =
        "\21\uffff";
    static final String DFA10_eofS =
        "\1\uffff\1\4\12\uffff\1\4\3\uffff\1\4";
    static final String DFA10_minS =
        "\2\4\1\6\1\4\1\uffff\1\25\1\24\1\uffff\1\6\1\20\1\22\1\6\1\4\1\25\1\6\1\22\1\4";
    static final String DFA10_maxS =
        "\1\4\1\23\2\6\1\uffff\1\25\1\24\1\uffff\1\6\1\20\1\22\1\6\1\23\1\25\1\6\1\22\1\23";
    static final String DFA10_acceptS =
        "\4\uffff\1\1\2\uffff\1\2\11\uffff";
    static final String DFA10_specialS =
        "\21\uffff}>";
    static final String[] DFA10_transitionS = {
            "\1\1",
            "\1\4\10\uffff\3\4\1\2\2\4\1\3",
            "\1\5",
            "\1\6\1\uffff\1\7",
            "",
            "\1\10",
            "\1\11",
            "",
            "\1\12",
            "\1\13",
            "\1\14",
            "\1\15",
            "\1\4\10\uffff\3\4\1\uffff\2\4\1\3",
            "\1\16",
            "\1\17",
            "\1\20",
            "\1\4\10\uffff\3\4\1\uffff\2\4\1\3"
    };

    static final short[] DFA10_eot = DFA.unpackEncodedString(DFA10_eotS);
    static final short[] DFA10_eof = DFA.unpackEncodedString(DFA10_eofS);
    static final char[] DFA10_min = DFA.unpackEncodedStringToUnsignedChars(DFA10_minS);
    static final char[] DFA10_max = DFA.unpackEncodedStringToUnsignedChars(DFA10_maxS);
    static final short[] DFA10_accept = DFA.unpackEncodedString(DFA10_acceptS);
    static final short[] DFA10_special = DFA.unpackEncodedString(DFA10_specialS);
    static final short[][] DFA10_transition;

    static {
        int numStates = DFA10_transitionS.length;
        DFA10_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA10_transition[i] = DFA.unpackEncodedString(DFA10_transitionS[i]);
        }
    }

    class DFA10 extends DFA {

        public DFA10(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 10;
            this.eot = DFA10_eot;
            this.eof = DFA10_eof;
            this.min = DFA10_min;
            this.max = DFA10_max;
            this.accept = DFA10_accept;
            this.special = DFA10_special;
            this.transition = DFA10_transition;
        }
        public String getDescription() {
            return "377:1: (this_Feature_0= ruleFeature | this_FeatureGroup_1= ruleFeatureGroup )";
        }
    }
    static final String DFA12_eotS =
        "\13\uffff";
    static final String DFA12_eofS =
        "\1\1\10\uffff\1\12\1\uffff";
    static final String DFA12_minS =
        "\1\4\1\uffff\1\4\1\24\1\20\1\6\1\25\1\6\1\22\1\4\1\uffff";
    static final String DFA12_maxS =
        "\1\23\1\uffff\1\4\1\24\1\27\1\6\1\25\1\6\1\22\1\27\1\uffff";
    static final String DFA12_acceptS =
        "\1\uffff\1\2\10\uffff\1\1";
    static final String DFA12_specialS =
        "\13\uffff}>";
    static final String[] DFA12_transitionS = {
            "\1\1\10\uffff\3\1\1\uffff\2\1\1\2",
            "",
            "\1\3",
            "\1\4",
            "\1\5\6\uffff\1\1",
            "\1\6",
            "\1\7",
            "\1\10",
            "\1\11",
            "\1\12\10\uffff\3\12\1\uffff\3\12\3\uffff\1\1",
            ""
    };

    static final short[] DFA12_eot = DFA.unpackEncodedString(DFA12_eotS);
    static final short[] DFA12_eof = DFA.unpackEncodedString(DFA12_eofS);
    static final char[] DFA12_min = DFA.unpackEncodedStringToUnsignedChars(DFA12_minS);
    static final char[] DFA12_max = DFA.unpackEncodedStringToUnsignedChars(DFA12_maxS);
    static final short[] DFA12_accept = DFA.unpackEncodedString(DFA12_acceptS);
    static final short[] DFA12_special = DFA.unpackEncodedString(DFA12_specialS);
    static final short[][] DFA12_transition;

    static {
        int numStates = DFA12_transitionS.length;
        DFA12_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA12_transition[i] = DFA.unpackEncodedString(DFA12_transitionS[i]);
        }
    }

    class DFA12 extends DFA {

        public DFA12(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 12;
            this.eot = DFA12_eot;
            this.eof = DFA12_eof;
            this.min = DFA12_min;
            this.max = DFA12_max;
            this.accept = DFA12_accept;
            this.special = DFA12_special;
            this.transition = DFA12_transition;
        }
        public String getDescription() {
            return "()* loopback of 453:3: ( (lv_cardinalities_2_0= ruleRelativeCardinalityToUpper ) )*";
        }
    }
 

    public static final BitSet FOLLOW_ruleElement_in_entryRuleElement75 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleElement85 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureModel_in_ruleElement132 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleConfiguration_in_ruleElement159 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleConfiguration_in_entryRuleConfiguration194 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleConfiguration204 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_11_in_ruleConfiguration241 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleConfiguration261 = new BitSet(new long[]{0x0000000000001050L});
    public static final BitSet FOLLOW_12_in_ruleConfiguration274 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_RULE_STRING_in_ruleConfiguration291 = new BitSet(new long[]{0x0000000000001050L});
    public static final BitSet FOLLOW_ruleInstance_in_ruleConfiguration319 = new BitSet(new long[]{0x0000000000003052L});
    public static final BitSet FOLLOW_13_in_ruleConfiguration333 = new BitSet(new long[]{0x0000000000001050L});
    public static final BitSet FOLLOW_ruleInstance_in_ruleConfiguration356 = new BitSet(new long[]{0x0000000000003052L});
    public static final BitSet FOLLOW_ruleInstance_in_entryRuleInstance394 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleInstance404 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_INT_in_ruleInstance446 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleInstance472 = new BitSet(new long[]{0x0000000000004002L});
    public static final BitSet FOLLOW_14_in_ruleInstance485 = new BitSet(new long[]{0x0000000000001050L});
    public static final BitSet FOLLOW_ruleInstance_in_ruleInstance506 = new BitSet(new long[]{0x000000000000B050L});
    public static final BitSet FOLLOW_13_in_ruleInstance520 = new BitSet(new long[]{0x0000000000001050L});
    public static final BitSet FOLLOW_ruleInstance_in_ruleInstance543 = new BitSet(new long[]{0x000000000000B050L});
    public static final BitSet FOLLOW_15_in_ruleInstance557 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureModel_in_entryRuleFeatureModel595 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleFeatureModel605 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeature_in_ruleFeatureModel651 = new BitSet(new long[]{0x0000000000080002L});
    public static final BitSet FOLLOW_ruleConstraint_in_ruleFeatureModel672 = new BitSet(new long[]{0x0000000000080002L});
    public static final BitSet FOLLOW_ruleAbstractFeature_in_entryRuleAbstractFeature709 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleAbstractFeature719 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeature_in_ruleAbstractFeature766 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureGroup_in_ruleAbstractFeature793 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeature_in_entryRuleFeature828 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleFeature838 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleFeature880 = new BitSet(new long[]{0x0000000000094002L});
    public static final BitSet FOLLOW_ruleRelativeCardinalityDirect_in_ruleFeature906 = new BitSet(new long[]{0x0000000000084002L});
    public static final BitSet FOLLOW_ruleRelativeCardinalityToUpper_in_ruleFeature928 = new BitSet(new long[]{0x0000000000084002L});
    public static final BitSet FOLLOW_14_in_ruleFeature942 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ruleAbstractFeature_in_ruleFeature963 = new BitSet(new long[]{0x000000000000A010L});
    public static final BitSet FOLLOW_13_in_ruleFeature977 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ruleAbstractFeature_in_ruleFeature1000 = new BitSet(new long[]{0x000000000000A010L});
    public static final BitSet FOLLOW_15_in_ruleFeature1014 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureGroup_in_entryRuleFeatureGroup1052 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleFeatureGroup1062 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleFeatureGroup1104 = new BitSet(new long[]{0x0000000000090000L});
    public static final BitSet FOLLOW_ruleRelativeCardinalityDirect_in_ruleFeatureGroup1130 = new BitSet(new long[]{0x0000000000090000L});
    public static final BitSet FOLLOW_ruleRelativeCardinalityToUpper_in_ruleFeatureGroup1152 = new BitSet(new long[]{0x0000000000090000L});
    public static final BitSet FOLLOW_ruleGroupCardinality_in_ruleFeatureGroup1174 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_16_in_ruleFeatureGroup1186 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ruleAbstractFeature_in_ruleFeatureGroup1207 = new BitSet(new long[]{0x0000000000020010L});
    public static final BitSet FOLLOW_17_in_ruleFeatureGroup1221 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_ruleAbstractFeature_in_ruleFeatureGroup1244 = new BitSet(new long[]{0x0000000000060010L});
    public static final BitSet FOLLOW_18_in_ruleFeatureGroup1258 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleRelativeCardinalityDirect_in_entryRuleRelativeCardinalityDirect1294 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleRelativeCardinalityDirect1304 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureCardinality_in_ruleRelativeCardinalityDirect1349 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleRelativeCardinalityToUpper_in_entryRuleRelativeCardinalityToUpper1384 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleRelativeCardinalityToUpper1394 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_19_in_ruleRelativeCardinalityToUpper1431 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleRelativeCardinalityToUpper1451 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_20_in_ruleRelativeCardinalityToUpper1463 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_ruleFeatureCardinality_in_ruleRelativeCardinalityToUpper1484 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleGroupCardinality_in_entryRuleGroupCardinality1520 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleGroupCardinality1530 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_19_in_ruleGroupCardinality1567 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_ruleCardinality_in_ruleGroupCardinality1589 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_20_in_ruleGroupCardinality1600 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureCardinality_in_entryRuleFeatureCardinality1636 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleFeatureCardinality1646 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_16_in_ruleFeatureCardinality1683 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_ruleCardinality_in_ruleFeatureCardinality1705 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_18_in_ruleFeatureCardinality1716 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleCardinality_in_entryRuleCardinality1752 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleCardinality1762 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_RULE_INT_in_ruleCardinality1804 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_21_in_ruleCardinality1821 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_RULE_INT_in_ruleCardinality1838 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleConstraint_in_entryRuleConstraint1879 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleConstraint1889 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_19_in_ruleConstraint1926 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleConstraint1946 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_20_in_ruleConstraint1958 = new BitSet(new long[]{0x0000000000810000L});
    public static final BitSet FOLLOW_ruleExpression_in_ruleConstraint1979 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_22_in_ruleConstraint1991 = new BitSet(new long[]{0x0000000000810000L});
    public static final BitSet FOLLOW_ruleExpression_in_ruleConstraint2012 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleConstrainingExpression_in_entryRuleConstrainingExpression2048 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleConstrainingExpression2058 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleFeatureCardinality_in_ruleConstrainingExpression2104 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_23_in_ruleConstrainingExpression2116 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleConstrainingExpression2136 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_13_in_ruleConstrainingExpression2148 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_RULE_ID_in_ruleConstrainingExpression2168 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_24_in_ruleConstrainingExpression2180 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleExpression_in_entryRuleExpression2216 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleExpression2226 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleOrConstrainingExpression_in_ruleExpression2272 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleOrConstrainingExpression_in_entryRuleOrConstrainingExpression2306 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleOrConstrainingExpression2316 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleAndConstrainingExpression_in_ruleOrConstrainingExpression2362 = new BitSet(new long[]{0x0000000000020002L});
    public static final BitSet FOLLOW_17_in_ruleOrConstrainingExpression2375 = new BitSet(new long[]{0x0000000000810000L});
    public static final BitSet FOLLOW_ruleAndConstrainingExpression_in_ruleOrConstrainingExpression2396 = new BitSet(new long[]{0x0000000000020002L});
    public static final BitSet FOLLOW_ruleAndConstrainingExpression_in_entryRuleAndConstrainingExpression2434 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRuleAndConstrainingExpression2444 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_rulePrimary_in_ruleAndConstrainingExpression2490 = new BitSet(new long[]{0x0000000002000002L});
    public static final BitSet FOLLOW_25_in_ruleAndConstrainingExpression2503 = new BitSet(new long[]{0x0000000000810000L});
    public static final BitSet FOLLOW_rulePrimary_in_ruleAndConstrainingExpression2524 = new BitSet(new long[]{0x0000000002000002L});
    public static final BitSet FOLLOW_rulePrimary_in_entryRulePrimary2562 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_entryRulePrimary2572 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ruleConstrainingExpression_in_rulePrimary2619 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_23_in_rulePrimary2637 = new BitSet(new long[]{0x0000000000810000L});
    public static final BitSet FOLLOW_ruleOrConstrainingExpression_in_rulePrimary2659 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_24_in_rulePrimary2670 = new BitSet(new long[]{0x0000000000000002L});

}