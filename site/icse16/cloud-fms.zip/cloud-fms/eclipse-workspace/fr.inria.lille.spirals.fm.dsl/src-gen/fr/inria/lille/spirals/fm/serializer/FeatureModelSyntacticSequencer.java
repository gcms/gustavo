package fr.inria.lille.spirals.fm.serializer;

import com.google.inject.Inject;
import fr.inria.lille.spirals.fm.services.FeatureModelGrammarAccess;
import java.util.List;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.IGrammarAccess;
import org.eclipse.xtext.RuleCall;
import org.eclipse.xtext.nodemodel.INode;
import org.eclipse.xtext.serializer.analysis.GrammarAlias.AbstractElementAlias;
import org.eclipse.xtext.serializer.analysis.GrammarAlias.TokenAlias;
import org.eclipse.xtext.serializer.analysis.ISyntacticSequencerPDAProvider.ISynNavigable;
import org.eclipse.xtext.serializer.analysis.ISyntacticSequencerPDAProvider.ISynTransition;
import org.eclipse.xtext.serializer.sequencer.AbstractSyntacticSequencer;

@SuppressWarnings("all")
public class FeatureModelSyntacticSequencer extends AbstractSyntacticSequencer {

	protected FeatureModelGrammarAccess grammarAccess;
	protected AbstractElementAlias match_Configuration_CommaKeyword_4_0_q;
	protected AbstractElementAlias match_FeatureGroup_VerticalLineKeyword_6_0_q;
	protected AbstractElementAlias match_Feature_CommaKeyword_3_2_0_q;
	protected AbstractElementAlias match_Instance_CommaKeyword_2_2_0_q;
	
	@Inject
	protected void init(IGrammarAccess access) {
		grammarAccess = (FeatureModelGrammarAccess) access;
		match_Configuration_CommaKeyword_4_0_q = new TokenAlias(false, true, grammarAccess.getConfigurationAccess().getCommaKeyword_4_0());
		match_FeatureGroup_VerticalLineKeyword_6_0_q = new TokenAlias(false, true, grammarAccess.getFeatureGroupAccess().getVerticalLineKeyword_6_0());
		match_Feature_CommaKeyword_3_2_0_q = new TokenAlias(false, true, grammarAccess.getFeatureAccess().getCommaKeyword_3_2_0());
		match_Instance_CommaKeyword_2_2_0_q = new TokenAlias(false, true, grammarAccess.getInstanceAccess().getCommaKeyword_2_2_0());
	}
	
	@Override
	protected String getUnassignedRuleCallToken(EObject semanticObject, RuleCall ruleCall, INode node) {
		return "";
	}
	
	
	@Override
	protected void emitUnassignedTokens(EObject semanticObject, ISynTransition transition, INode fromNode, INode toNode) {
		if (transition.getAmbiguousSyntaxes().isEmpty()) return;
		List<INode> transitionNodes = collectNodes(fromNode, toNode);
		for (AbstractElementAlias syntax : transition.getAmbiguousSyntaxes()) {
			List<INode> syntaxNodes = getNodesFor(transitionNodes, syntax);
			if(match_Configuration_CommaKeyword_4_0_q.equals(syntax))
				emit_Configuration_CommaKeyword_4_0_q(semanticObject, getLastNavigableState(), syntaxNodes);
			else if(match_FeatureGroup_VerticalLineKeyword_6_0_q.equals(syntax))
				emit_FeatureGroup_VerticalLineKeyword_6_0_q(semanticObject, getLastNavigableState(), syntaxNodes);
			else if(match_Feature_CommaKeyword_3_2_0_q.equals(syntax))
				emit_Feature_CommaKeyword_3_2_0_q(semanticObject, getLastNavigableState(), syntaxNodes);
			else if(match_Instance_CommaKeyword_2_2_0_q.equals(syntax))
				emit_Instance_CommaKeyword_2_2_0_q(semanticObject, getLastNavigableState(), syntaxNodes);
			else acceptNodes(getLastNavigableState(), syntaxNodes);
		}
	}

	/**
	 * Syntax:
	 *     ','?
	 */
	protected void emit_Configuration_CommaKeyword_4_0_q(EObject semanticObject, ISynNavigable transition, List<INode> nodes) {
		acceptNodes(transition, nodes);
	}
	
	/**
	 * Syntax:
	 *     '|'?
	 */
	protected void emit_FeatureGroup_VerticalLineKeyword_6_0_q(EObject semanticObject, ISynNavigable transition, List<INode> nodes) {
		acceptNodes(transition, nodes);
	}
	
	/**
	 * Syntax:
	 *     ','?
	 */
	protected void emit_Feature_CommaKeyword_3_2_0_q(EObject semanticObject, ISynNavigable transition, List<INode> nodes) {
		acceptNodes(transition, nodes);
	}
	
	/**
	 * Syntax:
	 *     ','?
	 */
	protected void emit_Instance_CommaKeyword_2_2_0_q(EObject semanticObject, ISynNavigable transition, List<INode> nodes) {
		acceptNodes(transition, nodes);
	}
	
}
