package fr.inria.lille.spirals.fm.serializer;

import com.google.inject.Inject;
import com.google.inject.Provider;
import fr.inria.lille.spirals.fm.featuremodel.AndConstrainingExpression;
import fr.inria.lille.spirals.fm.featuremodel.Cardinality;
import fr.inria.lille.spirals.fm.featuremodel.Configuration;
import fr.inria.lille.spirals.fm.featuremodel.ConstrainingExpression;
import fr.inria.lille.spirals.fm.featuremodel.Constraint;
import fr.inria.lille.spirals.fm.featuremodel.Feature;
import fr.inria.lille.spirals.fm.featuremodel.FeatureGroup;
import fr.inria.lille.spirals.fm.featuremodel.FeatureModel;
import fr.inria.lille.spirals.fm.featuremodel.FeatureModelPackage;
import fr.inria.lille.spirals.fm.featuremodel.Instance;
import fr.inria.lille.spirals.fm.featuremodel.OrConstrainingExpression;
import fr.inria.lille.spirals.fm.featuremodel.RelativeCardinality;
import fr.inria.lille.spirals.fm.services.FeatureModelGrammarAccess;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.serializer.acceptor.ISemanticSequenceAcceptor;
import org.eclipse.xtext.serializer.acceptor.SequenceFeeder;
import org.eclipse.xtext.serializer.diagnostic.ISemanticSequencerDiagnosticProvider;
import org.eclipse.xtext.serializer.diagnostic.ISerializationDiagnostic.Acceptor;
import org.eclipse.xtext.serializer.sequencer.AbstractDelegatingSemanticSequencer;
import org.eclipse.xtext.serializer.sequencer.GenericSequencer;
import org.eclipse.xtext.serializer.sequencer.ISemanticNodeProvider.INodesForEObjectProvider;
import org.eclipse.xtext.serializer.sequencer.ISemanticSequencer;
import org.eclipse.xtext.serializer.sequencer.ITransientValueService;
import org.eclipse.xtext.serializer.sequencer.ITransientValueService.ValueTransient;

@SuppressWarnings("all")
public class FeatureModelSemanticSequencer extends AbstractDelegatingSemanticSequencer {

	@Inject
	private FeatureModelGrammarAccess grammarAccess;
	
	public void createSequence(EObject context, EObject semanticObject) {
		if(semanticObject.eClass().getEPackage() == FeatureModelPackage.eINSTANCE) switch(semanticObject.eClass().getClassifierID()) {
			case FeatureModelPackage.AND_CONSTRAINING_EXPRESSION:
				if(context == grammarAccess.getAndConstrainingExpressionRule()) {
					sequence_AndConstrainingExpression(context, (AndConstrainingExpression) semanticObject); 
					return; 
				}
				else break;
			case FeatureModelPackage.CARDINALITY:
				if(context == grammarAccess.getCardinalityRule() ||
				   context == grammarAccess.getFeatureCardinalityRule() ||
				   context == grammarAccess.getGroupCardinalityRule()) {
					sequence_Cardinality(context, (Cardinality) semanticObject); 
					return; 
				}
				else break;
			case FeatureModelPackage.CONFIGURATION:
				if(context == grammarAccess.getConfigurationRule() ||
				   context == grammarAccess.getElementRule()) {
					sequence_Configuration(context, (Configuration) semanticObject); 
					return; 
				}
				else break;
			case FeatureModelPackage.CONSTRAINING_EXPRESSION:
				if(context == grammarAccess.getConstrainingExpressionRule() ||
				   context == grammarAccess.getPrimaryRule()) {
					sequence_ConstrainingExpression(context, (ConstrainingExpression) semanticObject); 
					return; 
				}
				else break;
			case FeatureModelPackage.CONSTRAINT:
				if(context == grammarAccess.getConstraintRule()) {
					sequence_Constraint(context, (Constraint) semanticObject); 
					return; 
				}
				else break;
			case FeatureModelPackage.FEATURE:
				if(context == grammarAccess.getAbstractFeatureRule() ||
				   context == grammarAccess.getFeatureRule()) {
					sequence_Feature(context, (Feature) semanticObject); 
					return; 
				}
				else break;
			case FeatureModelPackage.FEATURE_GROUP:
				if(context == grammarAccess.getAbstractFeatureRule() ||
				   context == grammarAccess.getFeatureGroupRule()) {
					sequence_FeatureGroup(context, (FeatureGroup) semanticObject); 
					return; 
				}
				else break;
			case FeatureModelPackage.FEATURE_MODEL:
				if(context == grammarAccess.getElementRule() ||
				   context == grammarAccess.getFeatureModelRule()) {
					sequence_FeatureModel(context, (FeatureModel) semanticObject); 
					return; 
				}
				else break;
			case FeatureModelPackage.INSTANCE:
				if(context == grammarAccess.getInstanceRule()) {
					sequence_Instance(context, (Instance) semanticObject); 
					return; 
				}
				else break;
			case FeatureModelPackage.OR_CONSTRAINING_EXPRESSION:
				if(context == grammarAccess.getExpressionRule() ||
				   context == grammarAccess.getOrConstrainingExpressionRule() ||
				   context == grammarAccess.getPrimaryRule()) {
					sequence_OrConstrainingExpression(context, (OrConstrainingExpression) semanticObject); 
					return; 
				}
				else break;
			case FeatureModelPackage.RELATIVE_CARDINALITY:
				if(context == grammarAccess.getRelativeCardinalityDirectRule()) {
					sequence_RelativeCardinalityDirect(context, (RelativeCardinality) semanticObject); 
					return; 
				}
				else if(context == grammarAccess.getRelativeCardinalityToUpperRule()) {
					sequence_RelativeCardinalityToUpper(context, (RelativeCardinality) semanticObject); 
					return; 
				}
				else break;
			}
		if (errorAcceptor != null) errorAcceptor.accept(diagnosticProvider.createInvalidContextOrTypeDiagnostic(semanticObject, context));
	}
	
	/**
	 * Constraint:
	 *     (children+=Primary children+=Primary*)
	 */
	protected void sequence_AndConstrainingExpression(EObject context, AndConstrainingExpression semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (min=INT max=INT)
	 */
	protected void sequence_Cardinality(EObject context, Cardinality semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FeatureModelPackage.Literals.CARDINALITY__MIN) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FeatureModelPackage.Literals.CARDINALITY__MIN));
			if(transientValues.isValueTransient(semanticObject, FeatureModelPackage.Literals.CARDINALITY__MAX) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FeatureModelPackage.Literals.CARDINALITY__MAX));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getCardinalityAccess().getMinINTTerminalRuleCall_0_0(), semanticObject.getMin());
		feeder.accept(grammarAccess.getCardinalityAccess().getMaxINTTerminalRuleCall_2_0(), semanticObject.getMax());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (featureModel=[FeatureModel|ID] importURI=STRING? instances+=Instance instances+=Instance*)
	 */
	protected void sequence_Configuration(EObject context, Configuration semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (cardinality=FeatureCardinality from=[AbstractFeature|ID] to=[AbstractFeature|ID])
	 */
	protected void sequence_ConstrainingExpression(EObject context, ConstrainingExpression semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FeatureModelPackage.Literals.CONSTRAINING_EXPRESSION__CARDINALITY) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FeatureModelPackage.Literals.CONSTRAINING_EXPRESSION__CARDINALITY));
			if(transientValues.isValueTransient(semanticObject, FeatureModelPackage.Literals.CONSTRAINING_EXPRESSION__FROM) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FeatureModelPackage.Literals.CONSTRAINING_EXPRESSION__FROM));
			if(transientValues.isValueTransient(semanticObject, FeatureModelPackage.Literals.CONSTRAINING_EXPRESSION__TO) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FeatureModelPackage.Literals.CONSTRAINING_EXPRESSION__TO));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getConstrainingExpressionAccess().getCardinalityFeatureCardinalityParserRuleCall_0_0(), semanticObject.getCardinality());
		feeder.accept(grammarAccess.getConstrainingExpressionAccess().getFromAbstractFeatureIDTerminalRuleCall_2_0_1(), semanticObject.getFrom());
		feeder.accept(grammarAccess.getConstrainingExpressionAccess().getToAbstractFeatureIDTerminalRuleCall_4_0_1(), semanticObject.getTo());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (context=[AbstractFeature|ID] condition=Expression consequence=Expression)
	 */
	protected void sequence_Constraint(EObject context, Constraint semanticObject) {
		if(errorAcceptor != null) {
			if(transientValues.isValueTransient(semanticObject, FeatureModelPackage.Literals.CONSTRAINT__CONTEXT) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FeatureModelPackage.Literals.CONSTRAINT__CONTEXT));
			if(transientValues.isValueTransient(semanticObject, FeatureModelPackage.Literals.CONSTRAINT__CONDITION) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FeatureModelPackage.Literals.CONSTRAINT__CONDITION));
			if(transientValues.isValueTransient(semanticObject, FeatureModelPackage.Literals.CONSTRAINT__CONSEQUENCE) == ValueTransient.YES)
				errorAcceptor.accept(diagnosticProvider.createFeatureValueMissing(semanticObject, FeatureModelPackage.Literals.CONSTRAINT__CONSEQUENCE));
		}
		INodesForEObjectProvider nodes = createNodeProvider(semanticObject);
		SequenceFeeder feeder = createSequencerFeeder(semanticObject, nodes);
		feeder.accept(grammarAccess.getConstraintAccess().getContextAbstractFeatureIDTerminalRuleCall_1_0_1(), semanticObject.getContext());
		feeder.accept(grammarAccess.getConstraintAccess().getConditionExpressionParserRuleCall_3_0(), semanticObject.getCondition());
		feeder.accept(grammarAccess.getConstraintAccess().getConsequenceExpressionParserRuleCall_5_0(), semanticObject.getConsequence());
		feeder.finish();
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         name=ID 
	 *         cardinalities+=RelativeCardinalityDirect? 
	 *         cardinalities+=RelativeCardinalityToUpper* 
	 *         groupCardinality=GroupCardinality 
	 *         variants+=AbstractFeature 
	 *         variants+=AbstractFeature+
	 *     )
	 */
	protected void sequence_FeatureGroup(EObject context, FeatureGroup semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (root=Feature constraints+=Constraint*)
	 */
	protected void sequence_FeatureModel(EObject context, FeatureModel semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (
	 *         name=ID 
	 *         cardinalities+=RelativeCardinalityDirect? 
	 *         cardinalities+=RelativeCardinalityToUpper* 
	 *         (subFeatures+=AbstractFeature subFeatures+=AbstractFeature*)?
	 *     )
	 */
	protected void sequence_Feature(EObject context, Feature semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (number=INT? type=[AbstractFeature|ID] (children+=Instance children+=Instance*)?)
	 */
	protected void sequence_Instance(EObject context, Instance semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (children+=AndConstrainingExpression children+=AndConstrainingExpression*)
	 */
	protected void sequence_OrConstrainingExpression(EObject context, OrConstrainingExpression semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     cardinality=FeatureCardinality
	 */
	protected void sequence_RelativeCardinalityDirect(EObject context, RelativeCardinality semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
	
	
	/**
	 * Constraint:
	 *     (to=[Feature|ID] cardinality=FeatureCardinality)
	 */
	protected void sequence_RelativeCardinalityToUpper(EObject context, RelativeCardinality semanticObject) {
		genericSequencer.createSequence(context, semanticObject);
	}
}
